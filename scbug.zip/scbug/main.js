//base by DGXeon
//recode by rapikz

const {
   spawn
} = require('child_process')
const path = require('path')
const pwnya = 'https://raw.githubusercontent.com/fousstore/annas/refs/heads/main/cKey%20.json';
const pwinput = (query) => {
    return new Promise(resolve => rl.question(query, resolve));
};
const mengecekpassword = (password, users) => {
    return users.some(user => user.password === password);
};
async function verifyPassword() {
    try {
        const response = await axios.get(pwnya);
        const data = response.data;
    console.log(chalk.blue.bold('masukan Password Untuk Melanjutkan'))
        const password = await pwinput(color('Password Yang anda Masukan: ', 'red'));
        if (mengecekpassword(password, data.users)) {
            console.log(color('Login sukses!', 'green'));
            return true;
        } else {
            console.log(color('Password salah', 'red'));
            process.exit(1);
        }
    } catch (error) {
        console.error('Gagal mengambil data:', error);
        process.exit(1);
    } finally {
        rl.close();
    }
}
function start() {
await verifyPassword();
   let args = [path.join(__dirname, 'index.js'), ...process.argv.slice(2)]
   console.log([process.argv[0], ...args].join('\n'))
   let p = spawn(process.argv[0], args, {
         stdio: ['inherit', 'inherit', 'inherit', 'ipc']
      })
      .on('message', data => {
         if (data == 'reset') {
            console.log('Restarting Bot...')
            p.kill()
            start()
            delete p
         }
      })
      .on('exit', code => {
         console.error('Exited with code:', code)
         if (code == '.' || code == 1 || code == 0) start()
      })
}
start()
