/*

# Base By Devorsixcore
# Recode By Kizyy Kanaeru
# Owner ? : t.me/hir4izuu
# GitHub ? : Hiraizuu
!- do not delete this credit

*/

global.prefa = ['.']
global.owner = ['15822072443']
global.ownMain = '15822072443'
global.NamaOwner = 'ꓘizyy - Kanaeru' //gausah diganti
global.sessionName = 'sessionnya'
global.connect = true // Ubah Ke False Jika Ingin Menggunakan Qr Code
global.namabot = 'TrashDex - Execution' //ganti aj klo mau
global.author = 'ꓘizyy - Kanaeru' //ganti aj klo mau
global.packname = 'TdX - Master' //ganti aj klo mau
global.url1 = 'https://www.instagram.com/hir4izuu' //gausah diganti
global.url2 = 'https://whatsapp.com/channel/0029VaimTyuHFxPAMGteH52e' //gausah diganti
global.linkgc = 'https://chat.whatsapp.com/Jr9Sll6K8TjAx6HyWBQX2d'
global.delayjpm = 3500

global.mess = { // Custom Sesuka Lu
ingroup: 'This feature can only be used in groups',
admin: 'This feature is specifically for group admins',
notadmin: "The bot must be an admin first",
owner: 'You are not the owner',
premium: 'You are not a premium user',
seller: 'This feature can only be used by resellers and owners',
usingsetpp: `Setpp can only be used by the owner, do you think I'm stupid?`,
wait: '*Waiting for processing*',
success: 'Success Bwang',
bugrespon: `Processs...⏳`
}

global.nick = { // Custom Sesuka Lu
aaa: "⭑̤⟅̊༑ 𝐓͜͡𝐝͜𝐗͡🚯⃟ꢵ 𝐓͜͡𝐑͡𝚫͜͡𝐒͜𑪋͜͝𝐇͡ 𝐃͜𝐢͡𝐕͜𝐢͡𝐒͜𝐢𝐎͜͡𝐍͡  ༑̴⟆̊⿻‏‎‏‎‏‎‏",
bbb: "🦠̂⃟꙳͙͡༑ᐧ ᛕ꠸ƺꪗꪗ ᛕꪖꪀꪖꫀ᥅ꪊ - 𝐓𝐝𝐗 ᐧ ༑꙳͆⃟💚̺⃰",
ccc: "🥡⃟ ̊ ̥ ༚𐨁ᛕ꠸ƺꪗꪗ ᛕꪖꪀꪖꫀ᥅ꪊ ̥ ̊ ༚🍚⃰ꢵ⭑𝐓𝐫𝐚𝐬𝐡𝐃𝐞𝐱 𝂼઼🔪͜🍽️⃰🔪͜★ 𝐓͙͡𝐝͢𝐗͙ ꢵ ✩ ‌‌‌‌‌‌‌‌‌‌‌",
ddd: "🚫⃰͜͡⭑𝐓𝐝͢𝐗⭑͜͡🚫⃰",
eee: "*💤⃰ᛕ꠸ƺꪗꪗ ᛕꪖꪀꪖꫀ᥅ꪊ༏"
}

global.autOwn = 'req(62-8S57547ms11).287p'
let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
	require('fs').unwatchFile(file)
	console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
	delete require.cache[file]
	require(file)
})