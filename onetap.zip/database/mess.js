require("./global")

const mess = {
   wait: "`ᴘʀᴏsᴇs ᴀɴᴊɢ`",
   success: "`ʙᴇʀʜᴀsɪʟ ᴄᴏᴋ`",
   on: "*`[ On Feature ]` - Sudah Aktif*", 
   off: "*`[ Off Feature ]` - Sudah Off*",
   query: {
       text: "`ᴛᴇᴋsɴʏᴀ ᴍᴀɴᴀ ᴀɴᴊɢ`",
       link: "`ʟɪɴᴋɴʏᴀ ᴍᴀɴᴀ ᴀɴᴊɢ`",
   },
   error: {
       fitur: "`ᴇʀᴏʀʀ ᴄᴏᴋ, ʙᴜʀᴜᴀɴ ᴄʜᴀᴛ ᴅʀᴀʏ ʙɪᴀʀ ᴅɪᴘᴇʀʙᴀɪᴋɪ`",
   },
   only: {
       group: "`ғɪᴛᴜʀ ᴋʜᴜsᴜs ɢʀᴜᴘ`",
       private: "`ғɪᴛᴜʀ ᴋʜᴜsᴜs ᴘʀɪᴠᴀᴛᴇ ᴄʜᴀᴛ`",
       owner: "`ʟᴜ sɪᴀᴘᴀ ᴋᴏɴᴛᴏʟ`",
       admin: "`ғɪᴛᴜʀ ᴋʜᴜsᴜs ᴀᴅᴍɪɴ`",
       badmin: "`ᴊᴀᴅɪɪɴ ɢᴡ ᴀᴅᴍɪɴ ᴅʟᴜ ᴛᴏʟᴏʟ`",
       premium: "`ғɪᴛᴜʀ ᴋʜᴜsᴜs ᴍᴜʀʙᴜɢ, ɪɴɢɪɴ ᴊᴏɪɴ ᴍᴜʀʙᴜɢ? ᴄʜᴀᴛ ᴏᴡɴᴇʀ ᴅᴇɴɢᴀɴ ᴋᴇᴛɪᴋ .ᴏᴡɴᴇʀ`",
   }
}

global.mess = mess

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})